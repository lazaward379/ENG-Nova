import { useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, Modal, useApp, useLoad, when } from '../ui';

const PARAM_HINT: Record<string, string> = {
  'reg.room_min_area': '{ "min_area_m2": 9, "room_name_pattern": "BEDROOM|غرفة نوم" }',
  'reg.plot_coverage': '{ "max_coverage_pct": 60 }   (or {} to use the confirmed project fact max_plot_coverage_pct)',
  'reg.setback_uniform': '{ "min_setback_m": 3 }',
};

export function Regulatory() {
  const { can, toast } = useApp();
  const { t } = useT();
  const [tab, setTab] = useState('rules');
  const sources = useLoad(() => api.get('/api/regulatory/sources'), []);
  const rules = useLoad(() => api.get('/api/regulatory/rules'), []);
  const [addSource, setAddSource] = useState(false);
  const [verifySrc, setVerifySrc] = useState<any | null>(null);
  const [versionFor, setVersionFor] = useState<any | null>(null);
  const [historyFor, setHistoryFor] = useState<string | null>(null);

  return (
    <div className="stack">
      <div className="page-h">
        <div><h1>{t('nav.regulatory', 'Regulatory source library')}</h1><div className="sub">Official sources, versioned rules, reviewer verification.</div></div>
        <span className="spacer" />
        {can('reviewer') && <button className="btn primary" onClick={() => setAddSource(true)}><Icon name="plus" />{t('reg.addSource', 'Register source')}</button>}
      </div>
      <div className="notice">
        <b>No Abu Dhabi regulation is pre-loaded as verified.</b> NOVA ships rule <i>templates</i> with deterministic logic but no thresholds. A reviewer must register the official
        document (DMT, municipality, Civil Defence, utility provider, or client manual), attest that it was checked, and enter the clause and parameter. Every verification creates a new
        immutable rule version; earlier reports remain reproducible against the version they used.
      </div>
      <div className="tabs">{[['rules', t('reg.rules', 'Rules')], ['sources', t('reg.sources', 'Sources')]].map(([k, l]) => <button key={k} className={`tab ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</button>)}</div>

      {tab === 'rules' && (rules.data ? (
        <div className="card table-wrap"><table className="t">
          <thead><tr><th>Code</th><th>Rule</th><th>Category</th><th>Version</th><th>Source</th><th>Parameters</th><th /></tr></thead>
          <tbody>{rules.data.map((r: any) => (
            <tr key={r.code}>
              <td className="mono ltr">{r.code}</td>
              <td><div>{r.title}</div><div className="faint" dir="rtl">{r.title_ar}</div><div className="faint">{r.interpretation}</div></td>
              <td><span className="chip">{r.category}</span></td>
              <td><span className={`chip ${r.version_status === 'verified' ? 'c-confirmed' : r.version_status === 'internal' ? '' : 'c-unresolved'}`}>v{r.version} {r.version_status}</span>
                {r.reviewer_name && <div className="faint">{r.reviewer_name} · {when(r.reviewed_at)}</div>}</td>
              <td>{r.source_title ? <><div>{r.source_authority}</div><div className="faint">{r.source_title} · {r.clause}</div><span className={`chip ${r.source_status === 'verified' ? 'c-confirmed' : 'c-assumption'}`}>{r.source_status}</span></> : <span className="faint">{r.category === 'drawing_qa' ? 'internal convention' : 'none — SOURCE NOT VERIFIED'}</span>}</td>
              <td className="mono ltr" style={{ fontSize: 11.5 }}>{JSON.stringify(r.params)}</td>
              <td style={{ whiteSpace: 'nowrap' }}>
                <button className="btn sm ghost" onClick={() => setHistoryFor(r.code)}>History</button>
                {r.category === 'regulatory' && can('reviewer') && <button className="btn sm" onClick={() => setVersionFor(r)}>{t('reg.newVersion', 'New verified version')}</button>}
              </td>
            </tr>))}</tbody></table></div>
      ) : <Loading error={rules.error} loading={rules.loading} />)}

      {tab === 'sources' && (sources.data ? (
        sources.data.length ? <div className="card table-wrap"><table className="t">
          <thead><tr><th>{t('reg.authority', 'Authority')}</th><th>{t('reg.title', 'Title')}</th><th>Ref / revision</th><th>Dates</th><th>Status</th><th /></tr></thead>
          <tbody>{sources.data.map((s: any) => (
            <tr key={s.id}>
              <td>{s.authority}</td>
              <td><div>{s.title}</div>{s.url && <a className="faint ltr" href={s.url} target="_blank" rel="noreferrer noopener">{s.url}</a>}<div className="faint" style={{ whiteSpace: 'pre-wrap' }}>{s.access_notes}</div></td>
              <td className="mono">{s.document_ref} {s.revision}</td>
              <td className="faint">pub {s.publication_date ?? '—'}<br />eff {s.effective_date ?? '—'}<br />ret {s.retrieved_at ?? '—'}</td>
              <td><span className={`chip ${s.verification_status === 'verified' ? 'c-confirmed' : s.verification_status === 'test_only' ? 'c-assumption' : 'c-unresolved'}`}>{s.verification_status}</span>
                {s.verified_by_name && <div className="faint">{s.verified_by_name}</div>}</td>
              <td style={{ whiteSpace: 'nowrap' }}>
                {!s.org_id && <div className="faint">NOVA catalogue</div>}
                {!s.org_id && can('reviewer') && <button className="btn sm" title="Copy into your organisation so a reviewer can verify it" onClick={async () => {
                  try { const r = await api.post(`/api/regulatory/sources/${s.id}/adopt`); toast(r.existing ? 'Already adopted' : 'Adopted — now verify your copy', 'ok'); sources.reload(); } catch (e: any) { toast(e.message, 'error'); }
                }}>Adopt</button>}
                {s.org_id && s.verification_status === 'unverified' && can('reviewer') && <button className="btn sm" onClick={() => setVerifySrc(s)}>{t('reg.verify', 'Verify')}</button>}
              </td>
            </tr>))}</tbody></table></div>
          : <div className="card empty">No sources registered yet.</div>
      ) : <Loading error={sources.error} loading={sources.loading} />)}

      {addSource && <SourceModal onClose={() => setAddSource(false)} onDone={() => { setAddSource(false); sources.reload(); setTab('sources'); }} />}
      {verifySrc && <VerifyModal s={verifySrc} onClose={() => setVerifySrc(null)} onDone={() => { setVerifySrc(null); sources.reload(); }} />}
      {versionFor && <VersionModal rule={versionFor} sources={(sources.data ?? []).filter((s: any) => s.verification_status !== 'unverified')} onClose={() => setVersionFor(null)} onDone={() => { setVersionFor(null); rules.reload(); }} />}
      {historyFor && <HistoryModal code={historyFor} onClose={() => setHistoryFor(null)} />}
    </div>
  );
}

function SourceModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState<any>({ authority: '', title: '', document_ref: '', url: '', revision: '', publication_date: '', effective_date: '', retrieved_at: '', applicability: '', access_notes: '' });
  const [err, setErr] = useState<string | null>(null);
  const field = (k: string, label: string, type = 'text') => <label className="field">{label}<input type={type} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} dir={k === 'url' ? 'ltr' : 'auto'} /></label>;
  const save = async () => {
    const body = Object.fromEntries(Object.entries(f).map(([k, v]) => [k, k.endsWith('_date') || k === 'retrieved_at' ? (v || null) : v]));
    try { await api.post('/api/regulatory/sources', body); onDone(); } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title="Register regulatory source" onClose={onClose}>
      <div className="stack">
        {field('authority', 'Authority (e.g. Department of Municipalities and Transport)')}{field('title', 'Official title')}
        <div className="grid c2">{field('document_ref', 'Document identifier')}{field('revision', 'Revision')}</div>
        {field('url', 'Official URL')}
        <div className="grid c3">{field('publication_date', 'Publication date', 'date')}{field('effective_date', 'Effective date', 'date')}{field('retrieved_at', 'Retrieved', 'date')}</div>
        {field('applicability', 'Applicability')}{field('access_notes', 'Access & licensing notes')}
        {err && <div className="notice">{err}</div>}
        <div className="row end"><button className="btn primary" disabled={!f.authority || !f.title} onClick={save}>Register (unverified)</button></div>
      </div>
    </Modal>
  );
}

function VerifyModal({ s, onClose, onDone }: { s: any; onClose: () => void; onDone: () => void }) {
  const [status, setStatus] = useState('verified');
  const [att, setAtt] = useState('');
  const [err, setErr] = useState<string | null>(null);
  return (
    <Modal title={`Verify: ${s.title}`} onClose={onClose}>
      <div className="stack">
        <div className="notice">By verifying you attest that you checked this document against the official publication, and that it is current for the stated applicability. This is recorded with your name.</div>
        <label className="field">Status<select value={status} onChange={(e) => setStatus(e.target.value)}><option value="verified">verified — official document checked</option><option value="test_only">test_only — fixture, not a regulation</option></select></label>
        <label className="field">Attestation<textarea value={att} onChange={(e) => setAtt(e.target.value)} placeholder="What you checked, where, and when" /></label>
        {err && <div className="notice">{err}</div>}
        <div className="row end"><button className="btn primary" disabled={att.trim().length < 10} onClick={async () => { try { await api.post(`/api/regulatory/sources/${s.id}/verify`, { status, attestation: att }); onDone(); } catch (e: any) { setErr(e.message); } }}>Record verification</button></div>
      </div>
    </Modal>
  );
}

function VersionModal({ rule, sources, onClose, onDone }: { rule: any; sources: any[]; onClose: () => void; onDone: () => void }) {
  const { t } = useT();
  const [f, setF] = useState({ source_id: '', clause: '', quotation: '', interpretation: rule.interpretation, params: '{}', effective_date: '' });
  const [err, setErr] = useState<string | null>(null);
  const save = async () => {
    let params: any;
    try { params = JSON.parse(f.params); } catch { setErr('Parameters must be valid JSON'); return; }
    try { await api.post(`/api/regulatory/rules/${rule.code}/versions`, { ...f, params, effective_date: f.effective_date || null }); onDone(); } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={`${t('reg.newVersion', 'New verified version')}: ${rule.code}`} onClose={onClose}>
      <div className="stack">
        {!sources.length && <div className="notice">Register and verify a source first.</div>}
        <label className="field">Source<select value={f.source_id} onChange={(e) => setF({ ...f, source_id: e.target.value })}><option value="">—</option>{sources.map((s) => <option key={s.id} value={s.id}>{s.authority} — {s.title} ({s.verification_status})</option>)}</select></label>
        <label className="field">{t('reg.clause', 'Clause / page')}<input value={f.clause} onChange={(e) => setF({ ...f, clause: e.target.value })} /></label>
        <label className="field">{t('reg.quotation', 'Exact quotation (where permitted)')}<textarea value={f.quotation} onChange={(e) => setF({ ...f, quotation: e.target.value })} dir="auto" /></label>
        <label className="field">{t('reg.interpretation', 'Software interpretation')}<textarea value={f.interpretation} onChange={(e) => setF({ ...f, interpretation: e.target.value })} /></label>
        <label className="field">{t('reg.params', 'Parameters (JSON)')}<input className="mono" dir="ltr" value={f.params} onChange={(e) => setF({ ...f, params: e.target.value })} /><span className="faint mono ltr">{PARAM_HINT[rule.evaluator]}</span></label>
        <label className="field">Effective date<input type="date" value={f.effective_date} onChange={(e) => setF({ ...f, effective_date: e.target.value })} /></label>
        {err && <div className="notice">{err}</div>}
        <div className="row end"><button className="btn primary" disabled={!f.source_id || !f.clause} onClick={save}>Create verified version</button></div>
      </div>
    </Modal>
  );
}

function HistoryModal({ code, onClose }: { code: string; onClose: () => void }) {
  const v = useLoad(() => api.get(`/api/regulatory/rules/${code}/versions`), [code]);
  return (
    <Modal title={`${code} — versions`} onClose={onClose}>
      {v.data ? v.data.map((x: any) => (
        <div key={x.id} className="card" style={{ padding: 10, marginBottom: 8 }}>
          <div className="row"><b>v{x.version}</b><span className="chip">{x.status}</span><span className="faint">{x.org_id ? 'organisation' : 'global template'}</span></div>
          <div className="faint">{x.source_authority} {x.source_title} {x.clause}</div>
          <div style={{ fontSize: 13 }}>{x.interpretation}</div>
          <div className="mono ltr faint">{JSON.stringify(x.params)}</div>
          {x.reviewer_name && <div className="faint">reviewed by {x.reviewer_name} · {when(x.reviewed_at)}</div>}
        </div>
      )) : <Loading error={v.error} loading={v.loading} />}
    </Modal>
  );
}
