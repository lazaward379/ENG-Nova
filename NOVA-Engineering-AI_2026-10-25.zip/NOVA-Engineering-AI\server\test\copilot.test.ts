import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseInstruction } from '../src/copilot/ruleParser.ts';

const sel = { units: 'mm', selectionCount: 1, selectionTypes: { LINE: 1 }, entityCount: 10, layers: [] };
const none = { ...sel, selectionCount: 0 };

const cases: [string, Partial<ReturnType<typeof parseInstruction>>][] = [
  ['Move this door 200 mm to the left', { intent: 'operation', operation: 'move', dx_mm: -200, dy_mm: 0 }],
  ['move selected 1.5 m up', { intent: 'operation', operation: 'move', dx_mm: 0, dy_mm: 1500 }],
  ['انقل الباب 200 مم لليسار', { intent: 'operation', operation: 'move', dx_mm: -200, dy_mm: 0 }],
  ['حرّك العنصر ٣٠٠ ملم للأعلى', { intent: 'operation', operation: 'move', dx_mm: 0, dy_mm: 300 }],
  ['copy by 100, -50 mm', { intent: 'operation', operation: 'copy', dx_mm: 100, dy_mm: -50 }],
  ['rotate 90 degrees clockwise', { intent: 'operation', operation: 'rotate', angle_deg: -90 }],
  ['دوّر ٤٥ درجة', { intent: 'operation', operation: 'rotate', angle_deg: 45 }],
  ['mirror vertically', { intent: 'operation', operation: 'mirror_vertical' }],
  ['delete it', { intent: 'operation', operation: 'delete' }],
  ['Calculate the area of each room', { intent: 'query', query: 'room_areas' }],
  ['احسب مساحة الغرف', { intent: 'query', query: 'room_areas' }],
  ['Show all unresolved compliance checks', { intent: 'query', query: 'list_issues' }],
  ['run checks', { intent: 'query', query: 'run_checks' }],
];

for (const [text, expected] of cases) {
  test(`parses: ${text}`, () => {
    const r = parseInstruction(text, sel);
    for (const [k, v] of Object.entries(expected)) assert.deepEqual((r as any)[k], v, `${k} for "${text}"`);
  });
}

test('a distance without a unit is a question, not an assumption', () => {
  const r = parseInstruction('move 200 left', sel);
  assert.equal(r.intent, 'clarify');
  assert.match(r.questions[0], /unit/i);
});

test('missing direction asks for direction', () => {
  assert.equal(parseInstruction('move 200 mm', sel).intent, 'clarify');
});

test('an operation with nothing selected asks the user to select (Arabic reply for Arabic input)', () => {
  const r = parseInstruction('احذف', none);
  assert.equal(r.intent, 'clarify');
  assert.match(r.questions[0], /حدد/);
});

test('requirement hints from English and Arabic descriptions', async () => {
  const { suggestRequirements } = await import('../src/copilot/requirements.ts');
  const en = Object.fromEntries(suggestRequirements('Design a two-storey residential villa with a separate majlis, parking, three bedrooms on the upper floor, and a landscaped outdoor area.').map((s) => [s.key, s.value]));
  assert.equal(en.floors, '2');
  assert.equal(en.bedrooms, '3');
  assert.equal(en.space_majlis, 'required');
  assert.equal(en.space_parking, 'required');
  const ar = Object.fromEntries(suggestRequirements('فيلا سكنية من طابقين مع مجلس منفصل وثلاث غرف نوم في الطابق العلوي ومواقف').map((s) => [s.key, s.value]));
  assert.equal(ar.floors, '2');
  assert.equal(ar.space_majlis, 'required');
  assert.equal(ar.building_type, 'residential villa');
});

test('design generation is reported as unsupported offline', () => {
  assert.equal(parseInstruction('Design a two-storey villa with a majlis', sel).intent, 'unsupported');
});
