import type { Entity, Pt } from '../api';

export type BBox = { minX: number; minY: number; maxX: number; maxY: number };
/** World → screen: sx = (x - ox) * scale, sy = height - (y - oy) * scale (world Y points up). */
export type View = { ox: number; oy: number; scale: number; width: number; height: number };

export const toScreen = (v: View, p: Pt): Pt => ({ x: (p.x - v.ox) * v.scale, y: v.height - (p.y - v.oy) * v.scale });
export const toWorld = (v: View, sx: number, sy: number): Pt => ({ x: sx / v.scale + v.ox, y: (v.height - sy) / v.scale + v.oy });

const rad = (d: number) => (d * Math.PI) / 180;
const norm = (a: number) => ((a % 360) + 360) % 360;
export const arcPt = (c: Pt, r: number, a: number): Pt => ({ x: c.x + r * Math.cos(rad(a)), y: c.y + r * Math.sin(rad(a)) });
function inArc(a: number, s: number, e: number) { s = norm(s); e = norm(e); a = norm(a); return s <= e ? a >= s && a <= e : a >= s || a <= e; }

// ---- typed architectural elements (mirrors server/src/geometry/hosted.ts) ----
export function wallFrame(g: { a: Pt; b: Pt }) {
  const len = Math.hypot(g.b.x - g.a.x, g.b.y - g.a.y);
  const dir = len ? { x: (g.b.x - g.a.x) / len, y: (g.b.y - g.a.y) / len } : { x: 1, y: 0 };
  return { len, dir, normal: { x: -dir.y, y: dir.x } };
}
export function wallOutline(g: { a: Pt; b: Pt; thickness: number }): Pt[] {
  const { normal: n } = wallFrame(g), h = g.thickness / 2;
  return [{ x: g.a.x + n.x * h, y: g.a.y + n.y * h }, { x: g.b.x + n.x * h, y: g.b.y + n.y * h }, { x: g.b.x - n.x * h, y: g.b.y - n.y * h }, { x: g.a.x - n.x * h, y: g.a.y - n.y * h }];
}
export function doorParts(g: any) {
  const p = g.p, d = g.dir, sgn = g.swing === 'right' ? 1 : -1, side = g.side ?? 1;
  const hinge = { x: p.x + sgn * d.x * g.width / 2, y: p.y + sgn * d.y * g.width / 2 };
  const tip = { x: hinge.x - d.y * side * g.width, y: hinge.y + d.x * side * g.width };
  const closed = { x: p.x - sgn * d.x * g.width / 2, y: p.y - sgn * d.y * g.width / 2 };
  const ang = (q: Pt) => (Math.atan2(q.y - hinge.y, q.x - hinge.x) * 180) / Math.PI;
  let start = ang(closed), end = ang(tip);
  if ((((end - start) % 360) + 360) % 360 > 180) [start, end] = [end, start];
  return { hinge, tip, closed, start, end };
}
const openingEnds = (g: any): [Pt, Pt] => [{ x: g.p.x - g.dir.x * g.width / 2, y: g.p.y - g.dir.y * g.width / 2 }, { x: g.p.x + g.dir.x * g.width / 2, y: g.p.y + g.dir.y * g.width / 2 }];
/** Project a point onto a wall: offset along the wall and perpendicular distance. */
export function projectOnWall(w: { a: Pt; b: Pt }, p: Pt) {
  const { dir, len } = wallFrame(w);
  const offset = (p.x - w.a.x) * dir.x + (p.y - w.a.y) * dir.y;
  const perp = Math.abs(-(p.x - w.a.x) * dir.y + (p.y - w.a.y) * dir.x);
  return { offset, perp, len };
}

export function entityBBox(e: Entity): BBox {
  const g = e.geom;
  let pts: Pt[];
  switch (e.type) {
    case 'WALL': pts = wallOutline(g); break;
    case 'DOOR': { const k = doorParts(g); pts = [k.hinge, k.tip, k.closed, { x: k.hinge.x + (k.tip.x - k.hinge.x) + (k.closed.x - k.hinge.x), y: k.hinge.y + (k.tip.y - k.hinge.y) + (k.closed.y - k.hinge.y) }]; break; }
    case 'WINDOW': pts = openingEnds(g); break;
    case 'LINE': pts = [g.a, g.b]; break;
    case 'POLYLINE': pts = g.points; break;
    case 'CIRCLE': return { minX: g.c.x - g.r, minY: g.c.y - g.r, maxX: g.c.x + g.r, maxY: g.c.y + g.r };
    case 'ARC': pts = [arcPt(g.c, g.r, g.start), arcPt(g.c, g.r, g.end), ...[0, 90, 180, 270].filter((q) => inArc(q, g.start, g.end)).map((q) => arcPt(g.c, g.r, q))]; break;
    case 'TEXT': {
      const w = g.h * 0.6 * Math.max(1, g.text.length);
      return { minX: g.p.x, minY: g.p.y, maxX: g.p.x + w, maxY: g.p.y + g.h };
    }
    default: pts = [g.p];
  }
  let b = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
  for (const p of pts) b = { minX: Math.min(b.minX, p.x), minY: Math.min(b.minY, p.y), maxX: Math.max(b.maxX, p.x), maxY: Math.max(b.maxY, p.y) };
  return b;
}

export function unionBBox(bs: BBox[]): BBox | null {
  if (!bs.length) return null;
  return bs.reduce((a, b) => ({ minX: Math.min(a.minX, b.minX), minY: Math.min(a.minY, b.minY), maxX: Math.max(a.maxX, b.maxX), maxY: Math.max(a.maxY, b.maxY) }));
}

/** Uniform-grid spatial index over entity bounding boxes. */
export class SpatialIndex {
  private cells = new Map<string, number[]>();
  private size: number;
  readonly boxes: BBox[];
  readonly entities: Entity[];
  constructor(entities: Entity[]) {
    this.entities = entities;
    this.boxes = entities.map(entityBBox);
    const ext = unionBBox(this.boxes) ?? { minX: 0, minY: 0, maxX: 1, maxY: 1 };
    this.size = Math.max(ext.maxX - ext.minX, ext.maxY - ext.minY, 1e-6) / 64;
    this.boxes.forEach((b, i) => {
      const [x0, y0, x1, y1] = this.range(b);
      if ((x1 - x0 + 1) * (y1 - y0 + 1) > 4096) { this.push('big', i); return; } // huge entities live in one bucket
      for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) this.push(`${x},${y}`, i);
    });
  }
  private push(k: string, i: number) { const c = this.cells.get(k); c ? c.push(i) : this.cells.set(k, [i]); }
  private range(b: BBox) { const s = this.size; return [Math.floor(b.minX / s), Math.floor(b.minY / s), Math.floor(b.maxX / s), Math.floor(b.maxY / s)]; }
  query(b: BBox): number[] {
    const out = new Set<number>(this.cells.get('big') ?? []);
    const [x0, y0, x1, y1] = this.range(b);
    if ((x1 - x0 + 1) * (y1 - y0 + 1) > 20000) return this.entities.map((_, i) => i);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (const i of this.cells.get(`${x},${y}`) ?? []) out.add(i);
    return [...out].filter((i) => { const e = this.boxes[i]; return e.maxX >= b.minX && e.minX <= b.maxX && e.maxY >= b.minY && e.minY <= b.maxY; });
  }
}

function segDist(p: Pt, a: Pt, b: Pt) {
  const dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy;
  const t = l2 ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2)) : 0;
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}

/** World distance from a point to an entity's geometry. */
export function distanceTo(e: Entity, p: Pt): number {
  const g = e.geom;
  switch (e.type) {
    case 'LINE': return segDist(p, g.a, g.b);
    case 'POLYLINE': {
      let d = Infinity;
      const n = g.closed ? g.points.length : g.points.length - 1;
      for (let i = 0; i < n; i++) d = Math.min(d, segDist(p, g.points[i], g.points[(i + 1) % g.points.length]));
      return d;
    }
    case 'CIRCLE': return Math.abs(Math.hypot(p.x - g.c.x, p.y - g.c.y) - g.r);
    case 'ARC': {
      const a = (Math.atan2(p.y - g.c.y, p.x - g.c.x) * 180) / Math.PI;
      if (inArc(a, g.start, g.end)) return Math.abs(Math.hypot(p.x - g.c.x, p.y - g.c.y) - g.r);
      return Math.min(Math.hypot(p.x - arcPt(g.c, g.r, g.start).x, p.y - arcPt(g.c, g.r, g.start).y), Math.hypot(p.x - arcPt(g.c, g.r, g.end).x, p.y - arcPt(g.c, g.r, g.end).y));
    }
    case 'TEXT': { const b = entityBBox(e); return p.x >= b.minX && p.x <= b.maxX && p.y >= b.minY && p.y <= b.maxY ? 0 : Infinity; }
    case 'WALL': return Math.max(0, segDist(p, g.a, g.b) - g.thickness / 2);
    case 'DOOR': { const k = doorParts(g); return Math.min(segDist(p, k.hinge, k.tip), segDist(p, ...openingEnds(g))); }
    case 'WINDOW': return segDist(p, ...openingEnds(g));
    default: return Math.hypot(p.x - g.p.x, p.y - g.p.y);
  }
}

export type SnapKind = 'endpoint' | 'midpoint' | 'center' | 'grid';
export function snapCandidates(e: Entity): { p: Pt; kind: SnapKind }[] {
  const g = e.geom;
  switch (e.type) {
    case 'LINE': return [{ p: g.a, kind: 'endpoint' }, { p: g.b, kind: 'endpoint' }, { p: { x: (g.a.x + g.b.x) / 2, y: (g.a.y + g.b.y) / 2 }, kind: 'midpoint' }];
    case 'POLYLINE': {
      const out: { p: Pt; kind: SnapKind }[] = g.points.map((p: Pt) => ({ p, kind: 'endpoint' as const }));
      const n = g.closed ? g.points.length : g.points.length - 1;
      for (let i = 0; i < n; i++) { const a = g.points[i], b = g.points[(i + 1) % g.points.length]; out.push({ p: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, kind: 'midpoint' }); }
      return out;
    }
    case 'CIRCLE': return [{ p: g.c, kind: 'center' }];
    case 'ARC': return [{ p: g.c, kind: 'center' }, { p: arcPt(g.c, g.r, g.start), kind: 'endpoint' }, { p: arcPt(g.c, g.r, g.end), kind: 'endpoint' }];
    case 'TEXT': return [{ p: g.p, kind: 'endpoint' }];
    case 'WALL': return [{ p: g.a, kind: 'endpoint' }, { p: g.b, kind: 'endpoint' }, { p: { x: (g.a.x + g.b.x) / 2, y: (g.a.y + g.b.y) / 2 }, kind: 'midpoint' }];
    case 'DOOR': case 'WINDOW': return [...openingEnds(g).map((p) => ({ p, kind: 'endpoint' as const })), { p: g.p, kind: 'midpoint' }];
    default: return [{ p: g.p, kind: 'endpoint' }];
  }
}

/** Grid step in world units so lines are at least ~minPx apart (1/2/5 × 10ⁿ). */
export function gridStep(scale: number, minPx = 18) {
  const raw = minPx / scale;
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  for (const m of [1, 2, 5, 10]) if (p * m >= raw) return p * m;
  return p * 10;
}

const ACI: Record<number, string> = { 1: '#ef4444', 2: '#facc15', 3: '#22c55e', 4: '#22d3ee', 5: '#3b82f6', 6: '#d946ef', 7: '', 8: '#94a3b8', 9: '#cbd5e1' };
export const aciColor = (c: number | undefined, fallback: string) => (c && ACI[c]) || fallback;

export type RenderOpts = {
  view: View;
  index: SpatialIndex;
  layerInfo: Map<string, { color: number; visible: boolean; locked: boolean }>;
  selected: Set<string>;
  hover: string | null;
  ghosts: Entity[];
  markers: { p: Pt; status: string; n: number; active: boolean }[];
  showGrid: boolean;
  theme: { fg: string; grid: string; gridMajor: string; sel: string; ghost: string; text: string; bg: string };
};

/** Erase the wall section behind an opening (the wall thickness is taken from the gap width). */
function cutGap(ctx: CanvasRenderingContext2D, v: View, e: Entity, bg: string, t: number) {
  const g = e.geom;
  const [a, b] = openingEnds(g);
  const n = { x: -g.dir.y, y: g.dir.x }, h = Math.max(t / 2, 2 / v.scale) + 1.5 / v.scale;
  const quad = [{ x: a.x + n.x * h, y: a.y + n.y * h }, { x: b.x + n.x * h, y: b.y + n.y * h }, { x: b.x - n.x * h, y: b.y - n.y * h }, { x: a.x - n.x * h, y: a.y - n.y * h }].map((p) => toScreen(v, p));
  ctx.save(); ctx.fillStyle = bg; ctx.beginPath();
  quad.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath(); ctx.fill(); ctx.restore();
}

export function render(ctx: CanvasRenderingContext2D, o: RenderOpts) {
  const { view: v } = o;
  ctx.clearRect(0, 0, v.width, v.height);
  if (o.showGrid) drawGrid(ctx, v, o.theme);
  const vb = { minX: v.ox, minY: v.oy, maxX: v.ox + v.width / v.scale, maxY: v.oy + v.height / v.scale };
  const ids = o.index.query(vb);
  const many = ids.length > 20000;
  // walls first, then openings cut their gaps, then everything else on top
  const rank = (t: string) => (t === 'WALL' ? 0 : t === 'DOOR' || t === 'WINDOW' ? 1 : 2);
  ids.sort((a, b) => rank(o.index.entities[a].type) - rank(o.index.entities[b].type));
  const wallT = new Map(o.index.entities.filter((e) => e.type === 'WALL').map((w) => [w.id, w.geom.thickness as number]));  for (const i of ids) {
    const e = o.index.entities[i];
    const li = o.layerInfo.get(e.layer);
    if (li && !li.visible) continue;
    if (e.type === 'DOOR' || e.type === 'WINDOW') cutGap(ctx, v, e, o.theme.bg, wallT.get(e.geom.wallId) ?? 0);
    if (many && e.type === 'TEXT' && e.geom.h * v.scale < 3) continue; // large-drawing safeguard
    const sel = o.selected.has(e.id);
    ctx.strokeStyle = sel ? o.theme.sel : aciColor(e.props?.color ?? li?.color, o.theme.fg);
    ctx.fillStyle = ctx.strokeStyle;
    ctx.lineWidth = sel ? 2.2 : e.id === o.hover ? 1.8 : 1;
    ctx.setLineDash([]);
    drawEntity(ctx, v, e);
  }
  for (const g of o.ghosts) {
    ctx.strokeStyle = o.theme.ghost; ctx.fillStyle = o.theme.ghost; ctx.lineWidth = 1.6; ctx.setLineDash([6, 4]);
    drawEntity(ctx, v, g);
  }
  ctx.setLineDash([]);
  for (const m of o.markers) {
    const s = toScreen(v, m.p);
    const col = m.status === 'FAIL' ? '#f87171' : m.status === 'WARNING' ? '#fbbf24' : '#a78bfa';
    ctx.beginPath(); ctx.arc(s.x, s.y, m.active ? 13 : 10, 0, Math.PI * 2);
    ctx.fillStyle = col + (m.active ? 'ee' : '99'); ctx.fill();
    ctx.strokeStyle = '#0008'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#0b1020'; ctx.font = '600 10px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(m.n), s.x, s.y + 0.5);
  }
}

function drawGrid(ctx: CanvasRenderingContext2D, v: View, th: RenderOpts['theme']) {
  const step = gridStep(v.scale);
  const major = step * 10;
  const x0 = Math.floor(v.ox / step) * step, y0 = Math.floor(v.oy / step) * step;
  const x1 = v.ox + v.width / v.scale, y1 = v.oy + v.height / v.scale;
  ctx.lineWidth = 1;
  for (const [s, col] of [[step, th.grid], [major, th.gridMajor]] as [number, string][]) {
    ctx.strokeStyle = col; ctx.beginPath();
    for (let x = Math.floor(x0 / s) * s; x <= x1; x += s) { const sx = Math.round((x - v.ox) * v.scale) + 0.5; ctx.moveTo(sx, 0); ctx.lineTo(sx, v.height); }
    for (let y = Math.floor(y0 / s) * s; y <= y1; y += s) { const sy = Math.round(v.height - (y - v.oy) * v.scale) + 0.5; ctx.moveTo(0, sy); ctx.lineTo(v.width, sy); }
    ctx.stroke();
  }
}

export function drawEntity(ctx: CanvasRenderingContext2D, v: View, e: Entity) {
  const g = e.geom;
  const S = (p: Pt) => toScreen(v, p);
  ctx.beginPath();
  switch (e.type) {
    case 'LINE': { const a = S(g.a), b = S(g.b); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); break; }
    case 'POLYLINE': {
      g.points.forEach((p: Pt, i: number) => { const s = S(p); i ? ctx.lineTo(s.x, s.y) : ctx.moveTo(s.x, s.y); });
      if (g.closed) ctx.closePath();
      ctx.stroke(); break;
    }
    case 'CIRCLE': { const c = S(g.c); ctx.arc(c.x, c.y, g.r * v.scale, 0, Math.PI * 2); ctx.stroke(); break; }
    case 'ARC': {
      // Screen Y is flipped, so a counter-clockwise world arc is drawn anticlockwise=true with negated angles.
      const c = S(g.c); ctx.arc(c.x, c.y, g.r * v.scale, -rad(g.start), -rad(g.end), true); ctx.stroke(); break;
    }
    case 'TEXT': {
      const p = S(g.p), px = g.h * v.scale;
      if (px < 1.5) { ctx.fillRect(p.x, p.y - 1, Math.max(2, g.text.length * px * 0.6), 1); break; }
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-rad(g.rot || 0));
      ctx.font = `${px}px "IBM Plex Sans", "IBM Plex Sans Arabic", sans-serif`; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
      ctx.direction = 'ltr';
      ctx.fillText(g.text, 0, 0); ctx.restore(); break;
    }
    case 'WALL': {
      const q = wallOutline(g).map(S);
      q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath();
      ctx.save(); ctx.globalAlpha = 0.16; ctx.fill(); ctx.restore(); ctx.stroke(); break;
    }
    case 'DOOR': {
      const k = doorParts(g), h = S(k.hinge), t = S(k.tip);
      ctx.moveTo(h.x, h.y); ctx.lineTo(t.x, t.y); ctx.stroke();
      ctx.beginPath(); ctx.arc(h.x, h.y, g.width * v.scale, -rad(k.start), -rad(k.end), true);
      ctx.save(); ctx.setLineDash([3, 3]); ctx.stroke(); ctx.restore(); break;
    }
    case 'WINDOW': {
      const [a, b] = openingEnds(g), n = { x: -g.dir.y, y: g.dir.x }, o = 3 / v.scale;
      for (const s of [-1, 0, 1]) { const p = S({ x: a.x + n.x * o * s, y: a.y + n.y * o * s }), q = S({ x: b.x + n.x * o * s, y: b.y + n.y * o * s }); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); }
      ctx.stroke(); break;
    }
    default: { const p = S(g.p); ctx.moveTo(p.x - 4, p.y); ctx.lineTo(p.x + 4, p.y); ctx.moveTo(p.x, p.y - 4); ctx.lineTo(p.x, p.y + 4); ctx.stroke(); }
  }
}

/** Fit a view to a bounding box with a margin. */
export function fitView(b: BBox | null, width: number, height: number): View {
  if (!b || !isFinite(b.minX)) return { ox: -10, oy: -10, scale: Math.min(width, height) / 100, width, height };
  const w = Math.max(b.maxX - b.minX, 1e-6), h = Math.max(b.maxY - b.minY, 1e-6);
  const scale = Math.min(width / (w * 1.12), height / (h * 1.12));
  return { scale, width, height, ox: b.minX - (width / scale - w) / 2, oy: b.minY - (height / scale - h) / 2 };
}

export const fmt = (n: number, d = 3) => (Math.abs(n) >= 1e6 ? n.toExponential(4) : Number(n.toFixed(d)).toString());
