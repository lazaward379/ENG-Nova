import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../src/app.ts';
import { sampleDxf } from '../scripts/make-sample.ts';

let app: FastifyInstance, dir: string, token = '', refProject = '', refDrawing = '', target = '';

const call = async (method: string, url: string, body?: unknown) => {
  const res = await app.inject({ method: method as any, url, payload: body as any, headers: { authorization: `Bearer ${token}` } });
  let json: any = null; try { json = res.json(); } catch { /* html */ }
  return { status: res.statusCode, json, body: res.body };
};
const run_cov = (r: any) => r.json.findings.find((f: any) => f.rule_code === 'REG-TPL-COVERAGE').evidence.measured_for_information_only[0].evidence.coverage_pct;
const gen = (extra: any) => call('POST', `/api/projects/${target}/generate-from-reference`, {
  referenceDrawingId: refDrawing, setback_m: 3, setback_source: 'test assumption', ...extra,
});

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'nova-gen-'));
  ({ app } = await buildApp({ dbPath: ':memory:', storageDir: join(dir, 's') }));
  token = (await app.inject({ method: 'POST', url: '/api/auth/register', payload: { orgName: 'Gen Co', name: 'G', email: 'g@example.test', password: 'long-enough-pass' } })).json().token;
  refProject = (await call('POST', '/api/projects', { code: 'REF', name: 'Reference villa' })).json.id;
  const b = '----g' + Math.random().toString(16).slice(2);
  const payload = Buffer.concat([Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="file"; filename="ref.dxf"\r\n\r\n`), Buffer.from(sampleDxf()), Buffer.from(`\r\n--${b}--\r\n`)]);
  refDrawing = (await app.inject({ method: 'POST', url: `/api/projects/${refProject}/documents`, payload, headers: { 'content-type': `multipart/form-data; boundary=${b}`, authorization: `Bearer ${token}` } })).json().drawingId;
  target = (await call('POST', '/api/projects', { code: 'NEW', name: 'New villa' })).json.id;
});
after(async () => { await app.close(); rmSync(dir, { recursive: true, force: true }); });

test('generates a complete preliminary plan from the reference on a new plot', async () => {
  const r = await gen({ plot: { width_m: 32, depth_m: 26, source: 'test plot' } });
  assert.equal(r.status, 200, r.body);
  const rep = r.json.report;
  assert.deepEqual(rep.rooms.map((x: any) => x.name).sort(), ['GUEST BEDROOM', 'KITCHEN', 'LIVING', 'MAJLIS مجلس', 'ROOM 1'].sort());
  assert.ok(rep.counts.walls >= 10);
  assert.ok(rep.counts.doors >= 5, JSON.stringify(rep.counts));
  assert.ok(rep.counts.windows >= 3);
  assert.equal(rep.placedOpenings, rep.counts.doors + rep.counts.windows);
  // proportional scaling keeps every room's area ratio identical
  const ratios = rep.rooms.map((x: any) => x.areaM2 / x.refAreaM2);
  for (const q of ratios) assert.ok(Math.abs(q - ratios[0]) < 1e-3, JSON.stringify(ratios));
  assert.ok(Math.abs(ratios[0] - rep.transform.scaleX * rep.transform.scaleY) < 0.01);
  assert.ok(rep.assumptions.some((a: string) => /setback of 3 m/.test(a)));

  const d = (await call('GET', `/api/drawings/${r.json.drawingId}`)).json;
  assert.equal(d.units, 'mm');
  assert.ok(d.entities.every((e: any) => e.provenance === 'ai'));
  assert.equal(d.layers.find((l: any) => l.name === 'PLOT-BOUNDARY').locked, true);
  assert.ok(d.entities.some((e: any) => e.type === 'TEXT' && /PRELIMINARY/.test(e.geom.text)));
  // the outline follows the rooms (the reference has an empty notch), so its area equals the rooms' total
  const outl = d.entities.filter((e: any) => e.layer === 'A-BLDG-OUTL');
  assert.equal(outl.length, 1);
  const pts = outl[0].geom.points;
  let s = 0; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; s += a.x * b.y - b.x * a.y; }
  assert.ok(Math.abs(Math.abs(s / 2) / 1e6 - rep.footprintAreaM2) < 0.01, `${Math.abs(s / 2) / 1e6} vs ${rep.footprintAreaM2}`);
  const cov = run_cov(await call('GET', `/api/compliance-runs/${r.json.checks.runId}`));
  assert.ok(Math.abs(cov - rep.coveragePct) < 0.01, `${cov} vs ${rep.coveragePct}`);

  // automatic checks: geometry is consistent
  const run = (await call('GET', `/api/compliance-runs/${r.json.checks.runId}`)).json;
  const st = (code: string) => run.findings.filter((f: any) => f.rule_code === code).map((f: any) => f.status);
  assert.ok(st('QA-ROOM-CLOSED').every((s: string) => s === 'PASS'));
  assert.ok(st('QA-ROOM-OVERLAP').every((s: string) => s === 'PASS'));
  assert.ok(st('QA-ROOM-LABEL').every((s: string) => s === 'PASS'));
  assert.ok(st('QA-OPENINGS').every((s: string) => s === 'PASS'));
  // generated building stays inside the plot with the setback
  const sb = run.findings.find((f: any) => f.rule_code === 'REG-TPL-SETBACK');
  const measured = sb.evidence.measured_for_information_only[0].evidence.min_distance_m;
  assert.ok(measured >= 3 - 1e-6, String(measured));
});

test('rotates the layout for a deep, narrow plot and stays editable / undoable', async () => {
  const r = await gen({ plot: { width_m: 22, depth_m: 40, source: 'test plot' } });
  assert.equal(r.status, 200, r.body);
  assert.equal(r.json.report.transform.rotated90, true);
  const id = r.json.drawingId;
  const d = (await call('GET', `/api/drawings/${id}`)).json;
  const door = d.entities.find((e: any) => e.type === 'DOOR');
  const before = door.geom.offset;
  const mv = await call('POST', `/api/drawings/${id}/operations`, { op: { kind: 'set_opening', id: door.id, offset: before + 100 } });
  assert.ok(mv.status === 200 || mv.status === 422);
  await call('POST', `/api/drawings/${id}/undo`);
  assert.equal((await call('GET', `/api/drawings/${id}`)).json.entities.find((e: any) => e.id === door.id).geom.offset, before);
});

test('refuses unrealistic shrinking and missing inputs with a clear reason', async () => {
  const small = await gen({ plot: { width_m: 12, depth_m: 12, source: 'tiny' } });
  assert.equal(small.status, 422, small.body);
  assert.match(small.json.error, /too large for this plot/);
  assert.equal((await gen({ plot: { width_m: 30, depth_m: 30, source: 'x' }, setback_source: '' })).status, 400);
  const noUnits = (await call('POST', `/api/projects/${target}/drawings`, { name: 'blank', units: 'mm' })).json.id;
  const r = await call('POST', `/api/projects/${target}/generate-from-reference`, { referenceDrawingId: noUnits, plot: { width_m: 30, depth_m: 30, source: 'test plot' }, setback_m: 2, setback_source: 'test setback' });
  assert.equal(r.status, 422, r.body);
  assert.match(r.json.error, /no valid room boundaries/);
});

test('uses a plot boundary from an existing drawing and the confirmed coverage limit', async () => {
  const csvB = '----c' + Math.random().toString(16).slice(2);
  const csv = 'x,y\n0,0\n36000,0\n36000,30000\n0,30000\n';
  const up = (await app.inject({ method: 'POST', url: `/api/projects/${target}/documents`, payload: Buffer.from(`--${csvB}\r\nContent-Disposition: form-data; name="file"; filename="plot.csv"\r\n\r\n${csv}\r\n--${csvB}--\r\n`), headers: { 'content-type': `multipart/form-data; boundary=${csvB}`, authorization: `Bearer ${token}` } })).json();
  const plotDrawing = (await call('POST', `/api/documents/${up.id}/to-drawing`, { units: 'mm' })).json.id;
  await call('PUT', `/api/projects/${target}/facts`, { key: 'max_plot_coverage_pct', value: '25', class: 'confirmed', source: 'test fixture' });
  const r = await gen({ plot: { drawingId: plotDrawing } });
  assert.equal(r.status, 200, r.body);
  assert.ok(r.json.report.coveragePct <= 25 + 1e-6, String(r.json.report.coveragePct));
  assert.ok(r.json.report.assumptions.some((a: string) => /maximum plot coverage of 25%/.test(a)));
});
