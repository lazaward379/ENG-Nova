import { useEffect, useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, ProjectDrawingPicker, Status, useApp, useLoad, when } from '../ui';

export function Compliance({ scope }: { scope: 'all' | 'drawing_qa' }) {
  const { drawing, go, toast, can } = useApp();
  const { t } = useT();
  const [runId, setRunId] = useState<string | null>(null);
  const [filter, setFilter] = useState('not-pass');
  const runs = useLoad(() => (drawing ? api.get(`/api/drawings/${drawing}/compliance-runs`) : Promise.resolve([])), [drawing]);
  const run = useLoad(() => (runId ? api.get(`/api/compliance-runs/${runId}`) : Promise.resolve(null)), [runId]);
  useEffect(() => { setRunId(runs.data?.[0]?.id ?? null); }, [runs.data]);

  const execute = async (s: string) => {
    try { const r = await api.post(`/api/drawings/${drawing}/compliance-runs`, { scope: s }); await runs.reload(); setRunId(r.id); toast('Run complete', 'ok'); }
    catch (e: any) { toast(e.message, 'error'); }
  };
  const findings = (run.data?.findings ?? []).filter((f: any) => (scope === 'drawing_qa' ? f.category === 'drawing_qa' : true))
    .filter((f: any) => filter === 'all' || (filter === 'not-pass' ? f.status !== 'PASS' : f.status === filter));

  return (
    <div className="stack">
      <div className="page-h">
        <div><h1>{scope === 'drawing_qa' ? t('nav.qa', 'Drawing quality assurance') : t('nav.compliance', 'Engineering compliance center')}</h1>
          <div className="sub">{scope === 'drawing_qa' ? 'Geometry integrity, labelling, layer conventions and import coverage.' : 'Deterministic rule execution with inputs, evidence and source references.'}</div></div>
        <span className="spacer" /><ProjectDrawingPicker />
      </div>
      <div className="notice info">{t('comp.banner', 'Engineering support results only — not an authority approval. Regulatory rules without a verified source are not assessed.')}</div>
      {!drawing ? <div className="card empty">{t('common.selectDrawing', 'Select a project and drawing.')}</div> : (
        <div className="grid" style={{ gridTemplateColumns: 'minmax(220px, 280px) 1fr' }}>
          <div className="card stack" style={{ alignSelf: 'start' }}>
            <div className="row">
              <button className="btn primary sm" onClick={() => execute(scope)}><Icon name="play" />{t('comp.run', 'Run')} {scope === 'drawing_qa' ? t('comp.qaOnly', 'QA') : t('comp.allRules', 'all rules')}</button>
              {scope === 'all' && <button className="btn sm" onClick={() => execute('regulatory')}>{t('comp.regOnly', 'Regulatory')}</button>}
            </div>
            <div className="faint">Run history</div>
            {runs.data?.map((r: any) => (
              <div key={r.id} className={`card`} style={{ padding: 8, cursor: 'pointer', borderColor: r.id === runId ? 'var(--cyan)' : undefined }} onClick={() => setRunId(r.id)}>
                <div className="faint">{when(r.created_at)} · {r.run_by} · op #{r.op_seq}</div>
                <div className="row" style={{ gap: 4 }}>{Object.entries(r.summary).map(([s, n]) => <span key={s} className="faint"><Status s={s} /> {n as number}</span>)}</div>
              </div>
            ))}
            {!runs.data?.length && <div className="faint">No runs yet.</div>}
          </div>
          <div className="card">
            {!run.data ? <Loading error={run.error} loading={run.loading && !!runId} /> : <>
              <div className="row" style={{ marginBottom: 10 }}>
                <select value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: 220 }}>
                  <option value="not-pass">Not passing</option><option value="all">All results</option>
                  {['PASS', 'FAIL', 'WARNING', 'NOT CHECKED', 'INSUFFICIENT DATA', 'REQUIRES ENGINEER REVIEW', 'SOURCE NOT VERIFIED'].map((s) => <option key={s}>{s}</option>)}
                </select>
                <span className="faint">{findings.length} result(s)</span><span className="spacer" />
                <button className="btn sm" onClick={() => api.openHtml(`/api/compliance-runs/${run.data.id}/report`).catch((e) => toast(e.message, 'error'))}><Icon name="report" />{t('ws.report', 'Report')}</button>
                <button className="btn sm" onClick={() => go(`workspace/${drawing}`)}><Icon name="workspace" />{t('comp.showInDrawing', 'Open drawing')}</button>
              </div>
              <div className="stack" style={{ gap: 8 }}>
                {findings.map((f: any) => <FindingCard key={f.id} f={f} canEdit={can('engineer')} canAccept={can('reviewer')} onChange={run.reload} />)}
              </div>
            </>}
          </div>
        </div>
      )}
    </div>
  );
}

function FindingCard({ f, canEdit, canAccept, onChange }: { f: any; canEdit: boolean; canAccept: boolean; onChange: () => void }) {
  const { t } = useT();
  const { toast } = useApp();
  const [open, setOpen] = useState(false);
  const src = f.evidence?.source;
  const setRes = async (resolution: string) => { try { await api.patch(`/api/findings/${f.id}`, { resolution }); onChange(); } catch (e: any) { toast(e.message, 'error'); } };
  return (
    <div className="card" style={{ padding: 10 }}>
      <div className="row" style={{ gap: 8 }}>
        <Status s={f.status} /><span className="mono">{f.rule_code}</span><span className="faint">{f.rule_title}</span><span className="spacer" />
        {f.resolution !== 'open' && <span className="chip c-confirmed">{f.resolution}</span>}
        <button className="btn sm ghost" onClick={() => setOpen(!open)}>{open ? '−' : '+'} {t('comp.evidence', 'Evidence')}</button>
      </div>
      <div style={{ marginTop: 4 }} dir="auto">{f.message}</div>
      {f.corrective_action && f.status !== 'PASS' && <div className="faint">{t('comp.action', 'Corrective action')}: {f.corrective_action}</div>}
      {open && (
        <div className="grid c2" style={{ marginTop: 8 }}>
          <div><div className="faint">{t('comp.inputs', 'Inputs')}</div><pre className="json ltr">{JSON.stringify(f.inputs, null, 1)}</pre></div>
          <div><div className="faint">{t('comp.evidence', 'Evidence')}</div><pre className="json ltr">{JSON.stringify({ ...f.evidence, source: undefined }, null, 1)}</pre></div>
          <div style={{ gridColumn: '1 / -1' }} className="faint">
            {t('comp.source', 'Source')}: {src ? <>{src.authority} — {src.title} {src.clause && `· ${src.clause}`} · <b>{src.status}</b> {src.url && <a href={src.url} target="_blank" rel="noreferrer noopener">link</a>}</> : 'NOVA internal drawing-QA convention'}
            {f.entity_ids?.length > 0 && <> · {f.entity_ids.length} entit(ies)</>}{f.location && <span className="mono ltr"> · @ {f.location.x.toFixed(1)}, {f.location.y.toFixed(1)}</span>}
          </div>
          {f.status !== 'PASS' && canEdit && <div className="row" style={{ gridColumn: '1 / -1' }}>
            <button className="btn sm" onClick={() => setRes('resolved')}>Mark resolved</button>
            {canAccept && <button className="btn sm" onClick={() => setRes('accepted_risk')}>Accept (reviewer)</button>}
            {f.resolution !== 'open' && <button className="btn sm ghost" onClick={() => setRes('open')}>Re-open</button>}
            <span className="faint">Resolution is recorded; re-run checks to revalidate.</span>
          </div>}
        </div>
      )}
    </div>
  );
}
