import { useState } from 'react';
import { api } from '../api';
import { useT, type Lang } from '../i18n';
import { Icon, Loading, Modal, useApp, useLoad, when } from '../ui';

export function Admin() {
  const { can, toast, me } = useApp();
  const { t } = useT();
  const members = useLoad(() => api.get('/api/org/members'), []);
  const audit = useLoad(() => (can('admin') ? api.get('/api/audit') : Promise.resolve([])), []);
  const [add, setAdd] = useState(false);
  return (
    <div className="stack">
      <div className="page-h"><div><h1>{t('nav.admin', 'Organization administration')}</h1><div className="sub">{me.orgName}</div></div><span className="spacer" />
        {can('admin') && <button className="btn primary" onClick={() => setAdd(true)}><Icon name="plus" />Add member</button>}</div>
      <div className="card">
        <div className="card-h"><h2>Members & roles</h2></div>
        <div className="faint" style={{ marginBottom: 8 }}>viewer: read-only · engineer: edit projects and geometry · reviewer: verify sources and rule versions, accept findings · admin: members and audit log. All permissions are enforced by the server.</div>
        {members.data ? <table className="t"><tbody>{members.data.map((m: any) => (
          <tr key={m.id}><td>{m.name}</td><td className="ltr">{m.email}</td>
            <td>{can('admin') && m.id !== me.userId ? (
              <select value={m.role} style={{ width: 140 }} onChange={async (e) => { try { await api.patch(`/api/org/members/${m.id}`, { role: e.target.value }); members.reload(); } catch (x: any) { toast(x.message, 'error'); } }}>
                {['viewer', 'engineer', 'reviewer', 'admin'].map((r) => <option key={r}>{r}</option>)}</select>) : <span className="chip">{m.role}</span>}</td>
            <td className="faint">{when(m.created_at)}</td></tr>))}</tbody></table> : <Loading error={members.error} loading={members.loading} />}
      </div>
      {can('admin') && <div className="card">
        <div className="card-h"><h2>Audit log</h2><span className="spacer" /><button className="btn sm ghost" onClick={audit.reload}><Icon name="rotate" /></button></div>
        {audit.data ? <div className="table-wrap"><table className="t"><tbody>{audit.data.map((a: any) => (
          <tr key={a.id}><td className="faint">{when(a.created_at)}</td><td className="mono">{a.action}</td><td>{a.user}</td><td className="mono faint ltr" style={{ fontSize: 11 }}>{a.target?.slice(0, 8)} {JSON.stringify(a.detail)}</td></tr>))}</tbody></table></div>
          : <Loading error={audit.error} loading={audit.loading} />}
      </div>}
      {add && <AddMember onClose={() => setAdd(false)} onDone={() => { setAdd(false); members.reload(); }} />}
    </div>
  );
}

function AddMember({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'engineer' });
  const [err, setErr] = useState<string | null>(null);
  return (
    <Modal title="Add member" onClose={onClose}>
      <div className="stack">
        <label className="field">Name<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
        <label className="field">Email<input type="email" dir="ltr" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
        <label className="field">Initial password (share it securely; min 10 characters)<input type="password" dir="ltr" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="new-password" /></label>
        <label className="field">Role<select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>{['viewer', 'engineer', 'reviewer', 'admin'].map((r) => <option key={r}>{r}</option>)}</select></label>
        {err && <div className="notice">{err}</div>}
        <div className="row end"><button className="btn primary" onClick={async () => { try { await api.post('/api/org/members', f); onDone(); } catch (e: any) { setErr(e.message); } }}>Add</button></div>
      </div>
    </Modal>
  );
}

export function Settings({ lang, setLang, theme, setTheme }: { lang: Lang; setLang: (l: Lang) => void; theme: string; setTheme: (t: string) => void }) {
  const { t } = useT();
  const providers = useLoad(() => api.get('/api/copilot/providers'), []);
  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="page-h"><h1>{t('nav.settings', 'Settings & integrations')}</h1></div>
      <div className="card stack">
        <h2>Preferences</h2>
        <div className="grid c2">
          <label className="field">Language / اللغة<select value={lang} onChange={(e) => setLang(e.target.value as Lang)}><option value="en">English</option><option value="ar">العربية (RTL)</option></select></label>
          <label className="field">{t('common.theme', 'Theme')}<select value={theme} onChange={(e) => setTheme(e.target.value)}><option value="dark">Dark</option><option value="light">Light</option></select></label>
        </div>
        <div className="faint">Stored in this browser only.</div>
      </div>
      <div className="card">
        <h2>AI providers</h2>
        <p className="muted">Credentials are read from server environment variables only and never reach the browser.</p>
        {providers.data?.map((p: any) => (
          <div key={p.id} className="row" style={{ padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
            <b>{p.name}</b><span className="faint">{p.model ?? 'deterministic, offline'}</span><span className="spacer" />
            <span className={`chip ${p.available ? 'c-confirmed' : 'c-unresolved'}`}>{p.available ? 'available' : 'not configured'}</span>
          </div>
        ))}
        <div className="faint" style={{ marginTop: 8 }}>To enable the LLM interpreter, set <code>ANTHROPIC_API_KEY</code> in <code>server/.env</code> (optionally <code>NOVA_LLM_MODEL</code>) and restart the server.</div>
      </div>
      <div className="card">
        <h2>External integrations</h2>
        <table className="t"><tbody>
          {[
            ['DMT / municipality e-services', 'No API integration. NOVA prepares packages for manual submission; it never simulates portal submission.'],
            ['Binaa (DMT building permits)', 'Manual workflow: NOVA prepares the package, links to TAMM/DMT, and records the application number and outcome. No public API exists to connect to.'],
            ['AutoCAD (local, accoreconsole)', 'When AutoCAD is installed on the computer running NOVA: DWG import/export and detailed plan sheets (DWG + PDF). Status is shown in the workspace “AutoCAD sheet” dialog.'],
            ['IFC (IfcOpenShell / web-ifc)', 'Not installed. IFC files are registered only.'],
            ['OCR / PDF extraction', 'Not installed.'],
            ['Malware scanning', 'Integration point exists (storage scan hook); no scanner configured.'],
            ['S3-compatible storage', 'Local content-addressed storage in use; adapter interface ready.'],
          ].map(([k, v]) => <tr key={k}><td><b>{k}</b></td><td className="muted">{v}</td><td><span className={`chip ${k.startsWith('Binaa') ? 'c-assumption' : 'c-unresolved'}`}>{k.startsWith('Binaa') ? 'manual workflow' : 'not connected'}</span></td></tr>)}
        </tbody></table>
      </div>
    </div>
  );
}

export function SystemHealth() {
  const { t } = useT();
  const h = useLoad(() => api.get('/api/health'), []);
  const s = useLoad(() => api.get('/api/system'), []);
  return (
    <div className="stack">
      <div className="page-h"><h1>{t('nav.system', 'System health & background tasks')}</h1><span className="spacer" /><button className="btn sm" onClick={() => { h.reload(); s.reload(); }}><Icon name="rotate" />{t('common.refresh', 'Refresh')}</button></div>
      {h.data && <div className="grid c4">
        <div className="card stat"><div className="l">Status</div><div className="v" style={{ color: h.data.status === 'ok' ? 'var(--pass)' : 'var(--fail)' }}>{h.data.status}</div></div>
        <div className="card stat"><div className="l">Database</div><div className="v">{h.data.checks.database ? 'ok' : 'down'}</div></div>
        <div className="card stat"><div className="l">Storage</div><div className="v">{h.data.checks.storage ? 'ok' : 'down'}</div></div>
        <div className="card stat"><div className="l">Version</div><div className="v">{h.data.version}</div></div>
      </div>}
      {s.data ? <>
        <div className="grid c2">
          <div className="card"><h2>Runtime</h2><table className="t"><tbody>
            {[['Node', s.data.node], ['Database', s.data.database], ['Storage', s.data.storage]].map(([k, v]) => <tr key={k}><td>{k}</td><td className="mono">{v}</td></tr>)}
            {Object.entries(s.data.counts).map(([k, v]) => <tr key={k}><td>{k}</td><td className="mono">{v as number}</td></tr>)}
          </tbody></table></div>
          <div className="card"><h2>Capabilities</h2><table className="t"><tbody>
            {Object.entries(s.data.capabilities).map(([k, v]) => <tr key={k}><td>{k}</td><td>{v as string}</td></tr>)}
            {s.data.ai_providers.map((p: any) => <tr key={p.id}><td>AI: {p.name}</td><td>{p.available ? 'available' : 'not configured'}</td></tr>)}
          </tbody></table></div>
        </div>
        <div className="card"><h2>Background jobs</h2>
          {s.data.jobs.length ? <table className="t"><tbody>{s.data.jobs.map((j: any) => (
            <tr key={j.id}><td className="mono">{j.kind}</td><td><span className={`chip ${j.status === 'succeeded' ? 'c-confirmed' : j.status === 'failed' ? 'c-unresolved' : ''}`}>{j.status}</span></td><td className="faint">{when(j.started_at)}</td><td className="faint">{j.detail}</td></tr>))}</tbody></table>
            : <div className="empty">No jobs yet.</div>}
          <div className="faint">Jobs run in-process and synchronously in this release (no queue, retries or cancellation yet).</div>
        </div>
      </> : <Loading error={s.error} loading={s.loading} />}
    </div>
  );
}
