import { useEffect, useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, useApp, useLoad, when } from '../ui';

const TZ = 'Asia/Dubai';

/** Abu Dhabi time parts, independent of the computer's own time zone. */
function abuDhabiNow(d: Date) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).formatToParts(d).map((p) => [p.type, p.value]));
  return { h: +parts.hour % 24, m: +parts.minute, s: +parts.second };
}

function Clock() {
  const { lang } = useT();
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  const { h, m, s } = abuDhabiNow(now);
  const loc = lang === 'ar' ? 'ar-AE' : 'en-GB';
  const time = new Intl.DateTimeFormat(loc, { timeZone: TZ, hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(now);
  const greg = new Intl.DateTimeFormat(loc, { timeZone: TZ, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now);
  const hijri = new Intl.DateTimeFormat(`${lang === 'ar' ? 'ar' : 'en'}-u-ca-islamic-umalqura`, { timeZone: TZ, day: 'numeric', month: 'long', year: 'numeric' }).format(now);
  const hand = (deg: number, len: number, w: number, color: string) => <line x1="100" y1="100" x2={100 + len * Math.sin((deg * Math.PI) / 180)} y2={100 - len * Math.cos((deg * Math.PI) / 180)} stroke={color} strokeWidth={w} strokeLinecap="round" />;
  return (
    <div className="card glow clock-card">
      <svg viewBox="0 0 200 200" className="clock-face" role="img" aria-label={time}>
        <defs><radialGradient id="cf" cx="50%" cy="40%" r="70%"><stop offset="0" stopColor="var(--surface-2)" /><stop offset="1" stopColor="var(--bg)" /></radialGradient></defs>
        <circle cx="100" cy="100" r="94" fill="url(#cf)" stroke="var(--border-strong)" strokeWidth="2" />
        <circle cx="100" cy="100" r="88" fill="none" stroke="var(--cyan)" strokeOpacity=".25" strokeWidth="1" />
        {Array.from({ length: 60 }, (_, i) => {
          const a = (i * 6 * Math.PI) / 180, big = i % 5 === 0;
          return <line key={i} x1={100 + (big ? 72 : 78) * Math.sin(a)} y1={100 - (big ? 72 : 78) * Math.cos(a)} x2={100 + 84 * Math.sin(a)} y2={100 - 84 * Math.cos(a)} stroke={big ? 'var(--text)' : 'var(--text-3)'} strokeWidth={big ? 2.4 : 1} strokeLinecap="round" />;
        })}
        {hand((h % 12) * 30 + m * 0.5, 46, 5, 'var(--text)')}
        {hand(m * 6 + s * 0.1, 64, 3.5, 'var(--text)')}
        {hand(s * 6, 72, 1.6, 'var(--cyan)')}
        <circle cx="100" cy="100" r="5" fill="var(--cyan)" />
      </svg>
      <div className="clock-text">
        <div className="eyebrow">{lang === 'ar' ? 'أبوظبي' : 'ABU DHABI'}</div>
        <div className="clock-digital ltr">{time}</div>
        <div className="muted">{greg}</div>
        <div className="faint">{hijri}</div>
      </div>
    </div>
  );
}

const WEATHER_ICON: Record<string, string> = {
  sun: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4',
  partly: 'M8 4v1M3.5 6.5l.7.7M2 11h1M12.5 6.5l-.7.7M5 11a3 3 0 0 1 5.7-1.3M8 20h10a4 4 0 0 0 0-8 6 6 0 0 0-11 2 3 3 0 0 0 1 6z',
  cloud: 'M7 19h10a5 5 0 0 0 0-10 7 7 0 0 0-13 3 4 4 0 0 0 3 7z',
  rain: 'M7 15h10a5 5 0 0 0 0-10 7 7 0 0 0-13 3 4 4 0 0 0 3 7zM8 18l-1 3M12 18l-1 3M16 18l-1 3',
  fog: 'M3 8h18M3 12h18M5 16h14M7 20h10',
  storm: 'M7 15h10a5 5 0 0 0 0-10 7 7 0 0 0-13 3 4 4 0 0 0 3 7zM12 15l-2 4h4l-2 4',
};

function Weather() {
  const { lang } = useT();
  const ar = lang === 'ar';
  const w = useLoad(() => api.get('/api/home/weather'), []);
  const d = w.data;
  return (
    <div className="card weather-card">
      <div className="card-h"><h3>{ar ? 'الطقس في أبوظبي' : 'Abu Dhabi weather'}</h3><span className="spacer" /><button className="btn icon ghost" onClick={w.reload} aria-label="refresh"><Icon name="rotate" size={15} /></button></div>
      {!d ? <div className="faint">…</div> : !d.available ? <div className="faint">{ar ? 'خدمة الطقس غير متاحة الآن.' : 'Weather service unavailable right now.'}</div> : (
        <>
          <div className="row" style={{ gap: 14 }}>
            <svg viewBox="0 0 24 24" width="58" height="58" fill="none" stroke="var(--warn)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={WEATHER_ICON[d.condition.icon] ?? WEATHER_ICON.cloud} /></svg>
            <div><div className="weather-temp ltr">{Math.round(d.temperature)}°</div><div className="muted">{ar ? d.condition.ar : d.condition.en}</div></div>
          </div>
          <div className="weather-grid">
            <div><span className="faint">{ar ? 'العظمى / الصغرى' : 'High / low'}</span><b className="ltr">{Math.round(d.max)}° / {Math.round(d.min)}°</b></div>
            <div><span className="faint">{ar ? 'الإحساس' : 'Feels like'}</span><b className="ltr">{Math.round(d.feelsLike)}°</b></div>
            <div><span className="faint">{ar ? 'الرطوبة' : 'Humidity'}</span><b className="ltr">{d.humidity}%</b></div>
            <div><span className="faint">{ar ? 'الرياح' : 'Wind'}</span><b className="ltr">{Math.round(d.windKmh)} km/h</b></div>
          </div>
          <div className="faint" style={{ marginTop: 6 }}>{ar ? 'المصدر' : 'Source'}: {d.source}</div>
        </>
      )}
    </div>
  );
}

function Wisdom() {
  const { lang } = useT();
  const w = useLoad(() => api.get('/api/home/wisdom'), []);
  return (
    <div className="card wisdom-card">
      <div className="eyebrow">{lang === 'ar' ? 'حكمة اليوم' : 'Wisdom of the day'}</div>
      {w.data && <>
        <blockquote className="wisdom-ar" dir="rtl">{w.data.ar}</blockquote>
        <div className="muted" dir="ltr">{w.data.en}</div>
      </>}
    </div>
  );
}

function News() {
  const { lang } = useT();
  const ar = lang === 'ar';
  const n = useLoad(() => api.get(`/api/home/news?lang=${lang}`), [lang]);
  return (
    <div className="card news-card">
      <div className="card-h"><Icon name="regulatory" /><h3>{ar ? 'أخبار بلدية أبوظبي ودائرة البلديات والنقل' : 'Abu Dhabi Municipality & DMT news'}</h3><span className="spacer" />
        <button className="btn icon ghost" onClick={n.reload} aria-label="refresh"><Icon name="rotate" size={15} /></button></div>
      {!n.data ? <div className="faint">…</div> : !n.data.available || !n.data.items.length ? <div className="faint">{ar ? 'تعذّر جلب الأخبار الآن.' : 'News could not be loaded right now.'}</div> : (
        <ul className="news-list">
          {n.data.items.map((i: any) => (
            <li key={i.link}>
              <a href={i.link} target="_blank" rel="noreferrer noopener" dir="auto">{i.title}</a>
              <div className="faint">{i.source} · {new Date(i.date).toLocaleDateString(ar ? 'ar-AE' : 'en-GB', { day: 'numeric', month: 'short' })}</div>
            </li>
          ))}
        </ul>
      )}
      {n.data?.available && <div className="faint" style={{ marginTop: 6 }}>{ar ? 'عبر Google News — الروابط تفتح المصدر الأصلي' : 'via Google News — links open the original outlet'}</div>}
    </div>
  );
}

/** Full-width slideshow of today's AI-generated architecture images, with the greeting on top. */
function AiHero({ children }: { children: React.ReactNode }) {
  const { lang } = useT();
  const { can, toast } = useApp();
  const ar = lang === 'ar';
  const [meta, setMeta] = useState<any | null>(null);
  const [urls, setUrls] = useState<(string | null | 'failed')[]>([]);
  const [i, setI] = useState(0);
  const [busy, setBusy] = useState(false);
  const reduced = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;

  const load = async () => {
    try {
      const m = await api.get('/api/home/hero');
      setMeta(m); setUrls(m.images.map(() => null)); setI(0);
      // fetch one by one so the first image appears as soon as it is ready
      for (const im of m.images) {
        let u: string | 'failed' = 'failed';
        // the service can be busy: try again a few times before giving up on an image
        for (let attempt = 0; attempt < 3 && u === 'failed'; attempt++) {
          try { u = URL.createObjectURL(await (await api.raw(`/api/home/hero/${im.n}/image`)).blob()); }
          catch { await new Promise((r) => setTimeout(r, 10_000)); }
        }
        setUrls((xs) => xs.map((x, k) => (k === im.n ? u : x)));
      }
    } catch { setMeta({ images: [] }); }
  };
  useEffect(() => { load(); }, []);
  const ready = urls.map((u, k) => (u && u !== 'failed' ? k : -1)).filter((k) => k >= 0);
  useEffect(() => {
    if (reduced || ready.length < 2) return;
    const t = setInterval(() => setI((x) => { const pos = ready.indexOf(x); return ready[(pos + 1) % ready.length]; }), 8000);
    return () => clearInterval(t);
  }, [ready.join(','), reduced]);
  const cur = meta?.images?.[i];
  const allFailed = urls.length > 0 && urls.every((u) => u === 'failed');
  return (
    <div className="ai-hero">
      {urls.map((u, k) => u && u !== 'failed' && <img key={k} src={u} alt={meta.images[k][ar ? 'ar' : 'en']} className={k === i ? 'on' : ''} />)}
      {!ready.length && <div className={`ai-hero-wait ${allFailed ? 'failed' : ''}`} />}
      <div className="ai-hero-shade" />
      <div className="ai-hero-text">{children}</div>
      <div className="ai-hero-bar">
        <span className="ai-badge"><Icon name="assistant" size={14} />{ar ? 'صورة مولّدة بالذكاء الاصطناعي' : 'AI-generated image'}</span>
        <span className="ai-caption">{allFailed ? (ar ? 'خدمة توليد الصور غير متاحة الآن' : 'Image service unavailable right now') : !ready.length ? (ar ? 'جارٍ توليد صور اليوم…' : 'Generating today’s images…') : cur ? (ar ? cur.ar : cur.en) : ''}</span>
        <span className="spacer" />
        {meta?.images?.map((_: any, k: number) => (
          <button key={k} className={`ai-dot-btn ${k === i ? 'on' : ''}`} disabled={!urls[k] || urls[k] === 'failed'} onClick={() => setI(k)} aria-label={`image ${k + 1}`} />
        ))}
        {can('engineer') && <button className="btn sm ai-refresh" disabled={busy} onClick={async () => {
          setBusy(true);
          try { await api.post('/api/home/hero/refresh'); urls.forEach((u) => u && u !== 'failed' && URL.revokeObjectURL(u)); await load(); toast(ar ? 'صور جديدة' : 'New images', 'ok'); }
          catch (e: any) { toast(e.message, 'error'); } finally { setBusy(false); }
        }}><Icon name="rotate" size={14} />{ar ? 'صور جديدة' : 'New images'}</button>}
      </div>
    </div>
  );
}

const HUBS = [
  { route: 'design', icon: 'architecture', en: ['Design', 'From a blank page to municipality-ready drawings, submission (Binaa) and shop drawings.'], ar: ['التصميم', 'من الصفر إلى مخططات جاهزة للبلدية، والتقديم عبر بناء، والمخططات التنفيذية.'], cls: 'hub-design' },
  { route: 'review', icon: 'qa', en: ['Review & edit', 'Upload a drawing for checking, fix issues, and close municipality comments with evidence.'], ar: ['مراجعة وتعديل المخططات', 'ارفع مخططاً ليُراجَع ويُعدَّل، وعالج ملاحظات البلدية مع توثيق كل تعديل.'], cls: 'hub-review' },
  { route: 'present', icon: 'report', en: ['Client presentation', 'Build a presentation for any project — with an explanation for every slide.'], ar: ['عرض تقديمي للعميل', 'جهّز عرضاً لأي مشروع أو لملفات ترفعها، مع شرح لكل شريحة.'], cls: 'hub-present' },
];

export function Home() {
  const { me, go } = useApp();
  const { lang } = useT();
  const ar = lang === 'ar';
  const dash = useLoad(() => api.get('/api/dashboard'), []);
  const hour = abuDhabiNow(new Date()).h;
  const greet = ar ? (hour < 12 ? 'صباح الخير' : 'مساء الخير') : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  return (
    <div className="stack home" style={{ gap: 18 }}>
      <AiHero>
        <div className="eyebrow">{me.orgName}</div>
        <h1 className="home-title">{greet}{ar ? '، ' : ', '}{me.name}</h1>
        <p style={{ margin: '4px 0 0', opacity: 0.9 }}>{ar ? 'منصة هندسية لتصميم ومراجعة وعرض مشاريع أبوظبي.' : 'Your engineering workspace for designing, reviewing and presenting Abu Dhabi projects.'}</p>
      </AiHero>
      <div className="home-top">
        <Clock />
        <Weather />
        <Wisdom />
      </div>
      <div className="hub-grid">
        {HUBS.map((h) => (
          <button key={h.route} className={`hub-card ${h.cls}`} onClick={() => go(h.route)}>
            <div className="hub-art" aria-hidden="true"><Icon name={h.icon} size={34} /></div>
            <div className="hub-title">{(ar ? h.ar : h.en)[0]}</div>
            <div className="hub-desc">{(ar ? h.ar : h.en)[1]}</div>
            <div className="hub-go">{ar ? 'ادخل ←' : 'Open →'}</div>
          </button>
        ))}
      </div>
      <div className="grid c2">
        <News />
        <div className="card">
          <div className="card-h"><h3>{ar ? 'أحدث المشاريع' : 'Recent projects'}</h3><span className="spacer" /><a href="#/projects">{ar ? 'الكل' : 'All'} →</a></div>
          {dash.data?.recentProjects.length ? (
            <table className="t"><tbody>{dash.data.recentProjects.map((p: any) => (
              <tr key={p.id} className="click" onClick={() => go(`design/${p.id}`)}><td className="mono ltr">{p.code}</td><td dir="auto">{p.name}</td><td className="faint">{when(p.updated_at)}</td></tr>
            ))}</tbody></table>
          ) : <div className="empty">{ar ? 'لا توجد مشاريع بعد.' : 'No projects yet.'} <a href="#/projects/new">{ar ? 'مشروع جديد' : 'New project'}</a></div>}
        </div>
      </div>
    </div>
  );
}
