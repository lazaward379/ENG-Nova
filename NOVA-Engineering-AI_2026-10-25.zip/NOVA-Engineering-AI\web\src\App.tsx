import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api, getToken, setToken, setUnauthorizedHandler, type Me } from './api';
import { LangContext, translate, type Lang } from './i18n';
import { AppContext, Icon, type Toast } from './ui';
import { Auth } from './screens/Auth';
import { Dashboard } from './screens/Dashboard';
import { Projects, NewProjectWizard } from './screens/Projects';
import { ProjectDetail } from './screens/ProjectDetail';
import { Workspace } from './screens/Workspace';
import { Compliance } from './screens/Compliance';
import { Regulatory } from './screens/Regulatory';
import { Admin, Settings, SystemHealth } from './screens/Org';
import { Documents, Submission, Architecture, Assistant, Review } from './screens/Delivery';
import { Bim, ShopDrawings, Coordination } from './screens/Placeholders';
import { GenerateFromReference } from './screens/Generate';
import { Home } from './screens/Home';
import { DesignHub } from './screens/DesignHub';
import { ReviewHub } from './screens/ReviewHub';
import { PresentationHub } from './screens/PresentationHub';

type NavItem = { route: string; key: string; en: string; icon: string; group: string; tag?: string };
const NAV: NavItem[] = [
  { route: 'home', key: 'nav.home', en: 'Home', icon: 'dashboard', group: '' },
  { route: 'design', key: 'nav.hubDesign', en: 'Design', icon: 'architecture', group: 'main' },
  { route: 'review', key: 'nav.hubReview', en: 'Review & edit', icon: 'qa', group: 'main' },
  { route: 'present', key: 'nav.hubPresent', en: 'Client presentation', icon: 'report', group: 'main' },
  { route: 'projects', key: 'nav.projects', en: 'Projects', icon: 'projects', group: 'tools' },
  { route: 'dashboard', key: 'nav.dashboard', en: 'Activity overview', icon: 'system', group: 'tools' },
  { route: 'intake', key: 'nav.intake', en: 'Plot & document intake', icon: 'intake', group: 'design' },
  { route: 'requirements', key: 'nav.requirements', en: 'Requirements interpreter', icon: 'requirements', group: 'design' },
  { route: 'generate', key: 'nav.generate', en: 'Draw from reference', icon: 'assistant', group: 'design' },
  { route: 'workspace', key: 'nav.workspace', en: 'CAD workspace', icon: 'workspace', group: 'design' },
  { route: 'architecture', key: 'nav.architecture', en: 'Architectural design', icon: 'architecture', group: 'design' },
  { route: 'bim', key: 'nav.bim', en: 'BIM & model viewer', icon: 'bim', group: 'design', tag: 'soon' },
  { route: 'assistant', key: 'nav.assistant', en: 'AI engineering assistant', icon: 'assistant', group: 'design' },
  { route: 'compliance', key: 'nav.compliance', en: 'Compliance center', icon: 'compliance', group: 'verify' },
  { route: 'qa', key: 'nav.qa', en: 'Drawing QA', icon: 'qa', group: 'verify' },
  { route: 'coordination', key: 'nav.coordination', en: 'Structural & MEP coordination', icon: 'coordination', group: 'verify', tag: 'soon' },
  { route: 'regulatory', key: 'nav.regulatory', en: 'Regulatory source library', icon: 'regulatory', group: 'verify' },
  { route: 'shop', key: 'nav.shop', en: 'Shop drawing studio', icon: 'shop', group: 'deliver', tag: 'soon' },
  { route: 'submission', key: 'nav.submission', en: 'Submission packages', icon: 'submission', group: 'deliver' },
  { route: 'documents', key: 'nav.documents', en: 'Documents & revisions', icon: 'documents', group: 'deliver' },
  { route: 'collab', key: 'nav.review', en: 'Collaboration & review', icon: 'review', group: 'deliver' },
  { route: 'admin', key: 'nav.admin', en: 'Organization admin', icon: 'admin', group: 'org' },
  { route: 'settings', key: 'nav.settings', en: 'Settings & integrations', icon: 'settings', group: 'org' },
  { route: 'system', key: 'nav.system', en: 'System health & tasks', icon: 'system', group: 'org' },
];
const GROUPS: Record<string, [string, string]> = { main: ['group.main', 'Main sections'], tools: ['group.tools', 'Workspace'], design:['group.design', 'Design'], verify: ['group.verify', 'Verify'], deliver: ['group.deliver', 'Deliver'], org: ['group.org', 'Organization'] };

const read = (k: string) => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k: string, v: string | null) => { try { v === null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch { /* ignore */ } };
const parseHash = () => (location.hash.replace(/^#\/?/, '') || 'home').split('/');

export function App() {
  const [lang, setLang] = useState<Lang>(() => (read('nova.lang') as Lang) || 'en');
  const [theme, setTheme] = useState(() => read('nova.theme') || 'dark');
  const [me, setMe] = useState<Me | null>(null);
  const [booting, setBooting] = useState(true);
  const [route, setRoute] = useState(parseHash);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [palette, setPalette] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [project, setProjectState] = useState<string | null>(() => read('nova.project'));
  const [drawing, setDrawingState] = useState<string | null>(() => read('nova.drawing'));

  const t = useCallback((key: string, en: string) => translate(lang, key, en), [lang]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    write('nova.lang', lang);
  }, [lang]);
  useEffect(() => { document.documentElement.dataset.theme = theme; write('nova.theme', theme); }, [theme]);
  useEffect(() => {
    const h = () => { setRoute(parseHash()); setMobileNav(false); };
    window.addEventListener('hashchange', h);
    return () => window.removeEventListener('hashchange', h);
  }, []);

  const signOut = useCallback(() => { setToken(null); setMe(null); }, []);
  useEffect(() => {
    setUnauthorizedHandler(signOut);
    if (!getToken()) { setBooting(false); return; }
    api.get<Me>('/api/auth/me').then(setMe).catch(() => setToken(null)).finally(() => setBooting(false));
  }, [signOut]);

  const toast = useCallback((text: string, kind: Toast['kind'] = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((ts) => [...ts, { id, kind, text }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), kind === 'error' ? 8000 : 4000);
  }, []);
  const go = useCallback((r: string) => { location.hash = `#/${r}`; }, []);
  const setProject = (id: string | null) => { setProjectState(id); write('nova.project', id); };
  const setDrawing = (id: string | null) => { setDrawingState(id); write('nova.drawing', id); };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette((p) => !p); }
      if ((e.ctrlKey || e.metaKey) && e.key === '\\') { e.preventDefault(); setCollapsed((c) => !c); }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);

  const ctx = useMemo(() => me && ({
    me, go, toast, theme, project, setProject, drawing, setDrawing,
    can: (min: Me['role']) => ({ viewer: 0, engineer: 1, reviewer: 2, admin: 3 }[me.role] >= { viewer: 0, engineer: 1, reviewer: 2, admin: 3 }[min]),
  }), [me, go, toast, theme, project, drawing]);

  const langCtx = useMemo(() => ({ lang, t }), [lang, t]);

  if (booting) return <div className="empty">…</div>;
  if (!me || !ctx) return (
    <LangContext.Provider value={langCtx}>
      <Background />
      <Auth onSignedIn={(token) => { setToken(token); api.get<Me>('/api/auth/me').then(setMe); }} lang={lang} setLang={setLang} />
    </LangContext.Provider>
  );

  const [r0, r1, r2] = route;
  const page = (() => {
    switch (r0) {
      case 'home': return <Home />;
      case 'design': return <DesignHub projectId={r1} />;
      case 'review': return <ReviewHub projectId={r1} />;
      case 'present': return <PresentationHub />;
      case 'dashboard': return <Dashboard />;
      case 'projects': return r1 === 'new' ? <NewProjectWizard /> : <Projects />;
      case 'project': return <ProjectDetail id={r1} tab={r2 ?? 'intake'} />;
      case 'intake': return project ? <ProjectDetail id={project} tab="intake" /> : <Projects pickFor="intake" />;
      case 'requirements': return project ? <ProjectDetail id={project} tab="requirements" /> : <Projects pickFor="requirements" />;
      case 'workspace': return <Workspace drawingId={r1 ?? drawing} />;
      case 'architecture': return <Architecture />;
      case 'generate': return <GenerateFromReference />;
      case 'bim': return <Bim />;
      case 'assistant': return <Assistant />;
      case 'compliance': return <Compliance scope="all" />;
      case 'qa': return <Compliance scope="drawing_qa" />;
      case 'coordination': return <Coordination />;
      case 'regulatory': return <Regulatory />;
      case 'shop': return <ShopDrawings />;
      case 'submission': return <Submission />;
      case 'documents': return <Documents />;
      case 'collab': return <Review />;
      case 'admin': return <Admin />;
      case 'settings': return <Settings lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} />;
      case 'system': return <SystemHealth />;
      default: return <div className="empty">Not found. <a href="#/home">Home</a></div>;
    }
  })();
  const activeNav = r0 === 'project' ? (r2 === 'requirements' ? 'requirements' : 'intake') : r0;
  const full = r0 === 'workspace';

  const commands = [
    ...NAV.map((n) => ({ label: t(n.key, n.en), hint: 'go', run: () => go(n.route) })),
    { label: t('proj.new', 'New project'), hint: 'action', run: () => go('projects/new') },
    { label: lang === 'ar' ? 'Switch to English' : 'التبديل إلى العربية', hint: 'action', run: () => setLang(lang === 'ar' ? 'en' : 'ar') },
    { label: theme === 'dark' ? 'Light theme' : 'Dark theme', hint: 'action', run: () => setTheme(theme === 'dark' ? 'light' : 'dark') },
    { label: t('common.signOut', 'Sign out'), hint: 'action', run: async () => { await api.post('/api/auth/logout').catch(() => {}); signOut(); } },
  ];

  return (
    <LangContext.Provider value={langCtx}>
      <AppContext.Provider value={ctx}>
        <Background />
        <div className={`shell ${collapsed ? 'collapsed' : ''} ${mobileNav ? 'mobile-nav' : ''}`}>
          <aside className="sidebar" aria-label="Main navigation">
            <div className="brand">
              <svg className="brand-mark" viewBox="0 0 32 32" aria-hidden="true">
                <defs><linearGradient id="bg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#22d3ee" /><stop offset="1" stopColor="#a78bfa" /></linearGradient></defs>
                <rect x="1" y="1" width="30" height="30" rx="8" fill="none" stroke="url(#bg1)" strokeWidth="1.5" />
                <path d="M9 23V9l14 14V9" fill="none" stroke="url(#bg1)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <div className="brand-text"><div className="brand-name">NOVA</div><div className="brand-sub">ENGINEERING AI</div></div>
            </div>
            <nav className="nav">
              {NAV.map((n, i) => (
                <div key={n.route}>
                  {n.group && NAV[i - 1]?.group !== n.group && <div className="nav-group">{t(GROUPS[n.group][0], GROUPS[n.group][1])}</div>}
                  <a href={`#/${n.route}`} className={`nav-item ${activeNav === n.route ? 'active' : ''}`} title={t(n.key, n.en)}>
                    <Icon name={n.icon} /><span>{t(n.key, n.en)}</span>{n.tag && <span className="tag">{n.tag}</span>}
                  </a>
                </div>
              ))}
            </nav>
            <button className="nav-item" style={{ margin: 8, width: 'auto' }} onClick={() => setCollapsed((c) => !c)} title="Ctrl+\">
              <Icon name="menu" /><span>{collapsed ? '' : 'Collapse'}</span>
            </button>
          </aside>
          <div className="main">
            <TopBar onPalette={() => setPalette(true)} lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} signOut={signOut} onMenu={() => setMobileNav((m) => !m)} />
            <main className={`content ${full ? 'full' : ''}`}>{page}</main>
          </div>
        </div>
        {palette && <Palette commands={commands} onClose={() => setPalette(false)} />}
        <div className="toasts" role="status" aria-live="polite">{toasts.map((x) => <div key={x.id} className={`toast ${x.kind}`}>{x.text}</div>)}</div>
      </AppContext.Provider>
    </LangContext.Provider>
  );
}

function TopBar({ onPalette, lang, setLang, theme, setTheme, signOut, onMenu }: { onPalette: () => void; lang: Lang; setLang: (l: Lang) => void; theme: string; setTheme: (t: string) => void; signOut: () => void; onMenu: () => void }) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[] | null>(null);
  const [bell, setBell] = useState<any | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  useEffect(() => { api.get('/api/auth/me').then(setMe).catch(() => {}); }, []);
  useEffect(() => {
    if (!q.trim()) { setResults(null); return; }
    const h = setTimeout(() => api.get(`/api/projects?q=${encodeURIComponent(q)}`).then(setResults).catch(() => setResults([])), 200);
    return () => clearTimeout(h);
  }, [q]);
  const t = (k: string, en: string) => translate(lang, k, en);
  return (
    <header className="topbar">
      <button className="btn ghost icon" onClick={onMenu} aria-label="menu" style={{ display: 'none' }} id="mobile-menu"><Icon name="menu" /></button>
      <div className="search" style={{ position: 'relative' }}>
        <input placeholder={t('common.search', 'Search projects and files…')} value={q} onChange={(e) => setQ(e.target.value)} aria-label="search" />
        {results && (
          <div className="menu" style={{ insetInlineStart: 0, insetInlineEnd: 'auto' }}>
            {results.length ? results.slice(0, 8).map((p) => (
              <a key={p.id} className="mi" style={{ display: 'block' }} href={`#/project/${p.id}/intake`} onClick={() => setQ('')}>
                <b className="ltr mono">{p.code}</b> {p.name} <span className="faint">· {p.documents} docs · {p.drawings} drawings</span>
              </a>
            )) : <div className="mi faint">No matches</div>}
          </div>
        )}
      </div>
      <span className="spacer" />
      <button className="btn ghost sm" onClick={onPalette} title="Ctrl+K"><kbd>Ctrl K</kbd> {t('common.commandPalette', 'Commands')}</button>
      <div style={{ position: 'relative' }}>
        <button className="btn ghost icon" aria-label="notifications" onClick={async () => setBell(bell ? null : (await api.get('/api/dashboard')).recentActivity)}><Icon name="bell" /></button>
        {bell && (
          <div className="menu">
            {bell.length ? bell.map((a: any, i: number) => <div key={i} className="mi"><b>{a.action}</b> <span className="faint">{a.user} · {new Date(a.created_at).toLocaleTimeString()}</span></div>) : <div className="mi faint">No activity</div>}
          </div>
        )}
      </div>
      <button className="btn ghost sm" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} aria-label="language"><Icon name="globe" />{lang === 'ar' ? 'English' : 'العربية'}</button>
      <button className="btn ghost icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="theme"><Icon name={theme === 'dark' ? 'sun' : 'moon'} /></button>
      <div className="row" style={{ gap: 6 }}>
        <div style={{ textAlign: 'end', lineHeight: 1.2 }}>
          <div style={{ fontSize: 13 }}>{me?.name}</div>
          <div className="faint">{me?.orgName} · {me?.role}</div>
        </div>
        <button className="btn ghost icon" aria-label="sign out" title={t('common.signOut', 'Sign out')} onClick={async () => { await api.post('/api/auth/logout').catch(() => {}); signOut(); }}><Icon name="logout" /></button>
      </div>
    </header>
  );
}

function Palette({ commands, onClose }: { commands: { label: string; hint: string; run: () => void }[]; onClose: () => void }) {
  const [q, setQ] = useState('');
  const [i, setI] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => input.current?.focus(), []);
  const list = commands.filter((c) => c.label.toLowerCase().includes(q.toLowerCase()));
  const runAt = (k: number) => { list[k]?.run(); onClose(); };
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="palette" role="dialog" aria-label="Command palette">
        <input ref={input} value={q} placeholder="Type a command or screen…" onChange={(e) => { setQ(e.target.value); setI(0); }}
          onKeyDown={(e) => {
            if (e.key === 'Escape') onClose();
            if (e.key === 'ArrowDown') { e.preventDefault(); setI((x) => Math.min(list.length - 1, x + 1)); }
            if (e.key === 'ArrowUp') { e.preventDefault(); setI((x) => Math.max(0, x - 1)); }
            if (e.key === 'Enter') runAt(i);
          }} />
        <ul>{list.map((c, k) => <li key={c.label} className={k === i ? 'sel' : ''} onMouseEnter={() => setI(k)} onClick={() => runAt(k)}><span>{c.label}</span><span className="spacer" /><span className="faint">{c.hint}</span></li>)}</ul>
      </div>
    </div>
  );
}

/** Lightweight procedural background: CSS gradient field + an SVG node network. */
function Background() {
  const nodes = useMemo(() => {
    let s = 7;
    const rnd = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
    return Array.from({ length: 26 }, () => ({ x: rnd() * 100, y: rnd() * 100 }));
  }, []);
  const edges = nodes.flatMap((a, i) => nodes.slice(i + 1).filter((b) => Math.hypot(a.x - b.x, a.y - b.y) < 22).map((b) => [a, b]));
  return (
    <div className="bg-field" aria-hidden="true">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none">
        {edges.map(([a, b], i) => <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="var(--cyan)" strokeOpacity="0.18" strokeWidth="0.08" />)}
        {nodes.map((n, i) => <circle key={i} cx={n.x} cy={n.y} r="0.25" fill={i % 3 ? 'var(--cyan)' : 'var(--violet)'} fillOpacity="0.5" />)}
      </svg>
    </div>
  );
}
