import type { Entity, EntityInput, Pt, Units } from '../geometry/types.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { arcPoint, pointInPolygon, pointSegmentDistance, polygonArea } from '../geometry/math.ts';
import { closedOnLayer, extractRooms, PLOT_LAYER } from '../geometry/rooms.ts';
import { wallFrame } from '../geometry/hosted.ts';

/**
 * Preliminary layout generation from a reference drawing.
 *
 * NOVA learns the room programme of the reference (closed, labelled room boundaries, their shapes,
 * relative positions and door positions) and re-fits it to a new plot's buildable area with an affine
 * transform (optional 90° rotation + scale + translation). From the fitted rooms it derives typed walls,
 * re-hosts the reference doors, adds windows on external walls, labels and overall dimensions.
 *
 * It is deterministic and every choice is reported as an assumption. It is not an architectural optimiser,
 * does not check regulations, and the result is a PRELIMINARY draft for an engineer to develop.
 */

export type GenerateOptions = {
  setbackM: number;
  mode: 'proportional' | 'fill';
  rotate: 'auto' | 'none' | '90';
  externalWallMm: number;
  internalWallMm: number;
  doorWidthMm: number;
  windowWidthMm: number;
  maxCoveragePct: number | null;
  minScale: number;
  maxScale: number;
};

type Room = { name: string; points: Pt[]; refAreaM2: number };
export type Draft = { rooms: Room[]; plot: Pt[]; buildable: { minX: number; minY: number; maxX: number; maxY: number } };

export class GenerateError extends Error {}

const bboxOf = (pts: Pt[]) => pts.reduce((b, p) => ({ minX: Math.min(b.minX, p.x), minY: Math.min(b.minY, p.y), maxX: Math.max(b.maxX, p.x), maxY: Math.max(b.maxY, p.y) }), { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity });
const r3 = (v: number) => Math.round(v * 1000) / 1000;
const DOOR_LAYER = /DOOR|باب/i;
const NO_WINDOW = /PARK|GARAGE|STORE|STOR|موقف|مخزن|كراج/i;

/** Largest axis-aligned rectangle, shrunk from the plot's bounding box inset, whose corners lie inside the plot. */
function buildableRect(plot: Pt[], setback: number) {
  const b = bboxOf(plot);
  let r = { minX: b.minX + setback, minY: b.minY + setback, maxX: b.maxX - setback, maxY: b.maxY - setback };
  const inside = (q: typeof r) => [{ x: q.minX, y: q.minY }, { x: q.maxX, y: q.minY }, { x: q.maxX, y: q.maxY }, { x: q.minX, y: q.maxY }]
    .every((c) => pointInPolygon(c, plot) && plot.every((p, i) => pointSegmentDistance(c, p, plot[(i + 1) % plot.length]) >= setback - 1e-9));
  for (let k = 0; k < 60 && !inside(r); k++) {
    const cx = (r.minX + r.maxX) / 2, cy = (r.minY + r.maxY) / 2, f = 0.97;
    r = { minX: cx - (cx - r.minX) * f, minY: cy - (cy - r.minY) * f, maxX: cx + (r.maxX - cx) * f, maxY: cy + (r.maxY - cy) * f };
  }
  if (r.maxX <= r.minX || r.maxY <= r.minY || !inside(r)) throw new GenerateError('No buildable area remains inside the plot after applying the setback.');
  return r;
}

export function generateFromReference(ref: { entities: Entity[]; units: Units; name: string }, target: { plot: Pt[]; units: Units }, o: GenerateOptions) {
  const mRef = metresPerUnit(ref.units), mT = metresPerUnit(target.units);
  if (mRef === null) throw new GenerateError('The reference drawing has no units; NOVA cannot know the real size of its rooms.');
  if (mT === null) throw new GenerateError('The target drawing has no units.');
  const assumptions: string[] = [];
  const warnings: string[] = [];

  // ---- 1. learn the reference programme ----
  const refRooms = extractRooms(ref.entities, ref.units).filter((r) => r.valid);
  if (!refRooms.length) throw new GenerateError('The reference drawing has no valid room boundaries (closed polylines on ROOM / SPACE / A-AREA layers). NOVA learns the layout from them.');
  let unnamed = 0;
  const rooms0 = refRooms.map((r) => ({ name: r.name ?? `ROOM ${++unnamed}`, pts: r.points.map((p) => ({ x: p.x * mRef, y: p.y * mRef })), refAreaM2: r.areaM2! }));
  if (unnamed) warnings.push(`${unnamed} reference room(s) had no label and were named ROOM n.`);
  const refDoors = ref.entities.flatMap((e): { centre: Pt; width: number }[] => {
    if (e.type === 'DOOR' && e.geom.p) return [{ centre: { x: e.geom.p.x * mRef, y: e.geom.p.y * mRef }, width: e.geom.width * mRef }];
    if (e.type === 'ARC' && DOOR_LAYER.test(e.layer)) {
      // Door swing arcs: the hinge is the centre and the closed leaf lies along the start angle.
      const closed = arcPoint(e.geom.c, e.geom.r, e.geom.start);
      return [{ centre: { x: (e.geom.c.x + closed.x) / 2 * mRef, y: (e.geom.c.y + closed.y) / 2 * mRef }, width: e.geom.r * mRef }];
    }
    return [];
  });

  // ---- 2. fit to the new plot (all in metres) ----
  const plotM = target.plot.map((p) => ({ x: p.x * mT, y: p.y * mT }));
  const plotAreaM2 = polygonArea(plotM);
  const B = buildableRect(plotM, o.setbackM);
  const R = bboxOf(rooms0.flatMap((r) => r.pts));
  const Rw = R.maxX - R.minX, Rh = R.maxY - R.minY, Bw = B.maxX - B.minX, Bh = B.maxY - B.minY;
  const rotate = o.rotate === '90' || (o.rotate === 'auto' && (Rw >= Rh) !== (Bw >= Bh) && Math.abs(Rw - Rh) > 0.05 * Math.max(Rw, Rh));
  const W = rotate ? Rh : Rw, H = rotate ? Rw : Rh;
  let sx = Bw / W, sy = Bh / H;
  if (o.mode === 'proportional' || sx / sy > 1.25 || sy / sx > 1.25) {
    if (o.mode === 'fill') warnings.push('Filling the buildable area would distort rooms by more than 25%; proportional scaling was used instead.');
    sx = sy = Math.min(sx, sy);
  }
  const refProgrammeM2 = rooms0.reduce((s, r) => s + r.refAreaM2, 0);
  if (o.maxCoveragePct !== null) {
    const cap = Math.sqrt(((o.maxCoveragePct / 100) * plotAreaM2) / (refProgrammeM2 * sx * sy));
    if (cap < 1) { sx *= cap; sy *= cap; assumptions.push(`Scaled down to respect the maximum plot coverage of ${o.maxCoveragePct}% (confirmed project fact).`); }
  }
  const sMax = Math.max(sx, sy), sMin = Math.min(sx, sy);
  if (sMax > o.maxScale) { const k = o.maxScale / sMax; sx *= k; sy *= k; assumptions.push(`Enlargement limited to ×${o.maxScale}; the building does not fill the whole buildable area.`); }
  if (Math.min(sx, sy) < o.minScale) throw new GenerateError(`The reference is too large for this plot: rooms would shrink to ${Math.round(sMin * 100)}% of their size (limit ${Math.round(o.minScale * 100)}%). Choose a smaller reference or a larger plot.`);
  const fw = W * sx, fh = H * sy;
  const ox = B.minX + (Bw - fw) / 2, oy = B.minY + (Bh - fh) / 2;
  assumptions.push('The building is centred in the buildable area; road frontage and entrance orientation were not considered.');
  if (rotate) assumptions.push('The reference layout was rotated 90° to match the plot proportions.');
  const xf = (p: Pt): Pt => {
    const u = rotate ? { x: R.maxY - p.y, y: p.x - R.minX } : { x: p.x - R.minX, y: p.y - R.minY };
    return { x: (ox + u.x * sx) / mT, y: (oy + u.y * sy) / mT };
  };
  const rooms: Room[] = rooms0.map((r) => ({ name: r.name, points: r.pts.map(xf), refAreaM2: r.refAreaM2 }));

  // ---- 3. derive walls from room edges ----
  const eps = 1e-6 * Math.max(fw, fh) / mT;
  const lines = new Map<string, { dir: Pt; n: Pt; off: number; iv: [number, number][] }>();
  for (const r of rooms) for (let i = 0; i < r.points.length; i++) {
    const a = r.points[i], b = r.points[(i + 1) % r.points.length];
    let { dir } = wallFrame({ a, b });
    if (dir.x < -1e-12 || (Math.abs(dir.x) <= 1e-12 && dir.y < 0)) dir = { x: -dir.x, y: -dir.y };
    const n = { x: -dir.y, y: dir.x };
    const off = n.x * a.x + n.y * a.y;
    const key = `${Math.round(Math.atan2(dir.y, dir.x) * 1e6)}|${Math.round(off / eps)}`;
    const L = lines.get(key) ?? { dir, n, off, iv: [] };
    const ta = dir.x * a.x + dir.y * a.y, tb = dir.x * b.x + dir.y * b.y;
    L.iv.push([Math.min(ta, tb), Math.max(ta, tb)]);
    lines.set(key, L);
  }
  const extT = o.externalWallMm / 1000 / mT, intT = o.internalWallMm / 1000 / mT;
  const probe = 1e-4 * Math.max(fw, fh) / mT;
  type WallDraft = { a: Pt; b: Pt; external: boolean; rooms: string[] };
  /** A piece is a stretch of wall with the same room on each side; `from`/`to` are offsets along its wall. */
  type Piece = { wall: number; from: number; to: number; left: string[]; right: string[] };
  const walls: WallDraft[] = [];
  const pieces: Piece[] = [];
  for (const L of lines.values()) {
    const ts = [...new Set(L.iv.flatMap((x) => x))].sort((p, q) => p - q);
    const P = (t: number) => ({ x: L.dir.x * t + L.n.x * L.off, y: L.dir.y * t + L.n.y * L.off });
    type Run = { t0: number; t1: number; external: boolean; rooms: Set<string>; parts: { t0: number; t1: number; left: string[]; right: string[] }[] };
    let cur: Run | null = null;
    const flush = (c: Run | null) => {
      if (!c || c.t1 - c.t0 <= eps) return;
      const w = walls.push({ a: P(c.t0), b: P(c.t1), external: c.external, rooms: [...c.rooms] }) - 1;
      for (const part of c.parts) pieces.push({ wall: w, from: part.t0 - c.t0, to: part.t1 - c.t0, left: part.left, right: part.right });
    };
    for (let k = 0; k + 1 < ts.length; k++) {
      const t0 = ts[k], t1 = ts[k + 1];
      const tm = (t0 + t1) / 2;
      if (!L.iv.some(([p, q]) => p - eps <= tm && tm <= q + eps)) { flush(cur); cur = null; continue; }
      const m = P(tm);
      const side = (s: number) => rooms.filter((r) => pointInPolygon({ x: m.x + L.n.x * probe * s, y: m.y + L.n.y * probe * s }, r.points)).map((r) => r.name);
      const left = side(1), right = side(-1);
      const external = !(left.length && right.length);
      if (cur && cur.external === external && Math.abs(cur.t1 - t0) <= eps) {
        cur.t1 = t1; left.concat(right).forEach((n) => cur!.rooms.add(n)); cur.parts.push({ t0, t1, left, right });
      } else { flush(cur); cur = { t0, t1, external, rooms: new Set([...left, ...right]), parts: [{ t0, t1, left, right }] }; }
    }
    flush(cur);
  }
  assumptions.push(`Room boundaries are used as wall centrelines; external walls ${o.externalWallMm} mm, internal walls ${o.internalWallMm} mm (drafting defaults, not specifications). Net room areas will be slightly smaller.`);

  // ---- 4. openings ----
  type OpeningDraft = { wall: number; type: 'DOOR' | 'WINDOW'; offset: number; width: number };
  const openings: OpeningDraft[] = [];
  const fits = (w: number, offset: number, width: number) => {
    const len = Math.hypot(walls[w].b.x - walls[w].a.x, walls[w].b.y - walls[w].a.y);
    const clear = 0.1 / mT;
    return offset - width / 2 >= clear && offset + width / 2 <= len - clear
      && openings.every((x) => x.wall !== w || Math.abs(x.offset - offset) >= (x.width + width) / 2 + clear);
  };
  const nearestWall = (p: Pt) => {
    let best: { w: number; d: number; offset: number } | null = null;
    walls.forEach((w, i) => {
      const d = pointSegmentDistance(p, w.a, w.b);
      const { dir } = wallFrame(w);
      if (!best || d < best.d) best = { w: i, d, offset: (p.x - w.a.x) * dir.x + (p.y - w.a.y) * dir.y };
    });
    return best as { w: number; d: number; offset: number } | null;
  };
  let doorsMapped = 0, doorsSkipped = 0;
  for (const d of refDoors) {
    const width = Math.min(d.width, o.doorWidthMm / 1000 * 1.5) / mT; // reference door widths are kept (doors do not scale)
    const h = nearestWall(xf(d.centre));
    if (h && h.d <= 1.0 / mT && fits(h.w, h.offset, width)) { openings.push({ wall: h.w, type: 'DOOR', offset: h.offset, width }); doorsMapped++; }
    else doorsSkipped++;
  }
  if (refDoors.length) assumptions.push(`${doorsMapped} door(s) re-hosted from the reference at their equivalent positions; door widths kept from the reference.`);
  if (doorsSkipped) warnings.push(`${doorsSkipped} reference door(s) could not be placed on a generated wall and were skipped.`);
  // Which rooms does a door connect? Read it from the piece it sits on ([] on one side = outside).
  const doorW = o.doorWidthMm / 1000 / mT;
  const pieceAt = (w: number, off: number) => pieces.find((p) => p.wall === w && p.from - eps <= off && off <= p.to + eps);
  const connects = (x: OpeningDraft) => { const p = pieceAt(x.wall, x.offset); return p ? { a: p.left, b: p.right } : { a: [], b: [] }; };
  const doors = () => openings.filter((x) => x.type === 'DOOR');

  // Entrance: keep a reference door on an external wall, otherwise add one to the largest room.
  if (!doors().some((x) => !connects(x).a.length || !connects(x).b.length)) {
    const big = [...rooms].sort((p, q) => q.refAreaM2 - p.refAreaM2)[0];
    const cands = pieces.filter((p) => (p.left.includes(big.name) && !p.right.length) || (p.right.includes(big.name) && !p.left.length)).sort((p, q) => (q.to - q.from) - (p.to - p.from));
    const pick = cands.find((p) => fits(p.wall, (p.from + p.to) / 2, doorW * 1.2));
    if (pick) { openings.push({ wall: pick.wall, type: 'DOOR', offset: (pick.from + pick.to) / 2, width: doorW * 1.2 }); assumptions.push(`An entrance door was added to ${big.name}; its location was not chosen with respect to the road.`); }
    else warnings.push('No entrance door could be placed; add one manually.');
  }

  // Reachability: walk from the outside through doors; connect every unreached room to a reached one.
  let addedDoors = 0;
  for (let guard = 0; guard <= rooms.length; guard++) {
    const reached = new Set<string>();
    let grew = true;
    while (grew) {
      grew = false;
      for (const d of doors()) {
        const { a, b } = connects(d);
        const aIn = !a.length || a.some((n) => reached.has(n)), bIn = !b.length || b.some((n) => reached.has(n));
        for (const [side, other] of [[a, bIn], [b, aIn]] as [string[], boolean][]) if (other) for (const n of side) if (!reached.has(n)) { reached.add(n); grew = true; }
      }
    }
    const missing = rooms.filter((r) => !reached.has(r.name));
    if (!missing.length) break;
    // shared stretches between a reached and an unreached room, longest first
    const cands = pieces.filter((p) => p.left.length && p.right.length && missing.some((r) => p.left.includes(r.name) || p.right.includes(r.name))
      && (reached.size === 0 || [...p.left, ...p.right].some((n) => reached.has(n)))).sort((p, q) => (q.to - q.from) - (p.to - p.from));
    const pick = cands.find((p) => fits(p.wall, (p.from + p.to) / 2, doorW));
    if (!pick) { warnings.push(`No door could connect ${missing.map((r) => r.name).join(', ')}; add one manually.`); break; }
    openings.push({ wall: pick.wall, type: 'DOOR', offset: (pick.from + pick.to) / 2, width: doorW });
    addedDoors++;
  }
  if (addedDoors) assumptions.push(`${addedDoors} internal door(s) of ${o.doorWidthMm} mm were added at the middle of shared walls so that every room is reachable from the entrance; review circulation.`);
  let windows = 0;
  const winW = o.windowWidthMm / 1000 / mT;
  for (const p of pieces) {
    const inside = p.left.length ? p.left : p.right;
    if ((p.left.length && p.right.length) || inside.length !== 1 || NO_WINDOW.test(inside[0])) continue;
    const len = p.to - p.from;
    const width = Math.min(winW, len * 0.5);
    for (const f of [0.5, 0.25, 0.75]) {
      const off = p.from + len * f;
      if (width >= 0.6 / mT && fits(p.wall, off, width)) { openings.push({ wall: p.wall, type: 'WINDOW', offset: off, width }); windows++; break; }
    }
  }
  assumptions.push(`${windows} window(s) of up to ${o.windowWidthMm} mm were placed on external walls of habitable rooms (one per wall); sizes are placeholders, not daylight or ventilation calculations.`);

  // ---- 5. assemble drawing primitives ----
  const fpPts = rooms.flatMap((r) => r.points);
  const fb = bboxOf(fpPts);
  const toM = (v: number) => v * mT;
  const roomsOut = rooms.map((r) => ({ name: r.name, areaM2: r3(polygonArea(r.points) * mT * mT), refAreaM2: r3(r.refAreaM2) }));
  const textH = 0.25 / mT;
  const roomEntities: EntityInput[] = rooms.flatMap((r, i) => {
    const c = r.points.reduce((s, p) => ({ x: s.x + p.x / r.points.length, y: s.y + p.y / r.points.length }), { x: 0, y: 0 });
    return [
      { type: 'POLYLINE', layer: 'A-ROOM', geom: { points: r.points, closed: true } } as EntityInput,
      { type: 'TEXT', layer: 'A-ANNO-TEXT', geom: { p: { x: c.x - textH * 3, y: c.y }, h: textH, rot: 0, text: r.name } } as EntityInput,
      { type: 'TEXT', layer: 'A-ANNO-AREA', geom: { p: { x: c.x - textH * 3, y: c.y - textH * 1.6 }, h: textH * 0.8, rot: 0, text: `${roomsOut[i].areaM2.toFixed(2)} m²` } } as EntityInput,
    ];
  });
  const dimOff = 1.2 / mT, tick = 0.15 / mT;
  const dims: EntityInput[] = [
    { type: 'LINE', layer: 'A-DIMS', geom: { a: { x: fb.minX, y: fb.minY - dimOff }, b: { x: fb.maxX, y: fb.minY - dimOff } } },
    { type: 'LINE', layer: 'A-DIMS', geom: { a: { x: fb.minX, y: fb.minY - dimOff - tick }, b: { x: fb.minX, y: fb.minY - dimOff + tick } } },
    { type: 'LINE', layer: 'A-DIMS', geom: { a: { x: fb.maxX, y: fb.minY - dimOff - tick }, b: { x: fb.maxX, y: fb.minY - dimOff + tick } } },
    { type: 'TEXT', layer: 'A-DIMS', geom: { p: { x: (fb.minX + fb.maxX) / 2 - textH * 2, y: fb.minY - dimOff - textH * 1.6 }, h: textH, rot: 0, text: `${toM(fb.maxX - fb.minX).toFixed(2)} m` } },
    { type: 'LINE', layer: 'A-DIMS', geom: { a: { x: fb.minX - dimOff, y: fb.minY }, b: { x: fb.minX - dimOff, y: fb.maxY } } },
    { type: 'LINE', layer: 'A-DIMS', geom: { a: { x: fb.minX - dimOff - tick, y: fb.minY }, b: { x: fb.minX - dimOff + tick, y: fb.minY } } },
    { type: 'LINE', layer: 'A-DIMS', geom: { a: { x: fb.minX - dimOff - tick, y: fb.maxY }, b: { x: fb.minX - dimOff + tick, y: fb.maxY } } },
    { type: 'TEXT', layer: 'A-DIMS', geom: { p: { x: fb.minX - dimOff - textH * 0.5, y: (fb.minY + fb.maxY) / 2 - textH * 2 }, h: textH, rot: 90, text: `${toM(fb.maxY - fb.minY).toFixed(2)} m` } },
  ];
  const pb = bboxOf(target.plot);
  const note: EntityInput = { type: 'TEXT', layer: 'A-ANNO-NOTE', geom: { p: { x: pb.minX, y: pb.maxY + textH * 2 }, h: textH * 1.2, rot: 0, text: `PRELIMINARY - GENERATED FROM REFERENCE "${ref.name}" - NOT FOR CONSTRUCTION OR SUBMISSION` } };

  const footprintAreaM2 = r3(roomsOut.reduce((s, r) => s + r.areaM2, 0));
  // Building outline = the loop(s) formed by external wall centrelines (not the bounding box, which would
  // wrongly include courtyards or notches that belong to no room).
  const outlines = traceLoops(walls.filter((w) => w.external).map((w) => [w.a, w.b] as [Pt, Pt]), eps);
  if (!outlines.length) warnings.push('The building outline could not be traced from the external walls.');
  return {
    walls: walls.map((w) => ({ type: 'WALL', layer: 'A-WALL', geom: { a: w.a, b: w.b, thickness: w.external ? extT : intT } }) as EntityInput),
    openings,
    other: [...outlines.map((pts) => ({ type: 'POLYLINE', layer: 'A-BLDG-OUTL', geom: { points: pts, closed: true } }) as EntityInput), ...roomEntities, ...dims, note],
    report: {
      reference: ref.name,
      transform: { rotated90: rotate, scaleX: r3(sx), scaleY: r3(sy), buildable_m: { width: r3(Bw), depth: r3(Bh) }, footprint_m: { width: r3(fw), depth: r3(fh) } },
      plotAreaM2: r3(plotAreaM2), footprintAreaM2, coveragePct: r3((footprintAreaM2 / plotAreaM2) * 100),
      rooms: roomsOut,
      counts: { rooms: rooms.length, walls: walls.length, doors: openings.filter((x) => x.type === 'DOOR').length, windows },
      assumptions, warnings,
    },
  };
}

/** Chain segments that share endpoints into closed loops, dropping collinear intermediate vertices. */
export function traceLoops(segs: [Pt, Pt][], eps: number): Pt[][] {
  const key = (p: Pt) => `${Math.round(p.x / eps)}|${Math.round(p.y / eps)}`;
  const adj = new Map<string, { p: Pt; seg: number }[]>();
  segs.forEach(([a, b], i) => {
    for (const [p, q] of [[a, b], [b, a]] as [Pt, Pt][]) {
      const k = key(p);
      (adj.get(k) ?? adj.set(k, []).get(k)!).push({ p: q, seg: i });
    }
  });
  const used = new Set<number>();
  const loops: Pt[][] = [];
  for (let s = 0; s < segs.length; s++) {
    if (used.has(s)) continue;
    const loop: Pt[] = [segs[s][0]];
    let cur = segs[s][1];
    used.add(s);
    for (let guard = 0; guard < segs.length; guard++) {
      if (key(cur) === key(loop[0])) break;
      loop.push(cur);
      const next = (adj.get(key(cur)) ?? []).find((n) => !used.has(n.seg));
      if (!next) { loop.length = 0; break; }
      used.add(next.seg);
      cur = next.p;
    }
    if (loop.length < 3) continue;
    const simple = loop.filter((p, i) => {
      const a = loop[(i - 1 + loop.length) % loop.length], b = loop[(i + 1) % loop.length];
      return Math.abs((p.x - a.x) * (b.y - a.y) - (p.y - a.y) * (b.x - a.x)) > eps * Math.hypot(b.x - a.x, b.y - a.y);
    });
    if (simple.length >= 3 && polygonArea(simple) > eps * eps) loops.push(simple);
  }
  return loops.sort((p, q) => polygonArea(q) - polygonArea(p));
}

export function plotFrom(entities: Entity[]) {
  const plots = closedOnLayer(entities, PLOT_LAYER);
  if (plots.length !== 1) throw new GenerateError(plots.length ? 'The target drawing has more than one plot boundary.' : 'The target drawing has no closed plot boundary (PLOT / BOUNDARY layer).');
  return plots[0].geom.points;
}
