import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, useApp, useLoad } from '../ui';

/** Builds a client presentation for any project (or for files uploaded right here) and explains every slide. */
export function PresentationHub() {
  const { project, setProject, toast, can } = useApp();
  const { lang } = useT();
  const ar = lang === 'ar';
  const projects = useLoad(() => api.get('/api/projects'), []);
  const [pid, setPid] = useState<string>(project ?? '');
  const detail = useLoad(() => (pid ? api.get(`/api/projects/${pid}`) : Promise.resolve(null)), [pid]);
  const [drawing, setDrawing] = useState('');
  const [deckLang, setDeckLang] = useState<'ar' | 'en'>(ar ? 'ar' : 'en');
  const [busy, setBusy] = useState('');
  const [deck, setDeck] = useState<any | null>(null);
  const [i, setI] = useState(0);
  const [newName, setNewName] = useState('');
  const files = useRef<HTMLInputElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  useEffect(() => { setDrawing(''); setDeck(null); if (pid) setProject(pid); }, [pid]);

  const fromFiles = async (list: FileList | null) => {
    if (!list?.length) return;
    setBusy('upload');
    try {
      let target = pid;
      if (!target) {
        const code = `PRS-${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}`;
        target = (await api.post('/api/projects', { code, name: newName.trim() || (ar ? 'مشروع للعرض' : 'Presentation project'), project_type: 'presentation' })).id;
      }
      for (const f of Array.from(list)) {
        try { const r = await api.upload(`/api/projects/${target}/documents`, f); toast(`${f.name}: ${r.extraction_status}`, r.extraction_status === 'failed' ? 'error' : 'ok'); }
        catch (e: any) { toast(`${f.name}: ${e.message}`, 'error'); }
      }
      await projects.reload(); setPid(target); detail.reload();
    } finally { setBusy(''); }
  };
  const generate = async () => {
    setBusy('gen');
    try { const r = await api.post(`/api/projects/${pid}/presentation`, { lang: deckLang, drawing_id: drawing || null }); setDeck(r); setI(0); toast(ar ? `تم تجهيز ${r.slides.length} شرائح` : `${r.slides.length} slides ready`, 'ok'); }
    catch (e: any) { toast(e.message, 'error'); } finally { setBusy(''); }
  };
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (!deck || (e.target as HTMLElement)?.closest('input, textarea, select')) return;
      // arrows follow the reading direction: in an Arabic deck the left arrow moves forward
      const step = e.key === 'PageDown' ? 1 : e.key === 'PageUp' ? -1 : e.key === 'ArrowRight' ? (deckLang === 'ar' ? -1 : 1) : e.key === 'ArrowLeft' ? (deckLang === 'ar' ? 1 : -1) : 0;
      if (step) setI((x) => Math.max(0, Math.min(deck.slides.length - 1, x + step)));
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [deck, deckLang]);

  const s = deck?.slides[i];
  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="section-hero hub-present">
        <div><div className="eyebrow">{ar ? 'القسم الثالث' : 'Section 3'}</div><h1>{ar ? 'عرض تقديمي للعميل' : 'Client presentation'}</h1>
          <p className="muted" style={{ margin: 0 }}>{ar ? 'اختر مشروعاً أو ارفع ملفاته، ويجهّز NOVA عرضاً من بيانات المشروع الحقيقية مع شرح لكل شريحة تقوله للعميل.' : 'Pick a project or upload its files; NOVA builds a deck from the real project data, with what to say on every slide.'}</p></div>
      </div>

      <div className="grid c2">
        <div className="card stack">
          <h3>1. {ar ? 'المشروع' : 'Project'}</h3>
          <select value={pid} onChange={(e) => setPid(e.target.value)}>
            <option value="">{ar ? '— مشروع جديد من ملفات أرفعها —' : '— new project from files I upload —'}</option>
            {projects.data?.map((p: any) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
          </select>
          {!pid && <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder={ar ? 'اسم المشروع الجديد' : 'New project name'} dir="auto" />}
          <button className="btn" disabled={!!busy || !can('engineer')} onClick={() => files.current?.click()}><Icon name="intake" />{busy === 'upload' ? '…' : pid ? (ar ? 'أضف ملفات للمشروع (DXF, DWG, PDF, صور)' : 'Add files to this project (DXF, DWG, PDF, images)') : (ar ? 'ارفع ملفات المشروع' : 'Upload the project files')}</button>
          <input ref={files} type="file" hidden multiple accept=".dxf,.dwg,.pdf,.png,.jpg,.jpeg,.csv,.xlsx,.docx,.ifc" onChange={(e) => { fromFiles(e.target.files); e.target.value = ''; }} />
          {detail.data && <div className="faint">{detail.data.documents.length} {ar ? 'ملفات' : 'files'} · {detail.data.drawings.length} {ar ? 'مخططات' : 'drawings'} · {detail.data.facts.length} {ar ? 'بيانات' : 'facts'}</div>}
        </div>
        <div className="card stack">
          <h3>2. {ar ? 'إعداد العرض' : 'Deck settings'}</h3>
          <div className="row">
            <label className="field" style={{ flex: 1 }}>{ar ? 'المخطط المستخدم' : 'Drawing to show'}
              <select value={drawing} onChange={(e) => setDrawing(e.target.value)}>
                <option value="">{ar ? 'تلقائي (الأكمل)' : 'Automatic (most complete)'}</option>
                {detail.data?.drawings.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select></label>
            <label className="field" style={{ width: 140 }}>{ar ? 'لغة العرض' : 'Deck language'}
              <select value={deckLang} onChange={(e) => setDeckLang(e.target.value as any)}><option value="ar">العربية</option><option value="en">English</option></select></label>
          </div>
          <button className="btn primary" disabled={!pid || !!busy || !can('engineer')} onClick={generate}><Icon name="report" />{busy === 'gen' ? '…' : ar ? 'جهّز العرض' : 'Build presentation'}</button>
          <div className="faint">{ar ? 'المحتوى مأخوذ من بيانات المشروع فقط؛ ما ينقص يظهر كـ"غير متوفر" بدل اختلاقه.' : 'Content comes only from the project data; anything missing is shown as missing, never invented.'}</div>
        </div>
      </div>

      {deck && s && (
        <div className="deck">
          <div className="deck-main">
            <div ref={stage} className={`slide slide-${s.kind}`} dir={deckLang === 'ar' ? 'rtl' : 'ltr'}>
              {s.kind === 'cover' || s.kind === 'close' ? (
                <div className="slide-cover"><h2 dir="auto">{s.title}</h2>{s.subtitle && <div className="slide-sub">{s.subtitle}</div>}{s.bullets.map((b: string) => <div key={b} className="slide-meta">{b}</div>)}</div>
              ) : <>
                <div className="slide-head">{s.title}</div>
                <div className={`slide-body ${s.svg || s.table ? 'two' : ''}`}>
                  <ul>{s.bullets.map((b: string, k: number) => <li key={k} dir="auto">{b}</li>)}</ul>
                  {s.svg && <div className="slide-visual" dangerouslySetInnerHTML={{ __html: s.svg }} />}
                  {!s.svg && s.table && <table className="slide-table"><thead><tr>{s.table.head.map((h: string) => <th key={h}>{h}</th>)}</tr></thead>
                    <tbody>{s.table.rows.map((r: string[], k: number) => <tr key={k}>{r.map((c, n) => <td key={n} dir="auto">{c}</td>)}</tr>)}</tbody></table>}
                </div>
                <div className="slide-foot">NOVA Engineering AI · PRELIMINARY · {i + 1}/{deck.slides.length}</div>
              </>}
            </div>
            <div className="row" style={{ justifyContent: 'center', marginTop: 10 }}>
              <button className="btn" onClick={() => setI(Math.max(0, i - 1))} disabled={i === 0}>{ar ? 'السابق' : 'Previous'}</button>
              <span className="mono">{i + 1} / {deck.slides.length}</span>
              <button className="btn" onClick={() => setI(Math.min(deck.slides.length - 1, i + 1))} disabled={i === deck.slides.length - 1}>{ar ? 'التالي' : 'Next'}</button>
              <button className="btn" onClick={() => stage.current?.requestFullscreen?.()}><Icon name="fit" />{ar ? 'عرض بملء الشاشة' : 'Present full screen'}</button>
              <button className="btn primary" onClick={() => api.download(`/api/documents/${deck.document.id}/download`, deck.document.name).catch((e) => toast(e.message, 'error'))}><Icon name="download" />PowerPoint</button>
            </div>
          </div>
          <aside className="card deck-notes">
            <div className="eyebrow">{ar ? 'الشرح — ماذا تقول للعميل' : 'Explanation — what to say'}</div>
            <p dir={deckLang === 'ar' ? 'rtl' : 'ltr'} style={{ lineHeight: 1.8 }}>{s.notes}</p>
            <div className="faint">{ar ? 'هذا الشرح موجود أيضاً في ملاحظات المتحدث داخل ملف PowerPoint.' : 'The same explanation is in the PowerPoint speaker notes.'}</div>
            <div className="deck-thumbs">
              {deck.slides.map((x: any, k: number) => <button key={k} className={`thumb ${k === i ? 'on' : ''}`} onClick={() => setI(k)}><span className="mono">{k + 1}</span> <span dir="auto">{x.title}</span></button>)}
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
