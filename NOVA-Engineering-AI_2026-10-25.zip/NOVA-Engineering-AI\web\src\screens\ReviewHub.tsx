import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, Status, useApp, useLoad, when } from '../ui';

const SRC: Record<string, [string, string, string]> = {
  municipality: ['Municipality', 'البلدية', 'c-unresolved'], client: ['Client', 'العميل', 'c-extracted'], internal: ['Internal', 'داخلي', ''], nova_check: ['NOVA check', 'فحص NOVA', 'c-ai_suggestion'],
};
const ST: Record<string, [string, string]> = { open: ['Open', 'مفتوحة'], in_progress: ['In progress', 'قيد المعالجة'], resolved: ['Resolved', 'تمت المعالجة'], not_applicable: ['Not applicable', 'لا تنطبق'] };

export function ReviewHub({ projectId }: { projectId?: string }) {
  const { project, setProject, go, toast, can } = useApp();
  const { lang } = useT();
  const ar = lang === 'ar';
  const pid = projectId ?? project;
  useEffect(() => { if (projectId) setProject(projectId); }, [projectId]);
  const projects = useLoad(() => api.get('/api/projects'), []);
  const p = useLoad(() => (pid ? api.get(`/api/projects/${pid}`) : Promise.resolve(null)), [pid]);
  const comments = useLoad(() => (pid ? api.get(`/api/projects/${pid}/comments`) : Promise.resolve([])), [pid]);
  const [drawing, setDrawing] = useState<string>('');
  const [run, setRun] = useState<any | null>(null);
  const [busy, setBusy] = useState('');
  const [paste, setPaste] = useState({ source: 'municipality', prefix: '', text: '' });
  const [filter, setFilter] = useState('active');
  const file = useRef<HTMLInputElement>(null);
  useEffect(() => { setDrawing(p.data?.drawings[0]?.id ?? ''); setRun(null); }, [p.data?.id]);

  const quickProject = async () => {
    const code = `REV-${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}`;
    const r = await api.post('/api/projects', { code, name: ar ? 'مراجعة مخطط' : 'Drawing review', project_type: 'review' });
    go(`review/${r.id}`);
  };
  const upload = async (files: FileList | null) => {
    if (!files?.length || !pid) return;
    setBusy('upload');
    for (const f of Array.from(files)) {
      try { const r = await api.upload(`/api/projects/${pid}/documents`, f); toast(`${f.name}: ${r.extraction_status}`, r.extraction_status === 'failed' ? 'error' : 'ok'); if (r.drawingId) setDrawing(r.drawingId); }
      catch (e: any) { toast(e.message, 'error'); }
    }
    setBusy(''); p.reload();
  };
  const review = async () => {
    setBusy('review');
    try { setRun(await api.post(`/api/drawings/${drawing}/compliance-runs`, {})); } catch (e: any) { toast(e.message, 'error'); } finally { setBusy(''); }
  };
  const toComments = async () => {
    try { const r = await api.post(`/api/drawings/${drawing}/comments-from-checks`); toast(ar ? `أضيفت ${r.added} ملاحظة` : `${r.added} comment(s) added`, 'ok'); comments.reload(); } catch (e: any) { toast(e.message, 'error'); }
  };
  const addPasted = async () => {
    try {
      const r = await api.post(`/api/projects/${pid}/comments`, { source: paste.source, drawing_id: drawing || null, text: paste.text, reference_prefix: paste.prefix });
      toast(ar ? `أضيفت ${r.added} ملاحظة` : `${r.added} comment(s) added`, 'ok'); setPaste({ ...paste, text: '' }); comments.reload();
    } catch (e: any) { toast(e.message, 'error'); }
  };
  const list = (comments.data ?? []).filter((c: any) => filter === 'all' || (filter === 'active' ? ['open', 'in_progress'].includes(c.status) : c.source === filter));
  const openCount = (comments.data ?? []).filter((c: any) => ['open', 'in_progress'].includes(c.status)).length;

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="section-hero hub-review">
        <div><div className="eyebrow">{ar ? 'القسم الثاني' : 'Section 2'}</div><h1>{ar ? 'مراجعة وتعديل المخططات' : 'Review & edit drawings'}</h1>
          <p className="muted" style={{ margin: 0 }}>{ar ? 'ارفع مخططاً ليُراجَع، عدّل ما يلزم، وعالج ملاحظات البلدية واحدة واحدة مع توثيق التعديلات.' : 'Upload a drawing to review, fix what is needed, and close municipality comments one by one with documented changes.'}</p></div>
        <span className="spacer" />
        <div className="row">
          <select value={pid ?? ''} onChange={(e) => go(e.target.value ? `review/${e.target.value}` : 'review')} style={{ minWidth: 240 }} aria-label="project">
            <option value="">{ar ? '— اختر مشروعاً —' : '— choose a project —'}</option>
            {projects.data?.map((x: any) => <option key={x.id} value={x.id}>{x.code} — {x.name}</option>)}
          </select>
          {can('engineer') && <button className="btn" onClick={quickProject}><Icon name="plus" />{ar ? 'مراجعة جديدة' : 'New review'}</button>}
        </div>
      </div>

      {!pid ? <div className="card empty">{ar ? 'اختر مشروعاً أو ابدأ مراجعة جديدة ثم ارفع المخطط.' : 'Choose a project or start a new review, then upload the drawing.'}</div>
        : !p.data ? <Loading error={p.error} loading={p.loading} /> : <>
          <div className="grid c2">
            <div className="card stack">
              <h3>1. {ar ? 'المخطط' : 'Drawing'}</h3>
              <div className="row">
                <select value={drawing} onChange={(e) => { setDrawing(e.target.value); setRun(null); }} style={{ flex: 1 }}>
                  {!p.data.drawings.length && <option value="">{ar ? 'لا يوجد مخطط بعد' : 'No drawing yet'}</option>}
                  {p.data.drawings.map((d: any) => <option key={d.id} value={d.id}>{d.name} ({d.entities})</option>)}
                </select>
                <button className="btn" onClick={() => file.current?.click()} disabled={!!busy || !can('engineer')}><Icon name="intake" />{ar ? 'رفع DXF / DWG' : 'Upload DXF / DWG'}</button>
                <input ref={file} type="file" hidden accept=".dxf,.dwg,.pdf" multiple onChange={(e) => { upload(e.target.files); e.target.value = ''; }} />
              </div>
              <div className="row">
                <button className="btn primary" disabled={!drawing || !!busy} onClick={review}><Icon name="play" />{busy === 'review' ? '…' : ar ? 'راجع المخطط' : 'Review drawing'}</button>
                <button className="btn" disabled={!drawing} onClick={() => go(`workspace/${drawing}`)}><Icon name="workspace" />{ar ? 'افتح للتعديل' : 'Open to edit'}</button>
              </div>
              {run && <div className="stack" style={{ gap: 6 }}>
                <div className="row">{Object.entries(run.summary).map(([s, n]) => <span key={s} className="row" style={{ gap: 3 }}><Status s={s} /><span className="faint">{n as number}</span></span>)}</div>
                {run.findings.filter((f: any) => ['FAIL', 'WARNING'].includes(f.status)).slice(0, 6).map((f: any) => <div key={f.id} className="faint" dir="auto">• {f.rule_code}: {f.message}</div>)}
                <div className="row">
                  <button className="btn sm" onClick={toComments} disabled={!can('engineer')}>{ar ? 'حوّل الملاحظات إلى قائمة متابعة' : 'Track issues as comments'}</button>
                  <button className="btn sm ghost" onClick={() => api.openHtml(`/api/compliance-runs/${run.id}/report`)}>{ar ? 'التقرير' : 'Report'}</button>
                </div>
              </div>}
            </div>
            <div className="card stack">
              <h3>2. {ar ? 'ملاحظات البلدية أو العميل' : 'Municipality / client comments'}</h3>
              <div className="row">
                <select value={paste.source} onChange={(e) => setPaste({ ...paste, source: e.target.value })} style={{ width: 150 }}>
                  {['municipality', 'client', 'internal'].map((s) => <option key={s} value={s}>{ar ? SRC[s][1] : SRC[s][0]}</option>)}
                </select>
                <input value={paste.prefix} onChange={(e) => setPaste({ ...paste, prefix: e.target.value })} placeholder={ar ? 'بادئة الرقم، مثال DMT-' : 'Ref. prefix, e.g. DMT-'} style={{ width: 170 }} dir="ltr" />
              </div>
              <textarea rows={6} dir="auto" value={paste.text} onChange={(e) => setPaste({ ...paste, text: e.target.value })}
                placeholder={ar ? 'الصق نص خطاب الملاحظات هنا — كل سطر ملاحظة مستقلة، والترقيم (1- أو ١.) يُحفظ كرقم مرجعي.' : 'Paste the comments letter — one comment per line; numbering like "1-" is kept as the reference.'} />
              <button className="btn primary" disabled={paste.text.trim().length < 2 || !can('engineer')} onClick={addPasted}>{ar ? 'أضف الملاحظات' : 'Add comments'}</button>
            </div>
          </div>

          <div className="card">
            <div className="card-h">
              <h3>3. {ar ? 'متابعة الملاحظات' : 'Comment tracker'}</h3><span className="chip">{openCount} {ar ? 'مفتوحة' : 'open'}</span><span className="spacer" />
              <select value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: 170 }}>
                <option value="active">{ar ? 'المفتوحة فقط' : 'Open only'}</option><option value="all">{ar ? 'الكل' : 'All'}</option>
                {Object.keys(SRC).map((s) => <option key={s} value={s}>{ar ? SRC[s][1] : SRC[s][0]}</option>)}
              </select>
              <button className="btn sm" onClick={() => api.openHtml(`/api/projects/${pid}/comments/response-sheet`).catch((e) => toast(e.message, 'error'))}><Icon name="report" />{ar ? 'جدول الرد على الملاحظات' : 'Response sheet'}</button>
            </div>
            {!list.length ? <div className="empty">{ar ? 'لا توجد ملاحظات هنا.' : 'Nothing here.'}</div> : list.map((c: any) => <CommentRow key={c.id} c={c} ar={ar} onChange={comments.reload} />)}
          </div>
        </>}
    </div>
  );
}

function CommentRow({ c, ar, onChange }: { c: any; ar: boolean; onChange: () => void }) {
  const { toast, go, can } = useApp();
  const [response, setResponse] = useState(c.response);
  const closed = ['resolved', 'not_applicable'].includes(c.status);
  const save = async (status?: string) => {
    try { await api.patch(`/api/comments/${c.id}`, { response, ...(status ? { status } : {}) }); onChange(); toast(ar ? 'تم الحفظ' : 'Saved', 'ok'); } catch (e: any) { toast(e.message, 'error'); }
  };
  const fix = () => {
    // hand the comment to the copilot in the workspace; the user selects the elements and sends
    try { sessionStorage.setItem('nova.copilotDraft', c.text); } catch { /* storage unavailable */ }
    go(`workspace/${c.drawing_id}`);
  };
  return (
    <div className={`comment-row ${closed ? 'closed' : ''}`}>
      <div className="row" style={{ gap: 8 }}>
        <b className="mono ltr">{c.reference}</b><span className={`chip ${SRC[c.source][2]}`}>{ar ? SRC[c.source][1] : SRC[c.source][0]}</span>
        <span className={`chip ${closed ? 'c-confirmed' : c.status === 'in_progress' ? 'c-assumption' : 'c-unresolved'}`}>{ar ? ST[c.status][1] : ST[c.status][0]}</span>
        <span className="spacer" /><span className="faint">{c.drawing_name ?? ''} · {when(c.created_at)}</span>
      </div>
      <div style={{ margin: '6px 0' }} dir="auto">{c.text}</div>
      <textarea rows={2} dir="auto" value={response} disabled={closed || !can('engineer')} onChange={(e) => setResponse(e.target.value)} placeholder={ar ? 'الرد / ما تم تعديله…' : 'Response / what was changed…'} style={{ minHeight: 48 }} />
      {c.operations.length > 0 && <div className="faint" style={{ marginTop: 4 }}>{ar ? 'تعديلات موثقة على المخطط:' : 'Documented drawing changes:'} {c.operations.map((o: any) => `#${o.seq} ${o.kind}${o.source === 'ai' ? (ar ? ' (المساعد)' : ' (copilot)') : ''}`).join(' · ')}</div>}
      {can('engineer') && <div className="row" style={{ marginTop: 6 }}>
        {!closed && c.drawing_id && <button className="btn sm" onClick={fix}><Icon name="assistant" />{ar ? 'عدّلها مع المساعد' : 'Fix with copilot'}</button>}
        {!closed && c.status === 'open' && <button className="btn sm ghost" onClick={() => save('in_progress')}>{ar ? 'قيد المعالجة' : 'Mark in progress'}</button>}
        {!closed && <button className="btn sm ghost" onClick={() => save()}>{ar ? 'حفظ الرد' : 'Save response'}</button>}
        {!closed && <button className="btn sm primary" disabled={!response.trim()} onClick={() => save('resolved')}><Icon name="check" />{ar ? 'تمت المعالجة' : 'Resolve'}</button>}
        {!closed && <button className="btn sm ghost" disabled={!response.trim()} onClick={() => save('not_applicable')}>{ar ? 'لا تنطبق' : 'Not applicable'}</button>}
        {closed && <button className="btn sm ghost" onClick={() => save('open')}>{ar ? 'إعادة فتح' : 'Reopen'}</button>}
      </div>}
    </div>
  );
}
