import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../src/app.ts';

let app: FastifyInstance, dir: string, token = '', projectId = '', pkg: any;

const call = async (method: string, url: string, body?: unknown, tk = token) => {
  const res = await app.inject({ method: method as any, url, payload: body as any, headers: { authorization: `Bearer ${tk}` } });
  let json: any = null; try { json = res.json(); } catch { /* html */ }
  return { status: res.statusCode, json, body: res.body };
};
async function upload(name: string, content: string) {
  const b = '----x' + Math.random().toString(16).slice(2);
  const payload = Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="file"; filename="${name}"\r\nContent-Type: application/octet-stream\r\n\r\n${content}\r\n--${b}--\r\n`);
  return (await app.inject({ method: 'POST', url: `/api/projects/${projectId}/documents`, payload, headers: { 'content-type': `multipart/form-data; boundary=${b}`, authorization: `Bearer ${token}` } })).json();
}

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'nova-binaa-'));
  ({ app } = await buildApp({ dbPath: ':memory:', storageDir: join(dir, 's') }));
  token = (await app.inject({ method: 'POST', url: '/api/auth/register', payload: { orgName: 'Binaa Co', name: 'B', email: 'b@example.test', password: 'long-enough-pass' } })).json().token;
  projectId = (await call('POST', '/api/projects', { code: 'B1', name: 'Villa' })).json.id;
});
after(async () => { await app.close(); rmSync(dir, { recursive: true, force: true }); });

test('integration info is honest: manual, no API, official entry points and sources', async () => {
  const r = (await call('GET', '/api/integrations/binaa')).json;
  assert.equal(r.integration, 'manual');
  assert.equal(r.apiAvailable, false);
  assert.ok(r.sources.length >= 3);
  assert.ok(r.sources.every((s: any) => s.verification_status === 'unverified'));
  assert.ok(r.sources.some((s: any) => s.url.includes('dmt.gov.ae')));
});

test('catalogue sources are adopted per organisation before verification', async () => {
  const src = (await call('GET', '/api/integrations/binaa')).json.sources.find((s: any) => s.org_id === null);
  assert.equal((await call('POST', `/api/regulatory/sources/${src.id}/verify`, { status: 'verified', attestation: 'checked the page on dmt.gov.ae' })).status, 404);
  const a = await call('POST', `/api/regulatory/sources/${src.id}/adopt`);
  assert.equal(a.status, 200);
  assert.equal((await call('POST', `/api/regulatory/sources/${src.id}/adopt`)).json.existing, true);
  assert.equal((await call('POST', `/api/regulatory/sources/${a.json.id}/verify`, { status: 'verified', attestation: 'Opened the official DMT page and compared the text.' })).status, 200);
});

test('Binaa package: starter checklist, blocking items, manual submission record', async () => {
  pkg = (await call('POST', `/api/projects/${projectId}/submissions`, { target: 'binaa', title: 'Villa building permit' })).json;
  assert.equal(pkg.status, 'draft');
  assert.ok(pkg.items.some((i: any) => i.origin === 'official' && i.required));
  assert.equal((await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'ready_for_review' })).status, 422);

  const doc = await upload('site-plan.pdf', '%PDF-1.4 test');
  for (const it of pkg.items.filter((i: any) => i.required)) {
    const r = await call('PATCH', `/api/submissions/${pkg.id}/items/${it.id}`, { document_id: doc.id });
    assert.equal(r.status, 200, r.body);
  }
  const optional = pkg.items.find((i: any) => !i.required);
  assert.equal((await call('PATCH', `/api/submissions/${pkg.id}/items/${optional.id}`, { status: 'not_applicable' })).status, 422);
  assert.equal((await call('PATCH', `/api/submissions/${pkg.id}/items/${optional.id}`, { status: 'not_applicable', note: 'not requested' })).status, 200);

  assert.equal((await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'ready_for_review' })).status, 200);
  assert.equal((await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'submitted_manually', external_reference: 'APP-123' })).status, 422);
  const sub = await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'submitted_manually', external_reference: 'APP-123', confirm: true });
  assert.equal(sub.json.status, 'submitted_manually');
  assert.equal(sub.json.external_reference, 'APP-123');

  // approval can only be recorded with an uploaded authority document as evidence
  assert.equal((await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'approval_recorded' })).status, 422);
  const letter = await upload('approval.pdf', '%PDF-1.4 approval');
  const ok = await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'approval_recorded', outcome_document_id: letter.id });
  assert.equal(ok.json.status, 'approval_recorded');
  assert.deepEqual(ok.json.events.map((e: any) => e.status), ['draft', 'ready_for_review', 'submitted_manually', 'approval_recorded']);
  assert.equal((await call('POST', `/api/submissions/${pkg.id}/status`, { status: 'draft' })).status, 409);

  const tr = await call('GET', `/api/submissions/${pkg.id}/transmittal`);
  assert.match(tr.body, /manual<\/b> submission/);
  assert.match(tr.body, /APP-123/);
});

test('packages are isolated by organisation and engineers cannot mark ready', async () => {
  const other = (await app.inject({ method: 'POST', url: '/api/auth/register', payload: { orgName: 'Other', name: 'O', email: 'o@example.test', password: 'long-enough-pass' } })).json().token;
  assert.equal((await call('GET', `/api/submissions/${pkg.id}`, undefined, other)).status, 404);
  await call('POST', '/api/org/members', { name: 'E', email: 'e@example.test', password: 'engineer-pass-1', role: 'engineer' });
  const et = (await app.inject({ method: 'POST', url: '/api/auth/login', payload: { email: 'e@example.test', password: 'engineer-pass-1' } })).json().token;
  const p2 = (await call('POST', `/api/projects/${projectId}/submissions`, { target: 'binaa', title: 'second' }, et)).json;
  for (const it of p2.items.filter((i: any) => i.required)) await call('PATCH', `/api/submissions/${p2.id}/items/${it.id}`, { status: 'not_applicable', note: 'test' }, et);
  assert.equal((await call('POST', `/api/submissions/${p2.id}/status`, { status: 'ready_for_review' }, et)).status, 403);
});
