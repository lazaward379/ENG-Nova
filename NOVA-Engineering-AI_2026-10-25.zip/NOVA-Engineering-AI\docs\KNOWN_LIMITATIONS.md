# Known Limitations (release 0.1)

## Environment
- Python, Docker and Git are not installed on the build machine. The backend is
  Node/TypeScript instead of FastAPI; there is no Docker Compose file yet.

## Regulatory
- **No verified Abu Dhabi rule is shipped.** Rule templates report `SOURCE NOT VERIFIED`
  until a reviewer records an official source and parameter.
- No official documents have been retrieved or ingested. Source change detection is not
  automated.
- NOVA does not and cannot confirm authority approval or submit to any portal.

## CAD
- DWG unsupported. DXF import supports LINE, (LW)POLYLINE without bulges, CIRCLE, ARC,
  TEXT/MTEXT, POINT. Blocks, hatches, dimensions, splines, ellipses are reported but not
  imported. Polyline bulges are flattened with a warning.
- Export is DXF R12 only, of supported entities only.
- Trim/extend/offset/mirror not yet implemented (move/copy/rotate/delete/add are).
- Spatial index is a uniform grid; very large drawings (>200k entities) are untested.

## Engineering objects
- Rooms are derived from closed polylines on room layers. Walls, doors, windows,
  structural and MEP elements are not yet typed objects.
- No structural, MEP or fire calculations exist. Shop Drawing, BIM, Coordination screens
  are placeholders that explain what is required.

## AI
- Without `ANTHROPIC_API_KEY`, only the deterministic bilingual command parser is
  available (supports move/rotate/copy/delete of selected entities, room areas, run checks,
  list issues). Free-form design generation is not available.
- The LLM provider is not covered by automated tests.

## UI
- Arabic covers navigation, shell, auth, dashboard, wizard, workspace and key labels; several
  secondary strings (chips, notes, some modal text) are still English only.
- Placeholder screens (BIM, Shop Drawing Studio, Coordination) state what is missing and list
  related files; they do not produce output.
- Hosted doors/windows exist only for elements drawn in NOVA; doors imported from DXF are still plain
  arcs/lines. Walls do not yet join/clean up at corners, and there are no wall types or layer build-ups.

## Draw from reference
- Produces a preliminary single-level plan only: no sections, elevations, roof, stairs, furniture, structure,
  MEP, schedules or construction details.
- Learns only from room boundaries drawn as closed polylines on room layers with text names; references
  drawn with plain lines only, or delivered as DWG/PDF/images, cannot be learned yet.
- Re-fitting scales rooms uniformly; it does not re-plan the layout, check minimum room sizes, corridor
  widths, orientation, road access, privacy or any regulation. Entrance and window positions are placeholders.
- Uniform setback only; irregular plots use a shrunk axis-aligned rectangle.

## AutoCAD integration
- Works only when NOVA runs on a computer with a licensed AutoCAD (full AutoCAD, not LT) that includes
  `accoreconsole.exe`. Jobs run one at a time (about 5–10 s per sheet).
- Arabic text is not shaped correctly in AutoCAD TEXT objects (letters appear unjoined); use English or
  bilingual room names on sheets for now.
- Sheets available: ground-floor plan; four elevations + one section. No enlarged details, roof plan,
  ceiling, structural or MEP sheets; no layouts/viewports (plotted from model space through a window).
- Elevations/section: only the ground floor has a plan, so upper floors are massing over the ground-floor
  walls with no openings; flat roof with uniform parapet; no stairs, roof features, finishes, materials,
  foundations or structural members; one automatic section line (horizontal in drawing axes); elevation
  names follow drawing axes unless north is confirmed.
- DWG import supports the same entity subset as DXF import; blocks, hatches and dimensions in an
  imported DWG are counted and reported, not converted into NOVA objects.

## Home page
- Weather (Open-Meteo) and news (Google News RSS search for Abu Dhabi Municipality / DMT) need internet
  access; when unreachable the widgets say so. DMT's own news page cannot be read automatically (its
  English page loads news by script and its Arabic page blocks automated requests), so news comes via
  Google News with links to the original outlets.
- The daily wisdom is a fixed curated list (31 entries) rotating by date.
- AI images depend on the free Pollinations service: it needs internet, is slow (roughly 10–60 s per image
  because it throttles consecutive requests), may add its small logo, and can be unavailable. Images are
  illustrative only — they are not designs for any project. Once generated, a day's images load instantly.

## Review & edit
- The copilot can only act on instructions it supports (move/copy/rotate/mirror/delete, areas, checks);
  most municipality comments need an engineer to decide and draw the change. Evidence links the
  operations made on the drawing between opening and closing a comment — it does not prove the change
  satisfies the comment.

## Client presentation
- The explanation for each slide is written by templates from the project data (no LLM); review it
  before presenting. Plans are embedded as SVG, which needs PowerPoint 2016 or newer.
- Elevation/section images are not embedded yet (the PDF sheets can be shown alongside).

## Binaa
- No connection to Binaa/TAMM exists or is possible without an official API or DMT authorisation.
  Submission is manual; NOVA records the application number and outcome that a person enters.
- The official Binaa document checklist is not in NOVA; teams must copy it from the platform.
- Catalogue sources are unverified; ADM-BIM-002 could not be text-extracted here and concerns infrastructure.
- No automated browser/E2E test suite yet; the UI was verified manually.

## Security
- No MFA, malware scanning, encryption at rest, backups, or TLS in-process.
- Rate limiting is in-memory (single process).

## Storage / scale
- SQLite and local disk; single-process synchronous jobs.
