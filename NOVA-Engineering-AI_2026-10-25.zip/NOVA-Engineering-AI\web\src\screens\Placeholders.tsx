import type { ReactNode } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, ProjectDrawingPicker, useApp, useLoad, when } from '../ui';

function Planned({ title, icon, why, needs, children }: { title: string; icon: string; why: string; needs: string[]; children?: ReactNode }) {
  return (
    <div className="stack" style={{ maxWidth: 980 }}>
      <div className="page-h"><div><div className="eyebrow">Planned module · not yet functional</div><h1>{title}</h1></div><span className="spacer" /><ProjectDrawingPicker needDrawing={false} /></div>
      <div className="card glow row" style={{ alignItems: 'flex-start' }}><Icon name={icon} size={28} /><div style={{ flex: 1 }}><p style={{ marginTop: 0 }}>{why}</p>
        <div className="faint">Required before this module can produce trustworthy output:</div>
        <ul style={{ margin: '6px 0 0', paddingInlineStart: 18 }}>{needs.map((n) => <li key={n} className="muted">{n}</li>)}</ul></div></div>
      {children}
    </div>
  );
}

function FilesOfType({ exts, label }: { exts: string[]; label: string }) {
  const { project, toast } = useApp();
  const p = useLoad(() => (project ? api.get(`/api/projects/${project}`) : Promise.resolve(null)), [project]);
  const docs = p.data?.documents.filter((d: any) => exts.includes(d.ext)) ?? [];
  return (
    <div className="card">
      <h2>{label}</h2>
      {!project ? <div className="faint">Select a project to list its files.</div> : docs.length ? <table className="t"><tbody>{docs.map((d: any) => (
        <tr key={d.id}><td className="ltr">{d.original_name}</td><td>{d.extraction_status}</td><td className="faint">{d.extraction_notes.at(-1)}</td><td className="faint">{when(d.created_at)}</td>
          <td><button className="btn sm ghost" onClick={() => api.download(`/api/documents/${d.id}/download`, d.original_name).catch((e) => toast(e.message, 'error'))}><Icon name="download" /></button></td></tr>))}</tbody></table>
        : <div className="faint">None uploaded. Upload them in Plot & document intake; they are preserved with checksums.</div>}
    </div>
  );
}

export function Bim() {
  const { t } = useT();
  return (
    <Planned title={t('nav.bim', 'BIM & model viewer')} icon="bim"
      why="IFC files can be uploaded, checksummed and preserved, but NOVA does not parse IFC yet. Showing a model tree or quantities without a real IFC engine would be fabricated."
      needs={['Integrate web-ifc (browser) or an IfcOpenShell worker and verify supported schema versions (IFC2x3 / IFC4)', 'Spatial hierarchy, property set and quantity extraction with unsupported-entity reporting', 'Model validation and comparison', 'Clash detection on real 3D geometry']}>
      <FilesOfType exts={['ifc']} label="IFC models in this project" />
    </Planned>
  );
}

export function ShopDrawings() {
  const { t } = useT();
  return (
    <Planned title={t('nav.shop', 'Shop drawing studio')} icon="shop"
      why="Shop drawings must come from approved design documents and verified engineering data. NOVA does not invent member sizes, reinforcement, pipe or duct sizes, cable ratings or equipment selections, so no shop drawing is generated in this release."
      needs={['Typed structural and MEP elements with verified design inputs', 'Discipline calculations reviewed by qualified engineers', 'Sheet, title block and schedule generation', 'Status gates: PRELIMINARY → AI-GENERATED DRAFT → ENGINEERING REVIEW REQUIRED → COORDINATION REQUIRED → APPROVED FOR ISSUE (authorised users only) → SUPERSEDED']}>
      <div className="card"><h2>Status model</h2>
        <div className="row">{['PRELIMINARY', 'AI-GENERATED DRAFT', 'ENGINEERING REVIEW REQUIRED', 'COORDINATION REQUIRED', 'APPROVED FOR ISSUE', 'SUPERSEDED'].map((s) => <span key={s} className="chip">{s}</span>)}</div>
        <div className="faint" style={{ marginTop: 8 }}>An AI-generated drawing can never be set to APPROVED FOR ISSUE automatically.</div></div>
    </Planned>
  );
}

export function Coordination() {
  const { t } = useT();
  return (
    <Planned title={t('nav.coordination', 'Structural & MEP coordination')} icon="coordination"
      why="Clash and clearance detection needs compatible multi-discipline geometry (IFC or typed 3D elements). Today NOVA holds 2D drawing geometry only, so coordination results would not be meaningful."
      needs={['IFC import or typed 3D elements per discipline', 'Clearance rules from verified sources or project specifications', 'Issue ownership and resolution tracking (finding resolution already exists for rule results)']}>
      <FilesOfType exts={['ifc', 'dwg']} label="Discipline models registered in this project" />
    </Planned>
  );
}
