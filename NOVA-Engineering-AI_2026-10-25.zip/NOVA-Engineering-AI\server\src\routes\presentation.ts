import type { FastifyInstance } from 'fastify';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { audit, get, now, run } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { projectForOrg } from './projects.ts';
import { drawingForOrg, type DrawingRow } from '../drawings.ts';
import { buildDeck, deckToPptx } from '../present/deck.ts';

/** Client presentation: slides from the project's real data + speaker explanation, stored as a .pptx. */
export function presentationRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;
  app.post('/api/projects/:id/presentation', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const b = z.object({ drawing_id: z.string().uuid().nullable().default(null), lang: z.enum(['ar', 'en']).default('ar') }).parse(req.body ?? {});
    let d: DrawingRow | null = null;
    if (b.drawing_id) {
      d = drawingForOrg(db, b.drawing_id, req.user.orgId) ?? null;
      if (!d || d.project_id !== p.id) throw new HttpError(404, 'drawing not found in this project');
    } else {
      // default: the drawing with walls, else the most recent one
      d = get<DrawingRow>(db, `SELECT d.* FROM drawings d WHERE d.project_id = ? ORDER BY (SELECT COUNT(*) FROM entities e WHERE e.drawing_id = d.id AND e.type = 'WALL') > 0 DESC, d.updated_at DESC LIMIT 1`, p.id) ?? null;
    }
    const org = get<any>(db, 'SELECT name FROM organizations WHERE id = ?', req.user.orgId);
    const slides = buildDeck(db, req.user.orgId, p, d, b.lang, req.user.name, org.name);
    const pptx = await deckToPptx(slides, b.lang, p.name);
    const { key, sha256 } = deps.storage.put(pptx);
    const id = randomUUID();
    const name = `${p.code}_client-presentation_${b.lang}_${now().slice(0, 10)}.pptx`.replace(/[^\p{L}\p{N}._ -]/gu, '_');
    run(db, `INSERT INTO documents (id, org_id, project_id, original_name, ext, mime, size_bytes, sha256, storage_key, origin, derived_from, classification, extraction_status, extraction_notes, uploaded_by, created_at)
             VALUES (?,?,?,?,'pptx','application/vnd.openxmlformats-officedocument.presentationml.presentation',?,?,?,'generated',NULL,'presentation','registered_only',?,?,?)`,
      id, req.user.orgId, p.id, name, pptx.length, sha256, key,
      JSON.stringify([`Client presentation (${slides.length} slides, ${b.lang}) generated from project data${d ? ` and drawing "${d.name}"` : ''}. Speaker explanation is in the slide notes.`, 'Preliminary — review before sending to the client.']),
      req.user.userId, now());
    audit(db, req.user.orgId, req.user.userId, 'presentation.generated', p.id, { document: id, slides: slides.length });
    return { slides, document: { id, name, size: pptx.length }, drawing: d ? { id: d.id, name: d.name } : null };
  });
}
