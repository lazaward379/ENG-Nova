import type { FastifyInstance } from 'fastify';
import { randomUUID } from 'node:crypto';
import { join } from 'node:path';
import { z } from 'zod';
import { audit, get, now, run } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { drawingForOrg, layers, loadEntities, currentSeq } from '../drawings.ts';
import { explode } from '../geometry/hosted.ts';
import { exportDxf, importDxf } from '../dxf/dxf.ts';
import { acadPath, cleanupJob, dxfToDwg, findAutoCAD, logTail, readJobFile, runAcadJob } from '../integrations/autocad.ts';
import { buildSheet } from '../integrations/detailing.ts';
import { buildElevations } from '../integrations/elevations.ts';
import { finishScript } from '../integrations/sheet.ts';

export function autocadRoutes(app: FastifyInstance, deps: Deps, jobsRoot: string) {
  const { db } = deps;

  const storeDoc = (orgId: string, projectId: string, userId: string, name: string, ext: string, mime: string, data: Buffer, derivedFrom: string | null, notes: string[]) => {
    const { key, sha256 } = deps.storage.put(data);
    const id = randomUUID();
    run(db, `INSERT INTO documents (id, org_id, project_id, original_name, ext, mime, size_bytes, sha256, storage_key, origin, derived_from, classification, extraction_status, extraction_notes, uploaded_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,'generated',?,?,'registered_only',?,?,?)`,
      id, orgId, projectId, name, ext, mime, data.length, sha256, key, derivedFrom, ext === 'pdf' ? 'document' : 'cad_drawing', JSON.stringify(notes), userId, now());
    return { id, name, sha256, size: data.length };
  };
  const need = () => { const a = findAutoCAD(); if (!a.available) throw new HttpError(503, 'AutoCAD (accoreconsole.exe) was not found on the computer running NOVA.'); return a; };
  const safeName = (s: string) => s.replace(/[^\p{L}\p{N}._ -]/gu, '_').slice(0, 80);

  app.get('/api/integrations/autocad', async () => {
    const a = findAutoCAD();
    return { ...a, capabilities: a.available ? ['DWG import (AutoCAD reads the DWG)', 'DWG export (AutoCAD 2018 format)', 'Detailed plan sheet: hatched walls, dimension chains, tags, schedules, title block, PDF plot'] : [] };
  });

  /** Save the drawing as a native DWG via AutoCAD. */
  app.post('/api/drawings/:id/autocad/dwg', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingForOrg(db, (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'drawing not found');
    const a = need();
    const ents = loadEntities(db, d.id).flatMap((e) => explode(e).map((x) => ({ ...x, props: e.props })));
    if (!ents.length) throw new HttpError(422, 'drawing is empty');
    let dwg: Buffer;
    try { dwg = await dxfToDwg(jobsRoot, exportDxf(ents, layers(db, d.id), d.units)); } catch (e: any) { throw new HttpError(502, e.message); }
    const doc = storeDoc(req.user.orgId, d.project_id, req.user.userId, `${safeName(d.name)}_seq${currentSeq(db, d.id)}.dwg`, 'dwg', 'image/vnd.dwg', dwg, d.source_document_id,
      [`Saved as DWG (AutoCAD 2018 format) by ${a.product} accoreconsole from NOVA drawing "${d.name}".`]);
    audit(db, req.user.orgId, req.user.userId, 'drawing.exported_dwg', d.id, { document: doc.id });
    return { document: doc };
  });

  /** Detailed plan sheet produced by AutoCAD: DWG + PDF, verified by reading AutoCAD's own output back. */
  app.post('/api/drawings/:id/autocad/sheet', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingForOrg(db, (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'drawing not found');
    const { paper } = z.object({ paper: z.enum(['A1', 'A2', 'A3']).default('A1') }).parse(req.body ?? {});
    const a = need();
    const project = get<any>(db, 'SELECT code, name FROM projects WHERE id = ?', d.project_id);
    const north = get<any>(db, "SELECT value FROM project_facts WHERE project_id = ? AND key = 'north_direction' AND class = 'confirmed'", d.project_id);
    let sheet: ReturnType<typeof buildSheet>;
    try {
      sheet = buildSheet({ entities: loadEntities(db, d.id), units: d.units, paper, project, drawingName: d.name, preparedBy: req.user.name,
        northDeg: north && isFinite(+north.value) ? +north.value : null, date: now().slice(0, 10) });
    } catch (e: any) { throw new HttpError(422, e.message); }

    const out = await produce(req, d, project, a.product!, 'plan sheet', sheet, paper);
    audit(db, req.user.orgId, req.user.userId, 'drawing.detailed_sheet', d.id, { dwg: out.dwg.id, pdf: out.pdf.id, verification: out.verification });
    return { ...out, report: sheet.report, warnings: sheet.warnings };
  });

  const Heights = z.object({
    paper: z.enum(['A1', 'A2', 'A3']).default('A1'),
    floors: z.array(z.object({ name: z.string().trim().min(1).max(40), height_m: z.number().min(2.2).max(12) })).min(1).max(12),
    slab_m: z.number().min(0.1).max(1.5).default(0.25),
    parapet_m: z.number().min(0).max(3).default(1.0),
    plinth_m: z.number().min(0).max(3).default(0.45),
    door_head_m: z.number().min(1.8).max(4).default(2.2),
    sill_m: z.number().min(0).max(3).default(0.9),
    window_head_m: z.number().min(1).max(4).default(2.2),
    source: z.string().trim().min(3).max(300),
  }).refine((h) => h.window_head_m > h.sill_m, { message: 'window head must be above the sill', path: ['window_head_m'] })
    .refine((h) => h.floors.every((f, i) => i > 0 || f.height_m - h.slab_m > h.door_head_m && f.height_m - h.slab_m > h.window_head_m), { message: 'ground-floor height minus slab must exceed door and window heads', path: ['floors'] });

  /** Elevations (4) + section A-A from the plan and the floor heights the user provides. */
  app.post('/api/drawings/:id/autocad/elevations', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingForOrg(db, (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'drawing not found');
    const h = Heights.parse(req.body ?? {});
    const a = need();
    const project = get<any>(db, 'SELECT code, name FROM projects WHERE id = ?', d.project_id);
    const north = get<any>(db, "SELECT value FROM project_facts WHERE project_id = ? AND key = 'north_direction' AND class = 'confirmed'", d.project_id);
    let sheet: ReturnType<typeof buildElevations>;
    try {
      sheet = buildElevations({ entities: loadEntities(db, d.id), units: d.units, paper: h.paper, heights: h, project, drawingName: d.name, preparedBy: req.user.name,
        date: now().slice(0, 10), northDeg: north && isFinite(+north.value) ? +north.value : null });
    } catch (e: any) { throw new HttpError(422, e.message); }
    // the heights are the user's design input: keep them with their source as a confirmed project fact
    run(db, `INSERT INTO project_facts (id, project_id, key, value, unit, class, source, confidence, created_by, created_at) VALUES (?,?,'floor_heights',?,'m','confirmed',?,NULL,?,?)
             ON CONFLICT(project_id, key) DO UPDATE SET value = excluded.value, source = excluded.source, class = 'confirmed', created_by = excluded.created_by, created_at = excluded.created_at`,
      randomUUID(), d.project_id, JSON.stringify({ floors: h.floors, slab_m: h.slab_m, parapet_m: h.parapet_m, plinth_m: h.plinth_m, door_head_m: h.door_head_m, sill_m: h.sill_m, window_head_m: h.window_head_m }), h.source, req.user.userId, now());
    const out = await produce(req, d, project, a.product!, 'elevations and section', sheet, h.paper, 'ELEV-SECT');
    audit(db, req.user.orgId, req.user.userId, 'drawing.elevations', d.id, { dwg: out.dwg.id, pdf: out.pdf.id, verification: out.verification });
    return { ...out, report: sheet.report, warnings: sheet.warnings };
  });

  /** Run a sheet through AutoCAD (DWG + PDF + DXF check), verify native object counts and store both files. */
  async function produce(req: any, d: any, project: any, product: string, what: string,
    sheet: { dxf: any[]; script: string[]; plot: { paperName: string; scaleArg: string; lo: string; hi: string }; expect: { hatches: number; dimensions: number }; report: { scale: string }; warnings: string[] }, paper: string, suffix = '') {
    const dxf = exportDxf(sheet.dxf, layers(db, d.id), d.units);
    const r = await runAcadJob(jobsRoot, {
      input: 'base.dxf', inputData: dxf, timeoutMs: 240_000,
      script: (dir) => [...sheet.script, ...finishScript(sheet.plot, { dwg: acadPath(join(dir, 'sheet.dwg')), dxf: acadPath(join(dir, 'check.dxf')), pdf: acadPath(join(dir, 'sheet.pdf')) })].join('\n'),
    });
    const dwg = readJobFile(r, 'sheet.dwg'), pdf = readJobFile(r, 'sheet.pdf'), check = readJobFile(r, 'check.dxf');
    const tail = logTail(r.log, 30);
    cleanupJob(r);
    if (!dwg || !pdf || !check) throw new HttpError(502, `AutoCAD did not produce all outputs (DWG ${!!dwg}, PDF ${!!pdf}).\n${tail}`);
    // Verify: read AutoCAD's own DXF of the result and count native objects.
    const counts = importDxf(check.toString('utf8')).diagnostics.rawEntityCounts;
    const verification = {
      hatches: { expected: sheet.expect.hatches, found: counts.HATCH ?? 0 },
      dimensions: { expected: sheet.expect.dimensions, found: counts.DIMENSION ?? 0 },
      ok: (counts.HATCH ?? 0) === sheet.expect.hatches && (counts.DIMENSION ?? 0) === sheet.expect.dimensions,
      pdfBytes: pdf.length,
    };
    const base = `${safeName(project.code)}_${safeName(d.name)}${suffix ? '_' + suffix : ''}_${sheet.report.scale.replace(':', '-')}_${paper}`;
    const notes = [`${what} ${sheet.report.scale} @ ${paper} produced with ${product} (accoreconsole).`, `Verified in AutoCAD output: ${verification.hatches.found}/${verification.hatches.expected} hatches, ${verification.dimensions.found}/${verification.dimensions.expected} dimensions.`, 'PRELIMINARY - not for construction or submission.', ...sheet.warnings];
    const dwgDoc = storeDoc(req.user.orgId, d.project_id, req.user.userId, `${base}.dwg`, 'dwg', 'image/vnd.dwg', dwg, d.source_document_id, notes);
    const pdfDoc = storeDoc(req.user.orgId, d.project_id, req.user.userId, `${base}.pdf`, 'pdf', 'application/pdf', pdf, dwgDoc.id, notes);
    return { dwg: dwgDoc, pdf: pdfDoc, verification };
  }
}
