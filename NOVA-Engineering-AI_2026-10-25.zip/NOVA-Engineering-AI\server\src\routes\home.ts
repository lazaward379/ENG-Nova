import type { FastifyInstance } from 'fastify';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { HttpError, requireRole, type Deps } from '../app.ts';

/**
 * Home-page widgets: Abu Dhabi weather (Open-Meteo, no key, no user data sent), Abu Dhabi municipality
 * news (Google News RSS search, each item credited to its original outlet), and a daily wisdom.
 * External results are cached; when a source is unreachable the widget says so instead of inventing data.
 */

const cache = new Map<string, { at: number; value: unknown }>();
async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  const value = await load();
  cache.set(key, { at: Date.now(), value });
  return value;
}

async function get(url: string, timeoutMs = 8000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: ctl.signal, headers: { 'user-agent': 'NOVA-Engineering-AI/0.1' } });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  } finally { clearTimeout(t); }
}

// WMO weather codes → [English, Arabic, icon]
const WMO: Record<number, [string, string, string]> = {
  0: ['Clear sky', 'صحو', 'sun'], 1: ['Mainly clear', 'صحو غالباً', 'sun'], 2: ['Partly cloudy', 'غائم جزئياً', 'partly'], 3: ['Overcast', 'غائم', 'cloud'],
  45: ['Fog', 'ضباب', 'fog'], 48: ['Fog', 'ضباب', 'fog'], 51: ['Light drizzle', 'رذاذ خفيف', 'rain'], 53: ['Drizzle', 'رذاذ', 'rain'], 55: ['Dense drizzle', 'رذاذ كثيف', 'rain'],
  61: ['Light rain', 'مطر خفيف', 'rain'], 63: ['Rain', 'مطر', 'rain'], 65: ['Heavy rain', 'مطر غزير', 'rain'], 80: ['Showers', 'زخات مطر', 'rain'], 81: ['Showers', 'زخات مطر', 'rain'], 82: ['Violent showers', 'زخات قوية', 'rain'],
  95: ['Thunderstorm', 'عاصفة رعدية', 'storm'], 96: ['Thunderstorm', 'عاصفة رعدية', 'storm'], 99: ['Thunderstorm', 'عاصفة رعدية', 'storm'],
};

/** Curated, unattributed Arabic proverbs and engineering maxims (no invented quotations of real people). */
export const WISDOM: [string, string][] = [
  ['من جدّ وجد، ومن زرع حصد.', 'Whoever strives finds; whoever sows, reaps.'],
  ['قِس مرتين واقطع مرة واحدة.', 'Measure twice, cut once.'],
  ['الأساس المتين يحمل البناء العالي.', 'A sound foundation carries a tall building.'],
  ['خير الأمور أوسطها.', 'The best of matters is the middle way.'],
  ['التفاصيل الصغيرة تصنع المشاريع الكبيرة.', 'Small details make great projects.'],
  ['في التأني السلامة وفي العجلة الندامة.', 'In patience lies safety; in haste, regret.'],
  ['المخطط الواضح يوفّر نصف وقت التنفيذ.', 'A clear drawing saves half the construction time.'],
  ['يد واحدة لا تصفّق.', 'One hand cannot clap — teamwork builds.'],
  ['العلم في الصغر كالنقش على الحجر.', 'Learning when young is like carving in stone.'],
  ['راجع عملك قبل أن يراجعه غيرك.', 'Check your work before someone else does.'],
  ['قطرة فوق قطرة تصنع بحراً.', 'Drop upon drop makes a sea.'],
  ['كل تعديل موثّق هو خطأ تم تجنّبه غداً.', 'Every documented change is a mistake avoided tomorrow.'],
  ['لا تؤجل عمل اليوم إلى الغد.', "Don't put off today's work until tomorrow."],
  ['البساطة في التصميم قمة الإتقان.', 'Simplicity in design is the height of mastery.'],
  ['السؤال مفتاح العلم.', 'A question is the key to knowledge.'],
  ['المبنى الآمن يبدأ من ورقة دقيقة.', 'A safe building starts with an accurate sheet.'],
  ['الصبر مفتاح الفرج.', 'Patience is the key to relief.'],
  ['من عرف قدر الوقت أحسن استغلاله.', 'Who knows the worth of time uses it well.'],
  ['الجودة لا تأتي صدفة.', 'Quality never happens by accident.'],
  ['لكل مجتهد نصيب.', 'Every diligent person gets a share.'],
  ['التخطيط الجيد نصف الإنجاز.', 'Good planning is half the achievement.'],
  ['ابدأ بالأهم ثم المهم.', 'Start with what matters most.'],
  ['الدقة في الأرقام أمانة.', 'Accuracy in numbers is a trust.'],
  ['ما بُني على صواب دام.', 'What is built on what is right endures.'],
  ['العمل الجماعي يختصر الطريق.', 'Teamwork shortens the road.'],
  ['الملاحظة اليوم توفّر الهدم غداً.', "Today's comment saves tomorrow's demolition."],
  ['اسأل مجرّباً ولا تسأل حكيماً.', 'Ask the experienced, not only the wise.'],
  ['النظام أساس كل نجاح.', 'Order is the basis of every success.'],
  ['الطريق الطويل يبدأ بخطوة.', 'A long road begins with a step.'],
  ['المهندس الجيد يصمم للناس قبل الجدران.', 'A good engineer designs for people before walls.'],
  ['الوقاية خير من العلاج.', 'Prevention is better than cure.'],
];

export function wisdomFor(date: Date) {
  // day number in Abu Dhabi time so the wisdom changes at local midnight
  const local = new Date(date.toLocaleString('en-US', { timeZone: 'Asia/Dubai' }));
  const day = Math.floor(Date.UTC(local.getFullYear(), local.getMonth(), local.getDate()) / 86_400_000);
  const [ar, en] = WISDOM[day % WISDOM.length];
  return { ar, en, day };
}

export function parseRss(xml: string) {
  const items: { title: string; link: string; date: string; source: string }[] = [];
  const unwrap = (s: string) => s.replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
  for (const m of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const body = m[1];
    const pick = (tag: string) => { const x = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`).exec(body); return x ? unwrap(x[1]) : ''; };
    const source = pick('source');
    let title = pick('title');
    if (source && title.endsWith(` - ${source}`)) title = title.slice(0, -(source.length + 3));
    const link = pick('link');
    if (!title || !/^https:\/\//.test(link)) continue;
    items.push({ title, link, date: new Date(pick('pubDate')).toISOString(), source });
  }
  return items.sort((a, b) => b.date.localeCompare(a.date));
}

const NEWS_QUERY = {
  ar: '"بلدية أبوظبي" OR "دائرة البلديات والنقل"',
  en: '"Abu Dhabi City Municipality" OR "Department of Municipalities and Transport"',
};

/**
 * AI-generated architecture images for the home page (Pollinations, free, no key). Only the fixed prompt
 * below is sent — never project data. Images are generated lazily, saved under data/ai-images and reused.
 */
export const THEMES: { ar: string; en: string; prompt: string }[] = [
  { ar: 'فيلا إماراتية معاصرة مع مشربيات عند الغروب', en: 'Contemporary Emirati villa with mashrabiya at sunset', prompt: 'award-winning contemporary Emirati villa in Abu Dhabi at golden hour, mashrabiya screens, palm trees, architectural photography' },
  { ar: 'مجلس بتصميم معاصر بإضاءة طبيعية', en: 'Contemporary majlis bathed in daylight', prompt: 'luxurious contemporary Arabic majlis interior, double height, geometric lattice light patterns, warm stone, architectural interior photography' },
  { ar: 'برج زجاجي على الواجهة البحرية', en: 'Glass tower on the waterfront', prompt: 'sculptural glass skyscraper on Abu Dhabi corniche waterfront, blue hour, reflections, architectural photography' },
  { ar: 'جناح صحراوي بين الكثبان', en: 'Desert pavilion among the dunes', prompt: 'minimalist desert pavilion among sand dunes in the UAE, rammed earth walls, deep shade canopy, sunset, architectural photography' },
  { ar: 'فناء داخلي بظل ونافورة', en: 'Shaded courtyard with a fountain', prompt: 'traditional inspired modern courtyard house, shaded central courtyard with fountain and date palms, Emirati architecture, soft light' },
  { ar: 'متحف بقبة مثقّبة', en: 'Museum under a perforated dome', prompt: 'museum with large perforated geometric dome casting rain of light, waterfront, Abu Dhabi, architectural photography' },
  { ar: 'واجهة بارامترية بأنماط هندسية', en: 'Parametric façade with geometric patterns', prompt: 'parametric building facade with Islamic geometric pattern panels, modern architecture detail, dramatic light and shadow' },
  { ar: 'مسجد معاصر بخطوط بسيطة', en: 'Contemporary minimalist mosque', prompt: 'contemporary minimalist white mosque, clean lines, reflecting pool, dusk, architectural photography' },
  { ar: 'مخطط معماري أزرق على طاولة التصميم', en: 'Architectural blueprint on the design table', prompt: 'architect desk with blueprint drawings of a villa, scale model, drafting tools, warm studio light, top view' },
  { ar: 'مجمع سكني مع حدائق وممرات مظللة', en: 'Residential community with shaded walkways', prompt: 'modern residential villa community in the UAE, shaded walkways, landscaped gardens, aerial view, architectural rendering' },
  { ar: 'جسر معماري فوق قناة مائية', en: 'Architectural bridge over a canal', prompt: 'elegant modern pedestrian bridge over a canal in Abu Dhabi, night lighting, long exposure, architectural photography' },
  { ar: 'مكتبة بإضاءة سقفية طبيعية', en: 'Library with skylight daylight', prompt: 'contemporary public library interior, sweeping timber shelves, skylights, people reading, architectural photography' },
];
const PER_DAY = 4;

export function heroForDay(day: number, variant = 0) {
  return Array.from({ length: PER_DAY }, (_, i) => {
    const t = THEMES[(day * PER_DAY + i + variant * 3) % THEMES.length];
    return { n: i, ...t, seed: (day * 97 + i * 13 + variant * 7919) % 2_147_483_647 };
  });
}

export function homeRoutes(app: FastifyInstance, deps: Deps) {
  let variant = 0;
  const inflight = new Map<string, Promise<Buffer>>();
  const fileFor = (day: number, v: number, n: number) => join(deps.aiImages, `${day}-${v}-${n}.jpg`);
  const today = () => wisdomFor(new Date()).day;

  // The free service allows one request at a time per address: queue requests and retry when it says it is busy.
  let queue: Promise<unknown> = Promise.resolve();
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  const fetchImage = (url: string) => {
    const job = async () => {
      for (let attempt = 0; ; attempt++) {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 90_000);
        try {
          const r = await fetch(url, { signal: ctl.signal, headers: { 'user-agent': 'NOVA-Engineering-AI/0.1' } });
          if ((r.status === 402 || r.status === 429 || r.status >= 500) && attempt < 4) { await sleep(8_000 * (attempt + 1)); continue; }
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          const b = Buffer.from(await r.arrayBuffer());
          await sleep(1_500);
          return b;
        } finally { clearTimeout(t); }
      }
    };
    const p = queue.then(job, job);
    queue = p.catch(() => undefined);
    return p;
  };

  async function generate(day: number, v: number, n: number): Promise<Buffer> {
    const f = fileFor(day, v, n);
    if (existsSync(f)) return readFileSync(f);
    const key = `${day}-${v}-${n}`;
    if (!inflight.has(key)) inflight.set(key, (async () => {
      const item = heroForDay(day, v)[n];
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(item.prompt + ', ultra detailed, high quality')}?width=1600&height=700&seed=${item.seed}&nologo=true&model=flux`;
      try {
        const b = await fetchImage(url);
        // accept only real JPEG/PNG images of a sane size
        const isImg = (b[0] === 0xff && b[1] === 0xd8) || b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
        if (!isImg || b.length < 5_000 || b.length > 8_000_000) throw new Error('the service did not return an image');
        mkdirSync(deps.aiImages, { recursive: true });
        writeFileSync(f, b);
        // keep only the last week of images
        for (const old of readdirSync(deps.aiImages)) if (+old.split('-')[0] < day - 7) rmSync(join(deps.aiImages, old), { force: true });
        return b;
      } finally { inflight.delete(key); }
    })());
    return inflight.get(key)!;
  }

  app.get('/api/home/hero', async () => {
    const day = today();
    return {
      day, variant, source: 'Pollinations (AI image generation)',
      images: heroForDay(day, variant).map((x) => ({ n: x.n, ar: x.ar, en: x.en, ready: existsSync(fileFor(day, variant, x.n)) })),
    };
  });

  app.get('/api/home/hero/:n/image', async (req, reply) => {
    const n = Number((req.params as any).n);
    if (!Number.isInteger(n) || n < 0 || n >= PER_DAY) throw new HttpError(404, 'no such image');
    try {
      const img = await generate(today(), variant, n);
      reply.header('content-type', img[0] === 0xff ? 'image/jpeg' : 'image/png').header('cache-control', 'private, max-age=3600');
      return reply.send(img);
    } catch (e: any) {
      throw new HttpError(503, `AI image service unavailable (${e?.message ?? e})`);
    }
  });

  /** New set of images (another variation of today's themes). */
  app.post('/api/home/hero/refresh', async (req) => {
    requireRole(req, 'engineer');
    variant++;
    return { variant };
  });

  app.get('/api/home/weather', async () => {
    try {
      return await cached('weather', 15 * 60_000, async () => {
        const j = JSON.parse(await get('https://api.open-meteo.com/v1/forecast?latitude=24.4539&longitude=54.3773&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=Asia%2FDubai&forecast_days=1'));
        const c = j.current, code = c.weather_code as number;
        const [en, ar, icon] = WMO[code] ?? ['Weather', 'الطقس', 'cloud'];
        return {
          available: true, city: { en: 'Abu Dhabi', ar: 'أبوظبي' }, observedAt: c.time,
          temperature: c.temperature_2m, feelsLike: c.apparent_temperature, humidity: c.relative_humidity_2m, windKmh: c.wind_speed_10m,
          max: j.daily?.temperature_2m_max?.[0] ?? null, min: j.daily?.temperature_2m_min?.[0] ?? null,
          condition: { en, ar, icon, code }, source: 'Open-Meteo',
        };
      });
    } catch (e: any) {
      return { available: false, reason: `weather service unreachable (${e?.message ?? e})` };
    }
  });

  app.get('/api/home/news', async (req) => {
    const lang = (req.query as any)?.lang === 'en' ? 'en' : 'ar';
    try {
      return await cached(`news:${lang}`, 60 * 60_000, async () => {
        const q = encodeURIComponent(NEWS_QUERY[lang]);
        const url = lang === 'ar' ? `https://news.google.com/rss/search?q=${q}&hl=ar&gl=AE&ceid=AE:ar` : `https://news.google.com/rss/search?q=${q}&hl=en-AE&gl=AE&ceid=AE:en`;
        const items = parseRss(await get(url)).slice(0, 8);
        return { available: true, lang, items, via: 'Google News', fetchedAt: new Date().toISOString() };
      });
    } catch (e: any) {
      return { available: false, lang, items: [], reason: `news feed unreachable (${e?.message ?? e})` };
    }
  });

  app.get('/api/home/wisdom', async () => wisdomFor(new Date()));
}
