-- Review comments: municipality / client / internal comments and NOVA check findings, tracked to resolution.
CREATE TABLE review_comments (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  drawing_id TEXT REFERENCES drawings(id) ON DELETE SET NULL,
  source TEXT NOT NULL CHECK (source IN ('municipality','client','internal','nova_check')),
  reference TEXT NOT NULL DEFAULT '',      -- e.g. comment number on the authority's letter
  text TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('open','in_progress','resolved','not_applicable')),
  response TEXT NOT NULL DEFAULT '',
  op_seq_at_open INTEGER,                  -- drawing operation number when the comment was logged
  op_seq_at_close INTEGER,                 -- ... and when it was closed (evidence = operations in between)
  finding_rule TEXT,                       -- rule code when created from a NOVA check
  closed_by TEXT REFERENCES users(id),
  closed_at TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_review_comments_project ON review_comments(project_id);
