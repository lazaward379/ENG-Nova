/**
 * Writes samples/sample-villa-ground-floor.dxf — a SYNTHETIC test fixture.
 * It is not a real plot, not a real design and carries no regulatory meaning.
 * It deliberately contains issues (an unlabelled room, a duplicate line, entities on layer 0,
 * an unsupported ELLIPSE) so that the validation and diagnostics paths have something to find.
 */
import { writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { exportDxf } from '../src/dxf/dxf.ts';
import type { EntityInput, Pt } from '../src/geometry/types.ts';

export function sampleEntities(): EntityInput[] {
  const rect = (x: number, y: number, w: number, h: number): Pt[] => [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
  const e: EntityInput[] = [];
  // Plot 30 m × 25 m and a footprint (all units mm).
  e.push({ type: 'POLYLINE', layer: 'PLOT-BOUNDARY', geom: { points: rect(0, 0, 30000, 25000), closed: true } });
  e.push({ type: 'POLYLINE', layer: 'A-BLDG-OUTL', geom: { points: rect(4000, 4000, 18000, 14000), closed: true } });
  // External walls as lines.
  const fp = rect(4000, 4000, 18000, 14000);
  for (let i = 0; i < 4; i++) e.push({ type: 'LINE', layer: 'A-WALL', geom: { a: fp[i], b: fp[(i + 1) % 4] } });
  // Rooms with labels.
  const rooms: [string, number, number, number, number][] = [
    ['MAJLIS مجلس', 4000, 4000, 7000, 6000],
    ['LIVING', 11000, 4000, 11000, 6000],
    ['KITCHEN', 4000, 10000, 5000, 4500],
    ['GUEST BEDROOM', 9000, 10000, 3200, 3000],
    ['', 12200, 10000, 9800, 8000], // intentionally unlabelled
  ];
  for (const [name, x, y, w, h] of rooms) {
    e.push({ type: 'POLYLINE', layer: 'A-ROOM', geom: { points: rect(x, y, w, h), closed: true } });
    if (name) e.push({ type: 'TEXT', layer: 'A-ANNO-TEXT', geom: { p: { x: x + 400, y: y + h / 2 }, h: 250, rot: 0, text: name } });
  }
  // Door swing, columns, a duplicate line, a point on layer 0.
  e.push({ type: 'ARC', layer: 'A-DOOR', geom: { c: { x: 7000, y: 4000 }, r: 900, start: 0, end: 90 } });
  e.push({ type: 'LINE', layer: 'A-DOOR', geom: { a: { x: 7000, y: 4000 }, b: { x: 7000, y: 4900 } } });
  for (const p of fp) e.push({ type: 'CIRCLE', layer: 'S-COLS', geom: { c: p, r: 200 } });
  e.push({ type: 'LINE', layer: 'A-WALL', geom: { a: fp[0], b: fp[1] } });
  e.push({ type: 'POINT', layer: '0', geom: { p: { x: 15000, y: 21000 } } });
  e.push({ type: 'TEXT', layer: 'A-ANNO-TEXT', geom: { p: { x: 500, y: 24000 }, h: 400, rot: 0, text: 'SYNTHETIC TEST FIXTURE - NOT A REAL PLOT' } });
  return e;
}

export function sampleDxf(): string {
  const dxf = exportDxf(sampleEntities(), [{ name: 'PLOT-BOUNDARY', color: 1 }, { name: 'A-WALL', color: 7 }, { name: 'A-ROOM', color: 4 }, { name: 'A-ANNO-TEXT', color: 2 }, { name: 'S-COLS', color: 5 }], 'mm');
  // Append one ELLIPSE so the import diagnostics have an unsupported entity to report.
  const ellipse = ['0', 'ELLIPSE', '8', 'L-PLNT', '10', '26000', '20', '21000', '30', '0', '11', '1500', '21', '0', '31', '0', '40', '0.5', '41', '0', '42', '6.283185307179586'].join('\r\n');
  return dxf.replace('\r\n  0\r\nENDSEC\r\n  0\r\nEOF', `\r\n${ellipse}\r\n  0\r\nENDSEC\r\n  0\r\nEOF`);
}

if (import.meta.url === `file:///${process.argv[1]?.replace(/\\/g, '/')}` || process.argv[1]?.endsWith('make-sample.ts')) {
  const out = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'samples', 'sample-villa-ground-floor.dxf');
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, sampleDxf());
  console.log(`wrote ${out}`);
}
