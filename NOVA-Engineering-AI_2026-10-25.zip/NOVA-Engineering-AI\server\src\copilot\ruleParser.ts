import { blankIntent, type CopilotContext, type CopilotIntent, type CopilotProvider } from './intent.ts';

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

export function normalise(s: string) {
  return s
    .replace(/[٠-٩]/g, (d) => String(AR_DIGITS.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d)))
    .replace(/٫/g, '.')
    .replace(/[ً-ْ]/g, '') // Arabic diacritics
    .replace(/[أإآ]/g, 'ا')
    .toLowerCase()
    .trim();
}

export const isArabic = (s: string) => /[؀-ۿ]/.test(s);

const NUM = '(-?\\d+(?:\\.\\d+)?)';
const END = '(?![\\p{L}])';
const UNIT_MM: [RegExp, number][] = [
  [new RegExp(`^(mm|millimet(?:er|re)s?|مم|ملم|مليمتر|ملليمتر)${END}`, 'u'), 1],
  [new RegExp(`^(cm|centimet(?:er|re)s?|سم|سنتيمتر)${END}`, 'u'), 10],
  [new RegExp(`^(m|met(?:er|re)s?|م|متر|متر|امتار)${END}`, 'u'), 1000],
];

/** Find "<number> <unit>" and return millimetres; a bare number is reported as missing its unit. */
function distanceMm(s: string): { mm: number | null; bareNumber: boolean } {
  const re = new RegExp(`${NUM}\\s*`, 'gu');
  let m: RegExpExecArray | null;
  let bare = false;
  while ((m = re.exec(s))) {
    const rest = s.slice(m.index + m[0].length);
    if (/^(°|deg|degree|درجة|درجات)/u.test(rest)) continue;
    for (const [u, f] of UNIT_MM) if (u.test(rest)) return { mm: parseFloat(m[1]) * f, bareNumber: false };
    bare = true;
  }
  return { mm: null, bareNumber: bare };
}

function direction(s: string): [number, number] | null {
  if (/\bleft\b|يسار|اليسار/u.test(s)) return [-1, 0];
  if (/\bright\b|يمين|اليمين/u.test(s)) return [1, 0];
  if (/\bup\b|upward|اعلى|للاعلى|فوق/u.test(s)) return [0, 1];
  if (/\bdown\b|downward|اسفل|للاسفل|تحت/u.test(s)) return [0, -1];
  return null;
}

const has = (s: string, re: RegExp) => re.test(s);

/** Deterministic bilingual interpreter for a fixed set of commands. Never guesses distances or units. */
export function parseInstruction(raw: string, ctx: CopilotContext): CopilotIntent {
  const s = normalise(raw);
  const ar = isArabic(raw);
  const t = (en: string, arText: string) => (ar ? arText : en);
  const needSelection = () => blankIntent({ intent: 'clarify', questions: [t('Select the entities to change first, then repeat the instruction.', 'حدد العناصر المطلوب تعديلها أولاً ثم أعد الأمر.')] });

  if (has(s, /\barea|مساح/u) && has(s, /room|غرف|غرفة|فراغ|space/u))
    return blankIntent({ intent: 'query', query: 'room_areas', explanation: t('Calculate the area of every room boundary.', 'حساب مساحة كل حدود غرفة.') });
  if (has(s, /unresolved|issues|problems|show .*check|list .*check|ملاحظات|مشاكل|غير محلول|اعرض/u))
    return blankIntent({ intent: 'query', query: 'list_issues', explanation: t('List checks that are not passing.', 'عرض الفحوصات غير الناجحة.') });
  if (has(s, /\b(checks?|validate|verify|compliance|qa)\b|افحص|فحص|تحقق|امتثال/u))
    return blankIntent({ intent: 'query', query: 'run_checks', explanation: t('Run drawing QA and rule checks.', 'تشغيل فحوصات جودة الرسم والقواعد.') });

  const op =
    has(s, /\b(move|shift|nudge)\b|انقل|حرك|ازح/u) ? 'move' :
    has(s, /\b(copy|duplicate)\b|انسخ|كرر/u) ? 'copy' :
    has(s, /\b(rotate|turn)\b|دور|ادر|تدوير/u) ? 'rotate' :
    has(s, /\b(mirror|flip)\b|اعكس|عكس|مراه|مرآة/u) ? 'mirror' :
    has(s, /\b(delete|remove|erase)\b|احذف|امسح|ازل|حذف/u) ? 'delete' : null;

  if (!op) return blankIntent({ intent: 'unsupported', explanation: t(
    'This instruction is not supported by the offline interpreter. Supported: move / copy / rotate / mirror / delete the selection, room areas, run checks, list issues.',
    'هذا الأمر غير مدعوم في المفسر المحلي. المدعوم: نقل / نسخ / تدوير / عكس / حذف العناصر المحددة، مساحات الغرف، تشغيل الفحوصات، عرض الملاحظات.') });
  if (!ctx.selectionCount) return needSelection();

  if (op === 'delete') return blankIntent({ intent: 'operation', operation: 'delete', explanation: t(`Delete ${ctx.selectionCount} selected entit(ies).`, `حذف ${ctx.selectionCount} من العناصر المحددة.`) });

  if (op === 'mirror') {
    const vertical = has(s, /vertical|عمودي|راسي|top|bottom/u);
    return blankIntent({ intent: 'operation', operation: vertical ? 'mirror_vertical' : 'mirror_horizontal',
      explanation: t(`Mirror the selection ${vertical ? 'top-to-bottom' : 'left-to-right'} about its centre.`, `عكس العناصر المحددة ${vertical ? 'رأسياً' : 'أفقياً'} حول مركزها.`),
      assumptions: [t('Mirror axis passes through the centre of the selection’s bounding box.', 'محور العكس يمر بمركز الإطار المحيط بالعناصر المحددة.')] });
  }

  if (op === 'rotate') {
    const m = s.match(new RegExp(`${NUM}\\s*(°|deg|degrees?|درجة|درجات)`, 'u'));
    if (!m) return blankIntent({ intent: 'clarify', questions: [t('By how many degrees? (e.g. "rotate 90 degrees")', 'كم درجة؟ (مثال: "دوّر 90 درجة")')] });
    let angle = parseFloat(m[1]);
    if (has(s, /\bclockwise\b|مع عقارب/u) && !has(s, /counter|anti|عكس عقارب/u)) angle = -angle;
    return blankIntent({ intent: 'operation', operation: 'rotate', angle_deg: angle,
      explanation: t(`Rotate the selection ${angle}° (counter-clockwise positive).`, `تدوير العناصر المحددة ${angle}° (الموجب عكس عقارب الساعة).`),
      assumptions: [t('Rotation centre is the centre of the selection’s bounding box.', 'مركز التدوير هو مركز الإطار المحيط بالعناصر المحددة.')] });
  }

  // move / copy
  const byPair = s.match(new RegExp(`(?:by|بمقدار)\\s*${NUM}\\s*,\\s*${NUM}\\s*(mm|cm|m|مم|ملم|سم|م)${END}`, 'u'));
  if (byPair) {
    const f = /^(cm|سم)$/.test(byPair[3]) ? 10 : /^(m|م)$/.test(byPair[3]) ? 1000 : 1;
    const dx = parseFloat(byPair[1]) * f, dy = parseFloat(byPair[2]) * f;
    return blankIntent({ intent: 'operation', operation: op, dx_mm: dx, dy_mm: dy, explanation: t(`${op === 'move' ? 'Move' : 'Copy'} the selection by (${dx}, ${dy}) mm.`, `${op === 'move' ? 'نقل' : 'نسخ'} العناصر المحددة بمقدار (${dx}، ${dy}) مم.`) });
  }
  const { mm, bareNumber } = distanceMm(s);
  const dir = direction(s);
  if (mm === null) return blankIntent({ intent: 'clarify', questions: [bareNumber
    ? t('Which unit is that distance in (mm, cm or m)? NOVA does not assume units.', 'ما وحدة المسافة (مم، سم، م)؟ لا يفترض NOVA الوحدات.')
    : t('How far? Give a distance with a unit, e.g. "200 mm".', 'ما المسافة؟ اذكر المسافة مع الوحدة، مثال: "200 مم".')] });
  if (!dir) return blankIntent({ intent: 'clarify', questions: [t('In which direction: left, right, up or down?', 'في أي اتجاه: يسار، يمين، أعلى، أسفل؟')] });
  const dx = dir[0] * mm, dy = dir[1] * mm;
  const dirWord = dir[0] < 0 ? t('left', 'لليسار') : dir[0] > 0 ? t('right', 'لليمين') : dir[1] > 0 ? t('up', 'للأعلى') : t('down', 'للأسفل');
  return blankIntent({ intent: 'operation', operation: op, dx_mm: dx, dy_mm: dy,
    explanation: t(`${op === 'move' ? 'Move' : 'Copy'} ${ctx.selectionCount} selected entit(ies) ${Math.abs(mm)} mm ${dirWord}.`, `${op === 'move' ? 'نقل' : 'نسخ'} ${ctx.selectionCount} من العناصر المحددة ${Math.abs(mm)} مم ${dirWord}.`),
    assumptions: [t('Left/right/up/down refer to the drawing’s world X/Y axes.', 'الاتجاهات تشير إلى محوري X/Y في نظام إحداثيات الرسم.')] });
}

export class RuleParserProvider implements CopilotProvider {
  readonly name = 'nova-rule-parser';
  readonly model = null;
  available() { return true; }
  async interpret(instruction: string, ctx: CopilotContext) { return parseInstruction(instruction, ctx); }
}
