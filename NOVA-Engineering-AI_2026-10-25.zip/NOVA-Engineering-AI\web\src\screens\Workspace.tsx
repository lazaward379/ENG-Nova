import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api, type Drawing, type Entity, type Finding, type Pt } from '../api';
import { useT } from '../i18n';
import { CadCanvas, type CadHandle, type NewEntity, type Tool } from '../cad/CadCanvas';
import { aciColor, entityBBox, fmt, unionBBox, wallFrame } from '../cad/engine';
import { Icon, Loading, Modal, Status, useApp, when } from '../ui';

const MM_PER_UNIT: Record<string, number> = { mm: 1, cm: 10, m: 1000, in: 25.4, ft: 304.8 };

export function Workspace({ drawingId }: { drawingId: string | null }) {
  const { go, setDrawing, setProject } = useApp();
  const { t } = useT();
  const [d, setD] = useState<Drawing | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!drawingId) return;
    try { const x = await api.get<Drawing>(`/api/drawings/${drawingId}`); setD(x); setErr(null); setDrawing(x.id); setProject(x.project_id); }
    catch (e: any) { setErr(e.message); }
  }, [drawingId]);
  useEffect(() => { setD(null); load(); }, [load]);

  if (!drawingId) return (
    <div className="content"><div className="card empty">{t('common.selectDrawing', 'Open a drawing from a project first.')} <a href="#/projects">{t('nav.projects', 'Projects')}</a></div></div>
  );
  if (!d) return <div className="content"><Loading error={err} loading={!err} />{err && <button className="btn" onClick={() => go('projects')}>{t('common.back', 'Back')}</button>}</div>;
  return <WorkspaceInner d={d} reload={load} />;
}

function WorkspaceInner({ d, reload }: { d: Drawing; reload: () => Promise<void> }) {
  const { toast, can, theme, go } = useApp();
  const { t } = useT();
  const cad = useRef<CadHandle>(null);
  const [tool, setTool] = useState<Tool>('select');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [snap, setSnap] = useState(true);
  const [gridSnap, setGridSnap] = useState(false);
  const [ortho, setOrtho] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [activeLayer, setActiveLayer] = useState(() => d.layers.find((l) => !l.locked && l.name !== '0')?.name ?? '0');
  const [cursor, setCursor] = useState<{ p: Pt | null; snap: string | null }>({ p: null, snap: null });
  const [measure, setMeasure] = useState<{ a: Pt; b: Pt } | null>(null);
  // a comment sent from the Review section arrives as a copilot draft
  const [draft] = useState<string | null>(() => { try { const x = sessionStorage.getItem('nova.copilotDraft'); sessionStorage.removeItem('nova.copilotDraft'); return x; } catch { return null; } });
  const [panel, setPanel] = useState(draft ? 'copilot' : 'properties');
  const [ghosts, setGhosts] = useState<Entity[]>([]);
  const [run, setRun] = useState<any | null>(null);
  const [activeFinding, setActiveFinding] = useState<number | null>(null);
  const [textAt, setTextAt] = useState<Pt | null>(null);
  const [busy, setBusy] = useState(false);
  const [acadOpen, setAcadOpen] = useState(false);
  const editable = can('engineer');
  const mmPerUnit = MM_PER_UNIT[d.units] ?? null;
  // Placement sizes for new elements, entered in mm. They are drafting inputs, not design values.
  const [sizes, setSizes] = useState({ wall: '200', door: '900', window: '1200' });
  const toUnits = (mm: string) => (mmPerUnit && +mm > 0 ? +mm / mmPerUnit : null);

  // drop selections that no longer exist after a reload
  useEffect(() => { setSelected((s) => new Set([...s].filter((id) => d.entities.some((e) => e.id === id)))); }, [d]);

  const op = async (body: any, label: string) => {
    if (!editable) { toast('Read-only role', 'error'); return null; }
    setBusy(true);
    try {
      const r = await api.post(`/api/drawings/${d.id}/operations`, { op: body });
      toast(`${label} · #${r.seq} · ${r.affected} affected`, 'ok');
      await reload();
      return r;
    } catch (e: any) { toast(e.message, 'error'); return null; } finally { setBusy(false); }
  };
  const undo = async () => { const r = await api.post(`/api/drawings/${d.id}/undo`).catch((e) => toast(e.message, 'error')); if (r?.undone) toast(`Undid ${r.undone.kind} #${r.undone.seq}`); await reload(); };
  const redo = async () => { const r = await api.post(`/api/drawings/${d.id}/redo`).catch((e) => toast(e.message, 'error')); if (r?.redone) toast(`Redid ${r.redone.kind} #${r.redone.seq}`); await reload(); };
  const runChecks = async (scope = 'all') => {
    setBusy(true);
    try { const r = await api.post(`/api/drawings/${d.id}/compliance-runs`, { scope }); setRun(r); setPanel('issues'); toast('Checks complete', 'ok'); }
    catch (e: any) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const exportDxf = async () => {
    try {
      const r = await api.post(`/api/drawings/${d.id}/export`);
      toast(`Export verified: ${r.verification.reparsed}/${r.verification.expected} entities re-parsed identically`, 'ok');
      await api.download(`/api/documents/${r.documentId}/download`, r.name);
    } catch (e: any) { toast(e.message, 'error'); }
  };
  const checkpoint = async () => {
    const label = prompt('Checkpoint label', `Checkpoint at #${d.seq}`);
    if (!label) return;
    try { const r = await api.post(`/api/drawings/${d.id}/revisions`, { label }); toast(`Revision R${r.number} saved`, 'ok'); } catch (e: any) { toast(e.message, 'error'); }
  };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.closest('input, textarea, select')) return;
      const ctrl = e.ctrlKey || e.metaKey;
      if (ctrl && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
      else if (ctrl && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
      else if (e.key === 'Delete' && selected.size) op({ kind: 'delete', ids: [...selected] }, 'Delete');
      else if (!ctrl && !e.altKey) {
        const map: Record<string, Tool> = { v: 'select', h: 'pan', l: 'line', r: 'rect', p: 'polyline', c: 'circle', t: 'text', m: 'measure', w: 'wall', d: 'door', n: 'window' };
        if (map[e.key] && !(tool === 'polyline' && e.key === 'c')) setTool(map[e.key]);
        if (e.key === 'f') cad.current?.fit();
        if (e.key === 'Escape') setSelected(new Set());
        const arrows: Record<string, [number, number]> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, 1], ArrowDown: [0, -1] };
        if (arrows[e.key] && selected.size && mmPerUnit) {
          e.preventDefault();
          const step = (e.shiftKey ? 100 : 10) / mmPerUnit;
          op({ kind: 'move', ids: [...selected], dx: arrows[e.key][0] * step, dy: arrows[e.key][1] * step }, `Nudge ${e.shiftKey ? 100 : 10} mm`);
        }
      }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  });

  const markers = useMemo(() => (run?.findings ?? [])
    .map((f: Finding, i: number) => ({ f, i }))
    .filter(({ f }: any) => f.location && ['FAIL', 'WARNING', 'INSUFFICIENT DATA', 'REQUIRES ENGINEER REVIEW'].includes(f.status))
    .map(({ f, i }: any, n: number) => ({ p: f.location, status: f.status, n: n + 1, active: i === activeFinding })), [run, activeFinding]);

  const sel = d.entities.filter((e) => selected.has(e.id));
  const selBox = unionBBox(sel.map(entityBBox));

  const tools: [Tool, string, string, string][] = [
    ['select', 'select', 'ws.select', 'Select (V)'], ['pan', 'pan', 'ws.pan', 'Pan (H / Space)'], ['line', 'line', 'ws.line', 'Line (L)'], ['rect', 'rect', 'ws.rect', 'Rectangle (R)'],
    ['polyline', 'polyline', 'ws.polyline', 'Polyline (P; Enter / double-click ends, C closes)'], ['circle', 'circle', 'ws.circle', 'Circle (C)'], ['text', 'text', 'ws.text', 'Text (T)'], ['measure', 'measure', 'ws.measure', 'Measure (M)'],
    ['wall', 'wall', 'ws.wall', 'Wall (W) — click start and end; chains until Esc'], ['door', 'door', 'ws.door', 'Door (D) — click on a wall'], ['window', 'window', 'ws.window', 'Window (N) — click on a wall'],
  ];
  const elementTool = tool === 'wall' || tool === 'door' || tool === 'window';

  return (
    <div className="ws">
      <div className="ws-left">
        <div className="ws-toolbar" role="toolbar">
          <a href={`#/project/${d.project.id}/intake`} className="btn ghost sm" title={d.project.name}><span className="ltr mono">{d.project.code}</span></a>
          <b style={{ fontSize: 13, marginInlineEnd: 6 }}>{d.name}</b>
          <span className="sep" />
          {tools.map(([k, icon, key, en]) => (
            <button key={k} className={`btn icon ${tool === k ? 'on' : 'ghost'}`} disabled={(!editable && !['select', 'pan', 'measure'].includes(k)) || (['wall', 'door', 'window'].includes(k) && !mmPerUnit)}
              title={!mmPerUnit && ['wall', 'door', 'window'].includes(k) ? 'Set drawing units first' : t(key, en)} aria-label={t(key, en)} onClick={() => setTool(k)}><Icon name={icon} /></button>
          ))}
          {elementTool && (
            <label className="row faint" style={{ gap: 4 }}>
              {tool === 'wall' ? 'thickness' : 'width'}
              <input className="mono" style={{ width: 70, padding: '3px 6px' }} value={sizes[tool]} onChange={(e) => setSizes({ ...sizes, [tool]: e.target.value })} aria-label="size in mm" />mm
            </label>
          )}
          <span className="sep" />
          <button className="btn icon ghost" title={`${t('ws.undo', 'Undo')} (Ctrl+Z)`} disabled={!d.canUndo || !editable} onClick={undo}><Icon name="undo" /></button>
          <button className="btn icon ghost" title={`${t('ws.redo', 'Redo')} (Ctrl+Y)`} disabled={!d.canRedo || !editable} onClick={redo}><Icon name="redo" /></button>
          <button className="btn icon ghost" title={`${t('ws.fit', 'Fit')} (F)`} onClick={() => cad.current?.fit()}><Icon name="fit" /></button>
          <span className="sep" />
          <button className={`btn sm ${snap ? 'on' : 'ghost'}`} onClick={() => setSnap(!snap)} title="Object snap: endpoint / midpoint / centre">{t('ws.snap', 'Snap')}</button>
          <button className={`btn sm ${gridSnap ? 'on' : 'ghost'}`} onClick={() => setGridSnap(!gridSnap)}>{t('ws.grid', 'Grid')}·snap</button>
          <button className={`btn sm ${ortho ? 'on' : 'ghost'}`} onClick={() => setOrtho(!ortho)}>{t('ws.ortho', 'Ortho')}</button>
          <button className={`btn sm ${showGrid ? 'on' : 'ghost'}`} onClick={() => setShowGrid(!showGrid)}><Icon name="eye" />{t('ws.grid', 'Grid')}</button>
          <select value={activeLayer} onChange={(e) => setActiveLayer(e.target.value)} style={{ width: 150, padding: '4px 8px' }} title="Active layer for new entities">
            {d.layers.filter((l) => !l.locked).map((l) => <option key={l.name}>{l.name}</option>)}
          </select>
          <span className="spacer" />
          <button className="btn sm" disabled={busy} onClick={() => runChecks()}><Icon name="play" />{t('ws.runChecks', 'Run checks')}</button>
          <button className="btn sm" disabled={!editable} onClick={checkpoint}><Icon name="flag" />{t('ws.checkpoint', 'Checkpoint')}</button>
          <button className="btn sm" disabled={!editable} onClick={exportDxf}><Icon name="download" />{t('ws.export', 'Export DXF')}</button>
          <button className="btn sm primary" disabled={!editable} onClick={() => setAcadOpen(true)} title="Use the AutoCAD installed on this computer"><Icon name="report" />{t('ws.acad', 'AutoCAD sheet')}</button>
        </div>
        {d.units === 'unitless' && <UnitsBanner d={d} reload={reload} />}
        <div style={{ position: 'relative', flex: 1, minHeight: 0, display: 'flex' }}>
          <CadCanvas ref={cad} entities={d.entities} layers={d.layers} selected={selected} onSelect={setSelected} tool={tool} activeLayer={activeLayer}
            snap={snap} gridSnap={gridSnap} ortho={ortho} showGrid={showGrid} ghosts={ghosts} markers={markers} theme={theme}
            onCreate={(es: NewEntity[]) => op({ kind: 'add', entities: es }, `Add ${es[0].type}`)}
            onMoveBy={(dx, dy) => op({ kind: 'move', ids: [...selected], dx, dy }, 'Move')}
            onRequestText={(p) => setTextAt(p)}
            onCursor={(p, s) => setCursor({ p, snap: s })}
            onMeasure={(a, b) => setMeasure({ a, b })}
            wallThickness={toUnits(sizes.wall)} doorWidth={toUnits(sizes.door)} windowWidth={toUnits(sizes.window)}
            onHint={(h) => h && toast(h)} />
          <div className="ws-overlay-label">{t('nav.workspace', 'CAD workspace')} · {d.units}</div>
        </div>
        <div className="ws-status">
          <span>X {cursor.p ? fmt(cursor.p.x) : '—'}</span><span>Y {cursor.p ? fmt(cursor.p.y) : '—'}</span>
          <span>{d.units}</span>{cursor.snap && <span style={{ color: 'var(--warn)' }}>⌖ {cursor.snap}</span>}
          <span>{d.entities.length} entities</span><span>{selected.size} selected</span><span>op #{d.seq}</span>
          {measure && <span style={{ color: 'var(--cyan)' }}>
            ⟷ {fmt(Math.hypot(measure.b.x - measure.a.x, measure.b.y - measure.a.y))} {d.units}
            {mmPerUnit && ` = ${fmt(Math.hypot(measure.b.x - measure.a.x, measure.b.y - measure.a.y) * mmPerUnit, 1)} mm`}
            {' '}· Δx {fmt(measure.b.x - measure.a.x)} Δy {fmt(measure.b.y - measure.a.y)}
          </span>}
          {busy && <span><span className="ai-dot" style={{ display: 'inline-block' }} /></span>}
        </div>
      </div>

      <aside className="ws-side">
        <div className="tabs" role="tablist">
          {[['properties', 'ws.properties', 'Properties'], ['layers', 'ws.layers', 'Layers'], ['copilot', 'ws.copilot', 'Copilot'], ['issues', 'ws.issues', 'Issues'], ['rooms', 'ws.rooms', 'Rooms'], ['history', 'ws.history', 'History'], ['revisions', 'ws.revisions', 'Revisions']].map(([k, key, en]) => (
            <button key={k} role="tab" aria-selected={panel === k} className={`tab ${panel === k ? 'active' : ''}`} onClick={() => setPanel(k)}>{t(key, en)}</button>
          ))}
        </div>
        <div className="ws-panel">
          {panel === 'properties' && <Properties d={d} sel={sel} selBox={selBox} op={op} editable={editable} mmPerUnit={mmPerUnit} />}
          {panel === 'layers' && <Layers d={d} reload={reload} editable={editable} />}
          {panel === 'copilot' && <Copilot initialText={draft ?? ''} d={d} selected={selected} setGhosts={setGhosts} reload={reload} onFocus={(ids) => { setSelected(new Set(ids)); cad.current?.focus({ x: 0, y: 0 }, ids); }} />}
          {panel === 'issues' && <Issues run={run} runChecks={runChecks} active={activeFinding} onPick={(f, i) => {
            setActiveFinding(i);
            if (f.entity_ids?.length) setSelected(new Set(f.entity_ids));
            if (f.location || f.entity_ids?.length) cad.current?.focus(f.location ?? { x: 0, y: 0 }, f.entity_ids);
          }} />}
          {panel === 'rooms' && <Rooms d={d} onPick={(id) => { setSelected(new Set([id])); cad.current?.focus({ x: 0, y: 0 }, [id]); }} />}
          {panel === 'history' && <History d={d} />}
          {panel === 'revisions' && <Revisions d={d} reload={reload} editable={editable} onShow={(ids) => { setSelected(new Set(ids)); setPanel('properties'); }} />}
        </div>
        <div className="faint" style={{ padding: '6px 12px', borderTop: '1px solid var(--border)' }}>
          {d.import_diagnostics?.warnings?.length ? <a href="#" onClick={(e) => { e.preventDefault(); go(`project/${d.project.id}/intake`); }}>⚠ {d.import_diagnostics.warnings.length} import warning(s)</a> : 'No import warnings'}
        </div>
      </aside>

      {acadOpen && <AutoCadModal d={d} onClose={() => setAcadOpen(false)} />}
      {textAt && <TextModal at={textAt} onClose={() => setTextAt(null)} onSubmit={async (text, h) => {
        await op({ kind: 'add', entities: [{ type: 'TEXT', layer: activeLayer, geom: { p: textAt, h, rot: 0, text } }] }, 'Add TEXT');
        setTextAt(null);
      }} />}
    </div>
  );
}

function UnitsBanner({ d, reload }: { d: Drawing; reload: () => Promise<void> }) {
  const { toast, can } = useApp();
  const [units, setUnits] = useState('');
  const [source, setSource] = useState('');
  return (
    <div className="notice" style={{ margin: 8, borderRadius: 8 }}>
      <b>Drawing units are not defined.</b> Areas, distances in mm and unit-bearing checks report INSUFFICIENT DATA. Set the unit only from an authoritative source.
      {can('engineer') && <div className="row" style={{ marginTop: 6 }}>
        <select value={units} onChange={(e) => setUnits(e.target.value)} style={{ width: 120 }}><option value="">unit…</option>{['mm', 'cm', 'm', 'in', 'ft'].map((u) => <option key={u}>{u}</option>)}</select>
        <input value={source} onChange={(e) => setSource(e.target.value)} placeholder="source, e.g. title block of the original drawing" style={{ flex: 1, minWidth: 200 }} />
        <button className="btn sm" disabled={!units || !source} onClick={async () => { try { await api.patch(`/api/drawings/${d.id}`, { units, unitsSource: source }); await reload(); } catch (e: any) { toast(e.message, 'error'); } }}>Set units</button>
      </div>}
    </div>
  );
}

function Properties({ d, sel, selBox, op, editable, mmPerUnit }: { d: Drawing; sel: Entity[]; selBox: any; op: (b: any, l: string) => Promise<any>; editable: boolean; mmPerUnit: number | null }) {
  const { t } = useT();
  const [dx, setDx] = useState('0'), [dy, setDy] = useState('0'), [ang, setAng] = useState('90'), [layer, setLayer] = useState('');
  const ids = sel.map((e) => e.id);
  const unitLabel = d.units === 'unitless' ? 'units' : d.units;
  if (!sel.length) return (
    <div className="stack">
      <div className="faint">{t('ws.noSelection', 'Nothing selected')}. Click an entity, drag a window, or Shift+click to add.</div>
      <div className="card" style={{ padding: 10 }}>
        <div className="faint">Drawing extents</div>
        {d.extents ? <div className="mono ltr">{fmt(d.extents.minX)}, {fmt(d.extents.minY)} → {fmt(d.extents.maxX)}, {fmt(d.extents.maxY)} {unitLabel}</div> : '—'}
        <div className="faint" style={{ marginTop: 8 }}>Keyboard</div>
        <div className="faint">V select · H pan · L line · R rect · P polyline · C circle · T text · M measure · W wall · D door · N window · F fit · Del delete · ←↑→↓ nudge 10 mm (Shift 100 mm) · Ctrl+Z / Ctrl+Y</div>
      </div>
    </div>
  );
  const c = selBox ? { x: (selBox.minX + selBox.maxX) / 2, y: (selBox.minY + selBox.maxY) / 2 } : { x: 0, y: 0 };
  const one = sel.length === 1 ? sel[0] : null;
  return (
    <div className="stack">
      <div className="row"><b>{sel.length} {t('ws.selected', 'selected')}</b><span className="faint">{[...new Set(sel.map((e) => e.type))].join(', ')}</span></div>
      {one && (
        <div className="card" style={{ padding: 10 }}>
          <div className="faint mono ltr">{one.id}</div>
          <div className="row"><span className="chip">{one.type}</span><span className="chip">{one.layer}</span><span className={`chip ${one.provenance === 'ai' ? 'c-ai_suggestion' : ''}`}>{one.provenance}</span></div>
          <pre className="json ltr" style={{ marginTop: 6 }}>{JSON.stringify(one.geom, (_k, v) => (typeof v === 'number' ? Number(v.toFixed(6)) : v), 1)}</pre>
          {one.type === 'POLYLINE' && one.geom.closed && <div className="faint">closed polygon · {one.geom.points.length} vertices</div>}
        </div>
      )}
      {editable && <>
        <div className="card stack" style={{ padding: 10 }}>
          <div className="faint">{t('ws.move', 'Move')} / {t('ws.copy', 'Copy')} by Δ ({unitLabel})</div>
          <div className="row"><input className="mono" value={dx} onChange={(e) => setDx(e.target.value)} aria-label="dx" style={{ width: 90 }} /><input className="mono" value={dy} onChange={(e) => setDy(e.target.value)} aria-label="dy" style={{ width: 90 }} /></div>
          {mmPerUnit && <div className="faint">= {fmt(+dx * mmPerUnit, 2)} mm, {fmt(+dy * mmPerUnit, 2)} mm</div>}
          <div className="row">
            <button className="btn sm" disabled={!isFinite(+dx) || !isFinite(+dy)} onClick={() => op({ kind: 'move', ids, dx: +dx, dy: +dy }, 'Move')}><Icon name="move" />{t('ws.move', 'Move')}</button>
            <button className="btn sm" disabled={!isFinite(+dx) || !isFinite(+dy)} onClick={() => op({ kind: 'copy', ids, dx: +dx, dy: +dy }, 'Copy')}><Icon name="copy" />{t('ws.copy', 'Copy')}</button>
          </div>
        </div>
        <div className="card stack" style={{ padding: 10 }}>
          <div className="faint">{t('ws.rotate', 'Rotate')} about selection centre (°, CCW +)</div>
          <div className="row"><input className="mono" value={ang} onChange={(e) => setAng(e.target.value)} style={{ width: 90 }} />
            <button className="btn sm" disabled={!isFinite(+ang)} onClick={() => op({ kind: 'rotate', ids, cx: c.x, cy: c.y, angle: +ang }, 'Rotate')}><Icon name="rotate" />{t('ws.rotate', 'Rotate')}</button></div>
          <div className="row">
            <button className="btn sm" onClick={() => op({ kind: 'mirror', ids, ax: c.x, ay: c.y, bx: c.x, by: c.y + 1 }, 'Mirror ↔')}><Icon name="mirror" />{t('ws.mirror', 'Mirror')} ↔</button>
            <button className="btn sm" onClick={() => op({ kind: 'mirror', ids, ax: c.x, ay: c.y, bx: c.x + 1, by: c.y }, 'Mirror ↕')}><Icon name="mirror" />{t('ws.mirror', 'Mirror')} ↕</button>
          </div>
        </div>
        <div className="card stack" style={{ padding: 10 }}>
          <div className="faint">Layer</div>
          <div className="row"><select value={layer} onChange={(e) => setLayer(e.target.value)} style={{ flex: 1 }}><option value="">move to layer…</option>{d.layers.filter((l) => !l.locked).map((l) => <option key={l.name}>{l.name}</option>)}</select>
            <button className="btn sm" disabled={!layer} onClick={() => op({ kind: 'set_layer', ids, layer }, 'Set layer')}>{t('common.apply', 'Apply')}</button></div>
          {one?.type === 'TEXT' && <EditText e={one} op={op} />}
        </div>
        {one && (one.type === 'DOOR' || one.type === 'WINDOW') && <OpeningProps e={one} d={d} op={op} mmPerUnit={mmPerUnit} />}
        {one?.type === 'WALL' && <WallInfo e={one} d={d} mmPerUnit={mmPerUnit} />}
        <button className="btn danger" onClick={() => op({ kind: 'delete', ids }, 'Delete')}><Icon name="trash" />{t('ws.delete', 'Delete')} ({sel.length})</button>
      </>}
    </div>
  );
}

const mm = (v: number, k: number | null) => (k ? `${fmt(v * k, 1)} mm` : `${fmt(v)} u`);

function OpeningProps({ e, d, op, mmPerUnit }: { e: Entity; d: Drawing; op: (b: any, l: string) => Promise<any>; mmPerUnit: number | null }) {
  const wall = d.entities.find((w) => w.id === e.geom.wallId);
  const len = wall ? wallFrame(wall.geom).len : 0;
  const [offset, setOffset] = useState(''), [width, setWidth] = useState('');
  useEffect(() => { setOffset(mmPerUnit ? String(+(e.geom.offset * mmPerUnit).toFixed(1)) : String(e.geom.offset)); setWidth(mmPerUnit ? String(+(e.geom.width * mmPerUnit).toFixed(1)) : String(e.geom.width)); }, [e.id, e.geom.offset, e.geom.width]);
  const u = (s: string) => (mmPerUnit ? +s / mmPerUnit : +s);
  const unit = mmPerUnit ? 'mm' : 'units';
  return (
    <div className="card stack" style={{ padding: 10 }}>
      <div className="row"><b>{e.type === 'DOOR' ? 'Door' : 'Window'}</b><span className="faint">hosted in wall {e.geom.wallId.slice(0, 8)}</span></div>
      {wall ? <div className="faint">Wall length {mm(len, mmPerUnit)} · clear to start {mm(e.geom.offset - e.geom.width / 2, mmPerUnit)} · clear to end {mm(len - e.geom.offset - e.geom.width / 2, mmPerUnit)}</div>
        : <div className="notice">Host wall missing</div>}
      <div className="grid c2" style={{ gap: 6 }}>
        <label className="field">Centre from wall start ({unit})<input className="mono" value={offset} onChange={(x) => setOffset(x.target.value)} /></label>
        <label className="field">Width ({unit})<input className="mono" value={width} onChange={(x) => setWidth(x.target.value)} /></label>
      </div>
      <div className="row">
        <button className="btn sm" disabled={!(+width > 0) || !isFinite(+offset)} onClick={() => op({ kind: 'set_opening', id: e.id, offset: u(offset), width: u(width) }, 'Set opening')}>Apply</button>
        {e.type === 'DOOR' && <>
          <button className="btn sm" onClick={() => op({ kind: 'set_opening', id: e.id, swing: e.geom.swing === 'left' ? 'right' : 'left' }, 'Flip hinge')}>Flip hinge</button>
          <button className="btn sm" onClick={() => op({ kind: 'set_opening', id: e.id, side: e.geom.side === 1 ? -1 : 1 }, 'Flip swing side')}>Flip side</button>
        </>}
      </div>
      <div className="faint">Moving a door or window slides it along its wall; it cannot leave the wall or overlap another opening.</div>
    </div>
  );
}

function WallInfo({ e, d, mmPerUnit }: { e: Entity; d: Drawing; mmPerUnit: number | null }) {
  const openings = d.entities.filter((o) => (o.type === 'DOOR' || o.type === 'WINDOW') && o.geom.wallId === e.id);
  return (
    <div className="card" style={{ padding: 10 }}>
      <b>Wall</b> <span className="faint">length {mm(wallFrame(e.geom).len, mmPerUnit)} · thickness {mm(e.geom.thickness, mmPerUnit)}</span>
      <div className="faint">{openings.length} hosted opening(s): {openings.map((o) => `${o.type.toLowerCase()} ${mm(o.geom.width, mmPerUnit)}`).join(', ') || '—'}. They move, rotate and are deleted with the wall.</div>
    </div>
  );
}

function EditText({ e, op }: { e: Entity; op: (b: any, l: string) => Promise<any> }) {
  const [text, setText] = useState(e.geom.text);
  useEffect(() => setText(e.geom.text), [e.id, e.geom.text]);
  return <div className="row"><input value={text} onChange={(x) => setText(x.target.value)} style={{ flex: 1 }} dir="auto" /><button className="btn sm" disabled={!text || text === e.geom.text} onClick={() => op({ kind: 'edit_text', id: e.id, text }, 'Edit text')}>Set text</button></div>;
}

function Layers({ d, reload, editable }: { d: Drawing; reload: () => Promise<void>; editable: boolean }) {
  const { toast } = useApp();
  const counts = useMemo(() => { const m: Record<string, number> = {}; d.entities.forEach((e) => (m[e.layer] = (m[e.layer] ?? 0) + 1)); return m; }, [d.entities]);
  const patch = async (name: string, body: any) => { try { await api.patch(`/api/drawings/${d.id}/layers/${encodeURIComponent(name)}`, body); await reload(); } catch (e: any) { toast(e.message, 'error'); } };
  return (
    <div>
      {d.layers.map((l) => (
        <div key={l.name} className="layer-row">
          <span className="layer-swatch" style={{ background: aciColor(l.color, 'var(--text)') }} />
          <span style={{ flex: 1 }} className="ltr">{l.name}</span><span className="faint">{counts[l.name] ?? 0}</span>
          <button className="btn icon ghost" aria-label="visibility" onClick={() => patch(l.name, { visible: !l.visible })}><Icon name={l.visible ? 'eye' : 'eyeoff'} size={15} /></button>
          <button className="btn icon ghost" aria-label="lock" disabled={!editable} title={l.locked ? 'Locked: entities on this layer cannot be changed by users or the copilot' : 'Unlocked'}
            onClick={() => { if (!l.locked || confirm(`Unlock "${l.name}"? Plot and survey boundaries are locked to protect authoritative coordinates.`)) patch(l.name, { locked: !l.locked }); }}>
            <Icon name={l.locked ? 'lock' : 'unlock'} size={15} /></button>
        </div>
      ))}
    </div>
  );
}

function Copilot({ d, selected, setGhosts, reload, onFocus, initialText = '' }: { d: Drawing; selected: Set<string>; setGhosts: (g: Entity[]) => void; reload: () => Promise<void>; onFocus: (ids: string[]) => void; initialText?: string }) {
  const { toast, can } = useApp();
  const { t } = useT();
  const [text, setText] = useState(initialText);
  const [provider, setProvider] = useState('rule');
  const [providers, setProviders] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => { api.get('/api/copilot/providers').then(setProviders).catch(() => {}); }, []);
  useEffect(() => () => setGhosts([]), []);

  const send = async () => {
    if (!text.trim()) return;
    setBusy(true);
    try {
      const r = await api.post(`/api/drawings/${d.id}/copilot`, { instruction: text, selection: [...selected], provider });
      setItems((xs) => [...xs, { instruction: text, r, state: r.status }]);
      setGhosts(r.status === 'proposed' ? r.preview.filter((c: any) => c.after).map((c: any) => c.after) : []);
      setText('');
    } catch (e: any) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const apply = async (i: number) => {
    const it = items[i];
    try {
      const r = await api.post(`/api/drawings/${d.id}/proposals/${it.r.id}/apply`);
      setItems((xs) => xs.map((x, k) => (k === i ? { ...x, state: 'applied', applied: r } : x)));
      setGhosts([]); await reload();
      toast(`Applied as operation #${r.seq}. Stored result matches preview: ${r.verification.stored_matches_preview ? 'yes' : 'NO'}`, r.verification.stored_matches_preview ? 'ok' : 'error');
    } catch (e: any) { toast(e.message, 'error'); }
  };
  const reject = async (i: number) => {
    await api.post(`/api/drawings/${d.id}/proposals/${items[i].r.id}/reject`).catch(() => {});
    setItems((xs) => xs.map((x, k) => (k === i ? { ...x, state: 'rejected' } : x))); setGhosts([]);
  };

  return (
    <div className="stack" style={{ height: '100%' }}>
      <div className="notice violet" style={{ fontSize: 12 }}>The copilot only proposes operations on your selection. Nothing changes until you apply; every applied change is undoable and logged with its proposal.</div>
      <div style={{ flex: 1 }}>
        {!items.length && <div className="faint">Try: “Move this door 200 mm to the left”, “انقل الباب 200 مم لليسار”, “rotate 90 degrees”, “احسب مساحة الغرف”, “show unresolved checks”.</div>}
        {items.map((it, i) => (
          <div key={i}>
            <div className="msg user" dir="auto">{it.instruction}</div>
            <div className="msg ai">
              <div className="row" style={{ gap: 6 }}><span className="chip">{it.r.provider}{it.r.model ? ` · ${it.r.model}` : ''}</span><span className={`chip ${it.state === 'applied' ? 'c-confirmed' : it.state === 'invalid' ? 'c-unresolved' : 'c-ai_suggestion'}`}>{it.state}</span></div>
              {it.r.intent.explanation && <div style={{ marginTop: 6 }} dir="auto">{it.r.intent.explanation}</div>}
              {it.r.intent.questions.map((q: string) => <div key={q} style={{ marginTop: 6, color: 'var(--warn)' }} dir="auto">? {q}</div>)}
              {it.r.intent.assumptions.map((a: string) => <div key={a} className="faint" dir="auto">assumption: {a}</div>)}
              {it.r.operation && <pre className="json ltr" style={{ marginTop: 6 }}>{JSON.stringify({ ...it.r.operation, ids: it.r.operation.ids?.length }, null, 1)}</pre>}
              {it.r.validation?.errors?.map((e: string) => <div key={e} className="notice" style={{ marginTop: 6 }}>{e}</div>)}
              {it.r.answer?.kind === 'room_areas' && (
                <table className="t" style={{ marginTop: 6 }}><tbody>{it.r.answer.rooms.map((r: any) => (
                  <tr key={r.entityId} className="click" onClick={() => onFocus([r.entityId])}><td dir="auto">{r.name ?? '(unlabelled)'}</td><td className="mono">{r.area_m2 === null ? `${fmt(r.area_units2)} u²` : `${r.area_m2} m²`}</td><td>{r.valid ? '' : '⚠'}</td></tr>))}</tbody></table>
              )}
              {it.r.answer?.findings && (
                <div style={{ marginTop: 6 }}>{it.r.answer.findings.slice(0, 30).map((f: any, k: number) => (
                  <div key={k} className="row" style={{ padding: '2px 0', cursor: f.entityIds.length ? 'pointer' : 'default' }} onClick={() => f.entityIds.length && onFocus(f.entityIds)}><Status s={f.status} /><span className="mono">{f.rule}</span><span className="faint">{f.message}</span></div>))}</div>
              )}
              {it.state === 'proposed' && (
                <div className="row" style={{ marginTop: 8 }}>
                  <span className="faint">{t('ws.preliminary', 'Preliminary — preview shown dashed in violet')}</span>
                  <button className="btn sm primary" disabled={!can('engineer')} onClick={() => apply(i)}><Icon name="check" />{t('common.apply', 'Apply')}</button>
                  <button className="btn sm" onClick={() => reject(i)}>{t('common.reject', 'Reject')}</button>
                </div>
              )}
              {it.applied && <div className="faint" style={{ marginTop: 6 }}>Applied as op #{it.applied.seq}; QA after change: {Object.entries(it.applied.verification.qa_summary).map(([k, v]) => `${k} ${v}`).join(', ')}</div>}
            </div>
          </div>
        ))}
      </div>
      <div className="stack" style={{ gap: 6 }}>
        <div className="row"><span className="faint">{selected.size} selected</span><span className="spacer" />
          <select value={provider} onChange={(e) => setProvider(e.target.value)} style={{ width: 'auto', padding: '3px 6px', fontSize: 12 }}>
            {providers.map((p) => <option key={p.id} value={p.id} disabled={!p.available}>{p.id === 'rule' ? 'Offline interpreter' : `${p.name} ${p.model ?? ''}`}{p.available ? '' : ' (not configured)'}</option>)}
          </select></div>
        <textarea rows={2} dir="auto" value={text} placeholder={t('ws.askCopilot', 'Type an instruction… e.g. move this door 200 mm to the left')} onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} style={{ minHeight: 56 }} />
        <button className="btn primary" disabled={busy || !text.trim()} onClick={send}><Icon name="send" />{t('ws.send', 'Send')}</button>
      </div>
    </div>
  );
}

function Issues({ run, runChecks, onPick, active }: { run: any; runChecks: (s?: string) => void; onPick: (f: Finding, i: number) => void; active: number | null }) {
  const { t } = useT();
  if (!run) return <div className="stack"><div className="faint">No checks run in this session.</div><button className="btn" onClick={() => runChecks()}><Icon name="play" />{t('ws.runChecks', 'Run checks')}</button></div>;
  return (
    <div className="stack" style={{ gap: 8 }}>
      <div className="row">{Object.entries(run.summary).map(([s, n]) => <span key={s} className="row" style={{ gap: 3 }}><Status s={s} /><span className="faint">{n as number}</span></span>)}</div>
      <div className="row"><button className="btn sm" onClick={() => api.openHtml(`/api/compliance-runs/${run.id}/report`)}><Icon name="report" />{t('ws.report', 'Report')}</button>
        <button className="btn sm ghost" onClick={() => runChecks()}><Icon name="rotate" />{t('common.refresh', 'Re-run')}</button></div>
      {run.findings.map((f: Finding, i: number) => (
        <div key={i} className="card" style={{ padding: 8, cursor: 'pointer', borderColor: i === active ? 'var(--cyan)' : undefined }} onClick={() => onPick(f, i)}>
          <div className="row" style={{ gap: 6 }}><Status s={f.status} /><span className="mono" style={{ fontSize: 11 }}>{f.rule_code}</span></div>
          <div style={{ fontSize: 12.5, marginTop: 3 }} dir="auto">{f.message}</div>
          {f.corrective_action && f.status !== 'PASS' && <div className="faint">→ {f.corrective_action}</div>}
        </div>
      ))}
    </div>
  );
}

function Rooms({ d, onPick }: { d: Drawing; onPick: (id: string) => void }) {
  const total = d.rooms.reduce((s, r) => s + (r.areaM2 ?? 0), 0);
  if (!d.rooms.length) return <div className="faint">No room boundaries. Rooms are closed polylines on a layer named like ROOM / SPACE / A-AREA, named by a text label inside.</div>;
  return (
    <table className="t">
      <thead><tr><th>Room</th><th>Area</th><th /></tr></thead>
      <tbody>
        {d.rooms.map((r) => <tr key={r.entityId} className="click" onClick={() => onPick(r.entityId)}><td dir="auto">{r.name ?? <i className="faint">unlabelled</i>}</td><td className="mono">{r.areaM2 === null ? `${fmt(r.areaUnits2)} u²` : `${fmt(r.areaM2, 3)} m²`}</td><td>{r.valid ? '' : <span title={r.problems.join(', ')}>⚠</span>}</td></tr>)}
        <tr><td><b>Total (valid rooms)</b></td><td className="mono"><b>{d.units === 'unitless' ? '—' : `${fmt(total, 3)} m²`}</b></td><td /></tr>
      </tbody>
    </table>
  );
}

function History({ d }: { d: Drawing }) {
  const [h, setH] = useState<any[] | null>(null);
  useEffect(() => { api.get(`/api/drawings/${d.id}/history`).then(setH); }, [d.seq, d.canRedo]);
  if (!h) return null;
  if (!h.length) return <div className="faint">No operations yet.</div>;
  return (
    <div className="stack" style={{ gap: 4 }}>
      {h.map((o) => (
        <div key={o.id} className="row" style={{ fontSize: 12.5, opacity: o.state === 'applied' ? 1 : 0.5, borderBottom: '1px solid var(--border)', padding: '4px 0' }}>
          <span className="mono">#{o.seq}</span><b>{o.kind}</b><span className="faint">{o.affected} ent.</span>
          {o.source === 'ai' && <span className="chip c-ai_suggestion">AI</span>}
          <span className="spacer" /><span className="faint">{o.state !== 'applied' ? o.state : ''} {o.actor} · {new Date(o.created_at).toLocaleTimeString()}</span>
        </div>
      ))}
    </div>
  );
}

function Revisions({ d, reload, editable, onShow }: { d: Drawing; reload: () => Promise<void>; editable: boolean; onShow: (ids: string[]) => void }) {
  const { toast } = useApp();
  const [revs, setRevs] = useState<any[] | null>(null);
  const [diff, setDiff] = useState<any | null>(null);
  const load = () => api.get(`/api/drawings/${d.id}/revisions`).then(setRevs);
  useEffect(() => { load(); }, [d.seq]);
  if (!revs) return null;
  return (
    <div className="stack" style={{ gap: 6 }}>
      {!revs.length && <div className="faint">No checkpoints yet. Use “Checkpoint” in the toolbar.</div>}
      {revs.map((r) => (
        <div key={r.id} className="card" style={{ padding: 8 }}>
          <div className="row"><b>R{r.number}</b><span dir="auto">{r.label}</span></div>
          <div className="faint">{r.entities} entities · op #{r.op_seq} · {r.author} · {when(r.created_at)}</div>
          <div className="faint mono ltr">sha256 {r.sha256.slice(0, 16)}…</div>
          <div className="row" style={{ marginTop: 4 }}>
            <button className="btn sm" onClick={async () => setDiff({ r, ...(await api.get(`/api/drawings/${d.id}/revisions/${r.id}/diff`)) })}>Compare with current</button>
            {editable && <button className="btn sm" onClick={async () => {
              if (!confirm(`Restore R${r.number}? This is recorded as an undoable operation.`)) return;
              try { await api.post(`/api/drawings/${d.id}/operations`, { op: { kind: 'restore_revision', revisionId: r.id } }); toast(`Restored R${r.number}`, 'ok'); await reload(); } catch (e: any) { toast(e.message, 'error'); }
            }}>Restore</button>}
          </div>
          {diff?.r.id === r.id && <div style={{ marginTop: 6, fontSize: 12.5 }}>
            <div>+ {diff.added.length} added {diff.added.length > 0 && <a href="#" onClick={(e) => { e.preventDefault(); onShow(diff.added); }}>select</a>}</div>
            <div>~ {diff.modified.length} modified {diff.modified.length > 0 && <a href="#" onClick={(e) => { e.preventDefault(); onShow(diff.modified); }}>select</a>}</div>
            <div>− {diff.removed.length} removed {diff.removed.map((x: any) => `${x.type}@${x.layer}`).slice(0, 5).join(', ')}</div>
          </div>}
        </div>
      ))}
    </div>
  );
}

function AutoCadModal({ d, onClose }: { d: Drawing; onClose: () => void }) {
  const { toast } = useApp();
  const { lang } = useT();
  const ar = lang === 'ar';
  const [info, setInfo] = useState<any | null>(null);
  const [paper, setPaper] = useState('A1');
  const [busy, setBusy] = useState<string | null>(null);
  const [res, setRes] = useState<any | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { api.get('/api/integrations/autocad').then(setInfo).catch((e) => setErr(e.message)); }, []);
  const sheet = async () => {
    setBusy('sheet'); setErr(null); setRes(null);
    try { setRes(await api.post(`/api/drawings/${d.id}/autocad/sheet`, { paper })); } catch (e: any) { setErr(e.message); } finally { setBusy(null); }
  };
  const dwg = async () => {
    setBusy('dwg'); setErr(null);
    try { const r = await api.post(`/api/drawings/${d.id}/autocad/dwg`); await api.download(`/api/documents/${r.document.id}/download`, r.document.name); toast('DWG saved', 'ok'); } catch (e: any) { setErr(e.message); } finally { setBusy(null); }
  };
  return (
    <Modal title={ar ? 'إخراج تفصيلي عبر AutoCAD' : 'Detailed output with AutoCAD'} onClose={onClose}>
      <div className="stack">
        {!info ? <div className="faint">…</div> : info.available
          ? <div className="notice info">{ar ? `سيتم استخدام ${info.product} المثبت على هذا الجهاز.` : `Using ${info.product} installed on this computer.`}</div>
          : <div className="notice">{ar ? 'لم يُعثر على AutoCAD على الجهاز الذي يشغّل NOVA.' : 'AutoCAD was not found on the computer running NOVA.'}</div>}
        <div className="faint">{ar
          ? 'لوحة مخطط تفصيلية: جدران مهشّرة، سلاسل أبعاد على كل جدار خارجي، أبعاد صافية للغرف، رموز وجداول للأبواب والنوافذ، جدول الغرف، إطار وخانة عنوان، ثم حفظ DWG وطباعة PDF. يتحقق NOVA من النتيجة بقراءة ملف AutoCAD نفسه.'
          : 'A plan sheet with hatched walls, dimension chains on every external wall, clear room dimensions, door/window tags and schedules, a room schedule, frame and title block — saved as DWG and plotted to PDF. NOVA verifies the result by reading AutoCAD’s own output.'}</div>
        <div className="row">
          <label className="field" style={{ width: 120 }}>{ar ? 'المقاس' : 'Paper'}<select value={paper} onChange={(e) => setPaper(e.target.value)}>{['A1', 'A2', 'A3'].map((p) => <option key={p}>{p}</option>)}</select></label>
          <button className="btn primary" disabled={!info?.available || !!busy} onClick={sheet}>{busy === 'sheet' ? '…' : ar ? 'إنشاء اللوحة (DWG + PDF)' : 'Create sheet (DWG + PDF)'}</button>
          <button className="btn" disabled={!info?.available || !!busy} onClick={dwg}>{busy === 'dwg' ? '…' : ar ? 'حفظ كـ DWG' : 'Save as DWG'}</button>
        </div>
        <ElevationInputs ar={ar} disabled={!info?.available || !!busy} onRun={async (body) => {
          setBusy('elev'); setErr(null); setRes(null);
          try { setRes(await api.post(`/api/drawings/${d.id}/autocad/elevations`, { ...body, paper })); } catch (e: any) { setErr(e.message); } finally { setBusy(null); }
        }} />
        {busy && <div className="row faint"><span className="ai-dot" />{ar ? 'AutoCAD يعمل…' : 'AutoCAD is working…'}</div>}
        {err && <div className="notice" style={{ whiteSpace: 'pre-wrap' }}>{err}</div>}
        {res && (
          <div className="card stack" style={{ padding: 12 }}>
            <div className="row"><b>{res.report.scale} @ {res.report.paper}</b>
              <span className={`chip ${res.verification.ok ? 'c-confirmed' : 'c-unresolved'}`}>{res.verification.ok ? (ar ? 'تم التحقق' : 'verified') : (ar ? 'غير مطابق' : 'mismatch')}</span></div>
            <div className="faint">{ar ? 'التهشير' : 'Hatches'} {res.verification.hatches.found}/{res.verification.hatches.expected} · {ar ? 'الأبعاد' : 'Dimensions'} {res.verification.dimensions.found}/{res.verification.dimensions.expected}
              {res.report.rooms !== undefined && <> · {ar ? 'أبواب' : 'doors'} {res.report.doors} · {ar ? 'نوافذ' : 'windows'} {res.report.windows} · {ar ? 'غرف' : 'rooms'} {res.report.rooms}</>}
              {res.report.elevations !== undefined && <> · {ar ? 'واجهات' : 'elevations'} {res.report.elevations} · {ar ? 'مقطع' : 'section'} A-A · {ar ? 'الارتفاع الكلي' : 'total height'} {res.report.totalHeight_m} m</>}</div>
            {res.warnings.map((w: string) => <div key={w} className="notice">{w}</div>)}
            <div className="row">
              <button className="btn" onClick={() => api.download(`/api/documents/${res.pdf.id}/download`, res.pdf.name)}><Icon name="download" />PDF</button>
              <button className="btn" onClick={() => api.download(`/api/documents/${res.dwg.id}/download`, res.dwg.name)}><Icon name="download" />DWG</button>
            </div>
            <div className="faint">{ar ? 'مخطط أولي — ليس للتنفيذ أو التقديم. حُفظ الملفان في سجل وثائق المشروع.' : 'Preliminary — not for construction or submission. Both files are stored in the project document register.'}</div>
          </div>
        )}
      </div>
    </Modal>
  );
}

function ElevationInputs({ ar, disabled, onRun }: { ar: boolean; disabled: boolean; onRun: (body: any) => void }) {
  const [floors, setFloors] = useState([{ name: 'GROUND', h: '' }]);
  const [v, setV] = useState({ slab: '0.25', parapet: '1.0', plinth: '0.45', door: '2.2', sill: '0.9', head: '2.2', source: '' });
  const ok = floors.every((f) => f.name.trim() && +f.h >= 2.2) && v.source.trim().length >= 3;
  const num = (k: keyof typeof v, label: string) => (
    <label className="field" style={{ width: 92 }}>{label}<input className="mono" value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} /></label>
  );
  return (
    <div className="card stack" style={{ padding: 10 }}>
      <b>{ar ? 'الواجهات والمقطع' : 'Elevations & section'}</b>
      <div className="faint">{ar ? 'أدخل ارتفاعات الأدوار (من أرضية إلى أرضية) ومصدرها. المسقط يصف الدور الأرضي فقط؛ الأدوار العليا تُرسم ككتلة.' : 'Enter floor-to-floor heights and where they come from. The plan describes the ground floor only; upper floors are drawn as massing.'}</div>
      {floors.map((f, i) => (
        <div key={i} className="row">
          <input value={f.name} onChange={(e) => setFloors(floors.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} style={{ width: 120 }} aria-label="floor name" />
          <input className="mono" value={f.h} placeholder={ar ? 'الارتفاع (م)' : 'height (m)'} onChange={(e) => setFloors(floors.map((x, k) => (k === i ? { ...x, h: e.target.value } : x)))} style={{ width: 110 }} aria-label="floor height" />
          {floors.length > 1 && <button className="btn sm ghost" onClick={() => setFloors(floors.filter((_, k) => k !== i))}><Icon name="x" /></button>}
        </div>
      ))}
      <button className="btn sm ghost" style={{ justifySelf: 'start' }} onClick={() => setFloors([...floors, { name: floors.length === 1 ? 'FIRST' : `FLOOR ${floors.length}`, h: '' }])}><Icon name="plus" />{ar ? 'إضافة دور' : 'Add floor'}</button>
      <div className="row" style={{ alignItems: 'flex-end' }}>
        {num('slab', ar ? 'البلاطة' : 'Slab m')}{num('parapet', ar ? 'الدروة' : 'Parapet m')}{num('plinth', ar ? 'منسوب الأرضية' : 'Plinth m')}
        {num('door', ar ? 'أعلى الباب' : 'Door head')}{num('sill', ar ? 'جلسة الشباك' : 'Sill m')}{num('head', ar ? 'أعلى الشباك' : 'Window head')}
      </div>
      <label className="field">{ar ? 'مصدر الارتفاعات' : 'Source of heights'}<input value={v.source} onChange={(e) => setV({ ...v, source: e.target.value })} placeholder={ar ? 'مثال: متطلبات العميل' : 'e.g. client brief'} /></label>
      <button className="btn primary" disabled={disabled || !ok} onClick={() => onRun({
        floors: floors.map((f) => ({ name: f.name.trim(), height_m: +f.h })), slab_m: +v.slab, parapet_m: +v.parapet, plinth_m: +v.plinth,
        door_head_m: +v.door, sill_m: +v.sill, window_head_m: +v.head, source: v.source,
      })}>{ar ? 'إنشاء الواجهات والمقطع (DWG + PDF)' : 'Create elevations + section (DWG + PDF)'}</button>
    </div>
  );
}

function TextModal({ at, onClose, onSubmit }: { at: Pt; onClose: () => void; onSubmit: (text: string, h: number) => Promise<void> }) {
  const [text, setText] = useState('');
  const [h, setH] = useState('250');
  return (
    <Modal title="Add text" onClose={onClose}>
      <div className="stack">
        <div className="faint mono ltr">at {fmt(at.x)}, {fmt(at.y)}</div>
        <input autoFocus dir="auto" value={text} onChange={(e) => setText(e.target.value)} placeholder="text / النص" />
        <label className="field">Height (drawing units)<input className="mono" value={h} onChange={(e) => setH(e.target.value)} /></label>
        <div className="row end"><button className="btn primary" disabled={!text || !(+h > 0)} onClick={() => onSubmit(text, +h)}>Add</button></div>
      </div>
    </Modal>
  );
}
