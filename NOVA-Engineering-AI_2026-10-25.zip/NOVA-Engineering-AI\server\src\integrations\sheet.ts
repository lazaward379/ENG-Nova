import type { EntityInput, Pt, Units } from '../geometry/types.ts';

/** Shared sheet layout for AutoCAD-produced drawings: paper, automatic scale, frame, title block, north, script header. */

export type Paper = 'A1' | 'A2' | 'A3';
export const PAPER: Record<Paper, { w: number; h: number; name: string }> = {
  A1: { w: 841, h: 594, name: 'ISO full bleed A1 (841.00 x 594.00 MM)' },
  A2: { w: 594, h: 420, name: 'ISO full bleed A2 (594.00 x 420.00 MM)' },
  A3: { w: 420, h: 297, name: 'ISO full bleed A3 (420.00 x 297.00 MM)' },
};
const SCALES = [20, 50, 100, 150, 200, 500, 1000];
export const PANEL = 185; // right-hand panel width on paper (mm)

export type BBox = { minX: number; minY: number; maxX: number; maxY: number };
export const fmtN = (v: number) => (Math.abs(v) < 1e-9 ? '0' : v.toFixed(4));
export const fmtP = (p: Pt) => `${fmtN(p.x)},${fmtN(p.y)}`;

export function layoutSheet(o: {
  content: BBox; paper: Paper; mm: number; pad: number; out: EntityInput[];
  title: { project: { code: string; name: string }; drawingName: string; sheetTitle: string; units: Units; date: string; preparedBy: string };
  northDeg: number | null;
}) {
  const warnings: string[] = [];
  const { content, mm } = o;
  const paper = PAPER[o.paper];
  const cw = content.maxX - content.minX + 2 * o.pad, ch = content.maxY - content.minY + 2 * o.pad;
  const areaW = paper.w - PANEL - 20, areaH = paper.h - 20;
  const den = SCALES.find((d) => (cw / mm) / d <= areaW && (ch / mm) / d <= areaH) ?? SCALES[SCALES.length - 1];
  if ((cw / mm) / den > areaW || (ch / mm) / den > areaH) warnings.push('The content is larger than the sheet even at 1:1000; it will be clipped.');
  const k = den * mm; // drawing units per paper millimetre
  const sx = (content.minX + content.maxX) / 2 - (10 + areaW / 2) * k, sy = (content.minY + content.maxY) / 2 - (10 + areaH / 2) * k;
  const S = (x: number, y: number): Pt => ({ x: sx + x * k, y: sy + y * k });
  const line = (layer: string, x1: number, y1: number, x2: number, y2: number) => o.out.push({ type: 'LINE', layer, geom: { a: S(x1, y1), b: S(x2, y2) } });
  const text = (layer: string, x: number, y: number, h: number, t: string) => o.out.push({ type: 'TEXT', layer, geom: { p: S(x, y), h: h * k, rot: 0, text: t } });
  const box = (layer: string, x1: number, y1: number, x2: number, y2: number) => { line(layer, x1, y1, x2, y1); line(layer, x2, y1, x2, y2); line(layer, x2, y2, x1, y2); line(layer, x1, y2, x1, y1); };

  box('G-ANNO-TTLB', 0, 0, paper.w, paper.h);
  box('G-ANNO-TTLB', 10, 10, paper.w - 10, paper.h - 10);
  const px = paper.w - PANEL - 10;
  line('G-ANNO-TTLB', px, 10, px, paper.h - 10);
  const t = o.title;
  const tb = [
    [`PROJECT: ${t.project.code}`, 5], [t.project.name, 3.5], [`DRAWING: ${t.drawingName}`, 3.5], [t.sheetTitle, 3.5],
    [`SCALE 1:${den} @ ${o.paper}   UNITS: ${t.units}`, 3], [`DATE: ${t.date}`, 3], [`PREPARED BY: ${t.preparedBy}`, 3],
    ['CHECKED BY (LICENSED ENGINEER): ____________', 3], ['STATUS: PRELIMINARY - NOT FOR CONSTRUCTION OR SUBMISSION', 3],
    ['Detailed by NOVA Engineering AI with AutoCAD (accoreconsole)', 2.5],
  ] as [string, number][];
  let ty = 18;
  for (const [s, h] of [...tb].reverse()) { text('G-ANNO-TTLB', px + 5, ty, h, s); ty += h + 4; }
  line('G-ANNO-TTLB', px, ty + 2, paper.w - 10, ty + 2);

  const nx = px + 150, ny = paper.h - 40;
  if (o.northDeg !== null) {
    const r = (o.northDeg * Math.PI) / 180, L = 12;
    const tip = { x: nx + Math.sin(r) * L, y: ny + Math.cos(r) * L };
    o.out.push({ type: 'LINE', layer: 'G-ANNO-NRTH', geom: { a: S(nx - Math.sin(r) * L, ny - Math.cos(r) * L), b: S(tip.x, tip.y) } });
    o.out.push({ type: 'CIRCLE', layer: 'G-ANNO-NRTH', geom: { c: S(nx, ny), r: L * k } });
    text('G-ANNO-NRTH', tip.x - 1.5, tip.y + 2, 4, 'N');
  } else text('G-ANNO-NOTE', px + 5, paper.h - 25, 2.5, 'NORTH DIRECTION NOT CONFIRMED - NOT SHOWN');

  return {
    k, den, S, line, text, box, px, ty, paper, warnings,
    plot: { paperName: paper.name, scaleArg: `1=${fmtN(k)}`, lo: fmtP(S(0, 0)), hi: fmtP(S(paper.w, paper.h)) },
  };
}

/** Script header: drawing units, Arial text style and a dimension style sized for the sheet scale. */
export function scriptHeader(units: Units, k: number, mpu: number) {
  return ['_.FILEDIA 0', '_.CMDECHO 0', '_.OSMODE 0', '_.INSUNITS ' + ({ mm: 4, cm: 5, m: 6, in: 1, ft: 2, unitless: 0 } as const)[units],
    '_.-STYLE Standard arial.ttf 0 1 0 _N _N',
    `_.DIMSCALE ${fmtN(k)}`, '_.DIMTXT 2.2', '_.DIMASZ 1.2', '_.DIMTSZ 1', '_.DIMEXO 1.5', '_.DIMEXE 1.25', '_.DIMGAP 0.8', '_.DIMDEC 0', '_.DIMZIN 8',
    '_.DIMTAD 1', '_.DIMTIH 0', '_.DIMTOH 0', `_.DIMLFAC ${fmtN(1000 * mpu)}`, '_.DIMCLRD 8', '_.DIMCLRE 8'];
}

/** Closed polyline + hatch of it (pattern names are fixed strings chosen by NOVA). */
export function hatchCmds(pts: Pt[], pattern: 'ANSI31' | 'AR-CONC' | 'SOLID', scale: number) {
  const pl = `_.PLINE ${pts.map(fmtP).join(' ')} _C`;
  return pattern === 'SOLID' ? [pl, '_.-HATCH _P _S _S _L ', ''] : [pl, `_.-HATCH _P ${pattern} ${fmtN(scale)} 0 _S _L `, ''];
}

/** Paper finishing: zoom, save DWG, DXF for verification, plot PDF through the sheet window. */
export function finishScript(plot: { paperName: string; scaleArg: string; lo: string; hi: string }, paths: { dwg: string; dxf: string; pdf: string }) {
  return ['_.ZOOM _E', `_.SAVEAS 2018 ${paths.dwg}`, `_.DXFOUT ${paths.dxf} _V 2010 16`, '_.BACKGROUNDPLOT 0',
    '_.-PLOT', '_Y', 'Model', 'DWG To PDF.pc3', plot.paperName, '_M', '_L', '_N', '_W', plot.lo, plot.hi,
    plot.scaleArg, '_C', '_Y', 'monochrome.ctb', '_Y', '_A', paths.pdf, '_N', '_Y', '_.QUIT Y', ''];
}
