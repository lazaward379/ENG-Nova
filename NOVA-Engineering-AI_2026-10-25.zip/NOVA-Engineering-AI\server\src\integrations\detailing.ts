import type { Entity, EntityInput, Pt, Units } from '../geometry/types.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { bbox, pointInPolygon, polygonArea } from '../geometry/math.ts';
import { extractRooms } from '../geometry/rooms.ts';
import { explode, isOpening, wallFrame } from '../geometry/hosted.ts';
import { fmtP, hatchCmds, layoutSheet, scriptHeader, type Paper } from './sheet.ts';

export type { Paper };

/**
 * Turns a NOVA drawing into a detailed 1:n plan sheet:
 *  - DXF content (text/lines that may contain user text): door & window symbols, tags, schedules,
 *    room schedule, title block, notes;
 *  - an AutoCAD script that adds native objects from numbers only: hatched wall segments
 *    (solid between openings), aligned dimension chains, clear room dimensions, and plots to PDF.
 */

export type SheetInput = {
  entities: Entity[]; units: Units; paper: Paper;
  project: { code: string; name: string }; drawingName: string; preparedBy: string;
  northDeg: number | null; date: string;
};

const P = fmtP;
const add = (a: Pt, b: Pt, k = 1): Pt => ({ x: a.x + b.x * k, y: a.y + b.y * k });

export function buildSheet(s: SheetInput) {
  const mpu = metresPerUnit(s.units);
  if (mpu === null) throw new Error('Drawing units are not defined; a scaled sheet cannot be produced.');
  const mm = 0.001 / mpu; // drawing units per millimetre (real)
  const warnings: string[] = [];
  const dxf: EntityInput[] = [];
  const script: string[] = [];
  const walls = s.entities.filter((e) => e.type === 'WALL') as Extract<Entity, { type: 'WALL' }>[];
  const openings = s.entities.filter(isOpening);
  const rooms = extractRooms(s.entities, s.units).filter((r) => r.valid);
  const inRoom = (p: Pt) => rooms.some((r) => pointInPolygon(p, r.points));

  // ---- base content: every primitive except NOVA's old line-dimensions; typed elements are redrawn below ----
  for (const e of s.entities) {
    if (e.type === 'WALL' || isOpening(e) || /(^|-)DIMS?$/i.test(e.layer)) continue;
    dxf.push({ type: e.type, layer: e.layer, geom: e.geom, props: e.props } as any);
  }
  if (!walls.length) warnings.push('The drawing has no typed walls: wall hatching, opening tags and dimension chains need NOVA walls (draw them with the Wall tool or generate the plan from a reference).');

  // ---- walls: solid segments between openings (hatched by AutoCAD) ----
  type Solid = Pt[];
  const solids: Solid[] = [];
  const chains: { pts: Pt[]; off: Pt; overall: [Pt, Pt] | null }[] = [];
  for (const w of walls) {
    const { len, dir, normal } = wallFrame(w.geom);
    const h = w.geom.thickness / 2;
    const ops = openings.filter((o) => (o.geom as any).wallId === w.id).map((o) => [(o.geom as any).offset - (o.geom as any).width / 2, (o.geom as any).offset + (o.geom as any).width / 2]).sort((a, b) => a[0] - b[0]);
    let t = 0;
    const cuts: number[] = [0];
    for (const [a, b] of ops) { if (a > t) solids.push(rect(w.geom.a, dir, normal, t, a, h)); t = Math.max(t, b); cuts.push(a, b); }
    if (len > t) solids.push(rect(w.geom.a, dir, normal, t, len, h));
    cuts.push(len);
    // external if one face has no room behind it
    const mid = add(w.geom.a, dir, len / 2);
    const probe = h + 50 * mm;
    const leftIn = inRoom(add(mid, normal, probe)), rightIn = inRoom(add(mid, normal, -probe));
    if (leftIn !== rightIn) {
      const out = leftIn ? { x: -normal.x, y: -normal.y } : normal;
      const face = add(w.geom.a, out, h);
      const pts = [...new Set(cuts.map((c) => +c.toFixed(6)))].sort((a, b) => a - b).map((c) => add(face, dir, c));
      chains.push({ pts, off: { x: out.x * (h + 1200 * mm), y: out.y * (h + 1200 * mm) }, overall: ops.length ? [pts[0], pts[pts.length - 1]] : null });
    }
  }

  // ---- doors & windows: symbols and tags ----
  const tags: { tag: string; type: string; width: number; rooms: string }[] = [];
  const sorted = [...openings].sort((a, b) => a.type.localeCompare(b.type) || (a.geom as any).p.y - (b.geom as any).p.y || (a.geom as any).p.x - (b.geom as any).p.x);
  let di = 0, wi = 0;
  for (const o of sorted) {
    const g: any = o.geom;
    const wall = walls.find((w) => w.id === g.wallId);
    const h = (wall?.geom.thickness ?? 200 * mm) / 2;
    const nrm = { x: -g.dir.y, y: g.dir.x };
    const a = add(g.p, g.dir, -g.width / 2), b = add(g.p, g.dir, g.width / 2);
    // jambs
    for (const q of [a, b]) dxf.push({ type: 'LINE', layer: o.type === 'DOOR' ? 'A-DOOR' : 'A-GLAZ', geom: { a: add(q, nrm, -h), b: add(q, nrm, h) } });
    if (o.type === 'DOOR') dxf.push(...explode(o).map((x) => ({ ...x, layer: 'A-DOOR' })));
    else for (const k of [-h, 0, h]) dxf.push({ type: 'LINE', layer: 'A-GLAZ', geom: { a: add(a, nrm, k), b: add(b, nrm, k) } });
    const side = inRoom(add(g.p, nrm, h + 100 * mm)) ? 1 : -1;
    const tag = o.type === 'DOOR' ? `D${String(++di).padStart(2, '0')}` : `W${String(++wi).padStart(2, '0')}`;
    const at = add(g.p, nrm, side * (h + 450 * mm));
    dxf.push({ type: 'CIRCLE', layer: 'A-ANNO-TAG', geom: { c: { x: at.x + 180 * mm, y: at.y + 60 * mm }, r: 250 * mm } });
    dxf.push({ type: 'TEXT', layer: 'A-ANNO-TAG', geom: { p: at, h: 150 * mm, rot: 0, text: tag } });
    const adj = rooms.filter((r) => pointInPolygon(add(g.p, nrm, h + 100 * mm), r.points) || pointInPolygon(add(g.p, nrm, -(h + 100 * mm)), r.points)).map((r) => r.name ?? '?');
    tags.push({ tag, type: o.type === 'DOOR' ? `Door, single leaf, hinge ${g.swing}` : 'Window', width: g.width / mm, rooms: adj.join(' / ') || 'external' });
  }

  // ---- clear room dimensions (axis-aligned rectangular rooms) ----
  const roomDims: [Pt, Pt, Pt][] = [];
  for (const r of rooms) {
    if (r.points.length !== 4) continue;
    const b = bbox([{ type: 'POLYLINE', layer: 'x', geom: { points: r.points, closed: true } }])!;
    const isRect = Math.abs(polygonArea(r.points) - (b.maxX - b.minX) * (b.maxY - b.minY)) < 1e-6 * polygonArea(r.points);
    if (!isRect) continue;
    const half = (x1: Pt, x2: Pt) => (walls.find((w) => segOn(w.geom.a, w.geom.b, x1, x2))?.geom.thickness ?? 0) / 2;
    const L = b.minX + half({ x: b.minX, y: b.minY }, { x: b.minX, y: b.maxY }), R = b.maxX - half({ x: b.maxX, y: b.minY }, { x: b.maxX, y: b.maxY });
    const B = b.minY + half({ x: b.minX, y: b.minY }, { x: b.maxX, y: b.minY }), T = b.maxY - half({ x: b.minX, y: b.maxY }, { x: b.maxX, y: b.maxY });
    const yy = B + (T - B) * 0.3, xx = L + (R - L) * 0.7;
    roomDims.push([{ x: L, y: yy }, { x: R, y: yy }, { x: (L + R) / 2, y: yy }], [{ x: xx, y: B }, { x: xx, y: T }, { x: xx, y: (B + T) / 2 }]);
  }

  // ---- sheet layout: choose the scale, place the frame ----
  const content = bbox(dxf.concat(solids.map((q) => ({ type: 'POLYLINE', layer: 'x', geom: { points: q, closed: true } }) as EntityInput)))!;
  const L = layoutSheet({
    content, paper: s.paper, mm, pad: 3000 * mm, out: dxf, northDeg: s.northDeg,
    title: { project: s.project, drawingName: s.drawingName, sheetTitle: 'GROUND FLOOR PLAN', units: s.units, date: s.date, preparedBy: s.preparedBy },
  });
  warnings.push(...L.warnings);
  const { k, den, line, text, px, ty, paper } = L;

  // schedules (top of panel)
  let y = paper.h - 35;
  const table = (title: string, cols: [string, number][], rows: string[][]) => {
    text('A-ANNO-SCHD', px + 5, y, 3.5, title); y -= 7;
    let x = px + 5;
    for (const [c, w] of cols) { text('A-ANNO-SCHD', x, y, 2.2, c); x += w; }
    y -= 2; line('A-ANNO-SCHD', px + 5, y, paper.w - 15, y); y -= 4.5;
    for (const r of rows) {
      x = px + 5;
      r.forEach((cell, i) => { text('A-ANNO-SCHD', x, y, 2.2, cell.slice(0, Math.floor(cols[i][1] / 1.6))); x += cols[i][1]; });
      y -= 4.5;
      if (y < ty + 20) { warnings.push(`${title} truncated: not enough space on the sheet.`); break; }
    }
    y -= 6;
  };
  table('DOOR & WINDOW SCHEDULE', [['TAG', 14], ['TYPE', 64], ['WIDTH mm', 22], ['BETWEEN', 70]], tags.map((t) => [t.tag, t.type, t.width.toFixed(0), t.rooms]));
  table('ROOM SCHEDULE', [['ROOM', 80], ['AREA m2', 30], ['PERIM. m', 30]], rooms.map((r) => [r.name ?? '(unnamed)', (r.areaM2 ?? 0).toFixed(2), (r.perimeterUnits * mpu).toFixed(2)]));
  const total = rooms.reduce((a, r) => a + (r.areaM2 ?? 0), 0);
  text('A-ANNO-SCHD', px + 5, y + 2, 2.5, `TOTAL ROOM AREA (to wall centrelines): ${total.toFixed(2)} m2`);
  text('A-ANNO-NOTE', px + 5, y - 5, 2.2, 'Dimensions in mm. Room areas measured to wall centrelines.');
  text('A-ANNO-NOTE', px + 5, y - 9, 2.2, 'Sizes of walls/doors/windows are drafting values, not specifications.');

  // ---- AutoCAD script (numbers and fixed names only) ----
  script.push(...scriptHeader(s.units, k, mpu), '_.-LAYER _M A-WALL-PATT _C 8 A-WALL-PATT _M A-WALL _C 7 A-WALL ', '_.HPLAYER A-WALL-PATT');
  for (const q of solids) script.push(...hatchCmds(q, 'ANSI31', k * 0.6));
  script.push('_.-LAYER _M A-DIMS _C 8 A-DIMS ');
  let dims = 0;
  for (const c of chains) {
    for (let i = 0; i + 1 < c.pts.length; i++) {
      const a = c.pts[i], b = c.pts[i + 1];
      if (Math.hypot(b.x - a.x, b.y - a.y) < 1 * mm) continue;
      script.push(`_.DIMALIGNED ${P(a)} ${P(b)} ${P(add(add(a, { x: (b.x - a.x) / 2, y: (b.y - a.y) / 2 }), c.off))}`); dims++;
    }
    if (c.overall) {
      const [a, b] = c.overall;
      const off2 = { x: c.off.x * (2200 / 1200), y: c.off.y * (2200 / 1200) };
      script.push(`_.DIMALIGNED ${P(a)} ${P(b)} ${P(add(add(a, { x: (b.x - a.x) / 2, y: (b.y - a.y) / 2 }), off2))}`); dims++;
    }
  }
  for (const [a, b, at] of roomDims) { script.push(`_.DIMLINEAR ${P(a)} ${P(b)} ${P(at)}`); dims++; }
  return {
    dxf, script, warnings,
    plot: L.plot,
    expect: { hatches: solids.length, dimensions: dims },
    report: { scale: `1:${den}`, paper: s.paper, walls: walls.length, wallSegments: solids.length, openings: openings.length, dimensionChains: chains.length, roomDimensions: roomDims.length / 2, rooms: rooms.length, doors: di, windows: wi },
  };
}

function rect(a: Pt, dir: Pt, nrm: Pt, t0: number, t1: number, h: number): Pt[] {
  const p0 = add(a, dir, t0), p1 = add(a, dir, t1);
  return [add(p0, nrm, h), add(p1, nrm, h), add(p1, nrm, -h), add(p0, nrm, -h)];
}

/** Does the wall centreline a-b lie along (and overlap) the room side x1-x2? */
function segOn(a: Pt, b: Pt, x1: Pt, x2: Pt) {
  const cross = (p: Pt) => Math.abs((x2.x - x1.x) * (p.y - x1.y) - (x2.y - x1.y) * (p.x - x1.x));
  const L = Math.hypot(x2.x - x1.x, x2.y - x1.y);
  if (cross(a) > 1e-6 * L * L || cross(b) > 1e-6 * L * L) return false;
  const t = (p: Pt) => ((p.x - x1.x) * (x2.x - x1.x) + (p.y - x1.y) * (x2.y - x1.y)) / (L * L);
  return Math.max(t(a), t(b)) > 1e-6 && Math.min(t(a), t(b)) < 1 - 1e-6;
}
