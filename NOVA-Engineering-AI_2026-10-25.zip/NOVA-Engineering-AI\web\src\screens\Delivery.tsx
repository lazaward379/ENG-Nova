import { useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, ProjectDrawingPicker, Status, bytes, useApp, useLoad, when } from '../ui';

function NeedProject({ drawing = false }: { drawing?: boolean }) {
  const { t } = useT();
  return <div className="card empty">{drawing ? t('common.selectDrawing', 'Select a project and drawing.') : t('common.selectProject', 'Select a project.')}</div>;
}

export function Documents() {
  const { project, toast, go } = useApp();
  const { t } = useT();
  const p = useLoad(() => (project ? api.get(`/api/projects/${project}`) : Promise.resolve(null)), [project]);
  const revs = useLoad(async () => {
    if (!p.data) return [];
    return Promise.all(p.data.drawings.map(async (d: any) => ({ d, revs: await api.get(`/api/drawings/${d.id}/revisions`) })));
  }, [p.data]);
  return (
    <div className="stack">
      <div className="page-h"><div><h1>{t('nav.documents', 'Document & revision center')}</h1><div className="sub">Originals are preserved unchanged; generated files are recorded as derivatives with checksums.</div></div><span className="spacer" /><ProjectDrawingPicker needDrawing={false} /></div>
      {!project ? <NeedProject /> : !p.data ? <Loading error={p.error} loading={p.loading} /> : <>
        <div className="card table-wrap">
          <div className="card-h"><h2>{t('proj.documents', 'Document register')}</h2><span className="spacer" /><button className="btn sm" onClick={() => go(`project/${project}/intake`)}><Icon name="intake" />{t('common.upload', 'Upload')}</button></div>
          <table className="t"><thead><tr><th>File</th><th>Origin</th><th>Derived from</th><th>Status</th><th>Size</th><th>SHA-256</th><th>Date</th><th /></tr></thead>
            <tbody>{p.data.documents.map((d: any) => (
              <tr key={d.id}><td className="ltr">{d.original_name}</td><td><span className={`chip ${d.origin === 'upload' ? 'c-confirmed' : 'c-ai_suggestion'}`}>{d.origin === 'upload' ? 'original' : 'generated'}</span></td>
                <td className="faint ltr">{p.data.documents.find((x: any) => x.id === d.derived_from)?.original_name ?? '—'}</td>
                <td>{d.extraction_status}</td><td>{bytes(d.size_bytes)}</td><td className="mono faint ltr" title={d.sha256}>{d.sha256.slice(0, 16)}…</td><td className="faint">{when(d.created_at)}</td>
                <td><button className="btn sm ghost" onClick={() => api.download(`/api/documents/${d.id}/download`, d.original_name).catch((e) => toast(e.message, 'error'))}><Icon name="download" /></button></td></tr>))}</tbody></table>
        </div>
        <div className="card">
          <div className="card-h"><h2>Drawing revisions</h2></div>
          {revs.data?.map(({ d, revs: rs }: any) => (
            <div key={d.id} style={{ marginBottom: 12 }}>
              <div className="row"><b>{d.name}</b><span className="faint">{d.units} · {d.entities} entities</span><span className="spacer" /><button className="btn sm" onClick={() => go(`workspace/${d.id}`)}>{t('common.open', 'Open')}</button></div>
              {rs.length ? <table className="t"><tbody>{rs.map((r: any) => <tr key={r.id}><td><b>R{r.number}</b></td><td dir="auto">{r.label}</td><td>{r.entities} entities</td><td className="mono faint ltr">{r.sha256.slice(0, 12)}…</td><td className="faint">{r.author} · {when(r.created_at)}</td></tr>)}</tbody></table>
                : <div className="faint">No checkpoints.</div>}
            </div>
          ))}
        </div>
      </>}
    </div>
  );
}

export function Submission() {
  const { project, go } = useApp();
  const { t, lang } = useT();
  const p = useLoad(() => (project ? api.get(`/api/projects/${project}`) : Promise.resolve(null)), [project]);
  const r = useLoad(() => (project ? api.get(`/api/projects/${project}/readiness`) : Promise.resolve(null)), [project]);
  const binaa = useLoad(() => api.get('/api/integrations/binaa'), []);
  const pkgs = useLoad(() => (project ? api.get(`/api/projects/${project}/submissions`) : Promise.resolve([])), [project]);

  const register = () => {
    const rows = [['Drawing', 'Units', 'Entities', 'Updated', 'Source document'], ...p.data.drawings.map((d: any) => [d.name, d.units, d.entities, d.updated_at, ''])];
    const docs = [['Document', 'Origin', 'SHA-256', 'Date'], ...p.data.documents.map((d: any) => [d.original_name, d.origin, d.sha256, d.created_at])];
    const csv = [...rows, [], ...docs].map((r) => r.map((c: any) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
    a.download = `${p.data.code}_drawing_register.csv`; a.click();
  };

  return (
    <div className="stack">
      <div className="page-h"><div><h1>{t('nav.submission', 'Submission package manager')}</h1><div className="sub">Organised export for manual submission. NOVA has no authority-portal integration and never simulates one.</div></div><span className="spacer" /><ProjectDrawingPicker needDrawing={false} /></div>
      {binaa.data && <BinaaCard info={binaa.data} />}
      {!project ? <NeedProject /> : !p.data || !r.data ? <Loading error={p.error ?? r.error} loading={p.loading || r.loading} /> : <>
        <Packages projectId={project} pkgs={pkgs.data ?? []} reload={pkgs.reload} documents={p.data.documents} />
        <div className="card glow">
          <div className="row"><h2>Submission readiness</h2><span className="spacer" /><span className="chip c-unresolved">NOT READY</span></div>
          <p className="muted">{r.data.ready_for_submission_reason}</p>
          <div className="grid c3">
            <div><div className="faint">Target workflow</div>{r.data.known_facts.find((f: any) => f.key === 'target_authority')?.value ?? <span className="chip c-unresolved">not stated</span>}</div>
            <div><div className="faint">Verified regulatory sources</div>{r.data.verified_regulatory_sources}</div>
            <div><div className="faint">Official checklist items recorded</div>{(pkgs.data ?? []).flatMap((x: any) => x.items).filter((i: any) => i.origin === 'official').length || <span className="chip c-unresolved">none</span>}</div>
          </div>
        </div>
        <div className="grid c2">
          <div className="card"><h3>Missing items</h3>
            {r.data.missing_critical_inputs.map((m: any) => <div key={m.key} style={{ padding: '3px 0' }}>• {lang === 'ar' ? m.label_ar : m.label}</div>)}
            <div style={{ padding: '3px 0' }}>• Verified, versioned checklist for the target authority / client workflow</div>
            <div style={{ padding: '3px 0' }}>• Professional review and sign-off record</div>
            {r.data.checks_performable.filter((c: any) => c.status === 'FAIL').map((c: any, i: number) => <div key={i} style={{ padding: '3px 0' }}>• Resolve failing check {c.rule}</div>)}
          </div>
          <div className="card"><h3>Package contents available now</h3>
            {p.data.documents.filter((d: any) => d.origin === 'generated').map((d: any) => <div key={d.id} className="ltr" style={{ padding: '3px 0' }}>• {d.original_name}</div>)}
            {!p.data.documents.some((d: any) => d.origin === 'generated') && <div className="faint">No generated exports yet — export DXF from the CAD workspace.</div>}
            <div className="row" style={{ marginTop: 10 }}>
              <button className="btn" onClick={register}><Icon name="download" />Drawing & document register (CSV)</button>
              <button className="btn" onClick={() => go('compliance')}><Icon name="report" />Compliance report</button>
            </div>
          </div>
        </div>
      </>}
    </div>
  );
}

function BinaaCard({ info }: { info: any }) {
  const { go } = useApp();
  return (
    <div className="card">
      <div className="card-h"><Icon name="submission" /><h2>{info.name}</h2><span className="spacer" /><span className="chip c-assumption">manual workflow · no public API</span></div>
      <p className="muted" style={{ marginTop: 0 }}>{info.notes}</p>
      <div className="grid c2">
        <div>
          <div className="faint">What official sources say (researched {info.researchedAt})</div>
          <ul style={{ margin: '4px 0', paddingInlineStart: 18 }}>{info.knownFacts.map((f: string) => <li key={f} className="muted">{f}</li>)}</ul>
          <div className="row">{info.entryPoints.map((e: any) => <a key={e.url} className="btn sm" href={e.url} target="_blank" rel="noreferrer noopener"><Icon name="external" />{e.label}</a>)}</div>
        </div>
        <div>
          <div className="faint">Registered sources</div>
          {info.sources.map((s: any) => (
            <div key={s.id} className="row" style={{ padding: '3px 0' }}>
              <span className={`chip ${s.verification_status === 'verified' ? 'c-confirmed' : 'c-unresolved'}`}>{s.verification_status}</span>
              <a href={s.url} target="_blank" rel="noreferrer noopener" className="ltr" style={{ fontSize: 12.5 }}>{s.title}</a>
              <span className="faint">{s.org_id ? 'organisation' : 'catalogue'}</span>
            </div>
          ))}
          <button className="btn sm ghost" onClick={() => go('regulatory')}>Verify in regulatory library →</button>
        </div>
      </div>
    </div>
  );
}

const PKG_STATUS: Record<string, string> = { draft: '', ready_for_review: 'c-extracted', submitted_manually: 'c-ai_suggestion', returned: 'c-unresolved', approval_recorded: 'c-confirmed', withdrawn: '' };

function Packages({ projectId, pkgs, reload, documents }: { projectId: string; pkgs: any[]; reload: () => void; documents: any[] }) {
  const { toast, can } = useApp();
  const create = async () => {
    try { await api.post(`/api/projects/${projectId}/submissions`, { target: 'binaa', title: 'Building permit application (Binaa)' }); reload(); } catch (e: any) { toast(e.message, 'error'); }
  };
  return (
    <div className="card">
      <div className="card-h"><h2>Submission packages</h2><span className="spacer" />{can('engineer') && <button className="btn primary sm" onClick={create}><Icon name="plus" />New Binaa package</button>}</div>
      {!pkgs.length && <div className="empty">No packages yet.</div>}
      {pkgs.map((pk) => <Package key={pk.id} pk={pk} reload={reload} documents={documents} />)}
    </div>
  );
}

function Package({ pk, reload, documents }: { pk: any; reload: () => void; documents: any[] }) {
  const { toast, can } = useApp();
  const [newItem, setNewItem] = useState('');
  const [ref, setRef] = useState('');
  const [note, setNote] = useState('');
  const [evidence, setEvidence] = useState('');
  const editing = ['draft', 'returned'].includes(pk.status) && can('engineer');
  const patch = async (item: any, body: any) => { try { await api.patch(`/api/submissions/${pk.id}/items/${item.id}`, body); reload(); } catch (e: any) { toast(e.message, 'error'); } };
  const status = async (body: any) => { try { await api.post(`/api/submissions/${pk.id}/status`, body); setNote(''); reload(); } catch (e: any) { toast(e.message, 'error'); } };
  return (
    <div className="card" style={{ padding: 12, marginBottom: 12 }}>
      <div className="row">
        <b>{pk.title}</b><span className={`chip ${PKG_STATUS[pk.status]}`}>{pk.status.replace(/_/g, ' ')}</span>
        {pk.external_reference && <span className="chip mono ltr">application no. {pk.external_reference}</span>}
        <span className="spacer" />
        <button className="btn sm" onClick={() => api.openHtml(`/api/submissions/${pk.id}/transmittal`).catch((e) => toast(e.message, 'error'))}><Icon name="report" />Transmittal</button>
      </div>
      <div className="table-wrap" style={{ marginTop: 8 }}><table className="t">
        <thead><tr><th>Item</th><th>Origin</th><th>Req.</th><th>Document</th><th>Status</th></tr></thead>
        <tbody>{pk.items.map((it: any) => (
          <tr key={it.id}>
            <td>{it.label}{it.note && <div className="faint">{it.note}</div>}</td>
            <td><span className={`chip ${it.origin === 'official' ? 'c-unresolved' : it.origin === 'nova' ? 'c-ai_suggestion' : ''}`}>{it.origin}</span></td>
            <td>{it.required ? 'yes' : '—'}</td>
            <td>{editing ? (
              <select value={it.document_id ?? ''} onChange={(e) => patch(it, { document_id: e.target.value || null })} style={{ maxWidth: 240 }}>
                <option value="">— attach document —</option>{documents.map((d) => <option key={d.id} value={d.id}>{d.original_name} ({d.origin})</option>)}
              </select>) : <span className="ltr">{it.document_name ?? '—'}</span>}</td>
            <td style={{ whiteSpace: 'nowrap' }}><span className={`chip ${it.status === 'attached' ? 'c-confirmed' : it.status === 'missing' ? 'c-unresolved' : ''}`}>{it.status}</span>
              {editing && it.status === 'missing' && <button className="btn sm ghost" onClick={() => { const why = prompt('Why is this item not applicable?'); if (why) patch(it, { status: 'not_applicable', note: why }); }}>N/A</button>}
              {editing && it.status === 'not_applicable' && <button className="btn sm ghost" onClick={() => patch(it, { status: 'missing' })}>undo</button>}</td>
          </tr>))}</tbody></table></div>
      {editing && <div className="row" style={{ marginTop: 6 }}>
        <input value={newItem} onChange={(e) => setNewItem(e.target.value)} placeholder="Add an item from the official Binaa checklist…" style={{ flex: 1 }} dir="auto" />
        <button className="btn sm" disabled={!newItem.trim()} onClick={async () => { try { await api.post(`/api/submissions/${pk.id}/items`, { label: newItem, origin: 'official', required: true }); setNewItem(''); reload(); } catch (e: any) { toast(e.message, 'error'); } }}>Add official item</button>
      </div>}
      {pk.blocking.length > 0 && <div className="notice" style={{ marginTop: 8 }}>Required items missing: {pk.blocking.join(' · ')}</div>}

      <div className="row" style={{ marginTop: 10, alignItems: 'flex-end' }}>
        {pk.next.includes('ready_for_review') && <button className="btn" disabled={!can('reviewer') || pk.blocking.length > 0} title="Reviewer or admin" onClick={() => status({ status: 'ready_for_review' })}>Mark ready (reviewer)</button>}
        {pk.next.includes('submitted_manually') && <>
          <label className="field" style={{ width: 200 }}>Binaa application no.<input className="mono" dir="ltr" value={ref} onChange={(e) => setRef(e.target.value)} /></label>
          <button className="btn primary" disabled={!ref.trim() || !can('engineer')} onClick={() => {
            if (confirm('Confirm that you submitted this package yourself on Binaa/TAMM and received this application number. NOVA did not submit anything.')) status({ status: 'submitted_manually', external_reference: ref.trim(), confirm: true });
          }}>Record manual submission</button>
        </>}
        {pk.next.includes('returned') && <>
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Reason given by the authority" style={{ width: 240 }} dir="auto" />
          <button className="btn" disabled={!note.trim()} onClick={() => status({ status: 'returned', note })}>Record returned</button>
        </>}
        {pk.next.includes('approval_recorded') && <>
          <select value={evidence} onChange={(e) => setEvidence(e.target.value)} style={{ width: 240 }}><option value="">— uploaded approval document —</option>{documents.filter((d) => d.origin === 'upload').map((d) => <option key={d.id} value={d.id}>{d.original_name}</option>)}</select>
          <button className="btn" disabled={!evidence || !can('reviewer')} onClick={() => status({ status: 'approval_recorded', outcome_document_id: evidence })}>Record approval (reviewer)</button>
        </>}
        {pk.next.includes('draft') && <button className="btn ghost" onClick={() => status({ status: 'draft' })}>Back to draft</button>}
      </div>
      {pk.events.length > 0 && <div className="faint" style={{ marginTop: 8 }}>{pk.events.map((e: any, i: number) => <div key={i}>{when(e.created_at)} · {e.status.replace(/_/g, ' ')} · {e.user} {e.note && `· ${e.note}`}</div>)}</div>}
    </div>
  );
}

export function Architecture() {
  const { drawing, go } = useApp();
  const { t } = useT();
  const d = useLoad(() => (drawing ? api.get(`/api/drawings/${drawing}`) : Promise.resolve(null)), [drawing]);
  return (
    <div className="stack">
      <div className="page-h"><div><h1>{t('nav.architecture', 'Architectural design workspace')}</h1><div className="sub">Room schedule derived from real closed boundaries in the drawing.</div></div><span className="spacer" /><ProjectDrawingPicker /></div>
      {!drawing ? <NeedProject drawing /> : !d.data ? <Loading error={d.error} loading={d.loading} /> : <>
        <div className="card">
          <div className="card-h"><h2>Room schedule — {d.data.name}</h2><span className="spacer" /><button className="btn sm" onClick={() => go(`workspace/${drawing}`)}><Icon name="workspace" />{t('nav.workspace', 'Open in CAD')}</button></div>
          {d.data.rooms.length ? <table className="t">
            <thead><tr><th>Room</th><th>Area (m²)</th><th>Boundary</th><th>Problems</th></tr></thead>
            <tbody>{d.data.rooms.map((r: any) => <tr key={r.entityId}><td dir="auto">{r.name ?? <i className="faint">unlabelled</i>}</td><td className="mono">{r.areaM2 === null ? 'units unknown' : r.areaM2.toFixed(3)}</td><td>{r.valid ? 'closed, simple' : 'invalid'}</td><td className="faint">{r.problems.join(', ')}</td></tr>)}</tbody>
          </table> : <div className="empty">No room boundaries (closed polylines on ROOM / SPACE / A-AREA layers).</div>}
        </div>
        <div className="notice info">Not yet implemented: typed walls / doors / windows with hosting relationships, adjacency requirements, candidate layout generation and stair geometry. NOVA will not present an AI-generated layout as optimal or compliant.</div>
      </>}
    </div>
  );
}

export function Assistant() {
  const { drawing, go } = useApp();
  const { t } = useT();
  const props = useLoad(() => (drawing ? api.get(`/api/drawings/${drawing}/proposals`) : Promise.resolve([])), [drawing]);
  return (
    <div className="stack">
      <div className="page-h"><div><h1>{t('nav.assistant', 'AI engineering assistant')}</h1><div className="sub">Transparency log: every instruction, provider, generated operation, validation and approval.</div></div><span className="spacer" /><ProjectDrawingPicker /></div>
      {!drawing ? <NeedProject drawing /> : <>
        <div className="card glow row"><div className="ai-dot" /><div style={{ flex: 1 }}>The assistant works inside the CAD workspace so it can act on your selection and show previews on the drawing.</div>
          <button className="btn primary" onClick={() => go(`workspace/${drawing}`)}><Icon name="assistant" />Open copilot</button></div>
        <div className="card table-wrap">
          {props.data ? (props.data.length ? <table className="t">
            <thead><tr><th>When</th><th>Instruction</th><th>Provider</th><th>Intent</th><th>Operation</th><th>Validation</th><th>Status</th></tr></thead>
            <tbody>{props.data.map((x: any) => (
              <tr key={x.id}><td className="faint">{when(x.created_at)}<div>{x.author}</div></td><td dir="auto">{x.instruction}<div className="faint">{x.explanation}</div></td>
                <td className="faint">{x.provider}{x.model ? ` · ${x.model}` : ''}</td><td>{x.intent.intent}{x.intent.query !== 'none' ? ` · ${x.intent.query}` : ''}</td>
                <td className="mono ltr" style={{ fontSize: 11 }}>{x.operation ? JSON.stringify({ ...x.operation, ids: x.operation.ids?.length }) : '—'}</td>
                <td className="faint">{x.validation.errors?.join('; ') || (x.validation.verification ? `stored = preview: ${x.validation.verification.stored_matches_preview}` : '—')}</td>
                <td><span className={`chip ${x.status === 'applied' ? 'c-confirmed' : x.status === 'invalid' ? 'c-unresolved' : ''}`}>{x.status}</span>{x.approved_by && <div className="faint">by {x.approved_by}</div>}</td></tr>))}</tbody>
          </table> : <div className="empty">No copilot activity on this drawing yet.</div>) : <Loading error={props.error} loading={props.loading} />}
        </div>
      </>}
    </div>
  );
}

export function Review() {
  const { drawing, go } = useApp();
  const { t } = useT();
  const runs = useLoad(() => (drawing ? api.get(`/api/drawings/${drawing}/compliance-runs`) : Promise.resolve([])), [drawing]);
  const latest = useLoad(() => (runs.data?.[0] ? api.get(`/api/compliance-runs/${runs.data[0].id}`) : Promise.resolve(null)), [runs.data]);
  const props = useLoad(() => (drawing ? api.get(`/api/drawings/${drawing}/proposals`) : Promise.resolve([])), [drawing]);
  const open = latest.data?.findings.filter((f: any) => f.status !== 'PASS' && f.resolution === 'open') ?? [];
  const pending = props.data?.filter((p: any) => p.status === 'proposed') ?? [];
  return (
    <div className="stack">
      <div className="page-h"><div><h1>{t('nav.review', 'Project collaboration & review')}</h1><div className="sub">Open findings and AI proposals awaiting a decision.</div></div><span className="spacer" /><ProjectDrawingPicker /></div>
      {!drawing ? <NeedProject drawing /> : <div className="grid c2">
        <div className="card"><div className="card-h"><h2>Open findings ({open.length})</h2><span className="spacer" /><button className="btn sm" onClick={() => go('compliance')}>Compliance center</button></div>
          {open.map((f: any) => <div key={f.id} className="row" style={{ padding: '4px 0', borderBottom: '1px solid var(--border)' }}><Status s={f.status} /><span className="mono">{f.rule_code}</span><span className="faint" dir="auto">{f.message}</span></div>)}
          {!open.length && <div className="empty">{runs.data?.length ? 'Nothing open in the latest run.' : 'No checks run yet.'}</div>}</div>
        <div className="card"><div className="card-h"><h2>Proposals awaiting approval ({pending.length})</h2><span className="spacer" /><button className="btn sm" onClick={() => go(`workspace/${drawing}`)}>Open workspace</button></div>
          {pending.map((p: any) => <div key={p.id} style={{ padding: '4px 0', borderBottom: '1px solid var(--border)' }}><div dir="auto">{p.instruction}</div><div className="faint">{p.author} · {when(p.created_at)}</div></div>)}
          {!pending.length && <div className="empty">None.</div>}</div>
        <div className="notice info" style={{ gridColumn: '1 / -1' }}>Threaded comments, assignments and notifications to other members are on the roadmap; today, resolutions and approvals are recorded per finding and per proposal in the audit log.</div>
      </div>}
    </div>
  );
}
