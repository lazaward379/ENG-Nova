import Fastify, { type FastifyInstance, type FastifyReply, type FastifyRequest } from 'fastify';
import multipart from '@fastify/multipart';
import fastifyStatic from '@fastify/static';
import { existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { z, ZodError } from 'zod';
import { openDb, get, all, run, now, tx, audit, type DB } from './db.ts';
import { atLeast, createSession, destroySession, hashPassword, rateLimiter, sessionFromToken, verifyPassword, type Role, type SessionUser } from './auth.ts';
import { LocalStorage, MAX_UPLOAD_BYTES, type StorageProvider } from './storage.ts';
import { OperationError } from './operations.ts';
import { seedRules } from './rules/engine.ts';
import { providerStatus } from './copilot/service.ts';
import { projectRoutes } from './routes/projects.ts';
import { drawingRoutes } from './routes/drawings.ts';
import { regulatoryRoutes } from './routes/regulatory.ts';
import { submissionRoutes } from './routes/submissions.ts';
import { generateRoutes } from './routes/generate.ts';
import { autocadRoutes } from './routes/autocad.ts';
import { homeRoutes } from './routes/home.ts';
import { reviewRoutes } from './routes/review.ts';
import { journeyRoutes } from './routes/journey.ts';
import { presentationRoutes } from './routes/presentation.ts';
import { seedBinaaSources } from './integrations/binaa.ts';

declare module 'fastify' {
  interface FastifyRequest { user: SessionUser }
}

export type Deps = { db: DB; storage: StorageProvider; acadJobs: string; aiImages: string };
export type Options = { dbPath: string; storageDir: string; logger?: boolean; webDist?: string; allowSignup?: boolean; acadJobsDir?: string };

export class HttpError extends Error {
  statusCode: number;
  constructor(statusCode: number, message: string) { super(message); this.statusCode = statusCode; }
}

export function requireRole(req: FastifyRequest, min: Role) {
  if (!atLeast(req.user.role, min)) throw new HttpError(403, `requires ${min} role or higher`);
}

const PUBLIC = new Set(['/api/health', '/api/auth/login', '/api/auth/register']);
const VERSION = '0.1.0';

export async function buildApp(opts: Options): Promise<{ app: FastifyInstance; db: DB }> {
  const db = openDb(opts.dbPath);
  seedRules(db);
  seedBinaaSources(db);
  const storage = new LocalStorage(opts.storageDir);
  const deps: Deps = {
    db, storage,
    acadJobs: opts.acadJobsDir ?? join(resolve(opts.storageDir), '..', 'autocad-jobs'),
    aiImages: join(resolve(opts.storageDir), '..', 'ai-images'),
  };

  const app = Fastify({
    logger: opts.logger ? { redact: ['req.headers.authorization', 'req.headers.cookie'] } : false,
    bodyLimit: 2 * 1024 * 1024,
  });
  app.decorateRequest('user', null as any);
  await app.register(multipart, { limits: { fileSize: MAX_UPLOAD_BYTES, files: 1, fields: 10 } });

  app.setErrorHandler((err: any, req, reply) => {
    if (err instanceof ZodError) return reply.status(400).send({ error: 'validation failed', issues: err.issues.slice(0, 20).map((i) => ({ path: i.path.join('.'), message: i.message })) });
    if (err instanceof OperationError) return reply.status(422).send({ error: 'operation rejected', errors: err.errors });
    if (err.code === 'FST_REQ_FILE_TOO_LARGE') return reply.status(413).send({ error: `file exceeds ${MAX_UPLOAD_BYTES / 1024 / 1024} MB limit` });
    const status = err.statusCode ?? 500;
    if (status >= 500) req.log.error(err);
    reply.status(status).send({ error: status >= 500 ? 'internal error' : err.message });
  });

  const authLimiter = rateLimiter(10, 60_000);
  app.addHook('onRequest', async (req) => {
    const path = req.url.split('?')[0];
    if (!path.startsWith('/api/')) return;
    if (path.startsWith('/api/auth/') && req.method === 'POST' && !authLimiter(req.ip)) throw new HttpError(429, 'too many attempts; wait a minute');
    if (PUBLIC.has(path)) return;
    const token = /^Bearer (.+)$/.exec(req.headers.authorization ?? '')?.[1];
    const user = token ? sessionFromToken(db, token) : null;
    if (!user) throw new HttpError(401, 'not signed in');
    req.user = user;
  });

  // ---- health ----
  app.get('/api/health', async () => {
    let dbOk = false;
    try { dbOk = get(db, 'SELECT 1 AS ok')?.ok === 1; } catch { /* reported below */ }
    return { status: dbOk && storage.healthy() ? 'ok' : 'degraded', version: VERSION, time: now(), checks: { database: dbOk, storage: storage.healthy() } };
  });

  app.get('/api/system', async (req) => {
    const counts = Object.fromEntries(['projects', 'documents', 'drawings', 'entities', 'geometry_operations', 'compliance_runs', 'ai_proposals', 'audit_events']
      .map((t) => [t, (get<any>(db, `SELECT COUNT(*) AS n FROM ${t}`)?.n) ?? 0]));
    return {
      version: VERSION, node: process.version, database: 'SQLite (node:sqlite)', storage: 'local content-addressed',
      ai_providers: providerStatus(), counts,
      jobs: all(db, 'SELECT id, kind, status, detail, started_at, finished_at FROM background_jobs WHERE org_id = ? ORDER BY created_at DESC LIMIT 50', req.user.orgId),
      capabilities: {
        dxf_import: 'supported subset', dxf_export: 'R12', dwg: 'not supported', ifc: 'not parsed', ocr: 'not available',
        malware_scanning: 'not configured', queue: 'in-process synchronous',
      },
    };
  });

  // ---- auth ----
  const Register = z.object({ orgName: z.string().trim().min(2).max(120), name: z.string().trim().min(1).max(120), email: z.string().trim().toLowerCase().email().max(200), password: z.string().min(10).max(200) });
  app.post('/api/auth/register', async (req) => {
    if (opts.allowSignup === false) throw new HttpError(403, 'sign-up is disabled on this server');
    const b = Register.parse(req.body);
    if (get(db, 'SELECT 1 FROM users WHERE email = ?', b.email)) throw new HttpError(409, 'an account with this email already exists');
    const orgId = randomUUID(), userId = randomUUID();
    tx(db, () => {
      run(db, 'INSERT INTO organizations (id, name, created_at) VALUES (?,?,?)', orgId, b.orgName, now());
      run(db, 'INSERT INTO users (id, email, name, password_hash, created_at) VALUES (?,?,?,?,?)', userId, b.email, b.name, hashPassword(b.password), now());
      run(db, "INSERT INTO memberships (org_id, user_id, role, created_at) VALUES (?,?,'admin',?)", orgId, userId, now());
      audit(db, orgId, userId, 'org.created', orgId);
    });
    return { token: createSession(db, userId, orgId) };
  });

  const Login = z.object({ email: z.string().trim().toLowerCase().max(200), password: z.string().max(200) });
  app.post('/api/auth/login', async (req) => {
    const b = Login.parse(req.body);
    const u = get<any>(db, 'SELECT id, password_hash FROM users WHERE email = ?', b.email);
    if (!u || !verifyPassword(b.password, u.password_hash)) {
      audit(db, u ? (get<any>(db, 'SELECT org_id FROM memberships WHERE user_id = ? LIMIT 1', u.id)?.org_id ?? null) : null, u?.id ?? null, 'auth.failed');
      throw new HttpError(401, 'invalid email or password');
    }
    const m = get<any>(db, 'SELECT org_id FROM memberships WHERE user_id = ? ORDER BY created_at LIMIT 1', u.id);
    if (!m) throw new HttpError(403, 'account has no organisation');
    audit(db, m.org_id, u.id, 'auth.login');
    return { token: createSession(db, u.id, m.org_id) };
  });

  app.post('/api/auth/logout', async (req) => {
    const token = /^Bearer (.+)$/.exec(req.headers.authorization ?? '')![1];
    destroySession(db, token);
    return { ok: true };
  });
  app.get('/api/auth/me', async (req) => req.user);

  // ---- organisation ----
  app.get('/api/org/members', async (req) => all(db, `SELECT u.id, u.name, u.email, m.role, m.created_at FROM memberships m JOIN users u ON u.id = m.user_id WHERE m.org_id = ? ORDER BY u.name`, req.user.orgId));
  const NewMember = z.object({ name: z.string().trim().min(1).max(120), email: z.string().trim().toLowerCase().email(), password: z.string().min(10).max(200), role: z.enum(['admin', 'reviewer', 'engineer', 'viewer']) });
  app.post('/api/org/members', async (req) => {
    requireRole(req, 'admin');
    const b = NewMember.parse(req.body);
    if (get(db, 'SELECT 1 FROM users WHERE email = ?', b.email)) throw new HttpError(409, 'email already registered');
    const id = randomUUID();
    tx(db, () => {
      run(db, 'INSERT INTO users (id, email, name, password_hash, created_at) VALUES (?,?,?,?,?)', id, b.email, b.name, hashPassword(b.password), now());
      run(db, 'INSERT INTO memberships (org_id, user_id, role, created_at) VALUES (?,?,?,?)', req.user.orgId, id, b.role, now());
      audit(db, req.user.orgId, req.user.userId, 'member.added', id, { role: b.role });
    });
    return { id };
  });
  app.patch('/api/org/members/:userId', async (req) => {
    requireRole(req, 'admin');
    const { userId } = req.params as { userId: string };
    const { role } = z.object({ role: z.enum(['admin', 'reviewer', 'engineer', 'viewer']) }).parse(req.body);
    if (userId === req.user.userId && role !== 'admin') throw new HttpError(409, 'you cannot remove your own admin role');
    const r = run(db, 'UPDATE memberships SET role = ? WHERE org_id = ? AND user_id = ?', role, req.user.orgId, userId);
    if (!r.changes) throw new HttpError(404, 'member not found');
    audit(db, req.user.orgId, req.user.userId, 'member.role_changed', userId, { role });
    return { ok: true };
  });
  app.get('/api/audit', async (req) => {
    requireRole(req, 'admin');
    return all(db, `SELECT a.id, a.action, a.target, a.detail, a.created_at, u.name AS user FROM audit_events a LEFT JOIN users u ON u.id = a.user_id
                    WHERE a.org_id = ? ORDER BY a.id DESC LIMIT 300`, req.user.orgId).map((a) => ({ ...a, detail: JSON.parse(a.detail) }));
  });

  projectRoutes(app, deps);
  drawingRoutes(app, deps);
  regulatoryRoutes(app, deps);
  submissionRoutes(app, deps);
  generateRoutes(app, deps);
  autocadRoutes(app, deps, deps.acadJobs);
  homeRoutes(app, deps);
  reviewRoutes(app, deps);
  journeyRoutes(app, deps);
  presentationRoutes(app, deps);

  app.all('/api/*', async () => { throw new HttpError(404, 'no such endpoint'); });

  const webDist = opts.webDist && resolve(opts.webDist);
  if (webDist && existsSync(join(webDist, 'index.html'))) {
    await app.register(fastifyStatic, { root: webDist, index: false });
    app.get('/', (_req, reply) => reply.sendFile('index.html'));
    app.setNotFoundHandler((req: FastifyRequest, reply: FastifyReply) => {
      // Missing assets are real 404s; only page routes fall back to the single-page app.
      if (req.url.startsWith('/api/') || req.url.startsWith('/assets/')) return reply.status(404).send({ error: 'not found' });
      return reply.sendFile('index.html');
    });
  }

  app.addHook('onClose', async () => db.close());
  return { app, db };
}
