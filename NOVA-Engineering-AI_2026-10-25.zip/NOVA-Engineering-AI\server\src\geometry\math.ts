import type { Entity, EntityInput, Pt } from './types.ts';
import { typedPoints } from './hosted.ts';

export const EPS = 1e-9;

export type BBox = { minX: number; minY: number; maxX: number; maxY: number };

const deg = (r: number) => (r * 180) / Math.PI;
const rad = (d: number) => (d * Math.PI) / 180;
const normDeg = (a: number) => ((a % 360) + 360) % 360;

/** Signed area by the shoelace formula (positive = counter-clockwise). */
export function signedArea(pts: Pt[]): number {
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    s += a.x * b.y - b.x * a.y;
  }
  return s / 2;
}
export const polygonArea = (pts: Pt[]) => Math.abs(signedArea(pts));

export function perimeter(pts: Pt[], closed: boolean): number {
  let s = 0;
  const n = closed ? pts.length : pts.length - 1;
  for (let i = 0; i < n; i++) s += dist(pts[i], pts[(i + 1) % pts.length]);
  return s;
}

export const dist = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y);

/** Ray-casting point-in-polygon (boundary counts as outside). */
export function pointInPolygon(p: Pt, poly: Pt[]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a.y > p.y) !== (b.y > p.y) && p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
  }
  return inside;
}

function orient(a: Pt, b: Pt, c: Pt) {
  const v = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  return Math.abs(v) < EPS ? 0 : Math.sign(v);
}

/** Proper crossing of two segments (shared endpoints and collinear touching excluded). */
export function segmentsCross(a: Pt, b: Pt, c: Pt, d: Pt): boolean {
  const o1 = orient(a, b, c), o2 = orient(a, b, d), o3 = orient(c, d, a), o4 = orient(c, d, b);
  return o1 * o2 < 0 && o3 * o4 < 0;
}

/** True when a closed ring has two non-adjacent edges that cross. */
export function selfIntersects(pts: Pt[]): boolean {
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      if (j === i + 1 || (i === 0 && j === n - 1)) continue;
      if (segmentsCross(pts[i], pts[(i + 1) % n], pts[j], pts[(j + 1) % n])) return true;
    }
  }
  return false;
}

export function pointSegmentDistance(p: Pt, a: Pt, b: Pt): number {
  const dx = b.x - a.x, dy = b.y - a.y;
  const len2 = dx * dx + dy * dy;
  if (len2 < EPS) return dist(p, a);
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2));
  return dist(p, { x: a.x + t * dx, y: a.y + t * dy });
}

/** Minimum distance between two polygon boundaries (0 if they cross). */
export function ringDistance(p: Pt[], q: Pt[]): { d: number; at: Pt } {
  let best = { d: Infinity, at: p[0] };
  for (let i = 0; i < p.length; i++) {
    const a = p[i], b = p[(i + 1) % p.length];
    for (let j = 0; j < q.length; j++) {
      const c = q[j], e = q[(j + 1) % q.length];
      if (segmentsCross(a, b, c, e)) return { d: 0, at: a };
      for (const [pt, s1, s2] of [[a, c, e], [b, c, e], [c, a, b], [e, a, b]] as [Pt, Pt, Pt][]) {
        const d = pointSegmentDistance(pt, s1, s2);
        if (d < best.d) best = { d, at: pt };
      }
    }
  }
  return best;
}

export function entityPoints(e: EntityInput): Pt[] {
  switch (e.type) {
    case 'LINE': return [e.geom.a, e.geom.b];
    case 'POLYLINE': return e.geom.points;
    case 'CIRCLE': return [
      { x: e.geom.c.x - e.geom.r, y: e.geom.c.y - e.geom.r },
      { x: e.geom.c.x + e.geom.r, y: e.geom.c.y + e.geom.r }];
    case 'ARC': {
      const { c, r, start, end } = e.geom;
      const pts = [arcPoint(c, r, start), arcPoint(c, r, end)];
      for (const q of [0, 90, 180, 270]) if (angleInArc(q, start, end)) pts.push(arcPoint(c, r, q));
      return pts;
    }
    case 'TEXT': return [e.geom.p];
    case 'POINT': return [e.geom.p];
    default: return typedPoints(e) ?? [];
  }
}

export const arcPoint = (c: Pt, r: number, aDeg: number): Pt => ({ x: c.x + r * Math.cos(rad(aDeg)), y: c.y + r * Math.sin(rad(aDeg)) });
export function angleInArc(a: number, start: number, end: number) {
  const s = normDeg(start), e = normDeg(end), x = normDeg(a);
  return s <= e ? x >= s && x <= e : x >= s || x <= e;
}

export function bbox(es: EntityInput[]): BBox | null {
  let b: BBox | null = null;
  for (const e of es) for (const p of entityPoints(e)) {
    if (!b) b = { minX: p.x, minY: p.y, maxX: p.x, maxY: p.y };
    else { b.minX = Math.min(b.minX, p.x); b.minY = Math.min(b.minY, p.y); b.maxX = Math.max(b.maxX, p.x); b.maxY = Math.max(b.maxY, p.y); }
  }
  return b;
}

/** Affine point transforms used by operations. */
export type Xf = { pt: (p: Pt) => Pt; angle: (a: number) => number; mirrored: boolean };

export const translateXf = (dx: number, dy: number): Xf => ({ pt: (p) => ({ x: p.x + dx, y: p.y + dy }), angle: (a) => a, mirrored: false });

export function rotateXf(c: Pt, angleDeg: number): Xf {
  const cos = Math.cos(rad(angleDeg)), sin = Math.sin(rad(angleDeg));
  return {
    pt: (p) => ({ x: c.x + (p.x - c.x) * cos - (p.y - c.y) * sin, y: c.y + (p.x - c.x) * sin + (p.y - c.y) * cos }),
    angle: (a) => normDeg(a + angleDeg),
    mirrored: false,
  };
}

/** Reflection across the line through a and b. */
export function mirrorXf(a: Pt, b: Pt): Xf {
  const lineAng = Math.atan2(b.y - a.y, b.x - a.x);
  const cos2 = Math.cos(2 * lineAng), sin2 = Math.sin(2 * lineAng);
  return {
    pt: (p) => {
      const x = p.x - a.x, y = p.y - a.y;
      return { x: a.x + x * cos2 + y * sin2, y: a.y + x * sin2 - y * cos2 };
    },
    angle: (t) => normDeg(2 * deg(lineAng) - t),
    mirrored: true,
  };
}

export function transformEntity<T extends EntityInput>(e: T, xf: Xf): T {
  const g: any = e.geom;
  let geom: any;
  switch (e.type) {
    case 'LINE': geom = { a: xf.pt(g.a), b: xf.pt(g.b) }; break;
    case 'POLYLINE': geom = { points: g.points.map(xf.pt), closed: g.closed }; break;
    case 'CIRCLE': geom = { c: xf.pt(g.c), r: g.r }; break;
    case 'ARC': {
      const s = xf.angle(g.start), en = xf.angle(g.end);
      // A reflection reverses orientation, so start and end swap to keep the arc counter-clockwise.
      geom = xf.mirrored ? { c: xf.pt(g.c), r: g.r, start: en, end: s } : { c: xf.pt(g.c), r: g.r, start: s, end: en };
      break;
    }
    case 'TEXT': geom = { ...g, p: xf.pt(g.p), rot: xf.mirrored ? g.rot : xf.angle(g.rot) }; break;
    case 'POINT': geom = { p: xf.pt(g.p) }; break;
    case 'WALL': geom = { ...g, a: xf.pt(g.a), b: xf.pt(g.b) }; break;
    case 'DOOR':
    case 'WINDOW': {
      // Openings follow their host; operations recompute p/dir from the wall afterwards.
      const p = g.p ? xf.pt(g.p) : undefined;
      const q = g.p && g.dir ? xf.pt({ x: g.p.x + g.dir.x, y: g.p.y + g.dir.y }) : undefined;
      geom = { ...g, p, dir: p && q ? { x: q.x - p.x, y: q.y - p.y } : g.dir };
      break;
    }
  }
  return { ...e, geom };
}

/** Geometric equality within tolerance (used for duplicates and round-trip checks). */
export function geomEqual(a: EntityInput, b: EntityInput, tol = 1e-9): boolean {
  if (a.type !== b.type) return false;
  const pa = entityPoints(a), pb = entityPoints(b);
  if (pa.length !== pb.length) return false;
  for (let i = 0; i < pa.length; i++) if (Math.abs(pa[i].x - pb[i].x) > tol || Math.abs(pa[i].y - pb[i].y) > tol) return false;
  if (a.type === 'POLYLINE' && b.type === 'POLYLINE' && a.geom.closed !== b.geom.closed) return false;
  if (a.type === 'TEXT' && b.type === 'TEXT' && a.geom.text !== b.geom.text) return false;
  if ((a.type === 'CIRCLE' || a.type === 'ARC') && Math.abs((a.geom as any).r - (b.geom as any).r) > tol) return false;
  for (const k of ['thickness', 'offset', 'width'] as const) {
    const x = (a.geom as any)[k], y = (b.geom as any)[k];
    if (typeof x === 'number' && Math.abs(x - y) > tol) return false;
  }
  if ((a.geom as any).wallId !== (b.geom as any).wallId) return false;
  return true;
}

export function entityLength(e: Entity | EntityInput): number {
  switch (e.type) {
    case 'LINE': return dist(e.geom.a, e.geom.b);
    case 'POLYLINE': return perimeter(e.geom.points, e.geom.closed);
    case 'CIRCLE': return 2 * Math.PI * e.geom.r;
    case 'ARC': { const sweep = normDeg(e.geom.end - e.geom.start) || 360; return (Math.PI * e.geom.r * sweep) / 180; }
    case 'WALL': return dist(e.geom.a, e.geom.b);
    default: return 0;
  }
}
