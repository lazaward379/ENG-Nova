import type { FastifyInstance, FastifyRequest } from 'fastify';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { all, audit, get, now, run, tx } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { projectForOrg } from './projects.ts';
import { currentSeq, drawingForOrg, type DrawingRow } from '../drawings.ts';
import { evaluateRules } from '../rules/engine.ts';

const esc = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

/** Review & edit: comment registers (municipality, client, internal, NOVA checks) tracked to resolution with evidence. */
export function reviewRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;

  const commentForOrg = (req: FastifyRequest) => {
    const c = get<any>(db, `SELECT c.* FROM review_comments c JOIN projects p ON p.id = c.project_id WHERE c.id = ? AND p.org_id = ?`, (req.params as any).cid, req.user.orgId);
    if (!c) throw new HttpError(404, 'comment not found');
    return c;
  };
  const list = (projectId: string) => all(db, `SELECT c.*, u.name AS created_by_name, cu.name AS closed_by_name, d.name AS drawing_name
      FROM review_comments c JOIN users u ON u.id = c.created_by LEFT JOIN users cu ON cu.id = c.closed_by LEFT JOIN drawings d ON d.id = c.drawing_id
      WHERE c.project_id = ? ORDER BY CASE c.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 ELSE 2 END, c.created_at`, projectId)
    .map((c) => ({ ...c, operations: c.drawing_id && c.op_seq_at_open !== null ? opsBetween(c.drawing_id, c.op_seq_at_open, c.op_seq_at_close) : [] }));
  const opsBetween = (drawingId: string, from: number, to: number | null) =>
    all(db, `SELECT seq, kind, source, created_at FROM geometry_operations WHERE drawing_id = ? AND state = 'applied' AND seq > ? ${to === null ? '' : 'AND seq <= ?'} ORDER BY seq`, ...(to === null ? [drawingId, from] : [drawingId, from, to]));

  app.get('/api/projects/:id/comments', async (req) => list(projectForOrg(deps, (req.params as any).id, req.user.orgId).id));

  /** Add one comment, or paste a whole authority letter: one comment per non-empty line (numbering kept as reference). */
  app.post('/api/projects/:id/comments', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const b = z.object({
      source: z.enum(['municipality', 'client', 'internal']), drawing_id: z.string().uuid().nullable().default(null),
      text: z.string().trim().min(2).max(20_000), split_lines: z.boolean().default(true), reference_prefix: z.string().max(30).default(''),
    }).parse(req.body);
    let d: DrawingRow | undefined;
    if (b.drawing_id) { d = drawingForOrg(db, b.drawing_id, req.user.orgId); if (!d || d.project_id !== p.id) throw new HttpError(404, 'drawing not found in this project'); }
    const lines = b.split_lines ? b.text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 1) : [b.text];
    const seq = d ? currentSeq(db, d.id) : null;
    const ids: string[] = [];
    tx(db, () => lines.forEach((line, i) => {
      const m = /^\s*([0-9٠-٩]+|[A-Za-z]?\d+(?:\.\d+)*)\s*[-.)،:]\s*(.+)$/.exec(line);
      const ref = m ? `${b.reference_prefix}${m[1]}` : `${b.reference_prefix}${i + 1}`;
      const id = randomUUID();
      run(db, `INSERT INTO review_comments (id, project_id, drawing_id, source, reference, text, status, op_seq_at_open, created_by, created_at, updated_at)
               VALUES (?,?,?,?,?,?,'open',?,?,?,?)`, id, p.id, d?.id ?? null, b.source, ref, m ? m[2] : line, seq, req.user.userId, now(), now());
      ids.push(id);
    }));
    audit(db, req.user.orgId, req.user.userId, 'comments.added', p.id, { count: ids.length, source: b.source });
    return { added: ids.length, comments: list(p.id) };
  });

  /** Turn every non-passing NOVA check on a drawing into a tracked comment. */
  app.post('/api/drawings/:id/comments-from-checks', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingForOrg(db, (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'drawing not found');
    const findings = evaluateRules(db, req.user.orgId, d).filter((f) => ['FAIL', 'WARNING'].includes(f.status));
    const seq = currentSeq(db, d.id);
    let added = 0;
    tx(db, () => {
      for (const f of findings) {
        const text = `${f.status}: ${f.message}${f.correctiveAction ? ` — ${f.correctiveAction}` : ''}`;
        if (get(db, "SELECT 1 FROM review_comments WHERE drawing_id = ? AND source = 'nova_check' AND text = ? AND status IN ('open','in_progress')", d.id, text)) continue;
        run(db, `INSERT INTO review_comments (id, project_id, drawing_id, source, reference, text, status, op_seq_at_open, finding_rule, created_by, created_at, updated_at)
                 VALUES (?,?,?,'nova_check',?,?,'open',?,?,?,?,?)`, randomUUID(), d.project_id, d.id, f.rule_code, text, seq, f.rule_code, req.user.userId, now(), now());
        added++;
      }
    });
    return { added, comments: list(d.project_id) };
  });

  app.patch('/api/comments/:cid', async (req) => {
    requireRole(req, 'engineer');
    const c = commentForOrg(req);
    const b = z.object({ status: z.enum(['open', 'in_progress', 'resolved', 'not_applicable']).optional(), response: z.string().max(5000).optional(), drawing_id: z.string().uuid().nullable().optional() }).parse(req.body);
    const response = b.response ?? c.response;
    const status = b.status ?? c.status;
    if ((status === 'resolved' || status === 'not_applicable') && !response.trim()) throw new HttpError(422, 'write the response to this comment before closing it');
    let drawingId = b.drawing_id === undefined ? c.drawing_id : b.drawing_id;
    if (b.drawing_id) { const d = drawingForOrg(db, b.drawing_id, req.user.orgId); if (!d || d.project_id !== c.project_id) throw new HttpError(404, 'drawing not found'); }
    const closing = (status === 'resolved' || status === 'not_applicable') && !['resolved', 'not_applicable'].includes(c.status);
    const reopening = (status === 'open' || status === 'in_progress') && ['resolved', 'not_applicable'].includes(c.status);
    const opAtOpen = drawingId && drawingId !== c.drawing_id ? currentSeq(db, drawingId) : c.op_seq_at_open;
    run(db, `UPDATE review_comments SET status = ?, response = ?, drawing_id = ?, op_seq_at_open = ?, op_seq_at_close = ?, closed_by = ?, closed_at = ?, updated_at = ? WHERE id = ?`,
      status, response, drawingId, opAtOpen,
      closing ? (drawingId ? currentSeq(db, drawingId) : null) : reopening ? null : c.op_seq_at_close,
      closing ? req.user.userId : reopening ? null : c.closed_by, closing ? now() : reopening ? null : c.closed_at, now(), c.id);
    audit(db, req.user.orgId, req.user.userId, 'comment.updated', c.id, { status });
    return list(c.project_id).find((x: any) => x.id === c.id);
  });

  app.delete('/api/comments/:cid', async (req) => {
    requireRole(req, 'engineer');
    const c = commentForOrg(req);
    if (c.status === 'resolved') throw new HttpError(409, 'resolved comments are part of the record and cannot be deleted');
    run(db, 'DELETE FROM review_comments WHERE id = ?', c.id);
    return { ok: true };
  });

  /** Comment–response sheet for the authority / client. */
  app.get('/api/projects/:id/comments/response-sheet', async (req, reply) => {
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const src = (req.query as any)?.source;
    const rows = list(p.id).filter((c: any) => !src || c.source === src);
    const label: Record<string, string> = { open: 'Open / مفتوحة', in_progress: 'In progress / قيد المعالجة', resolved: 'Resolved / تمت المعالجة', not_applicable: 'Not applicable / لا تنطبق' };
    reply.header('content-type', 'text/html; charset=utf-8').header('content-security-policy', "default-src 'none'; style-src 'unsafe-inline'");
    return `<!doctype html><html><head><meta charset="utf-8"><title>Comment response ${esc(p.code)}</title>
<style>body{font:13px/1.5 "Segoe UI",Tahoma,sans-serif;margin:30px;color:#101828}table{border-collapse:collapse;width:100%}td,th{border:1px solid #d0d5dd;padding:6px 8px;vertical-align:top;text-align:start}th{background:#f2f4f7}.r{direction:rtl;unicode-bidi:plaintext}.n{border:2px solid #b54708;background:#fffaeb;padding:8px 12px;margin:12px 0}</style></head><body>
<h1 style="font-size:20px">Comment response sheet / جدول الرد على الملاحظات — ${esc(p.code)} ${esc(p.name)}</h1>
<div>Generated ${esc(now().slice(0, 16).replace('T', ' '))} · ${rows.length} comment(s) · open ${rows.filter((r: any) => r.status === 'open' || r.status === 'in_progress').length}</div>
<div class="n">Prepared with NOVA for review by the responsible licensed engineer before it is sent. NOVA does not submit anything to the authority.</div>
<table><tr><th>Ref.</th><th>Source</th><th>Comment / الملاحظة</th><th>Response / الرد</th><th>Status</th><th>Drawing changes (evidence)</th></tr>
${rows.map((c: any) => `<tr><td>${esc(c.reference)}</td><td>${esc(c.source)}</td><td class="r">${esc(c.text)}</td><td class="r">${esc(c.response)}</td><td>${esc(label[c.status])}</td>
<td>${c.drawing_name ? `${esc(c.drawing_name)}: ` : ''}${c.operations.length ? c.operations.map((o: any) => `#${o.seq} ${esc(o.kind)}${o.source === 'ai' ? ' (copilot)' : ''}`).join(', ') : '—'}</td></tr>`).join('')}
</table></body></html>`;
  });
}
