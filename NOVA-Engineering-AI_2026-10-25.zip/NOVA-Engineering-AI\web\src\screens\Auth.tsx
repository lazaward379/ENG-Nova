import { useState } from 'react';
import { api } from '../api';
import { useT, type Lang } from '../i18n';
import { Icon } from '../ui';

export function Auth({ onSignedIn, lang, setLang }: { onSignedIn: (token: string) => void; lang: Lang; setLang: (l: Lang) => void }) {
  const { t } = useT();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [f, setF] = useState({ orgName: '', name: '', email: '', password: '' });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setErr(null);
    try {
      const r = mode === 'login' ? await api.post('/api/auth/login', { email: f.email, password: f.password }) : await api.post('/api/auth/register', f);
      onSignedIn(r.token);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <div style={{ minHeight: '100%', display: 'grid', placeItems: 'center', padding: 16 }}>
      <div style={{ width: 'min(980px, 100%)', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 28, alignItems: 'center' }}>
        <div>
          <div className="eyebrow">NOVA · ENGINEERING AI</div>
          <h1 style={{ fontSize: 34, lineHeight: 1.15, margin: '10px 0 12px' }}>{t('auth.title', 'AI-powered engineering platform for Abu Dhabi consultancies')}</h1>
          <p className="muted" style={{ maxWidth: 460 }}>
            {lang === 'ar'
              ? 'هندسة ثنائية الأبعاد حقيقية، تحقق حتمي، مكتبة قواعد قابلة للتدقيق، ومساعد ذكي يعمل فقط عبر أدوات مُتحقق منها — مع سجل كامل للعمليات والتراجع.'
              : 'Real 2D geometry, deterministic validation, an auditable rule library, and a copilot that acts only through validated tools — with full operation history and undo.'}
          </p>
          <div className="row" style={{ marginTop: 18, gap: 18 }}>
            {[['workspace', 'DXF'], ['compliance', lang === 'ar' ? 'فحوصات' : 'Checks'], ['assistant', lang === 'ar' ? 'مساعد' : 'Copilot'], ['documents', lang === 'ar' ? 'مراجعات' : 'Revisions']].map(([i, l]) => (
              <div key={i} className="row" style={{ gap: 6, color: 'var(--text-2)' }}><Icon name={i} />{l}</div>
            ))}
          </div>
        </div>
        <form className="card glow stack" onSubmit={submit} style={{ padding: 22 }}>
          <div className="row"><h2>{mode === 'login' ? t('auth.signin', 'Sign in') : t('auth.signup', 'Create organization')}</h2><span className="spacer" />
            <button type="button" className="btn ghost sm" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}><Icon name="globe" />{lang === 'ar' ? 'English' : 'العربية'}</button></div>
          {mode === 'register' && <>
            <label className="field">{t('auth.org', 'Organization name')}<input required value={f.orgName} onChange={set('orgName')} autoComplete="organization" /></label>
            <label className="field">{t('auth.yourName', 'Your name')}<input required value={f.name} onChange={set('name')} autoComplete="name" /></label>
          </>}
          <label className="field">{t('auth.email', 'Email')}<input required type="email" value={f.email} onChange={set('email')} autoComplete="email" dir="ltr" /></label>
          <label className="field">{t('auth.password', 'Password')}<input required type="password" minLength={mode === 'register' ? 10 : 1} value={f.password} onChange={set('password')} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} dir="ltr" />
            {mode === 'register' && <span className="faint">{t('auth.pwHint', 'At least 10 characters')}</span>}</label>
          {err && <div className="notice">{err}</div>}
          <button className="btn primary" disabled={busy}>{mode === 'login' ? t('auth.signin', 'Sign in') : t('auth.signup', 'Create organization')}</button>
          <div className="faint">
            {mode === 'login' ? t('auth.noAccount', 'No account?') : t('auth.haveAccount', 'Have an account?')}{' '}
            <a href="#" onClick={(e) => { e.preventDefault(); setMode(mode === 'login' ? 'register' : 'login'); setErr(null); }}>{mode === 'login' ? t('auth.signup', 'Create organization') : t('auth.signin', 'Sign in')}</a>
          </div>
          <div className="faint" style={{ borderTop: '1px solid var(--border)', paddingTop: 10 }}>{t('auth.disclaimer', 'Engineering support tool. It does not grant official approvals or replace licensed engineers.')}</div>
        </form>
      </div>
    </div>
  );
}
