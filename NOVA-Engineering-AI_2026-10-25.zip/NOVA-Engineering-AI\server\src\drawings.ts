import { randomUUID } from 'node:crypto';
import { all, get, now, run, type DB } from './db.ts';
import type { Entity, EntityInput, Provenance, Units } from './geometry/types.ts';
import { PLOT_LAYER } from './geometry/rooms.ts';

export type DrawingRow = {
  id: string; project_id: string; source_document_id: string | null; name: string; units: Units;
  import_diagnostics: string; created_by: string; created_at: string; updated_at: string;
};

export function rowToEntity(r: any): Entity {
  return { id: r.id, type: r.type, layer: r.layer, geom: JSON.parse(r.geom), props: JSON.parse(r.props), provenance: r.provenance, source_handle: r.source_handle };
}

export function loadEntities(db: DB, drawingId: string): Entity[] {
  return all(db, 'SELECT * FROM entities WHERE drawing_id = ? ORDER BY rowid', drawingId).map(rowToEntity);
}

export function insertEntity(db: DB, drawingId: string, e: Entity) {
  ensureLayer(db, drawingId, e.layer);
  run(db, 'INSERT INTO entities (id, drawing_id, type, layer, geom, props, provenance, source_handle, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
    e.id, drawingId, e.type, e.layer, JSON.stringify(e.geom), JSON.stringify(e.props ?? {}), e.provenance, e.source_handle ?? null, now());
}

export function updateEntity(db: DB, e: Entity) {
  run(db, 'UPDATE entities SET type = ?, layer = ?, geom = ?, props = ?, updated_at = ? WHERE id = ?',
    e.type, e.layer, JSON.stringify(e.geom), JSON.stringify(e.props ?? {}), now(), e.id);
}

export function newEntity(input: EntityInput, provenance: Provenance, props: Entity['props'] = {}, handle: string | null = null): Entity {
  return { ...input, id: randomUUID(), props, provenance, source_handle: handle } as Entity;
}

export function ensureLayer(db: DB, drawingId: string, name: string, color = 7) {
  // Plot/survey boundaries are locked by default so neither users nor the copilot move them by accident.
  run(db, 'INSERT OR IGNORE INTO layers (drawing_id, name, color, visible, locked) VALUES (?,?,?,1,?)',
    drawingId, name, color, PLOT_LAYER.test(name) ? 1 : 0);
}

export function layers(db: DB, drawingId: string) {
  return all(db, 'SELECT name, color, visible, locked FROM layers WHERE drawing_id = ? ORDER BY name', drawingId)
    .map((l) => ({ ...l, visible: !!l.visible, locked: !!l.locked }));
}

export function createDrawing(db: DB, p: { projectId: string; name: string; units: Units; userId: string; sourceDocumentId?: string | null; diagnostics?: unknown }) {
  const id = randomUUID();
  run(db, 'INSERT INTO drawings (id, project_id, source_document_id, name, units, import_diagnostics, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
    id, p.projectId, p.sourceDocumentId ?? null, p.name, p.units, JSON.stringify(p.diagnostics ?? {}), p.userId, now(), now());
  return id;
}

/** Fetch a drawing only if it belongs to the caller's organisation. */
export function drawingForOrg(db: DB, drawingId: string, orgId: string): DrawingRow | undefined {
  return get<DrawingRow>(db, `SELECT d.* FROM drawings d JOIN projects p ON p.id = d.project_id WHERE d.id = ? AND p.org_id = ?`, drawingId, orgId);
}

export function currentSeq(db: DB, drawingId: string): number {
  return (get<{ s: number }>(db, "SELECT COALESCE(MAX(seq), 0) AS s FROM geometry_operations WHERE drawing_id = ? AND state = 'applied'", drawingId)?.s) ?? 0;
}
