import { createContext, useContext } from 'react';

export type Lang = 'en' | 'ar';

const AR: Record<string, string> = {
  // navigation
  'nav.dashboard': 'نظرة عامة على النشاط', 'nav.home': 'الرئيسية', 'nav.hubDesign': 'التصميم', 'nav.hubReview': 'مراجعة وتعديل المخططات', 'nav.hubPresent': 'عرض تقديمي للعميل',
  'group.main': 'الأقسام الرئيسية', 'group.tools': 'مساحة العمل', 'nav.projects': 'المشاريع', 'nav.intake': 'استلام الوثائق والقطعة', 'nav.requirements': 'مفسّر المتطلبات',
  'nav.workspace': 'مساحة عمل CAD', 'nav.generate': 'الرسم من مشروع مرجعي', 'nav.architecture': 'التصميم المعماري', 'nav.bim': 'عارض BIM والنماذج', 'nav.compliance': 'مركز الامتثال',
  'nav.qa': 'ضبط جودة الرسومات', 'nav.shop': 'استوديو المخططات التنفيذية', 'nav.coordination': 'التنسيق الإنشائي والكهروميكانيكي',
  'nav.submission': 'حزم التقديم', 'nav.documents': 'الوثائق والمراجعات', 'nav.assistant': 'المساعد الهندسي الذكي', 'nav.review': 'التعاون والمراجعة',
  'nav.admin': 'إدارة المؤسسة', 'nav.settings': 'الإعدادات والتكاملات', 'nav.regulatory': 'مكتبة المصادر التنظيمية', 'nav.system': 'صحة النظام والمهام',
  'group.design': 'التصميم', 'group.verify': 'التحقق', 'group.deliver': 'التسليم', 'group.org': 'المؤسسة',
  // common
  'common.save': 'حفظ', 'common.cancel': 'إلغاء', 'common.create': 'إنشاء', 'common.open': 'فتح', 'common.upload': 'رفع', 'common.download': 'تنزيل',
  'common.refresh': 'تحديث', 'common.loading': 'جارٍ التحميل…', 'common.none': 'لا يوجد', 'common.status': 'الحالة', 'common.name': 'الاسم',
  'common.actions': 'إجراءات', 'common.search': 'بحث في المشاريع والملفات…', 'common.selectProject': 'اختر مشروعاً', 'common.selectDrawing': 'اختر رسماً',
  'common.notImplemented': 'غير متوفر بعد', 'common.signOut': 'تسجيل الخروج', 'common.theme': 'المظهر', 'common.language': 'English',
  'common.commandPalette': 'لوحة الأوامر', 'common.back': 'رجوع', 'common.apply': 'تطبيق', 'common.reject': 'رفض', 'common.date': 'التاريخ',
  // auth
  'auth.title': 'منصة هندسية مدعومة بالذكاء الاصطناعي لاستشاريي أبوظبي', 'auth.signin': 'تسجيل الدخول', 'auth.signup': 'إنشاء مؤسسة',
  'auth.email': 'البريد الإلكتروني', 'auth.password': 'كلمة المرور', 'auth.org': 'اسم المؤسسة', 'auth.yourName': 'اسمك',
  'auth.pwHint': '10 أحرف على الأقل', 'auth.noAccount': 'ليس لديك حساب؟', 'auth.haveAccount': 'لديك حساب؟',
  'auth.disclaimer': 'أداة دعم هندسي. لا تمنح موافقات رسمية ولا تحل محل المهندسين المرخصين.',
  // dashboard
  'dash.welcome': 'مرحباً', 'dash.projects': 'المشاريع', 'dash.drawings': 'الرسومات', 'dash.documents': 'الوثائق', 'dash.operations': 'العمليات الهندسية',
  'dash.recentProjects': 'أحدث المشاريع', 'dash.recentRuns': 'أحدث الفحوصات', 'dash.activity': 'النشاط', 'dash.start': 'ابدأ مشروعاً جديداً',
  'dash.startHint': 'ارفع وثائق القطعة والرسومات، صف المطلوب، ودع NOVA يحدد المعلومات الناقصة ويشغّل الفحوصات.',
  // projects
  'proj.new': 'مشروع جديد', 'proj.code': 'رمز المشروع', 'proj.name': 'اسم المشروع', 'proj.type': 'نوع المشروع', 'proj.description': 'وصف العمل',
  'proj.descHint': 'صف المبنى أو العمل الهندسي بالعربية أو الإنجليزية', 'proj.wizard.step1': 'الوصف', 'proj.wizard.step2': 'القطعة',
  'proj.wizard.step3': 'المتطلبات', 'proj.wizard.step4': 'الوثائق', 'proj.wizard.step5': 'الجاهزية', 'proj.next': 'التالي', 'proj.prev': 'السابق',
  'proj.facts': 'حقائق المشروع', 'proj.addFact': 'إضافة حقيقة', 'proj.key': 'المفتاح', 'proj.value': 'القيمة', 'proj.unit': 'الوحدة', 'proj.class': 'التصنيف',
  'proj.source': 'المصدر', 'proj.confidence': 'الثقة', 'proj.documents': 'سجل الوثائق', 'proj.drawings': 'الرسومات', 'proj.readiness': 'تقرير الجاهزية',
  'proj.dropHint': 'اسحب الملفات هنا أو انقر للاختيار — DXF, DWG, IFC, PDF, PNG, JPG, CSV, XLSX, DOCX (حتى 50 ميغابايت)',
  'proj.missing': 'مدخلات حرجة ناقصة', 'proj.known': 'حقائق مؤكدة', 'proj.assumptions': 'افتراضات واقتراحات', 'proj.extracted': 'مستخرج من الوثائق',
  'proj.canCheck': 'فحوصات يمكن إجراؤها', 'proj.cannotCheck': 'فحوصات لا يمكن إجراؤها بعد', 'proj.nextAction': 'الإجراء التالي الموصى به',
  'proj.interpret': 'استخراج المتطلبات من الوصف', 'proj.confirm': 'تأكيد', 'proj.newDrawing': 'رسم جديد فارغ', 'proj.toDrawing': 'تحويل إلى رسم',
  // workspace
  'ws.layers': 'الطبقات', 'ws.properties': 'الخصائص', 'ws.copilot': 'المساعد', 'ws.issues': 'الملاحظات', 'ws.history': 'السجل', 'ws.revisions': 'المراجعات',
  'ws.rooms': 'الغرف', 'ws.select': 'تحديد', 'ws.pan': 'تحريك العرض', 'ws.line': 'خط', 'ws.rect': 'مستطيل', 'ws.polyline': 'خط متعدد', 'ws.circle': 'دائرة',
  'ws.text': 'نص', 'ws.measure': 'قياس', 'ws.wall': 'جدار', 'ws.acad': 'لوحة AutoCAD', 'ws.door': 'باب', 'ws.window': 'نافذة', 'ws.fit': 'ملاءمة', 'ws.undo': 'تراجع', 'ws.redo': 'إعادة', 'ws.snap': 'التقاط', 'ws.grid': 'شبكة', 'ws.ortho': 'تعامد',
  'ws.runChecks': 'تشغيل الفحوصات', 'ws.export': 'تصدير DXF', 'ws.checkpoint': 'نقطة حفظ', 'ws.report': 'تقرير', 'ws.noSelection': 'لا يوجد تحديد',
  'ws.selected': 'محدد', 'ws.move': 'نقل', 'ws.copy': 'نسخ', 'ws.rotate': 'تدوير', 'ws.mirror': 'عكس', 'ws.delete': 'حذف', 'ws.units': 'الوحدات',
  'ws.askCopilot': 'اكتب أمراً… مثال: انقل الباب 200 مم لليسار', 'ws.send': 'إرسال', 'ws.preliminary': 'مقترح أولي — يتطلب المراجعة',
  'ws.diagnostics': 'تشخيص الاستيراد', 'ws.locked': 'مقفلة', 'ws.restore': 'استعادة', 'ws.compare': 'مقارنة',
  // compliance
  'comp.run': 'تشغيل', 'comp.allRules': 'كل القواعد', 'comp.qaOnly': 'جودة الرسم', 'comp.regOnly': 'تنظيمية', 'comp.rule': 'القاعدة',
  'comp.result': 'النتيجة', 'comp.evidence': 'الدليل', 'comp.inputs': 'المدخلات', 'comp.source': 'المصدر', 'comp.action': 'الإجراء التصحيحي',
  'comp.showInDrawing': 'عرض في الرسم', 'comp.banner': 'نتائج دعم هندسي فقط — ليست موافقة رسمية. القواعد التنظيمية بلا مصدر موثق لا تُقيَّم.',
  // regulatory
  'reg.sources': 'المصادر', 'reg.rules': 'القواعد', 'reg.addSource': 'تسجيل مصدر', 'reg.authority': 'الجهة', 'reg.title': 'العنوان', 'reg.url': 'الرابط الرسمي',
  'reg.verify': 'توثيق', 'reg.version': 'الإصدار', 'reg.newVersion': 'إصدار موثق جديد', 'reg.clause': 'البند / الصفحة', 'reg.quotation': 'النص الحرفي',
  'reg.interpretation': 'التفسير', 'reg.params': 'المعاملات',
};

export function translate(lang: Lang, key: string, fallback: string) {
  return lang === 'ar' ? AR[key] ?? fallback : fallback;
}

export const LangContext = createContext<{ lang: Lang; t: (key: string, en: string) => string }>({ lang: 'en', t: (_k, en) => en });
export const useT = () => useContext(LangContext);

export const STATUS_AR: Record<string, string> = {
  PASS: 'ناجح', FAIL: 'راسب', WARNING: 'تحذير', 'NOT CHECKED': 'لم يُفحص', 'INSUFFICIENT DATA': 'بيانات غير كافية',
  'REQUIRES ENGINEER REVIEW': 'يتطلب مراجعة مهندس', 'SOURCE NOT VERIFIED': 'المصدر غير موثق',
};
