import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, Status, useApp, useLoad, when } from '../ui';

export function Dashboard() {
  const { me, go } = useApp();
  const { t, lang } = useT();
  const { data, error, loading } = useLoad(() => api.get('/api/dashboard'), []);
  if (!data) return <Loading error={error} loading={loading} />;
  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-h">
        <div><div className="eyebrow">{me.orgName}</div><h1>{t('dash.welcome', 'Welcome')}, {me.name}</h1></div>
        <span className="spacer" />
        <button className="btn primary" onClick={() => go('projects/new')}><Icon name="plus" />{t('proj.new', 'New project')}</button>
      </div>

      {!data.projects && (
        <div className="card glow" style={{ padding: 24 }}>
          <div className="row" style={{ alignItems: 'flex-start', gap: 18 }}>
            <div className="ai-dot" style={{ marginTop: 8 }} />
            <div style={{ flex: 1 }}>
              <h2>{t('dash.start', 'Start a new project')}</h2>
              <p className="muted" style={{ margin: '6px 0 14px' }}>{t('dash.startHint', 'Upload plot documents and drawings, describe the work, and let NOVA identify missing inputs and run checks.')}</p>
              <ol className="muted" style={{ margin: 0, paddingInlineStart: 18, lineHeight: 1.9 }}>
                {(lang === 'ar'
                  ? ['أنشئ مشروعاً وصف العمل', 'ارفع رسماً بصيغة DXF أو ملف مسح CSV (يوجد ملف تجريبي في مجلد samples)', 'افتح مساحة عمل CAD وعدّل الهندسة يدوياً أو عبر المساعد', 'شغّل الفحوصات وراجع الأدلة', 'أنشئ التقرير وصدّر DXF']
                  : ['Create a project and describe the work', 'Upload a DXF drawing or survey CSV (a synthetic sample is in the samples folder)', 'Open the CAD workspace; edit geometry directly or through the copilot', 'Run checks and review the evidence', 'Generate the report and export DXF']).map((s) => <li key={s}>{s}</li>)}
              </ol>
            </div>
          </div>
        </div>
      )}

      <div className="grid c4">
        {[['projects', t('dash.projects', 'Projects'), data.projects], ['workspace', t('dash.drawings', 'Drawings'), data.drawings], ['documents', t('dash.documents', 'Documents'), data.documents], ['system', t('dash.operations', 'Geometry operations'), data.operations]].map(([icon, l, v]) => (
          <div key={icon} className="card stat"><div className="row"><Icon name={icon} /><span className="l">{l}</span></div><div className="v">{v}</div></div>
        ))}
      </div>

      <div className="grid c2">
        <div className="card">
          <div className="card-h"><h2>{t('dash.recentProjects', 'Recent projects')}</h2><span className="spacer" /><a href="#/projects">{t('nav.projects', 'All')} →</a></div>
          {data.recentProjects.length ? (
            <table className="t"><tbody>{data.recentProjects.map((p: any) => (
              <tr key={p.id} className="click" onClick={() => go(`project/${p.id}/intake`)}><td className="mono ltr">{p.code}</td><td>{p.name}</td><td><span className="chip">{p.status}</span></td><td className="faint">{when(p.updated_at)}</td></tr>
            ))}</tbody></table>
          ) : <div className="empty">{t('common.none', 'None yet')}</div>}
        </div>
        <div className="card">
          <div className="card-h"><h2>{t('dash.recentRuns', 'Recent checks')}</h2></div>
          {data.recentRuns.length ? data.recentRuns.map((r: any) => (
            <div key={r.id} className="row" style={{ padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
              <span className="mono ltr">{r.project}</span><span>{r.drawing}</span><span className="spacer" />
              {Object.entries(r.summary).map(([s, n]) => <span key={s} className="row" style={{ gap: 3 }}><Status s={s} /><span className="faint">{n as number}</span></span>)}
            </div>
          )) : <div className="empty">{t('common.none', 'None yet')}</div>}
        </div>
      </div>

      <div className="card">
        <div className="card-h"><h2>{t('dash.activity', 'Activity')}</h2></div>
        {data.recentActivity.length ? <table className="t"><tbody>{data.recentActivity.map((a: any, i: number) => (
          <tr key={i}><td className="mono">{a.action}</td><td>{a.user}</td><td className="faint">{when(a.created_at)}</td></tr>))}</tbody></table>
          : <div className="empty">{t('common.none', 'None yet')}</div>}
      </div>
    </div>
  );
}
