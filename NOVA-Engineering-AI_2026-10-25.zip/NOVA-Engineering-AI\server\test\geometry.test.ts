import { test } from 'node:test';
import assert from 'node:assert/strict';
import { polygonArea, signedArea, selfIntersects, rotateXf, mirrorXf, translateXf, transformEntity, ringDistance, geomEqual, entityLength } from '../src/geometry/math.ts';
import { extractRooms } from '../src/geometry/rooms.ts';
import type { Entity, EntityInput } from '../src/geometry/types.ts';

const sq = [{ x: 0, y: 0 }, { x: 4000, y: 0 }, { x: 4000, y: 3000 }, { x: 0, y: 3000 }];

test('shoelace area and orientation', () => {
  assert.equal(polygonArea(sq), 12_000_000);
  assert.ok(signedArea(sq) > 0);
  assert.ok(signedArea([...sq].reverse()) < 0);
});

test('L-shaped polygon area', () => {
  const L = [{ x: 0, y: 0 }, { x: 6, y: 0 }, { x: 6, y: 2 }, { x: 2, y: 2 }, { x: 2, y: 5 }, { x: 0, y: 5 }];
  assert.equal(polygonArea(L), 6 * 2 + 2 * 3);
});

test('self-intersection detection', () => {
  assert.equal(selfIntersects(sq), false);
  assert.equal(selfIntersects([{ x: 0, y: 0 }, { x: 4, y: 4 }, { x: 4, y: 0 }, { x: 0, y: 4 }]), true);
});

test('rotate 4 × 90° returns to the start', () => {
  let e: EntityInput = { type: 'LINE', layer: 'A', geom: { a: { x: 1, y: 2 }, b: { x: 5, y: 7 } } };
  const start = e;
  for (let i = 0; i < 4; i++) e = transformEntity(e, rotateXf({ x: 3, y: -1 }, 90));
  assert.ok(geomEqual(e, start, 1e-9));
});

test('mirror keeps arcs counter-clockwise and is an involution', () => {
  const arc: EntityInput = { type: 'ARC', layer: 'A', geom: { c: { x: 10, y: 0 }, r: 5, start: 0, end: 90 } };
  const m = transformEntity(arc, mirrorXf({ x: 0, y: 0 }, { x: 0, y: 1 }));
  const g = m.geom as any;
  assert.ok(Math.abs(g.c.x + 10) < 1e-12 && Math.abs(g.c.y) < 1e-12);
  assert.deepEqual([Math.round(g.start), Math.round(g.end)], [90, 180]);
  assert.ok(Math.abs(entityLength(m) - entityLength(arc)) < 1e-9);
  const back = transformEntity(m, mirrorXf({ x: 0, y: 0 }, { x: 0, y: 1 }));
  assert.ok(geomEqual(back, arc, 1e-9));
});

test('translate is exact for representable values', () => {
  const p: EntityInput = { type: 'POINT', layer: '0', geom: { p: { x: 100, y: 50 } } };
  assert.deepEqual(transformEntity(p, translateXf(-200, 0)).geom, { p: { x: -100, y: 50 } });
});

test('ring distance measures a uniform setback', () => {
  const plot = [{ x: 0, y: 0 }, { x: 30, y: 0 }, { x: 30, y: 25 }, { x: 0, y: 25 }];
  const fp = [{ x: 4, y: 3 }, { x: 22, y: 3 }, { x: 22, y: 18 }, { x: 4, y: 18 }];
  assert.equal(ringDistance(fp, plot).d, 3);
});

test('rooms: closed boundary, label, area in m²; open boundary flagged', () => {
  const ents: Entity[] = [
    { id: 'r1', type: 'POLYLINE', layer: 'A-ROOM', geom: { points: sq, closed: true }, props: {}, provenance: 'user' },
    { id: 't1', type: 'TEXT', layer: 'A-ANNO', geom: { p: { x: 100, y: 100 }, h: 100, rot: 0, text: 'غرفة نوم' }, props: {}, provenance: 'user' },
    { id: 'r2', type: 'POLYLINE', layer: 'A-ROOM', geom: { points: sq, closed: false }, props: {}, provenance: 'user' },
  ];
  const rooms = extractRooms(ents, 'mm');
  assert.equal(rooms[0].name, 'غرفة نوم');
  assert.equal(rooms[0].areaM2, 12);
  assert.equal(rooms[1].valid, false);
  assert.deepEqual(rooms[1].problems, ['boundary not closed']);
  assert.equal(extractRooms(ents, 'unitless')[0].areaM2, null);
});
