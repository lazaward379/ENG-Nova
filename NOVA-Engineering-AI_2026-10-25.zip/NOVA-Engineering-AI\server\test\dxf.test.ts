import { test } from 'node:test';
import assert from 'node:assert/strict';
import { importDxf, exportDxf, verifyExport } from '../src/dxf/dxf.ts';
import { sampleDxf, sampleEntities } from '../scripts/make-sample.ts';

test('sample imports with units and reports the unsupported ELLIPSE', () => {
  const r = importDxf(sampleDxf());
  assert.equal(r.diagnostics.units, 'mm');
  assert.equal(r.entities.length, sampleEntities().length);
  assert.deepEqual(r.diagnostics.skipped, { ELLIPSE: 1 });
  assert.equal(r.diagnostics.rawEntityCounts.ELLIPSE, 1);
  assert.ok(r.diagnostics.warnings.some((w) => w.includes('ELLIPSE')));
});

test('round-trip preserves geometry, layers, text (incl. Arabic) and units', () => {
  const src = sampleEntities();
  const dxf = exportDxf(src, [], 'mm');
  const v = verifyExport(dxf, src, 'mm');
  assert.equal(v.ok, true, v.mismatches.join('\n'));
  const again = importDxf(dxf).entities.map((e) => e.input);
  assert.deepEqual(again.find((e) => e.type === 'TEXT')!.geom, src.find((e) => e.type === 'TEXT')!.geom);
});

test('round-trip with awkward floating point coordinates', () => {
  const src = [{ type: 'LINE' as const, layer: 'X', geom: { a: { x: 0.1 + 0.2, y: -1e-7 }, b: { x: 123456789.123456, y: 1 / 3 } } }];
  assert.equal(verifyExport(exportDxf(src, [], 'm'), src, 'm').ok, true);
});

test('verification detects a tampered export', () => {
  const src = sampleEntities();
  const dxf = exportDxf(src, [], 'mm').replace('\r\n 10\r\n4000\r\n', '\r\n 10\r\n4001\r\n');
  assert.equal(verifyExport(dxf, src, 'mm').ok, false);
});

test('missing $INSUNITS → unitless with a warning, never a guess', () => {
  const dxf = exportDxf(sampleEntities(), [], 'mm').replace(/\s*9\r\n\$INSUNITS\r\n\s*70\r\n4/, '');
  const r = importDxf(dxf);
  assert.equal(r.diagnostics.units, 'unitless');
  assert.ok(r.diagnostics.warnings.some((w) => /units are not defined/i.test(w)));
});

test('binary DXF and garbage are rejected', () => {
  assert.throws(() => importDxf('AutoCAD Binary DXF\r\n\x1a\x00'), /Binary DXF/);
});

test('mirrored OCS circle is converted to world coordinates', () => {
  const dxf = ['0', 'SECTION', '2', 'ENTITIES', '0', 'CIRCLE', '8', 'A', '10', '5', '20', '2', '30', '0', '40', '1', '210', '0', '220', '0', '230', '-1', '0', 'ENDSEC', '0', 'EOF'].join('\n');
  const r = importDxf(dxf);
  assert.deepEqual(r.entities[0].input.geom, { c: { x: -5, y: 2 }, r: 1 });
});
