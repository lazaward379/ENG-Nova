import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync, accessSync, constants } from 'node:fs';
import { join, resolve, sep } from 'node:path';

export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;

/** Allowed upload types: extension → MIME, plus an optional magic-byte check. */
export const ALLOWED: Record<string, { mime: string; magic?: (b: Buffer) => boolean; classify: string }> = {
  dxf: { mime: 'image/vnd.dxf', classify: 'cad_drawing' },
  dwg: { mime: 'image/vnd.dwg', magic: (b) => b.subarray(0, 4).toString('latin1') === 'AC10', classify: 'cad_drawing' },
  ifc: { mime: 'application/x-step', magic: (b) => b.subarray(0, 32).toString('latin1').includes('ISO-10303-21'), classify: 'bim_model' },
  pdf: { mime: 'application/pdf', magic: (b) => b.subarray(0, 5).toString('latin1') === '%PDF-', classify: 'document' },
  png: { mime: 'image/png', magic: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), classify: 'image' },
  jpg: { mime: 'image/jpeg', magic: (b) => b[0] === 0xff && b[1] === 0xd8, classify: 'image' },
  jpeg: { mime: 'image/jpeg', magic: (b) => b[0] === 0xff && b[1] === 0xd8, classify: 'image' },
  csv: { mime: 'text/csv', classify: 'data_table' },
  xlsx: { mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', magic: (b) => b[0] === 0x50 && b[1] === 0x4b, classify: 'data_table' },
  docx: { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', magic: (b) => b[0] === 0x50 && b[1] === 0x4b, classify: 'document' },
};

export function extOf(name: string) {
  const m = /\.([A-Za-z0-9]{1,8})$/.exec(name);
  return m ? m[1].toLowerCase() : '';
}

/** Strip path components and control characters from a client-supplied filename (display only). */
export const safeDisplayName = (name: string) => name.replace(/^.*[\\/]/, '').replace(/[\x00-\x1f]/g, '').slice(0, 255) || 'file';

export interface StorageProvider {
  put(data: Buffer): { key: string; sha256: string };
  get(key: string): Buffer;
  healthy(): boolean;
}

/** Content-addressed local storage. Keys are SHA-256 hex, so client filenames never become paths. */
export class LocalStorage implements StorageProvider {
  readonly root: string;
  constructor(root: string) {
    this.root = resolve(root);
    mkdirSync(this.root, { recursive: true });
  }
  private pathFor(key: string) {
    if (!/^[a-f0-9]{64}$/.test(key)) throw new Error('invalid storage key');
    const p = resolve(join(this.root, key.slice(0, 2), key));
    if (!p.startsWith(this.root + sep)) throw new Error('path escapes storage root');
    return p;
  }
  put(data: Buffer) {
    const sha256 = createHash('sha256').update(data).digest('hex');
    const p = this.pathFor(sha256);
    if (!existsSync(p)) {
      mkdirSync(resolve(p, '..'), { recursive: true });
      writeFileSync(p, data, { flag: 'wx' });
    }
    return { key: sha256, sha256 };
  }
  get(key: string) {
    const data = readFileSync(this.pathFor(key));
    if (createHash('sha256').update(data).digest('hex') !== key) throw new Error('stored file failed integrity check');
    return data;
  }
  healthy() {
    try { accessSync(this.root, constants.W_OK); return true; } catch { return false; }
  }
}

/** Integration point for a malware scanner (e.g. ClamAV). Not implemented in 0.1. */
export function scanHook(_data: Buffer): { scanned: false; reason: string } {
  return { scanned: false, reason: 'no malware scanner configured' };
}
