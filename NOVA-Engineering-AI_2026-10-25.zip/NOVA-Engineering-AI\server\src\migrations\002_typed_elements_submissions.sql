-- Typed architectural elements (WALL / DOOR / WINDOW) and submission packages.

-- SQLite cannot alter a CHECK constraint, so the entities table is rebuilt.
CREATE TABLE entities_v2 (
  id TEXT PRIMARY KEY,
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('LINE','POLYLINE','CIRCLE','ARC','TEXT','POINT','WALL','DOOR','WINDOW')),
  layer TEXT NOT NULL,
  geom TEXT NOT NULL,
  props TEXT NOT NULL DEFAULT '{}',
  provenance TEXT NOT NULL CHECK (provenance IN ('imported','user','ai')),
  source_handle TEXT,
  updated_at TEXT NOT NULL
);
INSERT INTO entities_v2 SELECT id, drawing_id, type, layer, geom, props, provenance, source_handle, updated_at FROM entities;
DROP TABLE entities;
ALTER TABLE entities_v2 RENAME TO entities;
CREATE INDEX idx_entities_drawing ON entities(drawing_id);

CREATE TABLE submission_packages (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  target TEXT NOT NULL CHECK (target IN ('binaa','other')),
  title TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft','ready_for_review','submitted_manually','returned','approval_recorded','withdrawn')),
  external_reference TEXT,          -- application number issued by the external platform, entered by a person
  outcome_document_id TEXT REFERENCES documents(id) ON DELETE SET NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_submissions_project ON submission_packages(project_id);

CREATE TABLE submission_items (
  id TEXT PRIMARY KEY,
  package_id TEXT NOT NULL REFERENCES submission_packages(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  origin TEXT NOT NULL CHECK (origin IN ('nova','official','user')),
  required INTEGER NOT NULL DEFAULT 1,
  document_id TEXT REFERENCES documents(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK (status IN ('missing','attached','not_applicable')),
  note TEXT NOT NULL DEFAULT '',
  source_id TEXT REFERENCES regulatory_sources(id),
  created_at TEXT NOT NULL
);

CREATE TABLE submission_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  package_id TEXT NOT NULL REFERENCES submission_packages(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  user_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);
