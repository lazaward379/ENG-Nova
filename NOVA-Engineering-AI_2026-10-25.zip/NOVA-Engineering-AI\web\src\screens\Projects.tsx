import { useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, useApp, useLoad, when } from '../ui';

export function Projects({ pickFor }: { pickFor?: string }) {
  const { go, setProject, can } = useApp();
  const { t } = useT();
  const { data, error, loading } = useLoad(() => api.get('/api/projects'), []);
  return (
    <div>
      <div className="page-h">
        <div><h1>{t('nav.projects', 'Projects')}</h1>{pickFor && <div className="sub">{t('common.selectProject', 'Select a project')} →</div>}</div>
        <span className="spacer" />
        {can('engineer') && <button className="btn primary" onClick={() => go('projects/new')}><Icon name="plus" />{t('proj.new', 'New project')}</button>}
      </div>
      <Loading error={error} loading={loading && !data} />
      {data && (data.length ? (
        <div className="card table-wrap">
          <table className="t">
            <thead><tr><th>{t('proj.code', 'Code')}</th><th>{t('proj.name', 'Name')}</th><th>{t('proj.type', 'Type')}</th><th>{t('common.status', 'Status')}</th><th>{t('proj.documents', 'Docs')}</th><th>{t('proj.drawings', 'Drawings')}</th><th>{t('common.date', 'Updated')}</th></tr></thead>
            <tbody>{data.map((p: any) => (
              <tr key={p.id} className="click" onClick={() => { setProject(p.id); go(`project/${p.id}/${pickFor ?? 'intake'}`); }}>
                <td className="mono ltr">{p.code}</td><td>{p.name}</td><td>{p.project_type || '—'}</td><td><span className="chip">{p.status}</span></td><td>{p.documents}</td><td>{p.drawings}</td><td className="faint">{when(p.updated_at)}</td>
              </tr>))}</tbody>
          </table>
        </div>
      ) : <div className="card empty">{t('common.none', 'No projects yet.')} <a href="#/projects/new">{t('proj.new', 'New project')}</a></div>)}
    </div>
  );
}

const TYPES = ['residential_villa', 'residential_building', 'commercial', 'mixed_use', 'industrial', 'infrastructure', 'fit_out', 'other'];

/** Wizard: description → plot → requirements → documents → readiness. Each step persists real data. */
export function NewProjectWizard() {
  const { go, toast, setProject } = useApp();
  const { t, lang } = useT();
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ code: '', name: '', project_type: 'residential_villa', description: '' });
  const [err, setErr] = useState<string | null>(null);

  const create = async () => {
    setErr(null);
    try {
      const r = await api.post('/api/projects', f);
      setProject(r.id);
      if (f.description.trim()) await api.post(`/api/projects/${r.id}/interpret-requirements`);
      toast(lang === 'ar' ? 'تم إنشاء المشروع' : 'Project created', 'ok');
      go(`project/${r.id}/plot`);
    } catch (e: any) { setErr(e.message); }
  };

  const steps = [t('proj.wizard.step1', 'Description'), t('proj.wizard.step2', 'Plot'), t('proj.wizard.step3', 'Requirements'), t('proj.wizard.step4', 'Documents'), t('proj.wizard.step5', 'Readiness')];
  return (
    <div style={{ maxWidth: 780 }}>
      <div className="page-h"><div><div className="eyebrow">{t('proj.new', 'New project')}</div><h1>{t('proj.wizard.step1', 'Describe the work')}</h1></div></div>
      <div className="steps">{steps.map((s, i) => <span key={s} className={`step ${i === step ? 'active' : i < step ? 'done' : ''}`}><b>{i + 1}</b>{s}</span>)}</div>
      <div className="card glow stack">
        <div className="grid c2">
          <label className="field">{t('proj.code', 'Project code')}<input className="mono" dir="ltr" placeholder="AD-2026-014" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></label>
          <label className="field">{t('proj.name', 'Project name')}<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
        </div>
        <label className="field">{t('proj.type', 'Project type')}
          <select value={f.project_type} onChange={(e) => setF({ ...f, project_type: e.target.value })}>{TYPES.map((x) => <option key={x}>{x}</option>)}</select></label>
        <label className="field">{t('proj.description', 'Description')}
          <textarea rows={5} placeholder={lang === 'ar' ? 'مثال: فيلا سكنية من طابقين مع مجلس منفصل ومواقف وثلاث غرف نوم في الطابق العلوي.' : 'e.g. A two-storey residential villa with a separate majlis, parking, and three bedrooms on the upper floor.'}
            value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <span className="faint">{t('proj.descHint', 'Arabic or English.')} {lang === 'ar' ? 'سيتم استخراج المتطلبات كاقتراحات تحتاج إلى تأكيدك.' : 'Requirement hints are extracted as suggestions you confirm — never as facts.'}</span>
        </label>
        {err && <div className="notice">{err}</div>}
        <div className="row end">
          <button className="btn" onClick={() => go('projects')}>{t('common.cancel', 'Cancel')}</button>
          <button className="btn primary" disabled={!f.code || !f.name} onClick={() => { setStep(1); create(); }}>{t('proj.next', 'Next')} →</button>
        </div>
      </div>
    </div>
  );
}
