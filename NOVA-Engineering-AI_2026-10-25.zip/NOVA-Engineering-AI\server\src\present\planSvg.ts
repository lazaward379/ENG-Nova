import type { Entity, Pt, Units } from '../geometry/types.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { bbox } from '../geometry/math.ts';
import { extractRooms, PLOT_LAYER } from '../geometry/rooms.ts';
import { doorParts, isOpening, wallFrame } from '../geometry/hosted.ts';

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const ROOM_FILLS = ['#e0f2fe', '#ede9fe', '#dcfce7', '#fef3c7', '#fce7f3', '#e0e7ff', '#ccfbf1', '#fee2e2'];

/** Presentation-quality SVG of a plan, drawn from the real geometry (no images involved). */
export function planSvg(entities: Entity[], units: Units, opts: { width?: number; height?: number; showPlot?: boolean } = {}) {
  const mpu = metresPerUnit(units) ?? 1;
  const W = opts.width ?? 1600, H = opts.height ?? 1000;
  const rooms = extractRooms(entities, units).filter((r) => r.valid);
  const plot = opts.showPlot === false ? [] : entities.filter((e) => e.type === 'POLYLINE' && PLOT_LAYER.test(e.layer));
  const walls = entities.filter((e) => e.type === 'WALL') as Extract<Entity, { type: 'WALL' }>[];
  const openings = entities.filter(isOpening);
  const scope = [...plot, ...rooms.map((r) => ({ type: 'POLYLINE', layer: 'x', geom: { points: r.points, closed: true } }) as any), ...walls];
  const b = bbox(scope.length ? scope : entities);
  if (!b) return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}"><text x="40" y="60" font-size="32">No geometry</text></svg>`;
  const pad = 0.06 * Math.max(b.maxX - b.minX, b.maxY - b.minY);
  const s = Math.min(W / (b.maxX - b.minX + 2 * pad), H / (b.maxY - b.minY + 2 * pad));
  const ox = (W - (b.maxX - b.minX) * s) / 2, oy = (H - (b.maxY - b.minY) * s) / 2;
  const X = (p: Pt) => (ox + (p.x - b.minX) * s).toFixed(2), Y = (p: Pt) => (H - oy - (p.y - b.minY) * s).toFixed(2);
  const pts = (ps: Pt[]) => ps.map((p) => `${X(p)},${Y(p)}`).join(' ');
  const out: string[] = [`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" direction="ltr" font-family="Segoe UI, Tahoma, Arial, sans-serif">`, `<rect width="${W}" height="${H}" fill="#ffffff"/>`];
  for (const p of plot) out.push(`<polygon points="${pts((p as any).geom.points)}" fill="#f8fafc" stroke="#ef4444" stroke-width="2" stroke-dasharray="14 8"/>`);
  rooms.forEach((r, i) => out.push(`<polygon points="${pts(r.points)}" fill="${ROOM_FILLS[i % ROOM_FILLS.length]}" stroke="none"/>`));
  // walls: solid parts between openings
  for (const w of walls) {
    const { len, dir, normal } = wallFrame(w.geom);
    const h = w.geom.thickness / 2;
    const ops = openings.filter((o) => (o.geom as any).wallId === w.id).map((o) => [(o.geom as any).offset - (o.geom as any).width / 2, (o.geom as any).offset + (o.geom as any).width / 2]).sort((a, c) => a[0] - c[0]);
    let t = 0;
    const seg = (t0: number, t1: number) => {
      const a = { x: w.geom.a.x + dir.x * t0, y: w.geom.a.y + dir.y * t0 }, c = { x: w.geom.a.x + dir.x * t1, y: w.geom.a.y + dir.y * t1 };
      out.push(`<polygon points="${pts([{ x: a.x + normal.x * h, y: a.y + normal.y * h }, { x: c.x + normal.x * h, y: c.y + normal.y * h }, { x: c.x - normal.x * h, y: c.y - normal.y * h }, { x: a.x - normal.x * h, y: a.y - normal.y * h }])}" fill="#1e293b"/>`);
    };
    for (const [a, c] of ops) { if (a > t) seg(t, a); t = Math.max(t, c); }
    if (len > t) seg(t, len);
  }
  // non-typed lines (e.g. imported drawings without walls)
  if (!walls.length) for (const e of entities) {
    if (e.type === 'LINE') out.push(`<line x1="${X(e.geom.a)}" y1="${Y(e.geom.a)}" x2="${X(e.geom.b)}" y2="${Y(e.geom.b)}" stroke="#334155" stroke-width="2"/>`);
    if (e.type === 'POLYLINE' && !PLOT_LAYER.test(e.layer)) out.push(`<polyline points="${pts(e.geom.points)}${e.geom.closed ? ' ' + pts([e.geom.points[0]]) : ''}" fill="none" stroke="#334155" stroke-width="2"/>`);
  }
  for (const o of openings) {
    const g: any = o.geom;
    if (!g.p || !g.dir) continue;
    if (o.type === 'DOOR') {
      const k = doorParts(g);
      const r = g.width * s;
      const sweep = ((k.end - k.start) % 360 + 360) % 360 > 0 ? 0 : 1;
      out.push(`<line x1="${X(k.hinge)}" y1="${Y(k.hinge)}" x2="${X(k.tip)}" y2="${Y(k.tip)}" stroke="#0ea5e9" stroke-width="3"/>`);
      out.push(`<path d="M ${X(k.tip)} ${Y(k.tip)} A ${r.toFixed(2)} ${r.toFixed(2)} 0 0 ${sweep} ${X(k.closed)} ${Y(k.closed)}" fill="none" stroke="#0ea5e9" stroke-width="1.5" stroke-dasharray="6 5"/>`);
    } else {
      const a = { x: g.p.x - g.dir.x * g.width / 2, y: g.p.y - g.dir.y * g.width / 2 }, c = { x: g.p.x + g.dir.x * g.width / 2, y: g.p.y + g.dir.y * g.width / 2 };
      out.push(`<line x1="${X(a)}" y1="${Y(a)}" x2="${X(c)}" y2="${Y(c)}" stroke="#7c3aed" stroke-width="5"/>`);
    }
  }
  // room labels
  for (const r of rooms) {
    const c = r.points.reduce((acc, p) => ({ x: acc.x + p.x / r.points.length, y: acc.y + p.y / r.points.length }), { x: 0, y: 0 });
    const bw = (Math.max(...r.points.map((p) => p.x)) - Math.min(...r.points.map((p) => p.x))) * s;
    const fs = Math.max(11, Math.min(26, bw / Math.max(6, (r.name ?? '').length) * 1.4));
    out.push(`<text x="${X(c)}" y="${Y(c)}" text-anchor="middle" font-size="${fs.toFixed(1)}" font-weight="600" fill="#0f172a">${esc(r.name ?? '')}</text>`);
    if (r.areaM2 !== null) out.push(`<text x="${X(c)}" y="${(+Y(c) + fs * 1.25).toFixed(2)}" text-anchor="middle" font-size="${(fs * 0.8).toFixed(1)}" fill="#475569" direction="ltr" unicode-bidi="embed">${r.areaM2.toFixed(1)} m²</text>`);
  }
  // scale bar (5 m)
  const five = 5 / mpu * s;
  out.push(`<g transform="translate(${30},${H - 30})"><rect width="${five.toFixed(1)}" height="8" fill="#0f172a"/><text y="-8" font-size="16" fill="#0f172a">0</text><text x="${five.toFixed(1)}" y="-8" font-size="16" text-anchor="end" fill="#0f172a">5 m</text></g>`);
  out.push('</svg>');
  return out.join('\n');
}
