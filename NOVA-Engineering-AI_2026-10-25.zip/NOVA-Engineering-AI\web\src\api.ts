const TOKEN_KEY = 'nova.token';

export function getToken(): string | null {
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function setToken(t: string | null) {
  try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch { /* storage unavailable */ }
}

export class ApiError extends Error {
  status: number;
  details: any;
  constructor(status: number, message: string, details: any) { super(message); this.status = status; this.details = details; }
}

let onUnauthorized: () => void = () => {};
export const setUnauthorizedHandler = (fn: () => void) => { onUnauthorized = fn; };

async function request<T>(method: string, url: string, body?: unknown, raw = false): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers.authorization = `Bearer ${token}`;
  let payload: BodyInit | undefined;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
  const res = await fetch(url, { method, headers, body: payload });
  if (res.status === 401 && !url.startsWith('/api/auth/')) onUnauthorized();
  if (!res.ok) {
    let j: any = null;
    try { j = await res.json(); } catch { /* not JSON */ }
    const msg = j?.errors?.join('; ') || (j?.issues ? j.issues.map((i: any) => `${i.path}: ${i.message}`).join('; ') : '') || j?.error || res.statusText;
    throw new ApiError(res.status, msg, j);
  }
  if (raw) return res as unknown as T;
  return res.headers.get('content-type')?.includes('json') ? res.json() : (res.text() as any);
}

export const api = {
  get: <T = any>(url: string) => request<T>('GET', url),
  post: <T = any>(url: string, body: unknown = {}) => request<T>('POST', url, body),
  put: <T = any>(url: string, body: unknown) => request<T>('PUT', url, body),
  patch: <T = any>(url: string, body: unknown) => request<T>('PATCH', url, body),
  del: <T = any>(url: string) => request<T>('DELETE', url),
  /** Authenticated request returning the raw Response (images, files). */
  raw: (url: string) => request<Response>('GET', url, undefined, true),
  upload: <T = any>(url: string, file: File) => { const f = new FormData(); f.append('file', file); return request<T>('POST', url, f); },
  /** Authenticated download via fetch → blob (the token never goes into a URL). */
  async download(url: string, filename: string) {
    const res = await request<Response>('GET', url, undefined, true);
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  },
  /** Open an HTML report in a new tab from an authenticated request. */
  async openHtml(url: string) {
    const html = await request<string>('GET', url);
    const w = window.open('', '_blank');
    if (!w) throw new Error('pop-up blocked');
    w.document.open(); w.document.write(html); w.document.close();
  },
};

// ---- shared types ----
export type Pt = { x: number; y: number };
export type EntityType = 'LINE' | 'POLYLINE' | 'CIRCLE' | 'ARC' | 'TEXT' | 'POINT' | 'WALL' | 'DOOR' | 'WINDOW';
export type Entity = { id: string; type: EntityType; layer: string; geom: any; props: { color?: number }; provenance: string };
export type Layer = { name: string; color: number; visible: boolean; locked: boolean };
export type Drawing = {
  id: string; name: string; units: string; project_id: string; project: { id: string; code: string; name: string };
  entities: Entity[]; layers: Layer[]; extents: { minX: number; minY: number; maxX: number; maxY: number } | null;
  import_diagnostics: any; seq: number; canUndo: boolean; canRedo: boolean;
  rooms: { entityId: string; name: string | null; areaM2: number | null; areaUnits2: number; valid: boolean; problems: string[] }[];
};
export type Finding = { id?: string; rule_code: string; rule_title?: string; category?: string; status: string; message: string; inputs: any; evidence: any; entity_ids: string[]; location: Pt | null; corrective_action?: string; resolution?: string };
export type Me = { userId: string; orgId: string; role: 'admin' | 'reviewer' | 'engineer' | 'viewer'; name: string; email: string; orgName: string };
