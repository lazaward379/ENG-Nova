import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { all, audit, get, run } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { projectForOrg } from './projects.ts';
import { createDrawing, drawingForOrg, ensureLayer, loadEntities } from '../drawings.ts';
import { applyOperation, OperationError } from '../operations.ts';
import { generateFromReference, GenerateError, plotFrom } from '../generator/fromReference.ts';
import { runCompliance } from '../rules/engine.ts';
import type { EntityInput, Pt, Units } from '../geometry/types.ts';

const Body = z.object({
  referenceDrawingId: z.string().uuid(),
  plot: z.union([
    z.object({ drawingId: z.string().uuid() }),
    z.object({ width_m: z.number().positive().max(2000), depth_m: z.number().positive().max(2000), source: z.string().trim().min(3).max(500) }),
  ]),
  setback_m: z.number().min(0).max(100),
  setback_source: z.string().trim().min(3).max(500),
  mode: z.enum(['proportional', 'fill']).default('proportional'),
  rotate: z.enum(['auto', 'none', '90']).default('auto'),
  external_wall_mm: z.number().min(50).max(1000).default(200),
  internal_wall_mm: z.number().min(50).max(1000).default(100),
  door_width_mm: z.number().min(600).max(3000).default(900),
  window_width_mm: z.number().min(400).max(6000).default(1200),
  name: z.string().trim().max(200).optional(),
});

export function generateRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;

  /** Every drawing in the organisation with its room count, for choosing a reference. */
  app.get('/api/drawings', async (req) =>
    all(db, `SELECT d.id, d.name, d.units, d.project_id, p.code AS project_code, p.name AS project_name,
                    (SELECT COUNT(*) FROM entities e WHERE e.drawing_id = d.id AND e.type = 'POLYLINE' AND (e.layer LIKE '%ROOM%' OR e.layer LIKE '%SPACE%' OR e.layer LIKE '%A-AREA%')) AS room_boundaries,
                    (SELECT COUNT(*) FROM entities e WHERE e.drawing_id = d.id AND e.type = 'POLYLINE' AND (e.layer LIKE '%PLOT%' OR e.layer LIKE '%BOUNDARY%')) AS plot_boundaries
             FROM drawings d JOIN projects p ON p.id = d.project_id WHERE p.org_id = ? ORDER BY d.updated_at DESC`, req.user.orgId));

  app.post('/api/projects/:id/generate-from-reference', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const b = Body.parse(req.body);
    const ref = drawingForOrg(db, b.referenceDrawingId, req.user.orgId);
    if (!ref) throw new HttpError(404, 'reference drawing not found');

    let plot: Pt[], units: Units, plotSource: string;
    if ('drawingId' in b.plot) {
      const pd = drawingForOrg(db, b.plot.drawingId, req.user.orgId);
      if (!pd || pd.project_id !== p.id) throw new HttpError(404, 'plot drawing not found in this project');
      units = pd.units;
      plotSource = `plot boundary from drawing "${pd.name}"`;
      try { plot = plotFrom(loadEntities(db, pd.id)); } catch (e: any) { throw new HttpError(422, e.message); }
    } else {
      units = 'mm';
      plot = [{ x: 0, y: 0 }, { x: b.plot.width_m * 1000, y: 0 }, { x: b.plot.width_m * 1000, y: b.plot.depth_m * 1000 }, { x: 0, y: b.plot.depth_m * 1000 }];
      plotSource = `rectangular plot ${b.plot.width_m} × ${b.plot.depth_m} m entered by ${req.user.name} (${b.plot.source})`;
    }
    const cov = get<any>(db, "SELECT value FROM project_facts WHERE project_id = ? AND key = 'max_plot_coverage_pct' AND class = 'confirmed'", p.id);

    let out: ReturnType<typeof generateFromReference>;
    try {
      out = generateFromReference({ entities: loadEntities(db, ref.id), units: ref.units, name: ref.name }, { plot, units }, {
        setbackM: b.setback_m, mode: b.mode, rotate: b.rotate, externalWallMm: b.external_wall_mm, internalWallMm: b.internal_wall_mm,
        doorWidthMm: b.door_width_mm, windowWidthMm: b.window_width_mm, maxCoveragePct: cov ? Number(cov.value) : null, minScale: 0.6, maxScale: 1.5,
      });
    } catch (e) {
      if (e instanceof GenerateError) throw new HttpError(422, e.message);
      throw e;
    }
    out.report.assumptions.unshift(`Uniform setback of ${b.setback_m} m applied on all sides (${b.setback_source}).`, `Plot: ${plotSource}.`);

    const drawingId = createDrawing(db, {
      projectId: p.id, name: b.name || `Preliminary plan from ${ref.name}`, units, userId: req.user.userId,
      diagnostics: { format: 'generated from reference (preliminary)', units, unitsSource: 'target plot', warnings: out.report.warnings, generation: out.report, imported: {}, skipped: {} },
    });
    ensureLayer(db, drawingId, 'PLOT-BOUNDARY', 1);
    for (const [l, c] of [['A-WALL', 7], ['A-ROOM', 4], ['A-DOOR', 3], ['A-GLAZ', 5], ['A-DIMS', 8], ['A-ANNO-TEXT', 2], ['A-ANNO-AREA', 9], ['A-ANNO-NOTE', 1], ['A-BLDG-OUTL', 7]] as [string, number][]) ensureLayer(db, drawingId, l, c);

    // Plot first (its layer is locked by default, so it is inserted as a system operation before locking takes effect on edits).
    run(db, 'UPDATE layers SET locked = 0 WHERE drawing_id = ? AND name = ?', drawingId, 'PLOT-BOUNDARY');
    const base: EntityInput[] = [{ type: 'POLYLINE', layer: 'PLOT-BOUNDARY', geom: { points: plot, closed: true } }, ...out.walls, ...out.other];
    const first = applyOperation(db, drawingId, { kind: 'add', entities: base }, req.user.userId, 'ai');
    run(db, 'UPDATE layers SET locked = 1 WHERE drawing_id = ? AND name = ?', drawingId, 'PLOT-BOUNDARY');
    const wallIds = first.changes.slice(1, 1 + out.walls.length).map((c) => c.id);

    const openingInputs: EntityInput[] = out.openings.map((o) => (o.type === 'DOOR'
      ? { type: 'DOOR', layer: 'A-DOOR', geom: { wallId: wallIds[o.wall], offset: o.offset, width: o.width, swing: 'left', side: 1 } }
      : { type: 'WINDOW', layer: 'A-GLAZ', geom: { wallId: wallIds[o.wall], offset: o.offset, width: o.width } }) as EntityInput);
    let placed = 0;
    if (openingInputs.length) {
      try { placed = applyOperation(db, drawingId, { kind: 'add', entities: openingInputs }, req.user.userId, 'ai').changes.length; }
      catch (e) {
        if (!(e instanceof OperationError)) throw e;
        for (const one of openingInputs) {
          try { applyOperation(db, drawingId, { kind: 'add', entities: [one] }, req.user.userId, 'ai'); placed++; }
          catch (x) { if (!(x instanceof OperationError)) throw x; out.report.warnings.push(`An opening was skipped: ${x.errors[0]}`); }
        }
      }
    }

    const d = drawingForOrg(db, drawingId, req.user.orgId)!;
    const qa = runCompliance(db, req.user.orgId, req.user.userId, d);
    audit(db, req.user.orgId, req.user.userId, 'drawing.generated_from_reference', drawingId, { reference: ref.id, counts: out.report.counts, placedOpenings: placed });
    return { drawingId, report: { ...out.report, placedOpenings: placed }, checks: { runId: qa.runId, summary: qa.summary } };
  });
}
