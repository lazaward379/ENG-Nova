import type { Entity, Pt, Units } from '../geometry/types.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { entityLength, entityPoints, pointInPolygon, pointSegmentDistance, polygonArea, ringDistance, segmentsCross, bbox } from '../geometry/math.ts';
import { closedOnLayer, extractRooms, FOOTPRINT_LAYER, PLOT_LAYER, type Room } from '../geometry/rooms.ts';
import type { Diagnostics } from '../dxf/dxf.ts';
import { isOpening, openingWithinWall, openingsOverlap, wallFrame } from '../geometry/hosted.ts';

export const STATUSES = ['PASS', 'FAIL', 'WARNING', 'NOT CHECKED', 'INSUFFICIENT DATA', 'REQUIRES ENGINEER REVIEW', 'SOURCE NOT VERIFIED'] as const;
export type Status = (typeof STATUSES)[number];

export type Fact = { value: string; class: string; source: string; unit: string | null };
export type Ctx = { entities: Entity[]; units: Units; rooms: Room[]; diagnostics: Partial<Diagnostics>; facts: Map<string, Fact> };
export type Result = {
  status: Status;
  message: string;
  inputs?: Record<string, unknown>;
  evidence?: Record<string, unknown>;
  entityIds?: string[];
  location?: Pt | null;
  correctiveAction?: string;
};
export type Evaluator = (ctx: Ctx, params: Record<string, any>) => Result[];

const r3 = (v: number) => Math.round(v * 1000) / 1000;
const centroid = (pts: Pt[]): Pt => ({ x: pts.reduce((s, p) => s + p.x, 0) / pts.length, y: pts.reduce((s, p) => s + p.y, 0) / pts.length });
const locOf = (e: Entity) => centroid(entityPoints(e));

export const evaluators: Record<string, Evaluator> = {
  'qa.units_defined': (ctx) => [ctx.units === 'unitless'
    ? { status: 'FAIL', message: 'Drawing units are not defined.', inputs: { units: ctx.units, source: ctx.diagnostics.unitsSource }, correctiveAction: 'Set drawing units from the authoritative source file (e.g. $INSUNITS) before measuring.' }
    : { status: 'PASS', message: `Drawing units defined: ${ctx.units}.`, inputs: { units: ctx.units, source: ctx.diagnostics.unitsSource ?? 'set in NOVA' } }],

  'qa.degenerate_geometry': (ctx) => {
    const bad = ctx.entities.filter((e) => (e.type === 'LINE' || e.type === 'POLYLINE' || e.type === 'WALL') && entityLength(e) < 1e-9);
    return bad.length
      ? bad.slice(0, 200).map((e) => ({ status: 'FAIL', message: `Zero-length ${e.type} on layer "${e.layer}".`, entityIds: [e.id], location: locOf(e), evidence: { length: 0 }, correctiveAction: 'Delete or redraw the degenerate entity.' }))
      : [{ status: 'PASS', message: 'No zero-length lines or polylines.', evidence: { checked: ctx.entities.length } }];
  },

  'qa.duplicates': (ctx) => {
    const seen = new Map<string, Entity>();
    const out: Result[] = [];
    for (const e of ctx.entities) {
      const key = `${e.type}|${e.layer}|${JSON.stringify(e.geom, (_k, v) => (typeof v === 'number' ? Math.round(v * 1e6) / 1e6 : v))}`;
      const prev = seen.get(key);
      if (prev) out.push({ status: 'WARNING', message: `Duplicate ${e.type} on layer "${e.layer}".`, entityIds: [prev.id, e.id], location: locOf(e), evidence: { tolerance: 1e-6 }, correctiveAction: 'Remove the duplicate entity.' });
      else seen.set(key, e);
    }
    return out.length ? out.slice(0, 200) : [{ status: 'PASS', message: 'No duplicate entities found.', evidence: { checked: ctx.entities.length, tolerance: 1e-6 } }];
  },

  'qa.room_closure': (ctx) => {
    if (!ctx.rooms.length) return [{ status: 'NOT CHECKED', message: 'No room boundaries found (closed polylines on ROOM / SPACE / A-AREA layers).', correctiveAction: 'Draw room boundaries on a room layer.' }];
    return ctx.rooms.map((r) => r.valid
      ? { status: 'PASS', message: `Room ${r.name ?? '(unnamed)'} boundary is closed and simple.`, entityIds: [r.entityId], location: centroid(r.points), evidence: { vertices: r.points.length } }
      : { status: 'FAIL', message: `Room ${r.name ?? '(unnamed)'}: ${r.problems.join(', ')}.`, entityIds: [r.entityId], location: centroid(r.points), evidence: { problems: r.problems }, correctiveAction: 'Close the boundary and remove self-intersections.' });
  },

  'qa.room_labels': (ctx) => {
    const rooms = ctx.rooms.filter((r) => r.valid);
    if (!rooms.length) return [{ status: 'NOT CHECKED', message: 'No valid room boundaries to check for labels.' }];
    return rooms.map((r) => r.labelIds.length === 1
      ? { status: 'PASS', message: `Room labelled "${r.name}".`, entityIds: [r.entityId, ...r.labelIds], location: centroid(r.points) }
      : { status: 'WARNING', message: r.labelIds.length ? `Room has ${r.labelIds.length} labels; expected one.` : 'Room has no label.', entityIds: [r.entityId, ...r.labelIds], location: centroid(r.points), correctiveAction: 'Place exactly one room name inside the boundary.' });
  },

  'qa.room_overlap': (ctx) => {
    const rooms = ctx.rooms.filter((r) => r.valid);
    if (rooms.length < 2) return [{ status: rooms.length ? 'PASS' : 'NOT CHECKED', message: rooms.length ? 'Only one room; no overlap possible.' : 'No valid rooms.' }];
    const out: Result[] = [];
    for (let i = 0; i < rooms.length; i++) for (let j = i + 1; j < rooms.length; j++) {
      const a = rooms[i].points, b = rooms[j].points;
      // Rooms sharing a wall line touch but do not overlap, so boundary points don't count as inside.
      const strictlyIn = (p: Pt, poly: Pt[]) => pointInPolygon(p, poly) && poly.every((q, k) => pointSegmentDistance(p, q, poly[(k + 1) % poly.length]) > 1e-6);
      let hit = [...a, centroid(a)].some((p) => strictlyIn(p, b)) || [...b, centroid(b)].some((p) => strictlyIn(p, a));
      for (let k = 0; !hit && k < a.length; k++) for (let m = 0; !hit && m < b.length; m++)
        hit = segmentsCross(a[k], a[(k + 1) % a.length], b[m], b[(m + 1) % b.length]);
      if (hit) out.push({ status: 'FAIL', message: `Rooms "${rooms[i].name ?? '?'}" and "${rooms[j].name ?? '?'}" overlap.`, entityIds: [rooms[i].entityId, rooms[j].entityId], location: centroid(a), correctiveAction: 'Adjust boundaries so rooms do not overlap.' });
    }
    return out.length ? out : [{ status: 'PASS', message: `No overlaps among ${rooms.length} rooms.`, evidence: { pairsChecked: (rooms.length * (rooms.length - 1)) / 2 } }];
  },

  'qa.layer_zero': (ctx) => {
    const onZero = ctx.entities.filter((e) => e.layer === '0');
    return [onZero.length
      ? { status: 'WARNING', message: `${onZero.length} entit(ies) on layer "0".`, entityIds: onZero.slice(0, 500).map((e) => e.id), location: locOf(onZero[0]), correctiveAction: 'Move entities to discipline layers.' }
      : { status: 'PASS', message: 'No entities on layer "0".' }];
  },

  'qa.unsupported_entities': (ctx) => {
    const skipped = ctx.diagnostics.skipped ?? {};
    const total = Object.values(skipped).reduce((a, b) => a + b, 0);
    return [total
      ? { status: 'WARNING', message: `${total} source entit(ies) were not imported; checks did not cover them.`, evidence: { skipped } , correctiveAction: 'Review the original file for blocks, hatches and dimensions not yet supported.' }
      : { status: 'PASS', message: 'All source entities were imported.', evidence: { imported: ctx.diagnostics.imported ?? {} } }];
  },

  'qa.openings': (ctx) => {
    const walls = new Map(ctx.entities.filter((e) => e.type === 'WALL').map((w) => [w.id, w]));
    const openings = ctx.entities.filter(isOpening);
    if (!openings.length) return [{ status: 'NOT CHECKED', message: walls.size ? 'Walls present but no typed doors or windows.' : 'No typed walls, doors or windows in this drawing.' }];
    const out: Result[] = [];
    for (const o of openings) {
      const g: any = o.geom;
      const wall = walls.get(g.wallId);
      const label = `${o.type === 'DOOR' ? 'Door' : 'Window'} ${o.id.slice(0, 8)}`;
      const loc = g.p ?? null;
      if (!wall) { out.push({ status: 'FAIL', message: `${label} has no host wall.`, entityIds: [o.id], location: loc, correctiveAction: 'Re-host the opening in a wall or delete it.' }); continue; }
      const { len } = wallFrame((wall as any).geom);
      const evidence = { offset: g.offset, width: g.width, wall_length: Math.round(len * 1e6) / 1e6, clear_start: Math.round((g.offset - g.width / 2) * 1e6) / 1e6, clear_end: Math.round((len - g.offset - g.width / 2) * 1e6) / 1e6 };
      if (!openingWithinWall(o as any, wall as any)) { out.push({ status: 'FAIL', message: `${label} extends beyond its wall.`, entityIds: [o.id, wall.id], location: loc, evidence, correctiveAction: 'Move the opening along the wall or reduce its width.' }); continue; }
      const clash = openings.find((x) => x.id !== o.id && (x.geom as any).wallId === g.wallId && openingsOverlap(o as any, x as any));
      if (clash) { out.push({ status: 'FAIL', message: `${label} overlaps another opening on the same wall.`, entityIds: [o.id, clash.id], location: loc, evidence, correctiveAction: 'Separate the openings.' }); continue; }
      out.push({ status: 'PASS', message: `${label} is inside its wall with no overlapping opening.`, entityIds: [o.id], location: loc, evidence });
    }
    return out;
  },

  /** Template: each room whose name matches a pattern has at least a minimum area. */
  'reg.room_min_area': (ctx, p) => {
    if (metresPerUnit(ctx.units) === null) return [{ status: 'INSUFFICIENT DATA', message: 'Drawing units unknown; areas cannot be measured.' }];
    const pattern = p.room_name_pattern ? new RegExp(p.room_name_pattern, 'i') : null;
    const rooms = ctx.rooms.filter((r) => r.valid && r.name && (!pattern || pattern.test(r.name)));
    if (!rooms.length) return [{ status: 'INSUFFICIENT DATA', message: `No valid labelled rooms match ${pattern ? `/${p.room_name_pattern}/` : 'the rule'}.`, inputs: { pattern: p.room_name_pattern ?? null } }];
    return rooms.map((r) => {
      const area = r3(r.areaM2!);
      const base = { entityIds: [r.entityId], location: centroid(r.points), inputs: { room: r.name, area_m2: area, min_area_m2: p.min_area_m2 ?? null, units: ctx.units }, evidence: { method: 'shoelace polygon area', vertices: r.points.length } };
      if (typeof p.min_area_m2 !== 'number') return { ...base, status: 'INSUFFICIENT DATA' as Status, message: `Room "${r.name}" measures ${area} m²; no threshold configured.` };
      return area >= p.min_area_m2
        ? { ...base, status: 'PASS' as Status, message: `Room "${r.name}" ${area} m² ≥ ${p.min_area_m2} m².` }
        : { ...base, status: 'FAIL' as Status, message: `Room "${r.name}" ${area} m² < ${p.min_area_m2} m².`, correctiveAction: `Increase the room area by at least ${r3(p.min_area_m2 - area)} m².` };
    });
  },

  /** Template: building footprint area ÷ plot area ≤ maximum coverage. */
  'reg.plot_coverage': (ctx, p) => {
    const plots = closedOnLayer(ctx.entities, PLOT_LAYER);
    const fps = closedOnLayer(ctx.entities, FOOTPRINT_LAYER);
    const fact = ctx.facts.get('max_plot_coverage_pct');
    const max = typeof p.max_coverage_pct === 'number' ? p.max_coverage_pct : fact?.class === 'confirmed' ? Number(fact.value) : null;
    const inputs = { plot_boundaries: plots.length, footprints: fps.length, max_coverage_pct: max, max_source: typeof p.max_coverage_pct === 'number' ? 'rule parameter' : fact ? `project fact (${fact.class}): ${fact.source}` : null };
    if (plots.length !== 1) return [{ status: 'INSUFFICIENT DATA', message: plots.length ? 'More than one plot boundary found.' : 'No closed plot boundary found (PLOT / BOUNDARY layer).', inputs }];
    if (!fps.length) return [{ status: 'INSUFFICIENT DATA', message: 'No closed building footprint found (FOOTPRINT / A-BLDG-OUTL layer).', inputs }];
    const plotArea = polygonArea(plots[0].geom.points);
    const fpArea = fps.reduce((s, f) => s + polygonArea(f.geom.points), 0);
    const pct = r3((fpArea / plotArea) * 100);
    const evidence = { plot_area_units2: r3(plotArea), footprint_area_units2: r3(fpArea), coverage_pct: pct, method: 'Σ footprint polygon areas ÷ plot polygon area (units cancel)' };
    const ids = [plots[0].id, ...fps.map((f) => f.id)];
    const loc = centroid(fps[0].geom.points);
    if (max === null || Number.isNaN(max)) return [{ status: 'INSUFFICIENT DATA', message: `Coverage measured at ${pct}%; no confirmed maximum coverage available.`, inputs, evidence, entityIds: ids, location: loc, correctiveAction: 'Record the maximum coverage from the plot’s official planning document as a confirmed project fact.' }];
    return [pct <= max
      ? { status: 'PASS', message: `Plot coverage ${pct}% ≤ ${max}%.`, inputs, evidence, entityIds: ids, location: loc }
      : { status: 'FAIL', message: `Plot coverage ${pct}% > ${max}%.`, inputs, evidence, entityIds: ids, location: loc, correctiveAction: 'Reduce the building footprint.' }];
  },

  /** Template: every footprint lies inside the plot with at least a uniform setback. */
  'reg.setback_uniform': (ctx, p) => {
    const mpu = metresPerUnit(ctx.units);
    if (mpu === null) return [{ status: 'INSUFFICIENT DATA', message: 'Drawing units unknown; distances cannot be measured.' }];
    const plots = closedOnLayer(ctx.entities, PLOT_LAYER);
    const fps = closedOnLayer(ctx.entities, FOOTPRINT_LAYER);
    if (plots.length !== 1 || !fps.length) return [{ status: 'INSUFFICIENT DATA', message: 'Need exactly one closed plot boundary and at least one closed footprint.', inputs: { plot_boundaries: plots.length, footprints: fps.length } }];
    const plot = plots[0].geom.points;
    return fps.map((f) => {
      const inside = f.geom.points.every((q) => pointInPolygon(q, plot));
      const { d, at } = ringDistance(f.geom.points, plot);
      const dm = r3(d * mpu);
      const base = { entityIds: [f.id, plots[0].id], location: at, inputs: { min_setback_m: p.min_setback_m ?? null, units: ctx.units }, evidence: { footprint_inside_plot: inside, min_distance_m: dm, method: 'minimum segment-to-segment distance between footprint and plot boundary' } };
      if (!inside) return { ...base, status: 'FAIL' as Status, message: 'Footprint is not fully inside the plot boundary.', correctiveAction: 'Move the footprint inside the plot.' };
      if (typeof p.min_setback_m !== 'number') return { ...base, status: 'INSUFFICIENT DATA' as Status, message: `Minimum distance to boundary ${dm} m; no setback configured.` };
      return dm >= p.min_setback_m
        ? { ...base, status: 'PASS' as Status, message: `Minimum distance to plot boundary ${dm} m ≥ ${p.min_setback_m} m (uniform setback interpretation).` }
        : { ...base, status: 'FAIL' as Status, message: `Minimum distance to plot boundary ${dm} m < ${p.min_setback_m} m.`, correctiveAction: `Increase the setback by ${r3(p.min_setback_m - dm)} m.` };
    });
  },
};

export function buildContext(entities: Entity[], units: Units, diagnostics: Partial<Diagnostics>, facts: Map<string, Fact>): Ctx {
  return { entities, units, rooms: extractRooms(entities, units), diagnostics, facts };
}

export const drawingExtents = (entities: Entity[]) => bbox(entities);
