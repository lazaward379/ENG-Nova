import { useEffect } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, useApp, useLoad } from '../ui';

const GUIDE: Record<string, [string, string]> = {
  brief: ['Write what the client wants, then confirm floors, rooms and target area as facts.', 'اكتب ما يريده العميل، ثم أكّد عدد الأدوار والغرف والمساحة المستهدفة كبيانات مؤكدة.'],
  plot: ['Upload the site plan / affection plan and survey, and record plot number, area, setbacks and coverage from the official document.', 'ارفع مخطط الأرض والمسح، وسجّل رقم القطعة ومساحتها والارتدادات ونسبة التغطية من الوثيقة الرسمية.'],
  plan: ['Generate the ground-floor plan from a reference project, or draw walls, doors and windows in the CAD workspace.', 'ولّد مسقط الدور الأرضي من مشروع مرجعي، أو ارسم الجدران والأبواب والنوافذ في مساحة CAD.'],
  checks: ['Run the checks, fix failing items, and review the readiness report.', 'شغّل الفحوصات وعالج البنود الراسبة وراجع تقرير الجاهزية.'],
  sheets: ['Produce the AutoCAD plan sheet and the elevations + section sheet (DWG + PDF).', 'أنشئ لوحة المسقط ولوحة الواجهات والمقطع في AutoCAD (DWG + PDF).'],
  submission: ['Create the Binaa package, attach the official checklist items, submit on TAMM/Binaa yourself and record the application number.', 'أنشئ حزمة بناء وأرفق بنود القائمة الرسمية، قدّم بنفسك عبر تم/بناء وسجّل رقم الطلب.'],
  shop: ['Shop drawings need the approved design plus verified structural and MEP inputs. Start from the plan sheet DWG in AutoCAD.', 'المخططات التنفيذية تحتاج التصميم المعتمد وبيانات إنشائية وكهروميكانيكية موثقة. ابدأ من لوحة المسقط DWG في AutoCAD.'],
};

const STATUS: Record<string, [string, string, string]> = {
  done: ['Done', 'منجز', 'c-confirmed'], partial: ['In progress', 'قيد العمل', 'c-assumption'], todo: ['Not started', 'لم يبدأ', ''], unavailable: ['Needs engineering input', 'يحتاج مدخلات هندسية', 'c-ai_suggestion'],
};

export function DesignHub({ projectId }: { projectId?: string }) {
  const { project, setProject, go, can } = useApp();
  const { lang } = useT();
  const ar = lang === 'ar';
  const pid = projectId ?? project;
  useEffect(() => { if (projectId) setProject(projectId); }, [projectId]);
  const projects = useLoad(() => api.get('/api/projects'), []);
  const j = useLoad(() => (pid ? api.get(`/api/projects/${pid}/journey`) : Promise.resolve(null)), [pid]);
  const done = j.data ? j.data.steps.filter((s: any) => s.status === 'done').length : 0;

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="section-hero hub-design">
        <div><div className="eyebrow">{ar ? 'القسم الأول' : 'Section 1'}</div><h1>{ar ? 'التصميم' : 'Design'}</h1>
          <p className="muted" style={{ margin: 0 }}>{ar ? 'كل ما يخص التصميم من الصفر حتى تجهيز المخططات وتقديمها للبلدية، ثم المخططات التنفيذية.' : 'Everything from a blank page to municipality-ready drawings, submission and shop drawings.'}</p></div>
        <span className="spacer" />
        <div className="row">
          <select value={pid ?? ''} onChange={(e) => go(e.target.value ? `design/${e.target.value}` : 'design')} style={{ minWidth: 240 }} aria-label="project">
            <option value="">{ar ? '— اختر مشروعاً —' : '— choose a project —'}</option>
            {projects.data?.map((p: any) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
          </select>
          {can('engineer') && <button className="btn primary" onClick={() => go('projects/new')}><Icon name="plus" />{ar ? 'مشروع جديد' : 'New project'}</button>}
        </div>
      </div>

      {!pid ? (
        <div className="grid c3">
          {[['plus', ar ? 'ابدأ مشروعاً جديداً' : 'Start a new project', ar ? 'صف المشروع وارفع وثائق القطعة.' : 'Describe it and upload the plot documents.', 'projects/new'],
            ['assistant', ar ? 'ارسم من مشروع مرجعي' : 'Draw from a reference', ar ? 'استخدم مخطط مشروع سابق كنقطة بداية.' : 'Use an earlier project as the starting point.', 'generate'],
            ['projects', ar ? 'تابع مشروعاً قائماً' : 'Continue a project', ar ? 'اختر المشروع من القائمة أعلاه.' : 'Pick it from the list above.', 'projects']].map(([i, t, d, r]) => (
            <button key={r} className="card action-card" onClick={() => go(r)}><Icon name={i} size={26} /><b>{t}</b><span className="muted">{d}</span></button>
          ))}
        </div>
      ) : !j.data ? <Loading error={j.error} loading={j.loading} /> : (
        <>
          <div className="card row" style={{ gap: 16 }}>
            <div className="progress-ring" style={{ ['--p' as any]: `${(done / j.data.steps.length) * 100}%` }}><span className="ltr">{done}/{j.data.steps.length}</span></div>
            <div style={{ flex: 1 }}>
              <h2 dir="auto">{j.data.project.code} — {j.data.project.name}</h2>
              <div className="muted">{ar ? 'المراحل المنجزة' : 'Stages completed'}{j.data.openComments ? (ar ? ` · ${j.data.openComments} ملاحظات مفتوحة` : ` · ${j.data.openComments} open comments`) : ''}</div>
            </div>
            <button className="btn" onClick={() => go(`project/${pid}/readiness`)}><Icon name="compliance" />{ar ? 'تقرير الجاهزية' : 'Readiness report'}</button>
          </div>
          <ol className="journey">
            {j.data.steps.map((s: any, i: number) => (
              <li key={s.key} className={`journey-step st-${s.status}`}>
                <div className="journey-dot">{s.status === 'done' ? <Icon name="check" size={16} /> : i + 1}</div>
                <div className="card journey-card">
                  <div className="row"><b>{ar ? s.ar : s.en}</b><span className={`chip ${STATUS[s.status][2]}`}>{ar ? STATUS[s.status][1] : STATUS[s.status][0]}</span><span className="spacer" />
                    <button className={`btn sm ${s.status === 'done' ? '' : 'primary'}`} onClick={() => go(s.route)}>{ar ? 'افتح' : 'Open'}</button></div>
                  <div className="muted" dir="auto">{ar ? s.detail_ar : s.detail_en}</div>
                  <div className="faint" dir="auto">{ar ? GUIDE[s.key][1] : GUIDE[s.key][0]}</div>
                </div>
              </li>
            ))}
          </ol>
        </>
      )}
    </div>
  );
}
