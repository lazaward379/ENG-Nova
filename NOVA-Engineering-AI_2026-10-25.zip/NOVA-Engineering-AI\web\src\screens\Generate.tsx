import { useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, ProjectDrawingPicker, useApp, useLoad } from '../ui';

/** Generate a preliminary plan for the current project from a reference drawing. */
export function GenerateFromReference() {
  const { project, go, toast, can, setDrawing } = useApp();
  const { lang } = useT();
  const ar = lang === 'ar';
  const drawings = useLoad(() => api.get('/api/drawings'), []);
  const [f, setF] = useState({
    ref: '', plotMode: 'dims' as 'dims' | 'drawing', plotDrawing: '', width: '', depth: '', plotSource: '', setback: '', setbackSource: '',
    mode: 'proportional', rotate: 'auto', ext: '200', int: '100', door: '900', win: '1200', name: '',
  });
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<any | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  const refs = (drawings.data ?? []).filter((d: any) => d.room_boundaries > 0);
  const plots = (drawings.data ?? []).filter((d: any) => d.project_id === project && d.plot_boundaries > 0);
  const ready = project && f.ref && +f.setback >= 0 && f.setback !== '' && f.setbackSource.trim().length >= 3 &&
    (f.plotMode === 'drawing' ? !!f.plotDrawing : +f.width > 0 && +f.depth > 0 && f.plotSource.trim().length >= 3);

  const run = async () => {
    setBusy(true); setErr(null); setRes(null);
    try {
      const r = await api.post(`/api/projects/${project}/generate-from-reference`, {
        referenceDrawingId: f.ref,
        plot: f.plotMode === 'drawing' ? { drawingId: f.plotDrawing } : { width_m: +f.width, depth_m: +f.depth, source: f.plotSource },
        setback_m: +f.setback, setback_source: f.setbackSource, mode: f.mode, rotate: f.rotate,
        external_wall_mm: +f.ext, internal_wall_mm: +f.int, door_width_mm: +f.door, window_width_mm: +f.win, name: f.name || undefined,
      });
      setRes(r); setDrawing(r.drawingId); toast(ar ? 'تم توليد المخطط الأولي' : 'Preliminary plan generated', 'ok');
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <div className="stack" style={{ maxWidth: 1100 }}>
      <div className="page-h">
        <div><div className="eyebrow">{ar ? 'توليد آلي' : 'Automatic drafting'}</div>
          <h1>{ar ? 'رسم مشروع جديد من مشروع مرجعي' : 'Draw a new project from a reference project'}</h1>
          <div className="sub">{ar ? 'يتعلّم NOVA برنامج الغرف وتوزيعها وأبوابها من رسم سابق، ثم يرسم مخططاً كاملاً قابلاً للتعديل على قطعة المشروع الجديد.' : 'NOVA learns the room programme, layout and doors from an earlier drawing, then draws a complete, editable plan on the new project’s plot.'}</div></div>
        <span className="spacer" /><ProjectDrawingPicker needDrawing={false} />
      </div>
      <div className="notice violet">{ar
        ? 'المخرج مخطط أولي (غرف، جدران، أبواب، نوافذ، تسميات، مساحات، أبعاد رئيسية). ليس رسومات تنفيذية ولا يتحقق من الاشتراطات. كل الافتراضات تُذكر في التقرير ويجب أن يراجعها مهندس.'
        : 'The output is a preliminary plan (rooms, walls, doors, windows, labels, areas, overall dimensions). It is not a construction drawing and does not check regulations. Every assumption is listed in the report for an engineer to review.'}</div>
      {!project ? <div className="card empty">{ar ? 'اختر المشروع الجديد أولاً.' : 'Select the new project first.'}</div> : (
        <div className="grid c2">
          <div className="card stack">
            <h2>1. {ar ? 'المشروع المرجعي' : 'Reference project'}</h2>
            {drawings.data ? (refs.length ? (
              <select value={f.ref} onChange={set('ref')}>
                <option value="">{ar ? '— اختر رسماً مرجعياً —' : '— choose a reference drawing —'}</option>
                {refs.map((d: any) => <option key={d.id} value={d.id}>{d.project_code} · {d.name} ({d.room_boundaries} {ar ? 'غرف' : 'rooms'}, {d.units})</option>)}
              </select>) : <div className="notice">{ar ? 'لا يوجد رسم يحتوي حدود غرف. ارفع ملف DXF لمشروع سابق تكون فيه الغرف مضلعات مغلقة على طبقة ROOM مع أسمائها.' : 'No drawing has room boundaries yet. Upload a DXF of an earlier project with rooms as closed polylines on a ROOM layer, named by text inside.'}</div>)
              : <Loading error={drawings.error} loading={drawings.loading} />}

            <h2>2. {ar ? 'قطعة المشروع الجديد' : 'New project plot'}</h2>
            <div className="row">
              <label className="row"><input type="radio" style={{ width: 'auto' }} checked={f.plotMode === 'dims'} onChange={() => setF({ ...f, plotMode: 'dims' })} />{ar ? 'أبعاد القطعة' : 'Plot dimensions'}</label>
              <label className="row"><input type="radio" style={{ width: 'auto' }} checked={f.plotMode === 'drawing'} onChange={() => setF({ ...f, plotMode: 'drawing' })} disabled={!plots.length} />{ar ? 'حدود من رسم' : 'Boundary from a drawing'}</label>
            </div>
            {f.plotMode === 'dims' ? <>
              <div className="grid c2" style={{ gap: 8 }}>
                <label className="field">{ar ? 'العرض (م)' : 'Width (m)'}<input className="mono" value={f.width} onChange={set('width')} /></label>
                <label className="field">{ar ? 'العمق (م)' : 'Depth (m)'}<input className="mono" value={f.depth} onChange={set('depth')} /></label>
              </div>
              <label className="field">{ar ? 'مصدر الأبعاد' : 'Source of dimensions'}<input value={f.plotSource} onChange={set('plotSource')} placeholder={ar ? 'مثال: مخطط الأرض رقم ...' : 'e.g. site plan no. …'} /></label>
            </> : (
              <select value={f.plotDrawing} onChange={set('plotDrawing')}>
                <option value="">—</option>{plots.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            )}
            <div className="grid c2" style={{ gap: 8 }}>
              <label className="field">{ar ? 'الارتداد (م، موحّد)' : 'Setback (m, uniform)'}<input className="mono" value={f.setback} onChange={set('setback')} /></label>
              <label className="field">{ar ? 'مصدر الارتداد' : 'Setback source'}<input value={f.setbackSource} onChange={set('setbackSource')} placeholder={ar ? 'مثال: اشتراطات القطعة' : 'e.g. plot affection plan'} /></label>
            </div>
          </div>

          <div className="card stack">
            <h2>3. {ar ? 'خيارات الرسم' : 'Drawing options'}</h2>
            <div className="grid c2" style={{ gap: 8 }}>
              <label className="field">{ar ? 'التحجيم' : 'Scaling'}<select value={f.mode} onChange={set('mode')}><option value="proportional">{ar ? 'متناسب (يحافظ على الأشكال)' : 'Proportional (keeps shapes)'}</option><option value="fill">{ar ? 'ملء المساحة المتاحة' : 'Fill buildable area'}</option></select></label>
              <label className="field">{ar ? 'التدوير' : 'Rotation'}<select value={f.rotate} onChange={set('rotate')}><option value="auto">{ar ? 'تلقائي حسب شكل القطعة' : 'Auto (match plot shape)'}</option><option value="none">{ar ? 'بدون' : 'None'}</option><option value="90">90°</option></select></label>
              <label className="field">{ar ? 'جدار خارجي (مم)' : 'External wall (mm)'}<input className="mono" value={f.ext} onChange={set('ext')} /></label>
              <label className="field">{ar ? 'جدار داخلي (مم)' : 'Internal wall (mm)'}<input className="mono" value={f.int} onChange={set('int')} /></label>
              <label className="field">{ar ? 'عرض الباب (مم)' : 'Door width (mm)'}<input className="mono" value={f.door} onChange={set('door')} /></label>
              <label className="field">{ar ? 'عرض النافذة (مم)' : 'Window width (mm)'}<input className="mono" value={f.win} onChange={set('win')} /></label>
            </div>
            <label className="field">{ar ? 'اسم الرسم (اختياري)' : 'Drawing name (optional)'}<input value={f.name} onChange={set('name')} /></label>
            {err && <div className="notice">{err}</div>}
            <button className="btn primary" disabled={!ready || busy || !can('engineer')} onClick={run}><Icon name="assistant" />{busy ? '…' : ar ? 'ارسم المخطط' : 'Draw the plan'}</button>
          </div>
        </div>
      )}

      {res && (
        <div className="card glow stack">
          <div className="row"><h2>{ar ? 'نتيجة التوليد' : 'Generation result'}</h2><span className="chip c-ai_suggestion">PRELIMINARY</span><span className="spacer" />
            <button className="btn primary" onClick={() => go(`workspace/${res.drawingId}`)}><Icon name="workspace" />{ar ? 'فتح في مساحة CAD' : 'Open in CAD workspace'}</button></div>
          <div className="grid c4">
            {[[ar ? 'غرف' : 'Rooms', res.report.counts.rooms], [ar ? 'جدران' : 'Walls', res.report.counts.walls], [ar ? 'أبواب' : 'Doors', res.report.counts.doors], [ar ? 'نوافذ' : 'Windows', res.report.counts.windows],
              [ar ? 'مساحة القطعة' : 'Plot area', `${res.report.plotAreaM2} m²`], [ar ? 'مساحة المبنى' : 'Footprint', `${res.report.footprintAreaM2} m²`], [ar ? 'نسبة التغطية' : 'Coverage', `${res.report.coveragePct}%`],
              [ar ? 'معامل التحجيم' : 'Scale', `${res.report.transform.scaleX} × ${res.report.transform.scaleY}${res.report.transform.rotated90 ? ' · 90°' : ''}`]].map(([l, v]) => (
              <div key={l as string} className="card stat" style={{ padding: 10 }}><div className="l">{l}</div><div className="v" style={{ fontSize: 18 }}>{v}</div></div>
            ))}
          </div>
          <table className="t"><thead><tr><th>{ar ? 'الغرفة' : 'Room'}</th><th>{ar ? 'المرجع' : 'Reference'}</th><th>{ar ? 'الجديد' : 'New'}</th></tr></thead>
            <tbody>{res.report.rooms.map((r: any) => <tr key={r.name}><td dir="auto">{r.name}</td><td className="mono">{r.refAreaM2.toFixed(2)} m²</td><td className="mono">{r.areaM2.toFixed(2)} m²</td></tr>)}</tbody></table>
          <div><h3>{ar ? 'الافتراضات' : 'Assumptions'}</h3><ul style={{ margin: 0, paddingInlineStart: 18 }}>{res.report.assumptions.map((a: string) => <li key={a} className="muted">{a}</li>)}</ul></div>
          {res.report.warnings.length > 0 && <div><h3>{ar ? 'تنبيهات' : 'Warnings'}</h3>{res.report.warnings.map((w: string) => <div key={w} className="notice" style={{ marginTop: 4 }}>{w}</div>)}</div>}
          <div className="faint">{ar ? 'نتائج الفحص التلقائي:' : 'Automatic checks:'} {Object.entries(res.checks.summary).map(([k, v]) => `${k} ${v}`).join(' · ')}</div>
        </div>
      )}
    </div>
  );
}
