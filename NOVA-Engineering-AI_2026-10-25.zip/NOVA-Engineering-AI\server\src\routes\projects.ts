import type { FastifyInstance, FastifyRequest } from 'fastify';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { all, audit, get, now, run, tx } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { ALLOWED, extOf, safeDisplayName, scanHook } from '../storage.ts';
import { importDxf } from '../dxf/dxf.ts';
import { createDrawing, ensureLayer, insertEntity, newEntity, type DrawingRow } from '../drawings.ts';
import { polygonArea } from '../geometry/math.ts';
import type { Pt } from '../geometry/types.ts';
import { evaluateRules } from '../rules/engine.ts';
import { suggestRequirements } from '../copilot/requirements.ts';
import { dwgToDxf, findAutoCAD } from '../integrations/autocad.ts';

export function projectForOrg(deps: Deps, projectId: string, orgId: string) {
  const p = get<any>(deps.db, 'SELECT * FROM projects WHERE id = ? AND org_id = ?', projectId, orgId);
  if (!p) throw new HttpError(404, 'project not found');
  return p;
}

/** Inputs NOVA needs before plot-level checks or a design proposal can be trusted. */
export const CRITICAL_INPUTS: { key: string; label: string; label_ar: string }[] = [
  { key: 'plot_id', label: 'Plot identifier', label_ar: 'رقم قطعة الأرض' },
  { key: 'plot_area_m2', label: 'Plot area (official)', label_ar: 'مساحة القطعة (رسمية)' },
  { key: 'crs', label: 'Coordinate reference system', label_ar: 'نظام الإحداثيات المرجعي' },
  { key: 'north_direction', label: 'North direction', label_ar: 'اتجاه الشمال' },
  { key: 'road_frontage', label: 'Road frontage / access', label_ar: 'الواجهة على الطريق / المداخل' },
  { key: 'floors', label: 'Number of floors', label_ar: 'عدد الطوابق' },
  { key: 'max_plot_coverage_pct', label: 'Maximum plot coverage (from official planning document)', label_ar: 'الحد الأقصى لنسبة التغطية (من وثيقة التخطيط الرسمية)' },
  { key: 'setbacks', label: 'Setback requirements (from official planning document)', label_ar: 'متطلبات الارتدادات (من وثيقة التخطيط الرسمية)' },
  { key: 'target_authority', label: 'Target authority / review workflow', label_ar: 'الجهة المستهدفة / مسار المراجعة' },
];

function parseCsvCoordinates(text: string): { points: Pt[]; columns: string[]; skipped: number } | null {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return null;
  const header = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const xi = header.findIndex((h) => h === 'x' || h === 'easting' || h === 'e');
  const yi = header.findIndex((h) => h === 'y' || h === 'northing' || h === 'n');
  if (xi < 0 || yi < 0) return null;
  const points: Pt[] = [];
  let skipped = 0;
  for (const l of lines.slice(1, 100_001)) {
    const c = l.split(',');
    const x = Number(c[xi]), y = Number(c[yi]);
    if (Number.isFinite(x) && Number.isFinite(y)) points.push({ x, y }); else skipped++;
  }
  return { points, columns: [header[xi], header[yi]], skipped };
}

function job<T>(deps: Deps, orgId: string, kind: string, fn: () => T): T {
  const id = randomUUID();
  run(deps.db, "INSERT INTO background_jobs (id, org_id, kind, status, started_at, created_at) VALUES (?,?,?,'running',?,?)", id, orgId, kind, now(), now());
  try {
    const out = fn();
    run(deps.db, "UPDATE background_jobs SET status = 'succeeded', finished_at = ? WHERE id = ?", now(), id);
    return out;
  } catch (e: any) {
    run(deps.db, "UPDATE background_jobs SET status = 'failed', detail = ?, finished_at = ? WHERE id = ?", String(e?.message ?? e).slice(0, 500), now(), id);
    throw e;
  }
}

export function projectRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;

  app.get('/api/dashboard', async (req) => {
    const org = req.user.orgId;
    const one = (sql: string) => (get<any>(db, sql, org)?.n as number) ?? 0;
    return {
      projects: one('SELECT COUNT(*) AS n FROM projects WHERE org_id = ?'),
      documents: one('SELECT COUNT(*) AS n FROM documents WHERE org_id = ?'),
      drawings: one('SELECT COUNT(*) AS n FROM drawings d JOIN projects p ON p.id = d.project_id WHERE p.org_id = ?'),
      operations: one('SELECT COUNT(*) AS n FROM geometry_operations o JOIN drawings d ON d.id = o.drawing_id JOIN projects p ON p.id = d.project_id WHERE p.org_id = ?'),
      recentProjects: all(db, 'SELECT id, code, name, status, updated_at FROM projects WHERE org_id = ? ORDER BY updated_at DESC LIMIT 6', org),
      recentRuns: all(db, `SELECT r.id, r.summary, r.created_at, d.name AS drawing, d.id AS drawing_id, p.code AS project FROM compliance_runs r
                           JOIN drawings d ON d.id = r.drawing_id JOIN projects p ON p.id = r.project_id WHERE p.org_id = ? ORDER BY r.created_at DESC LIMIT 6`, org)
        .map((r) => ({ ...r, summary: JSON.parse(r.summary) })),
      recentActivity: all(db, `SELECT a.action, a.target, a.created_at, u.name AS user FROM audit_events a LEFT JOIN users u ON u.id = a.user_id
                               WHERE a.org_id = ? ORDER BY a.id DESC LIMIT 10`, org),
    };
  });

  app.get('/api/projects', async (req) => {
    const q = (req.query as any)?.q ? `%${String((req.query as any).q).slice(0, 100)}%` : '%';
    return all(db, `SELECT p.*, (SELECT COUNT(*) FROM documents d WHERE d.project_id = p.id) AS documents,
                           (SELECT COUNT(*) FROM drawings d WHERE d.project_id = p.id) AS drawings
                    FROM projects p WHERE p.org_id = ? AND (p.name LIKE ? OR p.code LIKE ? OR p.description LIKE ?) ORDER BY p.updated_at DESC`, req.user.orgId, q, q, q);
  });

  const NewProject = z.object({
    code: z.string().trim().min(1).max(40).regex(/^[A-Za-z0-9._-]+$/, 'use letters, digits, . _ -'),
    name: z.string().trim().min(1).max(200),
    description: z.string().max(5000).default(''),
    project_type: z.string().max(100).default(''),
  });
  app.post('/api/projects', async (req) => {
    requireRole(req, 'engineer');
    const b = NewProject.parse(req.body);
    if (get(db, 'SELECT 1 FROM projects WHERE org_id = ? AND code = ?', req.user.orgId, b.code)) throw new HttpError(409, 'project code already used');
    const id = randomUUID();
    run(db, 'INSERT INTO projects (id, org_id, code, name, description, project_type, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
      id, req.user.orgId, b.code, b.name, b.description, b.project_type, req.user.userId, now(), now());
    audit(db, req.user.orgId, req.user.userId, 'project.created', id, { code: b.code });
    return { id };
  });

  app.get('/api/projects/:id', async (req) => {
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    return {
      ...p,
      facts: all(db, `SELECT f.*, d.original_name AS source_document FROM project_facts f LEFT JOIN documents d ON d.id = f.source_document_id WHERE f.project_id = ? ORDER BY f.key`, p.id),
      documents: all(db, 'SELECT id, original_name, ext, mime, size_bytes, sha256, origin, derived_from, classification, extraction_status, extraction_notes, created_at FROM documents WHERE project_id = ? ORDER BY created_at DESC', p.id)
        .map((d) => ({ ...d, extraction_notes: JSON.parse(d.extraction_notes) })),
      drawings: all(db, `SELECT d.id, d.name, d.units, d.created_at, d.updated_at, (SELECT COUNT(*) FROM entities e WHERE e.drawing_id = d.id) AS entities FROM drawings d WHERE d.project_id = ? ORDER BY d.created_at DESC`, p.id),
      criticalInputs: CRITICAL_INPUTS,
    };
  });

  const PatchProject = NewProject.partial().extend({ status: z.enum(['intake', 'design', 'review', 'archived']).optional() });
  app.patch('/api/projects/:id', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const b = PatchProject.parse(req.body);
    const merged = { ...p, ...b };
    run(db, 'UPDATE projects SET code = ?, name = ?, description = ?, project_type = ?, status = ?, updated_at = ? WHERE id = ?', merged.code, merged.name, merged.description, merged.project_type, merged.status, now(), p.id);
    audit(db, req.user.orgId, req.user.userId, 'project.updated', p.id, b);
    return { ok: true };
  });

  const Fact = z.object({
    key: z.string().trim().min(1).max(80).regex(/^[a-z0-9_]+$/),
    value: z.string().max(5000),
    unit: z.string().max(20).nullable().default(null),
    class: z.enum(['confirmed', 'extracted', 'assumption', 'ai_suggestion', 'unresolved']),
    source: z.string().max(1000).default(''),
    confidence: z.string().max(50).nullable().default(null),
  });
  app.put('/api/projects/:id/facts', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const f = Fact.parse(req.body);
    if (f.class === 'confirmed' && !f.source.trim()) throw new HttpError(400, 'a confirmed fact needs a source (document, authority, or person)');
    run(db, `INSERT INTO project_facts (id, project_id, key, value, unit, class, source, confidence, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)
             ON CONFLICT(project_id, key) DO UPDATE SET value = excluded.value, unit = excluded.unit, class = excluded.class, source = excluded.source,
             confidence = excluded.confidence, created_by = excluded.created_by, created_at = excluded.created_at, source_document_id = NULL`,
      randomUUID(), p.id, f.key, f.value, f.unit, f.class, f.source, f.confidence, req.user.userId, now());
    run(db, 'UPDATE projects SET updated_at = ? WHERE id = ?', now(), p.id);
    audit(db, req.user.orgId, req.user.userId, 'fact.set', p.id, { key: f.key, class: f.class });
    return { ok: true };
  });
  app.delete('/api/projects/:id/facts/:key', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    run(db, 'DELETE FROM project_facts WHERE project_id = ? AND key = ?', p.id, (req.params as any).key);
    audit(db, req.user.orgId, req.user.userId, 'fact.deleted', p.id, { key: (req.params as any).key });
    return { ok: true };
  });

  /** Store requirement hints found in the description as unconfirmed AI suggestions (never overwrites existing facts). */
  app.post('/api/projects/:id/interpret-requirements', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const suggestions = suggestRequirements(p.description);
    const added: string[] = [];
    for (const s of suggestions) {
      const r = run(db, `INSERT INTO project_facts (id, project_id, key, value, unit, class, source, confidence, created_by, created_at)
                         VALUES (?,?,?,?,NULL,'ai_suggestion',?,?,?,?) ON CONFLICT(project_id, key) DO NOTHING`,
        randomUUID(), p.id, s.key, s.value, `project description: “${s.evidence}”`, 'keyword match (offline interpreter)', req.user.userId, now());
      if (r.changes) added.push(s.key);
    }
    audit(db, req.user.orgId, req.user.userId, 'requirements.interpreted', p.id, { added });
    return { suggestions, added };
  });

  app.get('/api/projects/:id/readiness', async (req) => {
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const facts = all(db, 'SELECT key, value, unit, class, source, confidence FROM project_facts WHERE project_id = ?', p.id);
    const byKey = new Map(facts.map((f) => [f.key, f]));
    const docs = all(db, 'SELECT id FROM documents WHERE project_id = ?', p.id);
    const drawing = get<DrawingRow>(db, 'SELECT * FROM drawings WHERE project_id = ? ORDER BY updated_at DESC LIMIT 1', p.id);
    const missing = CRITICAL_INPUTS.filter((c) => !byKey.has(c.key) || byKey.get(c.key)!.class === 'unresolved');
    const unconfirmed = CRITICAL_INPUTS.filter((c) => byKey.has(c.key) && ['extracted', 'assumption', 'ai_suggestion'].includes(byKey.get(c.key)!.class));
    const findings = drawing ? evaluateRules(db, req.user.orgId, drawing) : [];
    const assessable = new Set(['PASS', 'FAIL', 'WARNING']);
    const performable = findings.filter((f) => assessable.has(f.status));
    const notPerformable = findings.filter((f) => !assessable.has(f.status));
    const verifiedSources = (get<any>(db, "SELECT COUNT(*) AS n FROM regulatory_sources WHERE (org_id IS NULL OR org_id = ?) AND verification_status = 'verified'", req.user.orgId)?.n) ?? 0;
    const failing = findings.filter((f) => f.status === 'FAIL');

    let next: { en: string; ar: string };
    if (!p.description.trim()) next = { en: 'Describe the building or engineering work.', ar: 'صف المبنى أو الأعمال الهندسية.' };
    else if (!docs.length) next = { en: 'Upload the plot documents, survey and reference drawings.', ar: 'ارفع وثائق القطعة والمسح والمخططات المرجعية.' };
    else if (!drawing) next = { en: 'Upload a DXF drawing or survey CSV so NOVA has real geometry.', ar: 'ارفع رسماً بصيغة DXF أو ملف مسح CSV ليحصل NOVA على هندسة فعلية.' };
    else if (missing.length) next = { en: `Provide: ${missing.slice(0, 3).map((m) => m.label).join('; ')}.`, ar: `يرجى تقديم: ${missing.slice(0, 3).map((m) => m.label_ar).join('؛ ')}.` };
    else if (failing.length) next = { en: `Resolve ${failing.length} failing check(s).`, ar: `عالج ${failing.length} من الفحوصات غير الناجحة.` };
    else if (!verifiedSources) next = { en: 'A reviewer must register and verify official regulatory sources before regulatory checks can run.', ar: 'يجب على المراجع تسجيل المصادر التنظيمية الرسمية والتحقق منها قبل تشغيل الفحوصات التنظيمية.' };
    else next = { en: 'Engineering review and sign-off.', ar: 'المراجعة الهندسية والاعتماد.' };

    return {
      ready_for_design: missing.length === 0 && !!drawing,
      ready_for_submission: false,
      ready_for_submission_reason: 'NOVA does not hold a verified authority checklist for this project; submission readiness cannot be asserted.',
      known_facts: facts.filter((f) => f.class === 'confirmed'),
      extracted: facts.filter((f) => f.class === 'extracted'),
      assumptions: facts.filter((f) => f.class === 'assumption' || f.class === 'ai_suggestion'),
      missing_critical_inputs: missing,
      unconfirmed_critical_inputs: unconfirmed,
      verified_regulatory_sources: verifiedSources,
      checks_performable: performable.map((f) => ({ rule: f.rule_code, status: f.status, message: f.message })),
      checks_not_performable: notPerformable.map((f) => ({ rule: f.rule_code, status: f.status, message: f.message })),
      drawing_id: drawing?.id ?? null,
      next_action: next,
    };
  });

  // ---- documents ----
  app.post('/api/projects/:id/documents', async (req: FastifyRequest) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const file = await req.file();
    if (!file) throw new HttpError(400, 'no file uploaded');
    const data = await file.toBuffer();
    const name = safeDisplayName(file.filename);
    const ext = extOf(name);
    const spec = ALLOWED[ext];
    if (!spec) throw new HttpError(415, `file type ".${ext}" is not accepted. Allowed: ${Object.keys(ALLOWED).join(', ')}`);
    if (!data.length) throw new HttpError(400, 'file is empty');
    if (spec.magic && !spec.magic(data)) throw new HttpError(415, `file content does not match a .${ext} file`);
    const scan = scanHook(data);

    // DWG is read by the local AutoCAD (if installed) and imported through the same DXF path.
    let dwgDxf: string | null = null, dwgError: string | null = null;
    const acad = ext === 'dwg' ? findAutoCAD() : null;
    if (acad?.available) {
      try { dwgDxf = (await dwgToDxf(deps.acadJobs, data)).dxf; } catch (e: any) { dwgError = String(e?.message ?? e).slice(0, 500); }
    }

    return job(deps, req.user.orgId, `ingest:${ext}`, () => {
      const { key, sha256 } = deps.storage.put(data);
      const docId = randomUUID();
      const notes: string[] = [`Malware scan: ${scan.reason}.`];
      let status: 'parsed' | 'registered_only' | 'failed' = 'registered_only';
      let drawingId: string | null = null;
      let diagnostics: unknown = null;

      tx(db, () => {
        run(db, `INSERT INTO documents (id, org_id, project_id, original_name, ext, mime, size_bytes, sha256, storage_key, origin, classification, extraction_status, extraction_notes, uploaded_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,'upload',?,'pending','[]',?,?)`,
          docId, req.user.orgId, p.id, name, ext, spec.mime, data.length, sha256, key, spec.classify, req.user.userId, now());

        if (ext === 'dwg' && !dwgDxf) {
          notes.push(acad?.available ? `AutoCAD could not read this DWG: ${dwgError}` : 'DWG registered and preserved. Install AutoCAD on the computer running NOVA to import DWG geometry.');
          if (acad?.available) status = 'failed';
        }
        if (ext === 'dxf' || dwgDxf) {
          try {
            if (dwgDxf) notes.push(`DWG read by ${acad!.product} (accoreconsole) and converted to DXF 2010 for import; the original DWG is preserved unchanged.`);
            const res = importDxf(dwgDxf ?? data.toString('utf8'));
            diagnostics = res.diagnostics;
            drawingId = createDrawing(db, { projectId: p.id, name: name.replace(/\.(dxf|dwg)$/i, ''), units: res.diagnostics.units, userId: req.user.userId, sourceDocumentId: docId, diagnostics: res.diagnostics });
            for (const l of res.layers) ensureLayer(db, drawingId, l.name, l.color);
            for (const e of res.entities) insertEntity(db, drawingId, newEntity(e.input, 'imported', e.color != null ? { color: e.color } : {}, e.handle));
            status = 'parsed';
            notes.push(`Imported ${res.entities.length} entities; units ${res.diagnostics.units} (${res.diagnostics.unitsSource}).`, ...res.diagnostics.warnings);
          } catch (e: any) {
            status = 'failed';
            notes.push(String(e?.message ?? e));
          }
        } else if (ext === 'csv') {
          const parsed = parseCsvCoordinates(data.toString('utf8'));
          if (!parsed) { notes.push('No x/y or easting/northing columns found; registered only.'); }
          else {
            status = 'parsed';
            notes.push(`${parsed.points.length} coordinate rows read from columns ${parsed.columns.join(', ')}${parsed.skipped ? `; ${parsed.skipped} non-numeric rows skipped` : ''}. Units and CRS are not stated in the file.`);
            const area = parsed.points.length >= 3 ? polygonArea(parsed.points) : null;
            const facts: [string, string, string | null][] = [
              ['survey_point_count', String(parsed.points.length), null],
              ...(area !== null ? [['survey_polygon_area', String(Math.round(area * 1000) / 1000), 'coordinate units²'] as [string, string, string]] : []),
            ];
            for (const [k, v, u] of facts) {
              run(db, `INSERT INTO project_facts (id, project_id, key, value, unit, class, source, source_document_id, confidence, created_by, created_at)
                       VALUES (?,?,?,?,?,'extracted',?,?,?,?,?) ON CONFLICT(project_id, key) DO NOTHING`,
                randomUUID(), p.id, k, v, u, `${name} (structured CSV)`, docId, 'high: structured table, units unknown', req.user.userId, now());
            }
          }
        } else {
          notes.push(`.${ext} files are registered and preserved; content extraction is not available in this release.`);
        }
        run(db, 'UPDATE documents SET extraction_status = ?, extraction_notes = ? WHERE id = ?', status, JSON.stringify(notes), docId);
        run(db, 'UPDATE projects SET updated_at = ? WHERE id = ?', now(), p.id);
        audit(db, req.user.orgId, req.user.userId, 'document.uploaded', docId, { name, sha256, status });
      });
      return { id: docId, sha256, extraction_status: status, notes, drawingId, diagnostics };
    });
  });

  app.get('/api/documents/:id/download', async (req, reply) => {
    const d = get<any>(db, 'SELECT * FROM documents WHERE id = ? AND org_id = ?', (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'document not found');
    audit(db, req.user.orgId, req.user.userId, 'document.downloaded', d.id);
    reply.header('content-type', d.mime).header('content-disposition', `attachment; filename*=UTF-8''${encodeURIComponent(d.original_name)}`).header('x-content-type-options', 'nosniff');
    return reply.send(deps.storage.get(d.storage_key));
  });

  /** Build a drawing from a survey CSV: a closed boundary polyline plus the surveyed points. Units must be stated by the user. */
  app.post('/api/documents/:id/to-drawing', async (req) => {
    requireRole(req, 'engineer');
    const { units, closed } = z.object({ units: z.enum(['mm', 'cm', 'm', 'in', 'ft']), closed: z.boolean().default(true) }).parse(req.body);
    const d = get<any>(db, "SELECT * FROM documents WHERE id = ? AND org_id = ? AND ext = 'csv'", (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'CSV document not found');
    const parsed = parseCsvCoordinates(deps.storage.get(d.storage_key).toString('utf8'));
    if (!parsed || parsed.points.length < 2) throw new HttpError(422, 'CSV has no usable coordinates');
    const id = tx(db, () => {
      const drawingId = createDrawing(db, { projectId: d.project_id, name: `${d.original_name} — survey`, units, userId: req.user.userId, sourceDocumentId: d.id,
        diagnostics: { format: 'CSV coordinates', units, unitsSource: 'stated by user at conversion', warnings: ['CRS not stated in file; coordinates kept exactly as given.'], imported: { POINT: parsed.points.length, POLYLINE: 1 }, skipped: {} } });
      insertEntity(db, drawingId, newEntity({ type: 'POLYLINE', layer: 'PLOT-BOUNDARY', geom: { points: parsed.points, closed: closed && parsed.points.length >= 3 } }, 'imported'));
      for (const pt of parsed.points) insertEntity(db, drawingId, newEntity({ type: 'POINT', layer: 'SURVEY-POINTS', geom: { p: pt } }, 'imported'));
      audit(db, req.user.orgId, req.user.userId, 'drawing.from_csv', drawingId, { document: d.id, units });
      return drawingId;
    });
    return { id };
  });
}
