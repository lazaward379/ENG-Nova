# Security and Privacy

## Implemented in 0.1

- **Passwords**: scrypt (N=16384, r=8, p=1, 64-byte key, per-user salt), timing-safe compare.
- **Sessions**: 32-byte random tokens; only the SHA-256 hash is stored; 12 h expiry;
  sent as `Authorization: Bearer`. No tokens in URLs. Download links use a short-lived
  token in the same header via fetch, never a query string.
- **Authorisation**: server-side on every route; `org_id` is taken from the session;
  each project/drawing/document lookup joins on `org_id`. Role checks (`admin`,
  `reviewer`, `engineer`, `viewer`) for mutating and verifying actions.
- **Rate limiting**: in-memory per-IP limiter on auth endpoints (10/min).
- **Input validation**: Zod schemas on every body; size limits on JSON (2 MB) and
  uploads (50 MB).
- **Uploads**: extension allow-list + magic-byte check; filenames never used as paths;
  content-addressed storage key (SHA-256); path resolution guarded against traversal.
- **Untrusted content**: document text, DXF text entities and filenames are treated as
  data. Copilot prompts wrap them as data and the LLM may only return schema-valid
  operations; nothing is ever executed as code.
- **Secrets**: only from environment variables (`ANTHROPIC_API_KEY`, `NOVA_*`); never
  sent to the browser; logs redact `authorization` headers.
- **Audit**: `audit_events` for auth, uploads, geometry operations, rule verification,
  proposals, exports.
- **CORS**: not enabled (frontend served same-origin / via Vite proxy).

## AutoCAD bridge
- AutoCAD scripts are generated only from numbers, fixed command names and NOVA-created paths; the
  script is rejected if it contains any non-ASCII character. All user text (room names, notes, project
  names) travels inside the DXF, never in the script, so it cannot inject AutoCAD commands.
- Each job runs in a fresh, empty folder (no acad.lsp/acaddoc.lsp can be picked up from it) with a timeout
  and is deleted afterwards. Uploaded DWG files are untrusted input to AutoCAD, as in normal office use.

## Not yet implemented (tracked in roadmap)

MFA, malware scanning (integration point: `storage.ts#scanHook`), encryption at rest
(rely on disk encryption for now), TLS termination (deploy behind a reverse proxy),
retention policies and secure deletion, backup automation, distributed rate limiting.
