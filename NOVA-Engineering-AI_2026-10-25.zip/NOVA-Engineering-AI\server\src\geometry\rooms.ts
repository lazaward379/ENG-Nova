import type { Entity, Pt, Units } from './types.ts';
import { metresPerUnit } from './types.ts';
import { pointInPolygon, polygonArea, perimeter, selfIntersects } from './math.ts';

/** Layer naming conventions NOVA uses to recognise semantic geometry (case-insensitive). */
export const ROOM_LAYER = /(^|[-_ ])(ROOM|ROOMS|SPACE|SPACES|A-AREA)([-_ ]|$)/i;
export const PLOT_LAYER = /(PLOT|BOUNDARY|SITE-BNDY|C-PROP)/i;
export const FOOTPRINT_LAYER = /(FOOTPRINT|A-BLDG-OUTL|BLDG-OUTLINE)/i;
export const ANNOTATION_LAYER = /(ANNO-AREA|AREA-NUM|(^|-)DIMS?$)/i;

export type Room = {
  entityId: string;
  name: string | null;
  labelIds: string[];
  points: Pt[];
  areaUnits2: number;
  areaM2: number | null;
  perimeterUnits: number;
  valid: boolean;
  problems: string[];
};

/** Rooms are closed polylines on a room layer, named by TEXT entities whose insertion point lies inside. */
export function extractRooms(entities: Entity[], units: Units): Room[] {
  const mpu = metresPerUnit(units);
  // Area tags and dimension text sit inside rooms too, but they are not room names.
  const texts = entities.filter((e) => e.type === 'TEXT' && !ANNOTATION_LAYER.test(e.layer));
  return entities
    .filter((e) => e.type === 'POLYLINE' && ROOM_LAYER.test(e.layer))
    .map((e) => {
      const g = (e as Extract<Entity, { type: 'POLYLINE' }>).geom;
      const problems: string[] = [];
      if (!g.closed) problems.push('boundary not closed');
      if (g.points.length < 3) problems.push('fewer than 3 vertices');
      if (g.closed && g.points.length >= 3 && selfIntersects(g.points)) problems.push('boundary self-intersects');
      const labels = g.closed ? texts.filter((t) => pointInPolygon((t as any).geom.p, g.points)) : [];
      const area = g.closed && g.points.length >= 3 ? polygonArea(g.points) : 0;
      return {
        entityId: e.id,
        name: labels.length ? (labels[0] as any).geom.text : null,
        labelIds: labels.map((l) => l.id),
        points: g.points,
        areaUnits2: area,
        areaM2: mpu === null ? null : area * mpu * mpu,
        perimeterUnits: perimeter(g.points, g.closed),
        valid: problems.length === 0,
        problems,
      };
    });
}

export function closedOnLayer(entities: Entity[], re: RegExp) {
  return entities.filter((e) => e.type === 'POLYLINE' && e.geom.closed && e.geom.points.length >= 3 && re.test(e.layer)) as Extract<Entity, { type: 'POLYLINE' }>[];
}
