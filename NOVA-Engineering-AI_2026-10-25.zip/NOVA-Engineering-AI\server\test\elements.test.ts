import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../src/app.ts';
import { importDxf } from '../src/dxf/dxf.ts';

let app: FastifyInstance, dir: string, token = '', projectId = '', drawingId = '';
let wallId = '', wall2Id = '', doorId = '';

const call = async (method: string, url: string, body?: unknown) => {
  const res = await app.inject({ method: method as any, url, payload: body as any, headers: { authorization: `Bearer ${token}` } });
  let json: any = null; try { json = res.json(); } catch { /* html */ }
  return { status: res.statusCode, json, body: res.body };
};
const op = (o: any) => call('POST', `/api/drawings/${drawingId}/operations`, { op: o });
const ent = async (id: string) => (await call('GET', `/api/drawings/${drawingId}`)).json.entities.find((e: any) => e.id === id);
const near = (a: number, b: number) => Math.abs(a - b) < 1e-6;

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'nova-el-'));
  ({ app } = await buildApp({ dbPath: ':memory:', storageDir: join(dir, 's') }));
  token = (await app.inject({ method: 'POST', url: '/api/auth/register', payload: { orgName: 'Walls Co', name: 'W', email: 'w@example.test', password: 'long-enough-pass' } })).json().token;
  projectId = (await call('POST', '/api/projects', { code: 'W1', name: 'Walls' })).json.id;
  drawingId = (await call('POST', `/api/projects/${projectId}/drawings`, { name: 'GF', units: 'mm' })).json.id;
});
after(async () => { await app.close(); rmSync(dir, { recursive: true, force: true }); });

test('add walls and a hosted door; derived position follows the wall', async () => {
  const w = await op({ kind: 'add', entities: [{ type: 'WALL', layer: 'A-WALL', geom: { a: { x: 0, y: 0 }, b: { x: 5000, y: 0 }, thickness: 200 } }] });
  wallId = w.json.created[0];
  wall2Id = (await op({ kind: 'add', entities: [{ type: 'WALL', layer: 'A-WALL', geom: { a: { x: 5000, y: 0 }, b: { x: 5000, y: 4000 }, thickness: 200 } }] })).json.created[0];
  const d = await op({ kind: 'add', entities: [{ type: 'DOOR', layer: 'A-DOOR', geom: { wallId, offset: 2000, width: 900 } }] });
  assert.equal(d.status, 200, d.body);
  doorId = d.json.created[0];
  const door = await ent(doorId);
  assert.deepEqual(door.geom.p, { x: 2000, y: 0 });
  assert.deepEqual(door.geom.dir, { x: 1, y: 0 });
});

test('“move the door 200 mm left” slides it along its wall', async () => {
  const r = await op({ kind: 'move', ids: [doorId], dx: -200, dy: 0 });
  assert.equal(r.status, 200, r.body);
  const door = await ent(doorId);
  assert.equal(door.geom.offset, 1800);
  assert.deepEqual(door.geom.p, { x: 1800, y: 0 });
  assert.equal(door.geom.wallId, wallId);
});

test('perpendicular movement is refused; a diagonal keeps only the along-wall part', async () => {
  const perp = await op({ kind: 'move', ids: [doorId], dx: 0, dy: 300 });
  assert.equal(perp.status, 422);
  assert.match(perp.json.errors[0], /along its host wall/);
  const diag = await op({ kind: 'move', ids: [doorId], dx: 100, dy: 50 });
  assert.equal(diag.status, 200);
  assert.ok(diag.json.warnings.some((w: string) => /kept in its wall/.test(w)));
  assert.equal((await ent(doorId)).geom.offset, 1900);
  await call('POST', `/api/drawings/${drawingId}/undo`);
});

test('openings cannot leave the wall or overlap another opening', async () => {
  const out = await op({ kind: 'move', ids: [doorId], dx: -2000, dy: 0 });
  assert.equal(out.status, 422);
  assert.match(out.json.errors[0], /beyond its wall/);
  const clash = await op({ kind: 'add', entities: [{ type: 'WINDOW', layer: 'A-GLAZ', geom: { wallId, offset: 2300, width: 1200 } }] });
  assert.equal(clash.status, 422);
  assert.match(clash.json.errors[0], /overlap/);
  const ok = await op({ kind: 'add', entities: [{ type: 'WINDOW', layer: 'A-GLAZ', geom: { wallId, offset: 3800, width: 1200 } }] });
  assert.equal(ok.status, 200, ok.body);
});

test('moving or rotating the wall carries its openings; rotating a door alone is refused', async () => {
  assert.equal((await op({ kind: 'rotate', ids: [doorId], cx: 0, cy: 0, angle: 90 })).status, 422);
  await op({ kind: 'move', ids: [wallId], dx: 0, dy: 1000 });
  assert.deepEqual((await ent(doorId)).geom.p, { x: 1800, y: 1000 });
  await op({ kind: 'rotate', ids: [wallId], cx: 0, cy: 1000, angle: 90 });
  const d = await ent(doorId);
  assert.ok(near(d.geom.p.x, 0) && near(d.geom.p.y, 2800), JSON.stringify(d.geom.p));
  assert.ok(near(d.geom.dir.x, 0) && near(d.geom.dir.y, 1));
  await call('POST', `/api/drawings/${drawingId}/undo`);
  await call('POST', `/api/drawings/${drawingId}/undo`);
  assert.deepEqual((await ent(doorId)).geom.p, { x: 1800, y: 0 });
});

test('deleting a wall deletes its openings; undo restores both', async () => {
  const r = await op({ kind: 'delete', ids: [wallId] });
  assert.ok(r.json.warnings === undefined || Array.isArray(r.json.warnings));
  assert.equal(await ent(doorId), undefined);
  await call('POST', `/api/drawings/${drawingId}/undo`);
  assert.equal((await ent(doorId)).geom.offset, 1800);
});

test('set_opening edits width and swing within constraints', async () => {
  assert.equal((await op({ kind: 'set_opening', id: doorId, width: 1000, swing: 'right' })).status, 200);
  assert.equal((await ent(doorId)).geom.swing, 'right');
  assert.equal((await op({ kind: 'set_opening', id: doorId, width: 4000 })).status, 422);
});

test('copilot: Arabic “move the door 200 mm left” on a hosted door', async () => {
  const r = await call('POST', `/api/drawings/${drawingId}/copilot`, { instruction: 'انقل الباب 200 مم لليسار', selection: [doorId] });
  assert.equal(r.json.status, 'proposed', JSON.stringify(r.json.validation));
  assert.equal(r.json.preview[0].after.geom.offset, 1600);
  assert.equal(r.json.preview[0].after.geom.wallId, wallId);
  const bad = await call('POST', `/api/drawings/${drawingId}/copilot`, { instruction: 'move the door 300 mm up', selection: [doorId] });
  assert.equal(bad.json.status, 'invalid');
});

test('QA-OPENINGS passes with evidence; export writes primitives and verifies', async () => {
  const run = (await call('POST', `/api/drawings/${drawingId}/compliance-runs`, { scope: 'drawing_qa' })).json;
  const f = run.findings.filter((x: any) => x.rule_code === 'QA-OPENINGS');
  assert.equal(f.length, 2);
  assert.ok(f.every((x: any) => x.status === 'PASS'));
  assert.equal(f.find((x: any) => x.entity_ids[0] === doorId).evidence.wall_length, 5000);
  const ex = await call('POST', `/api/drawings/${drawingId}/export`);
  assert.equal(ex.status, 200, ex.body);
  assert.equal(ex.json.verification.ok, true);
  assert.equal(ex.json.verification.typedElementsExploded, 4);
  const dl = await app.inject({ method: 'GET', url: `/api/documents/${ex.json.documentId}/download`, headers: { authorization: `Bearer ${token}` } });
  const back = importDxf(dl.body);
  assert.deepEqual(back.diagnostics.imported, { POLYLINE: 2, LINE: 2, ARC: 1 });
});
