import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { all, get, now, run, tx, type DB } from './db.ts';
import { EntityInput, type Entity } from './geometry/types.ts';
import { mirrorXf, rotateXf, transformEntity, translateXf, geomEqual } from './geometry/math.ts';
import { insertEntity, loadEntities, newEntity, updateEntity, layers } from './drawings.ts';
import { isOpening, openingWithinWall, openingsOverlap, resolveOpening, wallFrame } from './geometry/hosted.ts';

const Ids = z.array(z.string().uuid()).min(1).max(10_000);
const N = z.number().finite().gte(-1e8).lte(1e8);

/** The only geometry-changing operations NOVA executes — for users and for the copilot alike. */
export const Operation = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('move'), ids: Ids, dx: N, dy: N }),
  z.object({ kind: z.literal('copy'), ids: Ids, dx: N, dy: N }),
  z.object({ kind: z.literal('rotate'), ids: Ids, cx: N, cy: N, angle: z.number().finite().gt(-360).lt(360) }),
  z.object({ kind: z.literal('mirror'), ids: Ids, ax: N, ay: N, bx: N, by: N }),
  z.object({ kind: z.literal('delete'), ids: Ids }),
  z.object({ kind: z.literal('add'), entities: z.array(EntityInput).min(1).max(1000) }),
  z.object({ kind: z.literal('set_layer'), ids: Ids, layer: z.string().min(1).max(255) }),
  z.object({ kind: z.literal('edit_text'), id: z.string().uuid(), text: z.string().min(1).max(10_000) }),
  z.object({ kind: z.literal('restore_revision'), revisionId: z.string().uuid() }),
  z.object({
    kind: z.literal('set_opening'), id: z.string().uuid(), offset: N.optional(), width: z.number().finite().positive().max(1e6).optional(),
    swing: z.enum(['left', 'right']).optional(), side: z.union([z.literal(1), z.literal(-1)]).optional(),
  }),
]);
export type Operation = z.infer<typeof Operation>;

export type Change = { id: string; before: Entity | null; after: Entity | null };
export type Effect = { changes: Change[]; errors: string[]; warnings: string[] };

export class OperationError extends Error {
  errors: string[];
  constructor(errors: string[]) { super(errors.join('; ')); this.errors = errors; }
}

/** Compute what an operation would do without writing anything (used for previews and validation). */
export function computeEffect(db: DB, drawingId: string, op: Operation, provenance: 'user' | 'ai'): Effect {
  const current = loadEntities(db, drawingId);
  const byId = new Map(current.map((e) => [e.id, e]));
  const errors: string[] = [];
  const warnings: string[] = [];
  const changes: Change[] = [];

  const pick = (ids: string[]) => {
    const out: Entity[] = [];
    for (const id of new Set(ids)) {
      const e = byId.get(id);
      if (!e) errors.push(`entity ${id} does not exist in this drawing`);
      else out.push(e);
    }
    return out;
  };
  const xform = (es: Entity[], xf: ReturnType<typeof translateXf>) => es.forEach((e) => changes.push({ id: e.id, before: e, after: transformEntity(e, xf) }));

  /** Openings whose host wall is not part of the same selection can only slide along that wall. */
  const freeOpenings = (es: Entity[]) => { const ids = new Set(es.map((e) => e.id)); return es.filter((e) => isOpening(e) && !ids.has((e.geom as any).wallId)); };
  const slide = (o: Entity, dx: number, dy: number) => {
    const wall = byId.get((o.geom as any).wallId);
    if (!wall || wall.type !== 'WALL') { errors.push(`opening ${o.id} has no host wall`); return null; }
    const { dir } = wallFrame(wall.geom);
    const along = dx * dir.x + dy * dir.y;
    const perp = Math.abs(-dx * dir.y + dy * dir.x);
    if (Math.abs(along) < 1e-12 && perp > 0) { errors.push(`${o.type.toLowerCase()} ${o.id.slice(0, 8)} can only move along its host wall; the requested movement is perpendicular to the wall`); return null; }
    if (perp > 1e-9 * Math.max(1, Math.hypot(dx, dy))) warnings.push(`${o.type.toLowerCase()} kept in its wall: only the ${Math.abs(along).toPrecision(6)} component along the wall was applied`);
    return { ...o, geom: { ...(o.geom as any), offset: (o.geom as any).offset + along } } as Entity;
  };

  switch (op.kind) {
    case 'move': {
      const es = pick(op.ids);
      const free = new Set(freeOpenings(es).map((e) => e.id));
      for (const e of es) {
        if (free.has(e.id)) { const s = slide(e, op.dx, op.dy); if (s) changes.push({ id: e.id, before: e, after: s }); }
        else if (!isOpening(e)) changes.push({ id: e.id, before: e, after: transformEntity(e, translateXf(op.dx, op.dy)) });
        // openings whose wall moves too are carried by the cascade below
      }
      break;
    }
    case 'rotate':
    case 'mirror': {
      const es = pick(op.ids);
      if (op.kind === 'mirror' && op.ax === op.bx && op.ay === op.by) { errors.push('mirror axis points must differ'); break; }
      if (freeOpenings(es).length) { errors.push(`${op.kind} a door or window by ${op.kind === 'rotate' ? 'rotating' : 'mirroring'} its host wall, or use “flip swing” on a door`); break; }
      const xf = op.kind === 'rotate' ? rotateXf({ x: op.cx, y: op.cy }, op.angle) : mirrorXf({ x: op.ax, y: op.ay }, { x: op.bx, y: op.by });
      xform(es.filter((e) => !isOpening(e)), xf);
      break;
    }
    case 'copy': {
      const es = pick(op.ids);
      const free = new Set(freeOpenings(es).map((e) => e.id));
      const newIds = new Map<string, string>();
      for (const e of es.filter((x) => !isOpening(x))) {
        const t = transformEntity(e, translateXf(op.dx, op.dy));
        const c = newEntity({ type: t.type, layer: t.layer, geom: t.geom } as EntityInput, provenance, e.props);
        newIds.set(e.id, c.id);
        changes.push({ id: c.id, before: null, after: c });
      }
      for (const e of es.filter(isOpening)) {
        const src = free.has(e.id) ? slide(e, op.dx, op.dy) : ({ ...e, geom: { ...(e.geom as any), wallId: newIds.get((e.geom as any).wallId) } } as Entity);
        if (!src) continue;
        const c = newEntity({ type: e.type, layer: e.layer, geom: src.geom } as EntityInput, provenance, e.props);
        changes.push({ id: c.id, before: null, after: c });
      }
      break;
    }
    case 'delete': for (const e of pick(op.ids)) changes.push({ id: e.id, before: e, after: null }); break;
    case 'add': for (const input of op.entities) { const c = newEntity(input, provenance); changes.push({ id: c.id, before: null, after: c }); } break;
    case 'set_opening': {
      const [e] = pick([op.id]);
      if (e && !isOpening(e)) errors.push('set_opening applies only to doors and windows');
      else if (e) {
        const g: any = { ...e.geom };
        if (op.offset !== undefined) g.offset = op.offset;
        if (op.width !== undefined) g.width = op.width;
        if (e.type === 'DOOR') { if (op.swing) g.swing = op.swing; if (op.side) g.side = op.side; }
        changes.push({ id: e.id, before: e, after: { ...e, geom: g } as Entity });
      }
      break;
    }
    case 'set_layer': for (const e of pick(op.ids)) changes.push({ id: e.id, before: e, after: { ...e, layer: op.layer } }); break;
    case 'edit_text': {
      const [e] = pick([op.id]);
      if (e && e.type !== 'TEXT') errors.push('edit_text applies only to TEXT entities');
      else if (e) changes.push({ id: e.id, before: e, after: { ...e, geom: { ...(e as any).geom, text: op.text } } as Entity });
      break;
    }
    case 'restore_revision': {
      const rev = get<{ snapshot: string; drawing_id: string }>(db, 'SELECT snapshot, drawing_id FROM drawing_revisions WHERE id = ?', op.revisionId);
      if (!rev || rev.drawing_id !== drawingId) { errors.push('revision not found for this drawing'); break; }
      const snap: Entity[] = JSON.parse(rev.snapshot);
      const snapIds = new Set(snap.map((e) => e.id));
      for (const e of current) if (!snapIds.has(e.id)) changes.push({ id: e.id, before: e, after: null });
      for (const s of snap) {
        const e = byId.get(s.id);
        if (!e) changes.push({ id: s.id, before: null, after: s });
        else if (e.layer !== s.layer || !geomEqual(e, s, 0)) changes.push({ id: s.id, before: e, after: s });
      }
      break;
    }
  }

  if (!errors.length) cascadeHosted(current, changes, errors, warnings);

  // Guard rails: resulting geometry must be valid, and locked layers (e.g. plot boundaries) cannot change.
  const locked = new Set(layers(db, drawingId).filter((l) => l.locked).map((l) => l.name));
  for (const c of changes) {
    if (c.after) {
      const parsed = EntityInput.safeParse({ type: c.after.type, layer: c.after.layer, geom: c.after.geom });
      if (!parsed.success) errors.push(`resulting geometry for ${c.id} is invalid: ${parsed.error.issues[0]?.message}`);
    }
    for (const l of [c.before?.layer, c.after?.layer]) if (l && locked.has(l)) {
      errors.push(`layer "${l}" is locked; unlock it explicitly before changing its entities`);
      break;
    }
  }
  if (!changes.length && !errors.length) warnings.push('operation changes nothing');
  return { changes, errors: [...new Set(errors)], warnings };
}

/**
 * Keep wall/opening relationships consistent: openings follow their (changed) host wall, openings of a
 * deleted wall are deleted with it, and every affected opening must stay inside its wall without
 * overlapping another opening on the same wall.
 */
function cascadeHosted(current: Entity[], changes: Change[], errors: string[], warnings: string[]) {
  const byId = new Map<string, Change>(changes.map((c) => [c.id, c]));
  const state = new Map<string, Entity | null>(current.map((e) => [e.id, e]));
  for (const c of changes) state.set(c.id, c.after);
  const set = (e: Entity, after: Entity | null) => {
    const c = byId.get(e.id);
    if (c) c.after = after;
    else { const n = { id: e.id, before: e, after }; byId.set(e.id, n); changes.push(n); }
    state.set(e.id, after);
  };

  const changedWalls = new Set(changes.filter((c) => (c.before ?? c.after)?.type === 'WALL').map((c) => c.id));
  const touched = new Set<string>();
  for (const e of [...state.values()]) {
    if (!e || !isOpening(e)) continue;
    const wallId = (e.geom as any).wallId;
    const changedSelf = byId.has(e.id);
    if (!changedSelf && !changedWalls.has(wallId)) continue;
    const wall = state.get(wallId);
    if (!wall) {
      if (changedWalls.has(wallId)) { set(e, null); warnings.push(`${e.type.toLowerCase()} ${e.id.slice(0, 8)} removed with its host wall`); }
      else errors.push(`${e.type.toLowerCase()} ${e.id.slice(0, 8)} refers to a wall that does not exist`);
      continue;
    }
    if (wall.type !== 'WALL') { errors.push(`${e.type.toLowerCase()} host ${wallId.slice(0, 8)} is not a wall`); continue; }
    set(e, resolveOpening(state.get(e.id)!, wall));
    touched.add(e.id);
  }

  for (const id of touched) {
    const o = state.get(id)!;
    const wall = state.get((o.geom as any).wallId)!;
    if (!openingWithinWall(o as any, wall as any)) {
      const { len } = wallFrame((wall as any).geom);
      errors.push(`${o.type.toLowerCase()} ${id.slice(0, 8)} would extend beyond its wall (centre ${(o.geom as any).offset.toFixed(3)}, width ${(o.geom as any).width}, wall length ${len.toFixed(3)})`);
      continue;
    }
    for (const other of state.values()) {
      if (other && other.id !== id && isOpening(other) && (other.geom as any).wallId === (o.geom as any).wallId && openingsOverlap(o as any, other as any)) {
        errors.push(`${o.type.toLowerCase()} ${id.slice(0, 8)} would overlap ${other.type.toLowerCase()} ${other.id.slice(0, 8)} on the same wall`);
        break;
      }
    }
  }
}

function writeAfter(db: DB, drawingId: string, changes: Change[], dir: 'forward' | 'back') {
  for (const c of changes) {
    const from = dir === 'forward' ? c.before : c.after;
    const to = dir === 'forward' ? c.after : c.before;
    if (!to) run(db, 'DELETE FROM entities WHERE id = ?', c.id);
    else if (!from) insertEntity(db, drawingId, to);
    else updateEntity(db, to);
  }
  run(db, 'UPDATE drawings SET updated_at = ? WHERE id = ?', now(), drawingId);
}

export function applyOperation(db: DB, drawingId: string, op: Operation, actorId: string, source: 'user' | 'ai' | 'system', proposalId: string | null = null) {
  return tx(db, () => {
    const effect = computeEffect(db, drawingId, op, source === 'ai' ? 'ai' : 'user');
    if (effect.errors.length) throw new OperationError(effect.errors);
    writeAfter(db, drawingId, effect.changes, 'forward');
    // A new operation invalidates the redo stack.
    run(db, "UPDATE geometry_operations SET state = 'discarded' WHERE drawing_id = ? AND state = 'undone'", drawingId);
    const seq = (get<{ s: number }>(db, 'SELECT COALESCE(MAX(seq), 0) AS s FROM geometry_operations WHERE drawing_id = ?', drawingId)!.s) + 1;
    const id = randomUUID();
    run(db, `INSERT INTO geometry_operations (id, drawing_id, seq, kind, params, before_state, after_state, state, source, proposal_id, actor_id, created_at)
             VALUES (?,?,?,?,?,?,?,'applied',?,?,?,?)`,
      id, drawingId, seq, op.kind, JSON.stringify(op),
      JSON.stringify(effect.changes.map((c) => ({ id: c.id, e: c.before }))),
      JSON.stringify(effect.changes.map((c) => ({ id: c.id, e: c.after }))),
      source, proposalId, actorId, now());
    return { id, seq, changes: effect.changes, warnings: effect.warnings };
  });
}

function loadChanges(row: any): Change[] {
  const before: { id: string; e: Entity | null }[] = JSON.parse(row.before_state);
  const after: { id: string; e: Entity | null }[] = JSON.parse(row.after_state);
  return before.map((b, i) => ({ id: b.id, before: b.e, after: after[i].e }));
}

export function undo(db: DB, drawingId: string) {
  return tx(db, () => {
    const row = get(db, "SELECT * FROM geometry_operations WHERE drawing_id = ? AND state = 'applied' ORDER BY seq DESC LIMIT 1", drawingId);
    if (!row) return null;
    writeAfter(db, drawingId, loadChanges(row), 'back');
    run(db, "UPDATE geometry_operations SET state = 'undone' WHERE id = ?", row.id);
    return { id: row.id as string, kind: row.kind as string, seq: row.seq as number };
  });
}

export function redo(db: DB, drawingId: string) {
  return tx(db, () => {
    const row = get(db, "SELECT * FROM geometry_operations WHERE drawing_id = ? AND state = 'undone' ORDER BY seq ASC LIMIT 1", drawingId);
    if (!row) return null;
    writeAfter(db, drawingId, loadChanges(row), 'forward');
    run(db, "UPDATE geometry_operations SET state = 'applied' WHERE id = ?", row.id);
    return { id: row.id as string, kind: row.kind as string, seq: row.seq as number };
  });
}

export function history(db: DB, drawingId: string) {
  return all(db, `SELECT o.id, o.seq, o.kind, o.params, o.state, o.source, o.proposal_id, o.created_at, u.name AS actor,
                         json_array_length(o.after_state) AS affected
                  FROM geometry_operations o JOIN users u ON u.id = o.actor_id
                  WHERE o.drawing_id = ? ORDER BY o.seq DESC LIMIT 500`, drawingId)
    .map((r) => ({ ...r, params: JSON.parse(r.params) }));
}
