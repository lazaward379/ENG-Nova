-- NOVA Engineering AI — initial schema (SQLite dialect, portable to PostgreSQL)

CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE memberships (
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('admin','reviewer','engineer','viewer')),
  created_at TEXT NOT NULL,
  PRIMARY KEY (org_id, user_id)
);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  project_type TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'intake' CHECK (status IN ('intake','design','review','archived')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE (org_id, code)
);
CREATE INDEX idx_projects_org ON projects(org_id);

CREATE TABLE project_facts (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  unit TEXT,
  class TEXT NOT NULL CHECK (class IN ('confirmed','extracted','assumption','ai_suggestion','unresolved')),
  source TEXT NOT NULL DEFAULT '',
  source_document_id TEXT REFERENCES documents(id) ON DELETE SET NULL,
  confidence TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  UNIQUE (project_id, key)
);

CREATE TABLE documents (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  original_name TEXT NOT NULL,
  ext TEXT NOT NULL,
  mime TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  storage_key TEXT NOT NULL,
  origin TEXT NOT NULL CHECK (origin IN ('upload','generated')),
  derived_from TEXT REFERENCES documents(id) ON DELETE SET NULL,
  classification TEXT NOT NULL DEFAULT 'unclassified',
  extraction_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (extraction_status IN ('pending','parsed','registered_only','failed')),
  extraction_notes TEXT NOT NULL DEFAULT '[]',
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);
CREATE INDEX idx_documents_project ON documents(project_id);

CREATE TABLE drawings (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  source_document_id TEXT REFERENCES documents(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  units TEXT NOT NULL CHECK (units IN ('mm','cm','m','in','ft','unitless')),
  import_diagnostics TEXT NOT NULL DEFAULT '{}',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_drawings_project ON drawings(project_id);

CREATE TABLE layers (
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  color INTEGER NOT NULL DEFAULT 7,
  visible INTEGER NOT NULL DEFAULT 1,
  locked INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (drawing_id, name)
);

CREATE TABLE entities (
  id TEXT PRIMARY KEY,
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('LINE','POLYLINE','CIRCLE','ARC','TEXT','POINT')),
  layer TEXT NOT NULL,
  geom TEXT NOT NULL,
  props TEXT NOT NULL DEFAULT '{}',
  provenance TEXT NOT NULL CHECK (provenance IN ('imported','user','ai')),
  source_handle TEXT,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_entities_drawing ON entities(drawing_id);

CREATE TABLE geometry_operations (
  id TEXT PRIMARY KEY,
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL,
  kind TEXT NOT NULL,
  params TEXT NOT NULL,
  before_state TEXT NOT NULL,
  after_state TEXT NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('applied','undone','discarded')),
  source TEXT NOT NULL CHECK (source IN ('user','ai','system')),
  proposal_id TEXT,
  actor_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  UNIQUE (drawing_id, seq)
);

CREATE TABLE drawing_revisions (
  id TEXT PRIMARY KEY,
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  number INTEGER NOT NULL,
  label TEXT NOT NULL,
  snapshot TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  op_seq INTEGER NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  UNIQUE (drawing_id, number)
);

CREATE TABLE regulatory_sources (
  id TEXT PRIMARY KEY,
  org_id TEXT REFERENCES organizations(id) ON DELETE CASCADE, -- NULL = global
  authority TEXT NOT NULL,
  title TEXT NOT NULL,
  document_ref TEXT NOT NULL DEFAULT '',
  url TEXT NOT NULL DEFAULT '',
  publication_date TEXT,
  effective_date TEXT,
  revision TEXT NOT NULL DEFAULT '',
  retrieved_at TEXT,
  applicability TEXT NOT NULL DEFAULT '',
  checksum TEXT,
  superseded_by TEXT REFERENCES regulatory_sources(id),
  access_notes TEXT NOT NULL DEFAULT '',
  verification_status TEXT NOT NULL CHECK (verification_status IN ('unverified','verified','test_only')),
  verified_by TEXT REFERENCES users(id),
  verified_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE regulatory_rules (
  id TEXT PRIMARY KEY,
  org_id TEXT REFERENCES organizations(id) ON DELETE CASCADE, -- NULL = global template
  code TEXT NOT NULL,
  title TEXT NOT NULL,
  title_ar TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL CHECK (category IN ('regulatory','drawing_qa')),
  discipline TEXT NOT NULL DEFAULT 'architectural',
  evaluator TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (org_id, code)
);

CREATE TABLE rule_versions (
  id TEXT PRIMARY KEY,
  rule_id TEXT NOT NULL REFERENCES regulatory_rules(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('template','verified','internal','superseded')),
  source_id TEXT REFERENCES regulatory_sources(id),
  clause TEXT NOT NULL DEFAULT '',
  quotation TEXT NOT NULL DEFAULT '',
  interpretation TEXT NOT NULL,
  applicability TEXT NOT NULL DEFAULT '{}',
  params TEXT NOT NULL DEFAULT '{}',
  required_inputs TEXT NOT NULL DEFAULT '[]',
  effective_date TEXT,
  reviewer_id TEXT REFERENCES users(id),
  reviewed_at TEXT,
  created_at TEXT NOT NULL,
  UNIQUE (rule_id, version)
);

CREATE TABLE compliance_runs (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  op_seq INTEGER NOT NULL,
  rule_version_ids TEXT NOT NULL,
  summary TEXT NOT NULL,
  run_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);

CREATE TABLE compliance_findings (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES compliance_runs(id) ON DELETE CASCADE,
  rule_version_id TEXT NOT NULL REFERENCES rule_versions(id),
  rule_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PASS','FAIL','WARNING','NOT CHECKED','INSUFFICIENT DATA','REQUIRES ENGINEER REVIEW','SOURCE NOT VERIFIED')),
  message TEXT NOT NULL,
  inputs TEXT NOT NULL DEFAULT '{}',
  evidence TEXT NOT NULL DEFAULT '{}',
  entity_ids TEXT NOT NULL DEFAULT '[]',
  location TEXT,
  corrective_action TEXT NOT NULL DEFAULT '',
  resolution TEXT NOT NULL DEFAULT 'open' CHECK (resolution IN ('open','resolved','accepted_risk')),
  assignee_id TEXT REFERENCES users(id)
);
CREATE INDEX idx_findings_run ON compliance_findings(run_id);

CREATE TABLE ai_proposals (
  id TEXT PRIMARY KEY,
  drawing_id TEXT NOT NULL REFERENCES drawings(id) ON DELETE CASCADE,
  instruction TEXT NOT NULL,
  language TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT,
  intent TEXT NOT NULL,
  operation TEXT,
  explanation TEXT NOT NULL DEFAULT '',
  assumptions TEXT NOT NULL DEFAULT '[]',
  validation TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL CHECK (status IN ('proposed','applied','rejected','invalid','answered')),
  applied_op_id TEXT,
  approved_by TEXT REFERENCES users(id),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE background_jobs (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued','running','succeeded','failed','cancelled')),
  detail TEXT NOT NULL DEFAULT '',
  started_at TEXT,
  finished_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE audit_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  org_id TEXT,
  user_id TEXT,
  action TEXT NOT NULL,
  target TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_org ON audit_events(org_id, id);
