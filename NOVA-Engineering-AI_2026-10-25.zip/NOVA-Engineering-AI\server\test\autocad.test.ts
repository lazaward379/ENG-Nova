import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../src/app.ts';
import { sampleEntities } from '../scripts/make-sample.ts';
import { exportDxf } from '../src/dxf/dxf.ts';
import { findAutoCAD } from '../src/integrations/autocad.ts';

// Runs only where AutoCAD (accoreconsole.exe) is installed.
const skip = !findAutoCAD().available && 'AutoCAD not installed';
let app: FastifyInstance, dir: string, token = '', project = '', generated = '';

const call = async (method: string, url: string, body?: unknown) => {
  const res = await app.inject({ method: method as any, url, payload: body as any, headers: { authorization: `Bearer ${token}` } });
  let json: any = null; try { json = res.json(); } catch { /* binary */ }
  return { status: res.statusCode, json, body: res.body, raw: res.rawPayload };
};
const upload = async (name: string, data: Buffer) => {
  const b = '----a' + Math.random().toString(16).slice(2);
  const payload = Buffer.concat([Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="file"; filename="${name}"\r\n\r\n`), data, Buffer.from(`\r\n--${b}--\r\n`)]);
  return (await app.inject({ method: 'POST', url: `/api/projects/${project}/documents`, payload, headers: { 'content-type': `multipart/form-data; boundary=${b}`, authorization: `Bearer ${token}` } })).json();
};

before(async () => {
  if (skip) return;
  dir = mkdtempSync(join(tmpdir(), 'nova-acad-'));
  ({ app } = await buildApp({ dbPath: ':memory:', storageDir: join(dir, 's'), acadJobsDir: join(dir, 'jobs') }));
  token = (await app.inject({ method: 'POST', url: '/api/auth/register', payload: { orgName: 'Acad Co', name: 'A', email: 'a@example.test', password: 'long-enough-pass' } })).json().token;
  project = (await call('POST', '/api/projects', { code: 'ACAD', name: 'AutoCAD test' })).json.id;
  const ref = (await upload('ref.dxf', Buffer.from(exportDxf(sampleEntities(), [], 'mm')))).drawingId;
  generated = (await call('POST', `/api/projects/${project}/generate-from-reference`, { referenceDrawingId: ref, plot: { width_m: 30, depth_m: 26, source: 'test plot' }, setback_m: 3, setback_source: 'test setback' })).json.drawingId;
});
after(async () => { if (!skip) { await app.close(); rmSync(dir, { recursive: true, force: true }); } });

test('AutoCAD produces a detailed sheet (DWG + PDF) with verified native hatches and dimensions', { skip, timeout: 300_000 }, async () => {
  const r = await call('POST', `/api/drawings/${generated}/autocad/sheet`, { paper: 'A1' });
  assert.equal(r.status, 200, r.body);
  const v = r.json.verification;
  assert.equal(v.ok, true, JSON.stringify(v));
  assert.ok(v.hatches.found >= 12);
  assert.ok(v.dimensions.found >= 20, JSON.stringify(v));
  assert.equal(r.json.report.scale, '1:100');
  const pdf = await call('GET', `/api/documents/${r.json.pdf.id}/download`);
  assert.equal(pdf.raw.subarray(0, 5).toString('latin1'), '%PDF-');
  const dwg = await call('GET', `/api/documents/${r.json.dwg.id}/download`);
  assert.equal(dwg.raw.subarray(0, 4).toString('latin1'), 'AC10');
});

test('AutoCAD produces elevations + section from user floor heights, verified, heights kept as a fact', { skip, timeout: 300_000 }, async () => {
  const bad = await call('POST', `/api/drawings/${generated}/autocad/elevations`, { floors: [{ name: 'GF', height_m: 2.4 }], source: 'test heights' });
  assert.equal(bad.status, 400, bad.body);
  const r = await call('POST', `/api/drawings/${generated}/autocad/elevations`, {
    paper: 'A1', floors: [{ name: 'GROUND', height_m: 3.6 }, { name: 'FIRST', height_m: 3.4 }], slab_m: 0.25, parapet_m: 1.0, plinth_m: 0.45, source: 'test heights from the brief',
  });
  assert.equal(r.status, 200, r.body);
  assert.equal(r.json.verification.ok, true, JSON.stringify(r.json.verification));
  assert.equal(r.json.report.elevations, 4);
  assert.ok(r.json.report.cutWalls >= 2);
  assert.ok(r.json.verification.hatches.found >= 6);
  assert.ok(r.json.verification.dimensions.found >= 20);
  assert.ok(Math.abs(r.json.report.totalHeight_m - (0.45 + 3.6 + 3.4 + 1.0)) < 1e-6);
  const facts = (await call('GET', `/api/projects/${project}`)).json.facts;
  const fh = facts.find((f: any) => f.key === 'floor_heights');
  assert.equal(fh.class, 'confirmed');
  assert.equal(JSON.parse(fh.value).floors.length, 2);
  const pdf = await call('GET', `/api/documents/${r.json.pdf.id}/download`);
  assert.equal(pdf.raw.subarray(0, 5).toString('latin1'), '%PDF-');
});

test('DWG round trip: export with AutoCAD, upload the DWG, NOVA imports the same rooms', { skip, timeout: 300_000 }, async () => {
  const ex = await call('POST', `/api/drawings/${generated}/autocad/dwg`);
  assert.equal(ex.status, 200, ex.body);
  const dwg = (await call('GET', `/api/documents/${ex.json.document.id}/download`)).raw;
  const up = await upload('roundtrip.dwg', dwg);
  assert.equal(up.extraction_status, 'parsed', JSON.stringify(up.notes));
  const back = (await call('GET', `/api/drawings/${up.drawingId}`)).json;
  const orig = (await call('GET', `/api/drawings/${generated}`)).json;
  assert.deepEqual(back.rooms.map((r: any) => r.name).sort(), orig.rooms.map((r: any) => r.name).sort());
  for (const r of orig.rooms) {
    const m = back.rooms.find((x: any) => x.name === r.name);
    assert.ok(Math.abs(m.areaM2 - r.areaM2) < 1e-6, r.name);
  }
});
