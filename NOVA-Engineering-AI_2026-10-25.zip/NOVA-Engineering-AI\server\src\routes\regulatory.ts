import type { FastifyInstance } from 'fastify';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { all, audit, get, now, run, tx } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { activeRules } from '../rules/engine.ts';

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().default(null);

const Source = z.object({
  authority: z.string().trim().min(2).max(200),
  title: z.string().trim().min(2).max(500),
  document_ref: z.string().max(200).default(''),
  url: z.union([z.literal(''), z.string().url().max(1000).refine((u) => /^https?:\/\//.test(u), 'http(s) only')]).default(''),
  publication_date: isoDate,
  effective_date: isoDate,
  revision: z.string().max(100).default(''),
  retrieved_at: isoDate,
  applicability: z.string().max(2000).default(''),
  checksum: z.string().regex(/^[a-f0-9]{64}$/i).nullable().default(null),
  access_notes: z.string().max(2000).default(''),
});

/** Parameters each evaluator accepts. Keeps reviewers from entering values the engine would silently ignore. */
const PARAMS: Record<string, z.ZodType> = {
  'reg.room_min_area': z.object({
    min_area_m2: z.number().positive().max(10_000),
    room_name_pattern: z.string().max(200).refine((p) => { try { new RegExp(p, 'i'); return true; } catch { return false; } }, 'invalid pattern').optional(),
  }).strict(),
  'reg.plot_coverage': z.object({ max_coverage_pct: z.number().gt(0).lte(100).optional() }).strict(),
  'reg.setback_uniform': z.object({ min_setback_m: z.number().nonnegative().max(1000) }).strict(),
};

export function regulatoryRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;

  app.get('/api/regulatory/sources', async (req) =>
    all(db, `SELECT s.*, u.name AS verified_by_name FROM regulatory_sources s LEFT JOIN users u ON u.id = s.verified_by
             WHERE s.org_id IS NULL OR s.org_id = ? ORDER BY s.created_at DESC`, req.user.orgId));

  app.post('/api/regulatory/sources', async (req) => {
    requireRole(req, 'reviewer');
    const b = Source.parse(req.body);
    const id = randomUUID();
    run(db, `INSERT INTO regulatory_sources (id, org_id, authority, title, document_ref, url, publication_date, effective_date, revision, retrieved_at, applicability, checksum, access_notes, verification_status, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'unverified',?)`,
      id, req.user.orgId, b.authority, b.title, b.document_ref, b.url, b.publication_date, b.effective_date, b.revision, b.retrieved_at, b.applicability, b.checksum, b.access_notes, now());
    audit(db, req.user.orgId, req.user.userId, 'source.registered', id, { authority: b.authority, title: b.title });
    return { id };
  });

  /** Copy a global catalogue source into the organisation so its reviewer can verify it. */
  app.post('/api/regulatory/sources/:id/adopt', async (req) => {
    requireRole(req, 'reviewer');
    const s = get<any>(db, 'SELECT * FROM regulatory_sources WHERE id = ? AND org_id IS NULL', (req.params as any).id);
    if (!s) throw new HttpError(404, 'catalogue source not found');
    const existing = get<any>(db, 'SELECT id FROM regulatory_sources WHERE org_id = ? AND url = ? AND url <> \'\'', req.user.orgId, s.url);
    if (existing) return { id: existing.id, existing: true };
    const id = randomUUID();
    run(db, `INSERT INTO regulatory_sources (id, org_id, authority, title, document_ref, url, publication_date, effective_date, revision, retrieved_at, applicability, checksum, access_notes, verification_status, created_at)
             SELECT ?, ?, authority, title, document_ref, url, publication_date, effective_date, revision, retrieved_at, applicability, checksum, access_notes, 'unverified', ? FROM regulatory_sources WHERE id = ?`,
      id, req.user.orgId, now(), s.id);
    audit(db, req.user.orgId, req.user.userId, 'source.adopted', id, { from: s.id });
    return { id, existing: false };
  });

  /** A reviewer attests that they checked the official document ("verified"), or marks it as a test fixture. */
  app.post('/api/regulatory/sources/:id/verify', async (req) => {
    requireRole(req, 'reviewer');
    const { status, attestation } = z.object({ status: z.enum(['verified', 'test_only']), attestation: z.string().trim().min(10).max(1000) }).parse(req.body);
    const s = get<any>(db, 'SELECT * FROM regulatory_sources WHERE id = ? AND org_id = ?', (req.params as any).id, req.user.orgId);
    if (!s) throw new HttpError(404, 'source not found (global sources cannot be changed by an organisation)');
    if (status === 'verified' && (!s.url && !s.checksum)) throw new HttpError(422, 'a verified source needs an official URL or the checksum of the retained document');
    run(db, 'UPDATE regulatory_sources SET verification_status = ?, verified_by = ?, verified_at = ?, access_notes = ? WHERE id = ?',
      status, req.user.userId, now(), [s.access_notes, `Reviewer attestation (${now().slice(0, 10)}): ${attestation}`].filter(Boolean).join('\n'), s.id);
    audit(db, req.user.orgId, req.user.userId, 'source.verified', s.id, { status });
    return { ok: true };
  });

  app.get('/api/regulatory/rules', async (req) => activeRules(db, req.user.orgId));

  app.get('/api/regulatory/rules/:code/versions', async (req) =>
    all(db, `SELECT v.*, r.code, r.org_id, s.title AS source_title, s.authority AS source_authority, s.verification_status AS source_status, u.name AS reviewer_name
             FROM rule_versions v JOIN regulatory_rules r ON r.id = v.rule_id LEFT JOIN regulatory_sources s ON s.id = v.source_id LEFT JOIN users u ON u.id = v.reviewer_id
             WHERE r.code = ? AND (r.org_id IS NULL OR r.org_id = ?) ORDER BY r.org_id IS NULL, v.version DESC`, (req.params as any).code, req.user.orgId)
      .map((v) => ({ ...v, params: JSON.parse(v.params), required_inputs: JSON.parse(v.required_inputs) })));

  /**
   * Create a verified version of a regulatory rule for this organisation. Global templates are copied
   * into the organisation first, so one org's verification never changes another org's rule set.
   */
  app.post('/api/regulatory/rules/:code/versions', async (req) => {
    requireRole(req, 'reviewer');
    const code = (req.params as any).code;
    const b = z.object({
      source_id: z.string().uuid(),
      clause: z.string().trim().min(1).max(200),
      quotation: z.string().max(5000).default(''),
      interpretation: z.string().trim().min(10).max(5000),
      params: z.record(z.string(), z.unknown()),
      effective_date: isoDate,
    }).parse(req.body);

    const rules = activeRules(db, req.user.orgId);
    const rule = rules.find((r) => r.code === code);
    if (!rule) throw new HttpError(404, 'rule not found');
    if (rule.category !== 'regulatory') throw new HttpError(409, 'drawing QA rules are internal conventions and are not source-verified');
    const schema = PARAMS[rule.evaluator];
    if (!schema) throw new HttpError(409, `no parameter schema for evaluator ${rule.evaluator}`);
    const params = schema.parse(b.params);
    const src = get<any>(db, 'SELECT * FROM regulatory_sources WHERE id = ? AND (org_id IS NULL OR org_id = ?)', b.source_id, req.user.orgId);
    if (!src) throw new HttpError(404, 'source not found');
    if (src.verification_status === 'unverified') throw new HttpError(422, 'the source itself has not been verified by a reviewer');

    const result = tx(db, () => {
      let ruleId: string = rule.org_id ? rule.id : (get<any>(db, 'SELECT id FROM regulatory_rules WHERE org_id = ? AND code = ?', req.user.orgId, code)?.id);
      if (!ruleId) {
        ruleId = randomUUID();
        run(db, 'INSERT INTO regulatory_rules (id, org_id, code, title, title_ar, category, discipline, evaluator, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
          ruleId, req.user.orgId, code, rule.title.replace(/ \(template\)$/, ''), rule.title_ar.replace(/ \(قالب\)$/, ''), rule.category, rule.discipline, rule.evaluator, now());
      }
      run(db, "UPDATE rule_versions SET status = 'superseded' WHERE rule_id = ? AND status <> 'superseded'", ruleId);
      const version = ((get<any>(db, 'SELECT COALESCE(MAX(version), 0) AS n FROM rule_versions WHERE rule_id = ?', ruleId)?.n) ?? 0) + 1;
      const id = randomUUID();
      run(db, `INSERT INTO rule_versions (id, rule_id, version, status, source_id, clause, quotation, interpretation, applicability, params, required_inputs, effective_date, reviewer_id, reviewed_at, created_at)
               VALUES (?,?,?,'verified',?,?,?,?,'{}',?,?,?,?,?,?)`,
        id, ruleId, version, src.id, b.clause, b.quotation, b.interpretation, JSON.stringify(params), JSON.stringify(rule.required_inputs), b.effective_date, req.user.userId, now(), now());
      return { id, version };
    });
    audit(db, req.user.orgId, req.user.userId, 'rule.version_verified', code, { version: result.version, source: src.id, test_only: src.verification_status === 'test_only' });
    return result;
  });
}
