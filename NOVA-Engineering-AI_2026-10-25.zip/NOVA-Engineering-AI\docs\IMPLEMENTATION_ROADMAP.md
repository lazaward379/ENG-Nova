# Implementation Roadmap and Backlog

Priority: P0 = vertical slice, P1 = next, P2 = later, P3 = enterprise.

## Backlog

| # | Pri | Item | Status |
|---|---|---|---|
| 1 | P0 | Docs, architecture, environment decision | done |
| 2 | P0 | Auth, orgs, roles, org isolation | done |
| 3 | P0 | Projects + intake wizard + project facts with provenance | done |
| 4 | P0 | Secure file intake + document register | done |
| 5 | P0 | DXF import with diagnostics | done |
| 6 | P0 | CAD canvas: pan/zoom, layers, selection, snaps, measure | done |
| 7 | P0 | Geometry ops (move/rotate/copy/delete/add) + undo/redo | done |
| 8 | P0 | Checkpoints (revisions) and reload | done |
| 9 | P0 | Drawing QA checks + rule engine statuses | done |
| 10 | P0 | Regulatory registry + verification workflow | done |
| 11 | P0 | Copilot pipeline (deterministic EN/AR + LLM provider) | done |
| 12 | P0 | HTML report + DXF R12 export with verification | done |
| 13 | P1 | Typed Wall/Door/Window objects with wall-hosting relationships | done (cycle 2) |
| 13b | P1 | Binaa: official source catalogue + manual submission workflow | done (cycle 2) |
| 14 | P1 | Revision comparison (entity diff between checkpoints) UI | partial (API) |
| 15 | P1 | Python worker: ezdxf full entity set (blocks, hatches, dimensions) | todo |
| 16 | P1 | PDF text extraction + OCR worker; fact extraction with citations | todo |
| 17 | P1 | Retrieve and register official Abu Dhabi sources; reviewer-verify first rules | todo (needs human reviewer) |
| 18 | P1 | Trim/extend/offset/mirror tools | todo |
| 19 | P1 | Sheet + title block generation, PDF plotting | todo |
| 20 | P2 | IFC import (web-ifc) and model tree | todo |
| 21 | P2 | Clash detection on IFC/3D geometry | todo |
| 22 | P2 | Submission checklists (configurable per authority/client) | partial (readiness report) |
| 23 | P2 | Shop drawing workflows with status gates | placeholder |
| 24 | P2 | PostgreSQL + migrations, S3 storage, job queue | todo |
| 25 | P3 | MFA, malware scanning, backups, retention, SSO | todo |
| 26 | P3 | DWG via licensed SDK | todo (licensing decision) |

## Cycle log

### Cycle 1 — 2026-10-25
Implemented items 1–12 plus an offline requirements interpreter (description → AI-suggested facts).

Results:
- `npm --prefix server test`: **40 / 40 passed** (geometry, DXF round-trip, copilot EN/AR parser,
  requirements interpreter, API vertical slice, AI slice, regulatory slice, org isolation, upload validation).
- `npm --prefix server run typecheck`: clean. `npm --prefix web run build` (tsc + vite): clean.
- `npm audit`: 0 vulnerabilities in server and web after upgrading fastify, @fastify/static, zod and vite.
- Manual browser check: sample DXF rendered; door arc selected; Arabic instruction
  “انقل الباب 200 مم لليسار” → proposal with dashed preview → applied as op #1 → checks run with
  markers → undo back to op #0; Arabic RTL readiness screen reviewed.

Fixed during the cycle: OCS extrusion not exposed by dxf-parser for circles (now read from raw
group 230), room-overlap false positive for rooms sharing a wall, static assets 404 after rebuild,
narrow-screen workspace layout.

### Cycle 7 — 2026-10-25 — AI architecture images on the home page
- Full-width hero slideshow of 4 AI-generated architecture images per day (12 curated Emirati /
  contemporary themes, deterministic seeds; “New images” gives another variation). Images come from
  Pollinations (free, no key; only the fixed theme prompt is sent), are validated as JPEG/PNG, saved in
  `server/data/ai-images` (last 7 days kept) and served to the page with authentication.
- The free service refuses rapid consecutive requests (HTTP 402): requests are queued one at a time with
  retries and back-off; the page retries each image and shows a designed fallback if all fail.
- Every image carries an “AI-generated image” label and its theme caption.
- Results: 67 / 67 server tests; browser-verified (images generated and displayed with greeting overlay).

### Cycle 6 — 2026-10-25 — New home page and three main sections
- Home (`web/src/screens/Home.tsx`): Abu Dhabi analog + digital clock (Gregorian + Hijri), live weather
  (Open-Meteo, cached 15 min), daily wisdom (curated, unattributed proverbs/maxims, changes at Abu Dhabi
  midnight), Abu Dhabi Municipality / DMT news (Google News RSS, each item credited, cached 1 h), three
  section cards. Server: `routes/home.ts`.
- Section 1 — Design (`DesignHub.tsx`, `routes/journey.ts`): seven-stage journey with statuses computed
  from project data (brief, plot, plan, checks, AutoCAD sheets, Binaa submission, shop drawings).
- Section 2 — Review & edit (`ReviewHub.tsx`, `routes/review.ts`, migration 003): upload DXF/DWG, review,
  turn findings into tracked comments, paste municipality/client letters (one comment per line, numbering
  kept), responses, close with evidence = drawing operations made since the comment was logged,
  “Fix with copilot” hand-off to the workspace, bilingual comment-response sheet.
- Section 3 — Client presentation (`PresentationHub.tsx`, `present/deck.ts`, `present/planSvg.ts`,
  `routes/presentation.ts`): slides from real project data (cover, brief, site, plan drawing, areas,
  heights, checks, next steps, close) in Arabic or English, with a spoken explanation per slide;
  in-app viewer + full screen + PowerPoint (.pptx, explanation in speaker notes) stored in the register.
- Navigation: Home + three main sections at the top. `pptxgenjs` 4.0.1 added (`image-size` overridden to
  2.0.4 for a security advisory; it is not called by pptxgenjs).
- Results: 66 / 66 server tests (incl. AutoCAD), web build clean, audits clean; browser-verified in
  Arabic and English.

### Cycle 5 — 2026-10-25 — Elevations and section (AutoCAD)
- `server/src/integrations/elevations.ts` + `POST /api/drawings/:id/autocad/elevations`: four elevations
  (external faces with hidden-face removal per view, plinth/slab/roof/parapet lines, ground-floor doors and
  windows at user-given heights, level labels, height chain + overall width dimensions) and section A-A
  (automatic cut avoiding walls running along it; cut walls hatched with opening gaps, solid slabs, parapets,
  walls beyond with their openings, room names, level chain), key plan with cut line and view numbers,
  heights table with source. Floor heights are saved as a confirmed project fact with the user's source.
- Shared `integrations/sheet.ts` (paper, scale incl. 1:150, frame, title block, north, script header, hatches).
- UI: floors / heights / source inputs in the AutoCAD dialog.
- Results: all server tests pass incl. 3 real-AutoCAD tests; live DEMO-002 sheet 1:100 @ A1,
  11/11 hatches, 25/25 dimensions verified.

### Cycle 4 — 2026-10-25 — AutoCAD integration (local)
- `server/src/integrations/autocad.ts`: finds AutoCAD's `accoreconsole.exe` (AutoCAD 2023 here), runs one job
  at a time in an empty folder with a timeout; scripts contain only numbers, fixed commands and NOVA paths.
- DWG import (upload → AutoCAD DXFOUT → NOVA import, original preserved) and DWG export (AutoCAD 2018).
- `server/src/integrations/detailing.ts` + `POST /api/drawings/:id/autocad/sheet`: detailed plan sheet —
  hatched wall segments between openings, door/window symbols with jambs, D/W tags, aligned dimension
  chains on external walls + overall dims, clear room dimensions, door & window schedule, room schedule,
  frame + title block (scale chosen automatically), DWG + PDF; verified by re-reading AutoCAD's DXF output.
- UI: “AutoCAD sheet” button in the CAD workspace.
- Results: 59 / 59 tests incl. 2 that drive the real AutoCAD; live sheet for DEMO-002 at 1:100 @ A1 with
  28/28 hatches and 50/50 dimensions verified.

### Cycle 3 — 2026-10-25 — Draw from a reference project
- `server/src/generator/fromReference.ts` + `POST /api/projects/:id/generate-from-reference`, UI screen
  “Draw from reference”. Learns room programme, shapes, relative layout and doors from a reference drawing;
  fits it to the new plot's buildable area (setback, optional 90° rotation, proportional or fill scaling,
  confirmed coverage cap, scale limits 0.6–1.5); derives typed walls (external/internal by adjacency),
  re-hosts reference doors, adds doors until every room is reachable from the entrance, windows on external
  walls of habitable rooms, room name + area tags, overall dimensions, traced building outline and a
  PRELIMINARY note; writes everything through the operation pipeline (provenance `ai`, undoable) and runs checks.
- Room naming now ignores area/dimension annotation layers.
- Results: `npm --prefix server test` **57 / 57**; web build clean; browser: DEMO-001 → 24 × 38 m plot gave
  5 rooms, 12 walls, 5 doors, 11 windows, coverage 39.6 %, 32 PASS + 3 SOURCE NOT VERIFIED.

### Cycle 2 — 2026-10-25
- Typed WALL / DOOR / WINDOW with hosting rules, constraint checks, `set_opening`, cascade on wall
  move/rotate/delete, QA-OPENINGS, DXF export as primitives; canvas tools W / D / N with live previews,
  wall-gap rendering, opening property editor. Migration `002` rebuilds `entities` and adds submission tables.
- Binaa research (official DMT / Media Office pages): no public API found. Added source catalogue (unverified),
  adopt-then-verify flow, Binaa submission packages with status history, transmittal, Settings/Submission UI.
- Fixed: canvas `draw` captured a stale entity index in long-lived callbacks (ResizeObserver, key handlers);
  “not applicable” checklist items now require an explicit reason.
- Results: `npm --prefix server test` **53 / 53 passed**; server typecheck clean; web build clean.
  Manual browser check: drew a wall, placed door and window, Arabic “انقل الباب 500 مم للأعلى” slid the door
  along its vertical wall (op #5, stored result = preview); created a Binaa package in the UI.

**Next highest-priority task:** a human reviewer opens the catalogue sources, records the official Binaa/TAMM
checklist for villas into a package, and verifies the first regulatory rule versions (item 17); then DXF
import recognition of walls/doors (item 15).

(Previous) **Next highest-priority task:** typed Wall / Door / Window objects with wall-hosting relationships
(item 13), so “move this door 200 mm” keeps the door inside its wall and checks become
architecture-aware — followed by registering the first official Abu Dhabi sources with a human
reviewer (item 17).
