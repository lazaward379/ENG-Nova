import type { Entity, EntityInput, Pt, Units } from '../geometry/types.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { pointInPolygon } from '../geometry/math.ts';
import { extractRooms } from '../geometry/rooms.ts';
import { isOpening, wallFrame } from '../geometry/hosted.ts';
import { fmtP, hatchCmds, layoutSheet, scriptHeader, type BBox, type Paper } from './sheet.ts';

/**
 * Elevations (4 directions) and one cross-section derived from the ground-floor plan and floor heights
 * supplied by the user. Hidden faces are removed per view (nearest face wins on every horizontal stretch).
 * Openings exist only on the ground floor because only that plan is known; upper floors are massing.
 */

export type Heights = {
  floors: { name: string; height_m: number }[];
  slab_m: number; parapet_m: number; plinth_m: number;
  door_head_m: number; sill_m: number; window_head_m: number;
  source: string;
};

type Face = { a: Pt; b: Pt; out: Pt; dir: Pt; len: number; external: boolean; openings: { type: 'DOOR' | 'WINDOW'; from: number; to: number }[] };
type Piece = { face: Face; u0: number; u1: number };
type Rect = [number, number, number, number]; // x0, z0, x1, z1 in view-local drawing units

const add = (a: Pt, b: Pt, k = 1): Pt => ({ x: a.x + b.x * k, y: a.y + b.y * k });
const dot = (a: Pt, b: Pt) => a.x * b.x + a.y * b.y;

/** Visible stretches of faces for a viewer looking along d (nearest face wins). */
function visiblePieces(faces: Face[], d: Pt, r: Pt, eps: number, depthOf: (f: Face) => number): Piece[] {
  const spans = faces.map((f) => { const ua = dot(f.a, r), ub = dot(f.b, r); return { f, u0: Math.min(ua, ub), u1: Math.max(ua, ub), depth: depthOf(f) }; }).filter((s) => s.u1 - s.u0 > eps);
  const cuts = [...new Set(spans.flatMap((s) => [s.u0, s.u1]))].sort((a, b) => a - b);
  const out: Piece[] = [];
  for (let i = 0; i + 1 < cuts.length; i++) {
    const m = (cuts[i] + cuts[i + 1]) / 2;
    const cover = spans.filter((s) => s.u0 - eps <= m && m <= s.u1 + eps).sort((a, b) => a.depth - b.depth)[0];
    if (!cover) continue;
    const last = out[out.length - 1];
    if (last && last.face === cover.f && Math.abs(last.u1 - cuts[i]) <= eps) last.u1 = cuts[i + 1];
    else out.push({ face: cover.f, u0: cuts[i], u1: cuts[i + 1] });
  }
  return out;
}

/** Map an opening on a face to the view's u axis. */
function openingSpan(f: Face, o: { from: number; to: number }, r: Pt): [number, number] {
  const ua = dot(add(f.a, f.dir, o.from), r), ub = dot(add(f.a, f.dir, o.to), r);
  return [Math.min(ua, ub), Math.max(ua, ub)];
}

export function buildElevations(s: {
  entities: Entity[]; units: Units; paper: Paper; heights: Heights;
  project: { code: string; name: string }; drawingName: string; preparedBy: string; date: string; northDeg: number | null;
}) {
  const mpu = metresPerUnit(s.units);
  if (mpu === null) throw new Error('Drawing units are not defined.');
  const M = 1 / mpu, mm = 0.001 / mpu, H = s.heights;
  const warnings: string[] = [];
  const walls = s.entities.filter((e) => e.type === 'WALL') as Extract<Entity, { type: 'WALL' }>[];
  if (!walls.length) throw new Error('Elevations and sections need typed walls (draw them with the Wall tool or generate the plan from a reference).');
  const openings = s.entities.filter(isOpening);
  const rooms = extractRooms(s.entities, s.units).filter((r) => r.valid);
  const inRoom = (p: Pt) => rooms.some((r) => pointInPolygon(p, r.points));
  const eps = 1 * mm;

  // ---- levels (drawing units, z = 0 at natural ground) ----
  const plinth = H.plinth_m * M, slab = H.slab_m * M;
  const levels = [plinth];
  for (const f of H.floors) levels.push(levels[levels.length - 1] + f.height_m * M);
  const roof = levels[levels.length - 1], parapetTop = roof + H.parapet_m * M;
  const doorHead = plinth + H.door_head_m * M, sill = plinth + H.sill_m * M, winHead = plinth + H.window_head_m * M;

  // ---- faces: both sides of every wall, with openings ----
  const faces: Face[] = [];
  for (const w of walls) {
    const { len, dir, normal } = wallFrame(w.geom);
    const h = w.geom.thickness / 2;
    const ops = openings.filter((o) => (o.geom as any).wallId === w.id).map((o) => ({ type: o.type as 'DOOR' | 'WINDOW', from: (o.geom as any).offset - (o.geom as any).width / 2, to: (o.geom as any).offset + (o.geom as any).width / 2 }));
    const mid = add(w.geom.a, dir, len / 2);
    for (const side of [1, -1]) {
      const out = { x: normal.x * side, y: normal.y * side };
      const external = !inRoom(add(mid, out, h + 50 * mm)) && inRoom(add(mid, out, -(h + 50 * mm)));
      faces.push({ a: add(w.geom.a, out, h), b: add(w.geom.b, out, h), out, dir, len, external, openings: ops });
    }
  }
  const ext = faces.filter((f) => f.external);
  if (!ext.length) throw new Error('No external wall faces were found: rooms must be enclosed by typed walls.');

  const views: { title: string; rects: { kind: 'wall' | 'slab'; r: Rect }[]; lines: [number, number, number, number, string][]; texts: [number, number, string, number][]; dims: [Pt, Pt, Pt][]; w: number; h: number; place?: Pt }[] = [];
  const zTop = parapetTop;
  const levelNames = ['FFL GROUND', ...H.floors.slice(1).map((f) => `FFL ${f.name}`), 'ROOF (TOS)'];
  const levelLabel = (z: number) => `${((z - plinth) / M >= 0 ? '+' : '')}${((z - plinth) / M).toFixed(3)}`;

  // ---- elevations ----
  const dirs: [Pt, string][] = [[{ x: 0, y: 1 }, 'VIEW TOWARDS +Y'], [{ x: 0, y: -1 }, 'VIEW TOWARDS -Y'], [{ x: 1, y: 0 }, 'VIEW TOWARDS +X'], [{ x: -1, y: 0 }, 'VIEW TOWARDS -X']];
  dirs.forEach(([d, label], vi) => {
    const r = { x: d.y, y: -d.x };
    const pieces = visiblePieces(ext.filter((f) => dot(f.out, d) < -0.3), d, r, eps, (f) => dot(add(f.a, f.dir, f.len / 2), d));
    if (!pieces.length) { warnings.push(`Elevation ${vi + 1}: no visible faces.`); return; }
    const u0 = Math.min(...pieces.map((p) => p.u0)), u1 = Math.max(...pieces.map((p) => p.u1));
    const X = (u: number) => u - u0;
    const v: (typeof views)[number] = { title: `ELEVATION ${vi + 1} - ${label}`, rects: [], lines: [], texts: [], dims: [], w: X(u1), h: zTop };
    v.lines.push([X(u0) - 1.5 * M, 0, X(u1) + 1.5 * M, 0, 'A-ELEV-GRND']);
    for (const p of pieces) {
      v.lines.push([X(p.u0), 0, X(p.u0), zTop, 'A-ELEV-OTLN'], [X(p.u1), 0, X(p.u1), zTop, 'A-ELEV-OTLN'], [X(p.u0), zTop, X(p.u1), zTop, 'A-ELEV-OTLN']);
      v.lines.push([X(p.u0), plinth, X(p.u1), plinth, 'A-ELEV-SLAB']);
      for (const z of levels.slice(1)) v.lines.push([X(p.u0), z, X(p.u1), z, 'A-ELEV-SLAB'], [X(p.u0), z - slab, X(p.u1), z - slab, 'A-ELEV-SLAB']);
      for (const o of p.face.openings) {
        const [a, b] = openingSpan(p.face, o, r);
        if (b <= p.u0 + eps || a >= p.u1 - eps) continue;
        const [za, zb] = o.type === 'DOOR' ? [plinth, doorHead] : [sill, winHead];
        const f = 50 * mm;
        const xa = X(Math.max(a, p.u0)), xb = X(Math.min(b, p.u1));
        v.lines.push([xa, za, xb, za, 'A-ELEV-OPEN'], [xb, za, xb, zb, 'A-ELEV-OPEN'], [xb, zb, xa, zb, 'A-ELEV-OPEN'], [xa, zb, xa, za, 'A-ELEV-OPEN']);
        v.lines.push([xa + f, za + (o.type === 'DOOR' ? 0 : f), xb - f, za + (o.type === 'DOOR' ? 0 : f), 'A-ELEV-OPEN'], [xb - f, za, xb - f, zb - f, 'A-ELEV-OPEN'], [xb - f, zb - f, xa + f, zb - f, 'A-ELEV-OPEN'], [xa + f, zb - f, xa + f, za, 'A-ELEV-OPEN']);
        if (o.type === 'WINDOW') v.lines.push([(xa + xb) / 2, za + f, (xa + xb) / 2, zb - f, 'A-ELEV-OPEN']);
      }
    }
    // height chain on the right, overall width below
    const xd = X(u1) + 1.6 * M;
    const zs = [0, plinth, ...levels.slice(1), parapetTop];
    for (let i = 0; i + 1 < zs.length; i++) v.dims.push([{ x: X(u1), y: zs[i] }, { x: X(u1), y: zs[i + 1] }, { x: xd, y: (zs[i] + zs[i + 1]) / 2 }]);
    v.dims.push([{ x: X(u0), y: 0 }, { x: X(u1), y: 0 }, { x: (X(u0) + X(u1)) / 2, y: -1.4 * M }]);
    levels.forEach((z, i) => v.texts.push([X(u0) - 3.6 * M, z + 0.1 * M, `${levelNames[i] ?? ''} ${levelLabel(z)}`, 1.6]));
    v.texts.push([X(u0) - 3.6 * M, parapetTop + 0.1 * M, `TOP PARAPET ${levelLabel(parapetTop)}`, 1.6]);
    views.push(v);
  });

  // ---- section A-A: horizontal cut, looking towards +Y ----
  const all = rooms.flatMap((r) => r.points);
  const minY = Math.min(...all.map((p) => p.y)), maxY = Math.max(...all.map((p) => p.y));
  let yc = (minY + maxY) / 2;
  const nearHorizontalWall = (y: number) => walls.some((w) => { const { dir } = wallFrame(w.geom); return Math.abs(dir.y) < 0.2 && Math.abs((w.geom.a.y + w.geom.b.y) / 2 - y) < w.geom.thickness / 2 + 0.4 * M; });
  for (let k = 1; k < 12 && nearHorizontalWall(yc); k++) yc = (minY + maxY) / 2 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * 0.6 * M;
  const sec: (typeof views)[number] = { title: 'SECTION A-A - LOOKING TOWARDS +Y', rects: [], lines: [], texts: [], dims: [], w: 0, h: zTop };
  type Cut = { x: number; w: number; gaps: [number, number][] };
  const cuts: Cut[] = [];
  for (const w of walls) {
    const { len, dir } = wallFrame(w.geom);
    if (Math.abs(w.geom.b.y - w.geom.a.y) < eps) continue;
    const t = (yc - w.geom.a.y) / (w.geom.b.y - w.geom.a.y);
    if (t <= 0 || t >= 1) continue;
    const x = w.geom.a.x + t * (w.geom.b.x - w.geom.a.x), sAlong = t * len;
    const width = w.geom.thickness / Math.abs(dir.y);
    const gaps = openings.filter((o) => (o.geom as any).wallId === w.id && Math.abs((o.geom as any).offset - sAlong) < (o.geom as any).width / 2)
      .map((o) => (o.type === 'DOOR' ? [plinth, doorHead] : [sill, winHead]) as [number, number]);
    cuts.push({ x, w: width, gaps });
  }
  if (!cuts.length) throw new Error('The section line does not cut any wall.');
  const xL = Math.min(...cuts.map((c) => c.x - c.w / 2)), xR = Math.max(...cuts.map((c) => c.x + c.w / 2));
  const SX = (x: number) => x - xL;
  sec.w = SX(xR);
  for (const c of cuts) {
    const x0 = SX(c.x - c.w / 2), x1 = SX(c.x + c.w / 2);
    for (let f = 0; f < H.floors.length; f++) {
      let z0 = levels[f], z1 = levels[f + 1] - slab;
      const gs = f === 0 ? [...c.gaps].sort((a, b) => a[0] - b[0]) : [];
      for (const [ga, gb] of gs) { if (ga > z0 + eps) sec.rects.push({ kind: 'wall', r: [x0, z0, x1, ga] }); z0 = Math.max(z0, gb); }
      if (z1 > z0 + eps) sec.rects.push({ kind: 'wall', r: [x0, z0, x1, z1] });
    }
    const isOuter = Math.abs(c.x - c.w / 2 - xL) < eps || Math.abs(c.x + c.w / 2 - xR) < eps;
    if (isOuter && H.parapet_m > 0) sec.rects.push({ kind: 'wall', r: [x0, roof, x1, parapetTop] });
  }
  sec.rects.push({ kind: 'slab', r: [SX(xL), plinth - slab, SX(xR), plinth] });
  for (const z of levels.slice(1)) sec.rects.push({ kind: 'slab', r: [SX(xL), z - slab, SX(xR), z] });
  sec.lines.push([SX(xL) - 1.5 * M, 0, SX(xR) + 1.5 * M, 0, 'A-SECT-GRND']);
  // beyond: wall faces behind the cut that face the viewer
  const beyond = faces.filter((f) => f.out.y < -0.3 && Math.min(f.a.y, f.b.y) > yc + eps);
  for (const p of visiblePieces(beyond, { x: 0, y: 1 }, { x: 1, y: 0 }, eps, (f) => (f.a.y + f.b.y) / 2)) {
    const a = Math.max(p.u0, xL), b = Math.min(p.u1, xR);
    if (b - a <= eps) continue;
    for (let f = 0; f < H.floors.length; f++) {
      const z0 = levels[f], z1 = levels[f + 1] - slab;
      sec.lines.push([SX(a), z0, SX(a), z1, 'A-SECT-BYND'], [SX(b), z0, SX(b), z1, 'A-SECT-BYND']);
    }
    for (const o of p.face.openings) {
      const [oa, ob] = openingSpan(p.face, o, { x: 1, y: 0 });
      const xa = Math.max(oa, a), xb = Math.min(ob, b);
      if (xb - xa <= eps) continue;
      const [za, zb] = o.type === 'DOOR' ? [plinth, doorHead] : [sill, winHead];
      sec.lines.push([SX(xa), za, SX(xb), za, 'A-SECT-BYND'], [SX(xb), za, SX(xb), zb, 'A-SECT-BYND'], [SX(xb), zb, SX(xa), zb, 'A-SECT-BYND'], [SX(xa), zb, SX(xa), za, 'A-SECT-BYND']);
    }
  }
  // room names along the cut
  for (const r of rooms) {
    const xs: number[] = [];
    r.points.forEach((p, i) => { const q = r.points[(i + 1) % r.points.length]; if ((p.y - yc) * (q.y - yc) < 0) xs.push(p.x + ((yc - p.y) / (q.y - p.y)) * (q.x - p.x)); });
    if (xs.length >= 2) sec.texts.push([SX((Math.min(...xs) + Math.max(...xs)) / 2) - 1.2 * M, plinth + 1.1 * M, r.name ?? '', 2.5]);
  }
  for (let f = 1; f < H.floors.length; f++) sec.texts.push([SX(xL) + 0.6 * M, levels[f] + 1.1 * M, `${H.floors[f].name} - LAYOUT NOT DESIGNED`, 2.2]);
  const zs = [0, plinth, ...levels.slice(1), parapetTop];
  for (let i = 0; i + 1 < zs.length; i++) sec.dims.push([{ x: SX(xR), y: zs[i] }, { x: SX(xR), y: zs[i + 1] }, { x: SX(xR) + 1.6 * M, y: (zs[i] + zs[i + 1]) / 2 }]);
  sec.dims.push([{ x: SX(xL), y: plinth }, { x: SX(xR), y: plinth }, { x: (SX(xL) + SX(xR)) / 2, y: -1.4 * M }]);
  levels.forEach((z, i) => sec.texts.push([SX(xL) - 3.6 * M, z + 0.1 * M, `${levelNames[i] ?? ''} ${levelLabel(z)}`, 1.6]));
  views.push(sec);

  // ---- arrange views: two per row, section on the last row ----
  const gapX = 7.5 * M, gapY = 6 * M;
  const rows: (typeof views)[] = [];
  const elevs = views.slice(0, -1);
  for (let i = 0; i < elevs.length; i += 2) rows.push(elevs.slice(i, i + 2));
  rows.push([sec]);
  let y = 0;
  for (const row of [...rows].reverse()) {
    let x = 0;
    for (const v of row) { v.place = { x, y }; x += v.w + gapX; }
    y += Math.max(...row.map((v) => v.h)) + gapY;
  }
  const W = (v: (typeof views)[number], x: number, z: number): Pt => ({ x: v.place!.x + x, y: v.place!.y + z });
  const content: BBox = { minX: -4 * M, minY: -3.5 * M, maxX: Math.max(...views.map((v) => v.place!.x + v.w)) + 2.5 * M, maxY: y - gapY + 1 * M };

  const dxf: EntityInput[] = [];
  const L = layoutSheet({ content, paper: s.paper, mm, pad: 0.5 * M, out: dxf, northDeg: s.northDeg,
    title: { project: s.project, drawingName: s.drawingName, sheetTitle: 'ELEVATIONS AND SECTION A-A', units: s.units, date: s.date, preparedBy: s.preparedBy } });
  warnings.push(...L.warnings);
  const { k } = L;
  for (const v of views) {
    for (const [x1, z1, x2, z2, layer] of v.lines) dxf.push({ type: 'LINE', layer, geom: { a: W(v, x1, z1), b: W(v, x2, z2) } });
    for (const [x, z, t, h] of v.texts) dxf.push({ type: 'TEXT', layer: 'A-ANNO-TEXT', geom: { p: W(v, x, z), h: h * k, rot: 0, text: t } });
    dxf.push({ type: 'TEXT', layer: 'A-ANNO-TTLV', geom: { p: W(v, 0, -3.2 * M), h: 4 * k, rot: 0, text: v.title } });
  }

  // key plan, heights table and notes in the panel
  const kp = L.px + 10, kpTop = L.paper.h - 45, kpW = 160, kpH = 95;
  const bx = { minX: Math.min(...all.map((p) => p.x)), maxX: Math.max(...all.map((p) => p.x)), minY, maxY };
  const ks = Math.min(kpW / (bx.maxX - bx.minX), kpH / (bx.maxY - bx.minY)) * 0.8;
  const K = (p: Pt) => L.S(kp + (p.x - bx.minX) * ks + 8, kpTop - kpH + (p.y - bx.minY) * ks + 8);
  L.text('A-ANNO-KEYP', kp, kpTop + 4, 3.5, 'KEY PLAN');
  for (const r of rooms) dxf.push({ type: 'POLYLINE', layer: 'A-ANNO-KEYP', geom: { points: r.points.map(K), closed: true } });
  const ca = K({ x: bx.minX - 1.5 * M, y: yc }), cb = K({ x: bx.maxX + 1.5 * M, y: yc });
  dxf.push({ type: 'LINE', layer: 'A-ANNO-KEYP', geom: { a: ca, b: cb } });
  dxf.push({ type: 'TEXT', layer: 'A-ANNO-KEYP', geom: { p: ca, h: 3 * k, rot: 0, text: 'A' } }, { type: 'TEXT', layer: 'A-ANNO-KEYP', geom: { p: cb, h: 3 * k, rot: 0, text: 'A' } });
  const midP = { x: (bx.minX + bx.maxX) / 2, y: (minY + maxY) / 2 };
  const arrowAt: Pt[] = [{ x: midP.x, y: bx.minY - 2.5 * M }, { x: midP.x, y: bx.maxY + 2.5 * M }, { x: bx.minX - 2.5 * M, y: midP.y }, { x: bx.maxX + 2.5 * M, y: midP.y }];
  arrowAt.forEach((p, i) => dxf.push({ type: 'TEXT', layer: 'A-ANNO-KEYP', geom: { p: K(p), h: 3 * k, rot: 0, text: String(i + 1) } }));
  let ty = kpTop - kpH - 10;
  const note = (t: string, h = 2.2) => { L.text('A-ANNO-NOTE', kp, ty, h, t); ty -= h + 2.5; };
  note('HEIGHTS USED', 3.2);
  H.floors.forEach((f) => note(`${f.name}: floor-to-floor ${f.height_m.toFixed(2)} m`));
  note(`Slab ${H.slab_m.toFixed(2)} m  Parapet ${H.parapet_m.toFixed(2)} m  Plinth ${H.plinth_m.toFixed(2)} m`);
  note(`Door head ${H.door_head_m.toFixed(2)} m  Window sill ${H.sill_m.toFixed(2)} m  head ${H.window_head_m.toFixed(2)} m`);
  note(`Source: ${H.source.slice(0, 70)}`);
  ty -= 3;
  note('NOTES', 3.2);
  note('Levels relative to ground floor FFL (+0.000). Dimensions in mm.');
  note('Elevation directions refer to drawing axes (see key plan).');
  if (H.floors.length > 1) note('Upper floors shown as massing over the ground-floor walls; their layouts and openings are not designed.');
  note('Only ground-floor openings are shown. Roof, stair, finishes and structure not designed.');

  // ---- script: hatch cut walls and slabs, dimensions ----
  const script: string[] = [...scriptHeader(s.units, k, mpu), '_.-LAYER _M A-SECT-PATT _C 8 A-SECT-PATT _M A-SECT-CUT _C 7 A-SECT-CUT ', '_.HPLAYER A-SECT-PATT'];
  let hatches = 0;
  for (const { kind, r } of sec.rects) {
    const [x0, z0, x1, z1] = r;
    if (x1 - x0 <= eps || z1 - z0 <= eps) continue;
    script.push(...hatchCmds([W(sec, x0, z0), W(sec, x1, z0), W(sec, x1, z1), W(sec, x0, z1)], kind === 'wall' ? 'ANSI31' : 'SOLID', k * 0.6));
    hatches++;
  }
  script.push('_.-LAYER _M A-DIMS _C 8 A-DIMS ');
  let dims = 0;
  for (const v of views) for (const [a, b, at] of v.dims) { script.push(`_.DIMLINEAR ${fmtP(W(v, a.x, a.y))} ${fmtP(W(v, b.x, b.y))} ${fmtP(W(v, at.x, at.y))}`); dims++; }

  return {
    dxf, script, warnings, plot: L.plot,
    expect: { hatches, dimensions: dims },
    report: { scale: `1:${L.den}`, paper: s.paper, elevations: views.length - 1, sectionCutY: +(yc * mpu).toFixed(3), cutWalls: cuts.length, floors: H.floors.length, totalHeight_m: +((parapetTop) * mpu).toFixed(3) },
  };
}
