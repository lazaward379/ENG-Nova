import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { useT } from '../i18n';
import { Icon, Loading, Modal, Status, bytes, useApp, useLoad, when } from '../ui';

const TABS: [string, string, string][] = [
  ['overview', 'proj.wizard.step1', 'Description'], ['plot', 'proj.wizard.step2', 'Plot'], ['requirements', 'proj.wizard.step3', 'Requirements'],
  ['intake', 'proj.wizard.step4', 'Documents'], ['readiness', 'proj.wizard.step5', 'Readiness'],
];
const CLASSES = ['confirmed', 'extracted', 'assumption', 'ai_suggestion', 'unresolved'];

const PLOT_KEYS: [string, string, string | null][] = [
  ['plot_id', 'Plot identifier', null], ['plot_area_m2', 'Plot area (official)', 'm²'], ['crs', 'Coordinate reference system', null],
  ['north_direction', 'North direction (bearing of +Y)', '°'], ['road_frontage', 'Road frontage / access points', null], ['levels', 'Levels & topography', null],
  ['max_plot_coverage_pct', 'Maximum plot coverage', '%'], ['setbacks', 'Setback requirements', null], ['development_conditions', 'Applicable development conditions', null],
];
const REQ_KEYS: [string, string, string | null][] = [
  ['floors', 'Required floors', null], ['gross_area_target_m2', 'Approximate area target', 'm²'], ['bedrooms', 'Bedrooms', null], ['parking_spaces', 'Parking spaces', null],
  ['structural_system', 'Structural system preference', null], ['mep_requirements', 'MEP requirements', null], ['design_language', 'Preferred design language', null],
  ['accessibility', 'Accessibility requirements', null], ['target_authority', 'Target authority / client workflow', null], ['deliverables', 'Required deliverables', null],
  ['sheet_format', 'Sheet formats & scales', null],
];

export function ProjectDetail({ id, tab }: { id: string; tab: string }) {
  const { setProject, go } = useApp();
  const { t } = useT();
  const p = useLoad(() => api.get(`/api/projects/${id}`), [id]);
  useEffect(() => { setProject(id); }, [id]);
  if (!p.data) return <Loading error={p.error} loading={p.loading} />;
  const d = p.data;
  const idx = TABS.findIndex((x) => x[0] === tab);
  return (
    <div>
      <div className="page-h">
        <div><div className="eyebrow ltr">{d.code}</div><h1>{d.name}</h1><div className="sub">{d.project_type} · <span className="chip">{d.status}</span></div></div>
        <span className="spacer" />
        {d.drawings[0] && <button className="btn" onClick={() => go(`workspace/${d.drawings[0].id}`)}><Icon name="workspace" />{t('nav.workspace', 'CAD workspace')}</button>}
      </div>
      <div className="steps">{TABS.map(([k, key, en], i) => (
        <a key={k} href={`#/project/${id}/${k}`} className={`step ${k === tab ? 'active' : i < idx ? 'done' : ''}`}><b>{i + 1}</b>{t(key, en)}</a>
      ))}</div>
      {tab === 'overview' && <Overview p={d} reload={p.reload} />}
      {tab === 'plot' && <FactsEditor p={d} reload={p.reload} keys={PLOT_KEYS} title={t('proj.wizard.step2', 'Plot information')} note="Never enter values that are not in an authoritative document; leave them missing instead. Setbacks and coverage must come from the plot's official planning document." />}
      {tab === 'requirements' && <Requirements p={d} reload={p.reload} />}
      {tab === 'intake' && <Intake p={d} reload={p.reload} />}
      {tab === 'readiness' && <Readiness id={id} />}
      {idx >= 0 && idx < TABS.length - 1 && <div className="row end" style={{ marginTop: 16 }}><a className="btn" href={`#/project/${id}/${TABS[idx + 1][0]}`}>{t('proj.next', 'Next')}: {t(TABS[idx + 1][1], TABS[idx + 1][2])} →</a></div>}
    </div>
  );
}

function Overview({ p, reload }: { p: any; reload: () => void }) {
  const { toast, can } = useApp();
  const { t } = useT();
  const [f, setF] = useState({ name: p.name, description: p.description, project_type: p.project_type, status: p.status });
  const save = async () => {
    try { await api.patch(`/api/projects/${p.id}`, f); toast('Saved', 'ok'); reload(); } catch (e: any) { toast(e.message, 'error'); }
  };
  return (
    <div className="card stack">
      <label className="field">{t('proj.name', 'Name')}<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
      <label className="field">{t('proj.description', 'Description')}<textarea rows={6} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></label>
      <div className="grid c2">
        <label className="field">{t('proj.type', 'Type')}<input value={f.project_type} onChange={(e) => setF({ ...f, project_type: e.target.value })} /></label>
        <label className="field">{t('common.status', 'Status')}<select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>{['intake', 'design', 'review', 'archived'].map((s) => <option key={s}>{s}</option>)}</select></label>
      </div>
      <div className="row end"><button className="btn primary" disabled={!can('engineer')} onClick={save}>{t('common.save', 'Save')}</button></div>
    </div>
  );
}

function FactRow({ p, k, label, unit, fact, reload }: { p: any; k: string; label: string; unit: string | null; fact: any; reload: () => void }) {
  const { toast, can } = useApp();
  const [f, setF] = useState({ value: fact?.value ?? '', class: fact?.class ?? 'confirmed', source: fact?.source ?? '' });
  const dirty = f.value !== (fact?.value ?? '') || f.class !== (fact?.class ?? 'confirmed') || f.source !== (fact?.source ?? '');
  const save = async () => {
    try { await api.put(`/api/projects/${p.id}/facts`, { key: k, value: f.value, unit, class: f.class, source: f.source }); toast(`${k} saved`, 'ok'); reload(); }
    catch (e: any) { toast(e.message, 'error'); }
  };
  return (
    <tr>
      <td><div>{label}</div><div className="faint mono ltr">{k}{unit ? ` (${unit})` : ''}</div></td>
      <td><input value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} placeholder="missing" /></td>
      <td><select value={f.class} onChange={(e) => setF({ ...f, class: e.target.value })}>{CLASSES.map((c) => <option key={c}>{c}</option>)}</select></td>
      <td><input value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })} placeholder="document / authority / person" />
        {fact?.source_document && <div className="faint">from {fact.source_document} · {fact.confidence}</div>}</td>
      <td style={{ whiteSpace: 'nowrap' }}>
        <button className="btn sm" disabled={!dirty || !f.value || !can('engineer')} onClick={save}><Icon name="check" /></button>
        {fact && <button className="btn sm ghost" disabled={!can('engineer')} onClick={async () => { await api.del(`/api/projects/${p.id}/facts/${k}`); reload(); }}><Icon name="trash" /></button>}
      </td>
    </tr>
  );
}

function FactsEditor({ p, reload, keys, title, note }: { p: any; reload: () => void; keys: [string, string, string | null][]; title: string; note: string }) {
  const { t } = useT();
  const byKey = new Map(p.facts.map((f: any) => [f.key, f]));
  const extra = p.facts.filter((f: any) => !keys.some(([k]) => k === f.key) && !f.key.startsWith('space_') && f.class !== 'ai_suggestion');
  return (
    <div className="card">
      <div className="card-h"><h2>{title}</h2></div>
      <div className="notice info" style={{ marginBottom: 12 }}>{note}</div>
      <div className="table-wrap"><table className="t">
        <thead><tr><th>{t('proj.key', 'Item')}</th><th>{t('proj.value', 'Value')}</th><th>{t('proj.class', 'Class')}</th><th>{t('proj.source', 'Source')}</th><th /></tr></thead>
        <tbody>{keys.map(([k, label, unit]) => <FactRow key={k + (byKey.get(k) as any)?.created_at} p={p} k={k} label={label} unit={unit} fact={byKey.get(k)} reload={reload} />)}</tbody>
      </table></div>
      {extra.length > 0 && <>
        <h3 style={{ margin: '16px 0 6px' }}>{t('proj.extracted', 'Other recorded facts')}</h3>
        <table className="t"><tbody>{extra.map((f: any) => <tr key={f.key}><td className="mono ltr">{f.key}</td><td>{f.value} {f.unit}</td><td><span className={`chip c-${f.class}`}>{f.class}</span></td><td className="faint">{f.source} {f.confidence && `· ${f.confidence}`}</td></tr>)}</tbody></table>
      </>}
    </div>
  );
}

function Requirements({ p, reload }: { p: any; reload: () => void }) {
  const { toast, can, me } = useApp();
  const { t } = useT();
  const suggestions = p.facts.filter((f: any) => f.class === 'ai_suggestion');
  const interpret = async () => {
    try { const r = await api.post(`/api/projects/${p.id}/interpret-requirements`); toast(`${r.added.length} new suggestion(s)`, 'ok'); reload(); } catch (e: any) { toast(e.message, 'error'); }
  };
  const confirm = async (f: any) => {
    await api.put(`/api/projects/${p.id}/facts`, { key: f.key, value: f.value, unit: f.unit, class: 'confirmed', source: `confirmed by ${me.name} from project brief (${f.source})` });
    reload();
  };
  return (
    <div className="stack">
      <div className="card">
        <div className="card-h"><Icon name="assistant" /><h2>{t('nav.requirements', 'Requirements interpreter')}</h2><span className="spacer" />
          <button className="btn" disabled={!can('engineer') || !p.description} onClick={interpret}>{t('proj.interpret', 'Extract from description')}</button></div>
        <p className="muted" style={{ marginTop: 0 }}>“{p.description || '—'}”</p>
        <div className="notice violet">Offline keyword interpreter. Results are <b>AI suggestions</b> with the text that triggered them. Confirm only what is correct.</div>
        {suggestions.length ? (
          <table className="t" style={{ marginTop: 10 }}><tbody>{suggestions.map((f: any) => (
            <tr key={f.key}><td className="mono ltr">{f.key}</td><td>{f.value}</td><td className="faint">{f.source}</td>
              <td style={{ whiteSpace: 'nowrap' }}><button className="btn sm" disabled={!can('engineer')} onClick={() => confirm(f)}><Icon name="check" />{t('proj.confirm', 'Confirm')}</button>
                <button className="btn sm ghost" disabled={!can('engineer')} onClick={async () => { await api.del(`/api/projects/${p.id}/facts/${f.key}`); reload(); }}><Icon name="x" /></button></td></tr>))}</tbody></table>
        ) : <div className="empty">No pending suggestions.</div>}
      </div>
      <FactsEditor p={p} reload={reload} keys={REQ_KEYS} title={t('proj.wizard.step3', 'Building requirements')} note="Defaults are never filled in for you. Anything you enter as an assumption stays labelled as an assumption in reports." />
    </div>
  );
}

function Intake({ p, reload }: { p: any; reload: () => void }) {
  const { toast, go, can, setDrawing } = useApp();
  const { t, lang } = useT();
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState<string[]>([]);
  const [last, setLast] = useState<any[]>([]);
  const [csvFor, setCsvFor] = useState<any | null>(null);
  const [blank, setBlank] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  const upload = async (files: FileList | null) => {
    if (!files?.length) return;
    for (const f of Array.from(files)) {
      setBusy((b) => [...b, f.name]);
      try {
        const r = await api.upload(`/api/projects/${p.id}/documents`, f);
        setLast((l) => [{ name: f.name, ...r }, ...l]);
        toast(`${f.name}: ${r.extraction_status}`, r.extraction_status === 'failed' ? 'error' : 'ok');
      } catch (e: any) { toast(`${f.name}: ${e.message}`, 'error'); }
      setBusy((b) => b.filter((x) => x !== f.name));
    }
    reload();
  };

  return (
    <div className="stack">
      {can('engineer') && (
        <div className={`drop ${over ? 'over' : ''}`} onClick={() => input.current?.click()} onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
          onDrop={(e) => { e.preventDefault(); setOver(false); upload(e.dataTransfer.files); }} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && input.current?.click()}>
          <Icon name="intake" size={26} />
          <div style={{ marginTop: 6 }}>{t('proj.dropHint', 'Drop files here or click — DXF, DWG, IFC, PDF, PNG, JPG, CSV, XLSX, DOCX (max 50 MB)')}</div>
          {busy.length > 0 && <div className="faint" style={{ marginTop: 6 }}><span className="ai-dot" style={{ display: 'inline-block', marginInlineEnd: 6 }} />{busy.join(', ')}</div>}
          <input ref={input} type="file" multiple hidden onChange={(e) => { upload(e.target.files); e.target.value = ''; }} accept=".dxf,.dwg,.ifc,.pdf,.png,.jpg,.jpeg,.csv,.xlsx,.docx" />
        </div>
      )}
      {last.filter((l) => l.diagnostics).map((l) => (
        <div key={l.id} className="card">
          <div className="card-h"><h3>{t('ws.diagnostics', 'Import diagnostics')} — {l.name}</h3><span className="spacer" />
            {l.drawingId && <button className="btn primary sm" onClick={() => { setDrawing(l.drawingId); go(`workspace/${l.drawingId}`); }}><Icon name="workspace" />{t('common.open', 'Open')}</button>}</div>
          <div className="grid c3">
            <div><div className="faint">Units</div><b>{l.diagnostics.units}</b> <span className="faint">({l.diagnostics.unitsSource})</span></div>
            <div><div className="faint">Imported</div><span className="mono">{JSON.stringify(l.diagnostics.imported)}</span></div>
            <div><div className="faint">Not imported</div><span className="mono">{JSON.stringify(l.diagnostics.skipped)}</span></div>
          </div>
          {l.diagnostics.warnings.map((w: string) => <div key={w} className="notice" style={{ marginTop: 8 }}>{w}</div>)}
        </div>
      ))}

      <div className="card">
        <div className="card-h"><h2>{t('proj.documents', 'Document register')}</h2></div>
        {p.documents.length ? <div className="table-wrap"><table className="t">
          <thead><tr><th>{lang === 'ar' ? 'الملف' : 'File'}</th><th>Type</th><th>Origin</th><th>Classification</th><th>Extraction</th><th>Notes / warnings</th><th>SHA-256</th><th /></tr></thead>
          <tbody>{p.documents.map((d: any) => (
            <tr key={d.id}>
              <td><span className="ltr">{d.original_name}</span><div className="faint">{bytes(d.size_bytes)} · {when(d.created_at)}</div></td>
              <td className="mono">{d.ext}</td>
              <td><span className={`chip ${d.origin === 'upload' ? 'c-confirmed' : 'c-ai_suggestion'}`}>{d.origin === 'upload' ? 'original' : 'generated'}</span></td>
              <td>{d.classification}</td>
              <td><span className={`chip ${d.extraction_status === 'failed' ? 'c-unresolved' : d.extraction_status === 'parsed' ? 'c-confirmed' : ''}`}>{d.extraction_status}</span></td>
              <td style={{ maxWidth: 380 }}>{d.extraction_notes.map((n: string, i: number) => <div key={i} className="faint">• {n}</div>)}</td>
              <td className="mono faint ltr" title={d.sha256}>{d.sha256.slice(0, 12)}…</td>
              <td style={{ whiteSpace: 'nowrap' }}>
                <button className="btn sm ghost" onClick={() => api.download(`/api/documents/${d.id}/download`, d.original_name).catch((e) => toast(e.message, 'error'))}><Icon name="download" /></button>
                {d.ext === 'csv' && d.extraction_status === 'parsed' && can('engineer') && <button className="btn sm" onClick={() => setCsvFor(d)}>{t('proj.toDrawing', 'To drawing')}</button>}
              </td>
            </tr>))}</tbody></table></div> : <div className="empty">{t('common.none', 'No documents yet.')}</div>}
      </div>

      <div className="card">
        <div className="card-h"><h2>{t('proj.drawings', 'Drawings')}</h2><span className="spacer" />{can('engineer') && <button className="btn sm" onClick={() => setBlank(true)}><Icon name="plus" />{t('proj.newDrawing', 'New blank drawing')}</button>}</div>
        {p.drawings.length ? <table className="t"><tbody>{p.drawings.map((d: any) => (
          <tr key={d.id} className="click" onClick={() => { setDrawing(d.id); go(`workspace/${d.id}`); }}><td>{d.name}</td><td className="mono">{d.units}</td><td>{d.entities} entities</td><td className="faint">{when(d.updated_at)}</td></tr>
        ))}</tbody></table> : <div className="empty">{t('common.none', 'No drawings yet — upload a DXF or survey CSV.')}</div>}
      </div>

      {csvFor && <UnitsModal title={`${t('proj.toDrawing', 'Convert to drawing')}: ${csvFor.original_name}`} onClose={() => setCsvFor(null)}
        note="The CSV does not state its units or CRS. Choose the unit the surveyor used; coordinates are kept exactly as given."
        onSubmit={async (units) => { const r = await api.post(`/api/documents/${csvFor.id}/to-drawing`, { units }); setCsvFor(null); reload(); setDrawing(r.id); go(`workspace/${r.id}`); }} />}
      {blank && <UnitsModal title={t('proj.newDrawing', 'New blank drawing')} withName onClose={() => setBlank(false)}
        onSubmit={async (units, name) => { const r = await api.post(`/api/projects/${p.id}/drawings`, { units, name }); setBlank(false); setDrawing(r.id); go(`workspace/${r.id}`); }} />}
    </div>
  );
}

function UnitsModal({ title, note, withName, onClose, onSubmit }: { title: string; note?: string; withName?: boolean; onClose: () => void; onSubmit: (units: string, name: string) => Promise<void> }) {
  const [units, setUnits] = useState('');
  const [name, setName] = useState('');
  const [err, setErr] = useState<string | null>(null);
  return (
    <Modal title={title} onClose={onClose}>
      <div className="stack">
        {note && <div className="notice">{note}</div>}
        {withName && <label className="field">Name<input value={name} onChange={(e) => setName(e.target.value)} /></label>}
        <label className="field">Units<select value={units} onChange={(e) => setUnits(e.target.value)}><option value="">— choose —</option>{['mm', 'cm', 'm', 'in', 'ft'].map((u) => <option key={u}>{u}</option>)}</select></label>
        {err && <div className="notice">{err}</div>}
        <div className="row end"><button className="btn primary" disabled={!units || (withName && !name)} onClick={() => onSubmit(units, name).catch((e) => setErr(e.message))}>Create</button></div>
      </div>
    </Modal>
  );
}

function Readiness({ id }: { id: string }) {
  const { t, lang } = useT();
  const { go } = useApp();
  const r = useLoad(() => api.get(`/api/projects/${id}/readiness`), [id]);
  if (!r.data) return <Loading error={r.error} loading={r.loading} />;
  const d = r.data;
  const L = (x: any) => (lang === 'ar' ? x.label_ar : x.label);
  return (
    <div className="stack">
      <div className="card glow">
        <div className="card-h"><div className="ai-dot" /><h2>{t('proj.nextAction', 'Recommended next action')}</h2><span className="spacer" /><button className="btn sm ghost" onClick={r.reload}><Icon name="rotate" /></button></div>
        <p style={{ margin: 0, fontSize: 15 }}>{lang === 'ar' ? d.next_action.ar : d.next_action.en}</p>
        <div className="row" style={{ marginTop: 10 }}>
          <span className={`chip ${d.ready_for_design ? 'c-confirmed' : 'c-unresolved'}`}>design inputs: {d.ready_for_design ? 'complete' : 'incomplete'}</span>
          <span className="chip c-unresolved">submission: not assessable</span>
          <span className="chip">verified regulatory sources: {d.verified_regulatory_sources}</span>
          {d.drawing_id && <button className="btn sm" onClick={() => go(`workspace/${d.drawing_id}`)}>{t('nav.workspace', 'Open drawing')}</button>}
        </div>
        <div className="faint" style={{ marginTop: 8 }}>{d.ready_for_submission_reason}</div>
      </div>
      <div className="grid c2">
        <div className="card"><h3>{t('proj.missing', 'Missing critical inputs')} ({d.missing_critical_inputs.length})</h3>
          {d.missing_critical_inputs.map((m: any) => <div key={m.key} className="row" style={{ padding: '4px 0' }}><span className="chip c-unresolved">missing</span>{L(m)}</div>)}
          {d.unconfirmed_critical_inputs.map((m: any) => <div key={m.key} className="row" style={{ padding: '4px 0' }}><span className="chip c-assumption">unconfirmed</span>{L(m)}</div>)}
        </div>
        <div className="card"><h3>{t('proj.known', 'Confirmed facts')} ({d.known_facts.length})</h3>
          {d.known_facts.map((f: any) => <div key={f.key} style={{ padding: '3px 0' }}><span className="mono ltr">{f.key}</span> = <b>{f.value}</b> {f.unit} <span className="faint">· {f.source}</span></div>)}
          <h3 style={{ marginTop: 12 }}>{t('proj.assumptions', 'Assumptions & suggestions')} ({d.assumptions.length + d.extracted.length})</h3>
          {[...d.extracted, ...d.assumptions].map((f: any) => <div key={f.key} style={{ padding: '3px 0' }}><span className={`chip c-${f.class}`}>{f.class}</span> <span className="mono ltr">{f.key}</span> = {f.value} {f.unit}</div>)}
        </div>
      </div>
      <div className="grid c2">
        <div className="card"><h3>{t('proj.canCheck', 'Checks that can be performed')}</h3>
          {d.checks_performable.map((c: any, i: number) => <div key={i} className="row" style={{ padding: '3px 0' }}><Status s={c.status} /><span className="mono">{c.rule}</span><span className="faint">{c.message}</span></div>)}</div>
        <div className="card"><h3>{t('proj.cannotCheck', 'Checks that cannot be performed yet')}</h3>
          {d.checks_not_performable.map((c: any, i: number) => <div key={i} className="row" style={{ padding: '3px 0' }}><Status s={c.status} /><span className="mono">{c.rule}</span><span className="faint">{c.message}</span></div>)}</div>
      </div>
    </div>
  );
}
