import { z } from 'zod';

const num = z.number().finite().gte(-1e9).lte(1e9);
export const Pt = z.object({ x: num, y: num });
export type Pt = z.infer<typeof Pt>;

export const LineGeom = z.object({ a: Pt, b: Pt });
export const PolylineGeom = z.object({ points: z.array(Pt).min(2).max(100_000), closed: z.boolean() });
export const CircleGeom = z.object({ c: Pt, r: z.number().finite().positive() });
/** Angles in degrees, counter-clockwise from +X, as in DXF. */
export const ArcGeom = z.object({ c: Pt, r: z.number().finite().positive(), start: num, end: num });
export const TextGeom = z.object({ p: Pt, h: z.number().finite().positive(), rot: num, text: z.string().max(10_000) });
export const PointGeom = z.object({ p: Pt });

/** Wall centreline a→b with a thickness, in drawing units. */
export const WallGeom = z.object({ a: Pt, b: Pt, thickness: z.number().finite().positive() });
/**
 * Openings are hosted by a wall: `offset` is the distance from wall.a to the opening centre along the wall.
 * `p` (centre) and `dir` (unit wall direction) are derived from the host and recomputed by NOVA.
 */
const hosted = { wallId: z.string().uuid(), offset: num, width: z.number().finite().positive(), p: Pt.optional(), dir: Pt.optional() };
export const DoorGeom = z.object({ ...hosted, swing: z.enum(['left', 'right']).default('left'), side: z.union([z.literal(1), z.literal(-1)]).default(1) });
export const WindowGeom = z.object(hosted);

export const EntityInput = z.discriminatedUnion('type', [
  z.object({ type: z.literal('WALL'), layer: z.string().min(1).max(255), geom: WallGeom }),
  z.object({ type: z.literal('DOOR'), layer: z.string().min(1).max(255), geom: DoorGeom }),
  z.object({ type: z.literal('WINDOW'), layer: z.string().min(1).max(255), geom: WindowGeom }),
  z.object({ type: z.literal('LINE'), layer: z.string().min(1).max(255), geom: LineGeom }),
  z.object({ type: z.literal('POLYLINE'), layer: z.string().min(1).max(255), geom: PolylineGeom }),
  z.object({ type: z.literal('CIRCLE'), layer: z.string().min(1).max(255), geom: CircleGeom }),
  z.object({ type: z.literal('ARC'), layer: z.string().min(1).max(255), geom: ArcGeom }),
  z.object({ type: z.literal('TEXT'), layer: z.string().min(1).max(255), geom: TextGeom }),
  z.object({ type: z.literal('POINT'), layer: z.string().min(1).max(255), geom: PointGeom }),
]);
export type EntityInput = z.infer<typeof EntityInput>;

export type EntityType = EntityInput['type'];
export type Provenance = 'imported' | 'user' | 'ai';

export type Entity = EntityInput & {
  id: string;
  props: { color?: number };
  provenance: Provenance;
  source_handle?: string | null;
};

export type Units = 'mm' | 'cm' | 'm' | 'in' | 'ft' | 'unitless';

/** Metres per drawing unit; null when unknown. */
export function metresPerUnit(u: Units): number | null {
  return ({ mm: 0.001, cm: 0.01, m: 1, in: 0.0254, ft: 0.3048, unitless: null } as const)[u];
}
