# Engineering Data Model

Source of truth: `server/src/migrations/*.sql`.

## Units and coordinates

- Every drawing stores `units` (`mm`, `m`, `in`, `ft`, `unitless`) taken from DXF `$INSUNITS`
  when present; otherwise `unitless` with an import warning. NOVA never guesses units.
- Coordinates are stored exactly as imported (double precision, world coordinates, Y up).
- `crs` (coordinate reference system) is a project-level fact; blank means unknown.
- Copilot distances are given in mm and converted with the drawing's units; if the
  drawing is `unitless`, the copilot refuses unit-bearing operations.

## Core tables

| Table | Purpose |
|---|---|
| organizations, users, memberships | tenancy and roles (`admin`, `engineer`, `reviewer`, `viewer`) |
| sessions | hashed session tokens with expiry |
| projects | project header, description, status |
| project_facts | key/value facts with `class` (confirmed/extracted/assumption/ai_suggestion/unresolved), unit, source, confidence |
| documents | file register: original name, MIME, size, SHA-256, storage key, classification, extraction status |
| drawings | a CAD drawing derived from a document or created blank; units, extents |
| entities | one row per geometric entity: stable UUID, type, layer, geometry JSON, properties JSON, provenance |
| layers | layer table per drawing (name, colour, visibility) |
| geometry_operations | append-only operation log with before/after entity states (enables undo/redo) |
| drawing_revisions | checkpoints: label, snapshot of entities, checksum, author |
| regulatory_sources | source registry (authority, title, doc id, URL, dates, checksum, verification status) |
| regulatory_rules | rule header (rule code, title, discipline) |
| rule_versions | immutable versions: quotation, interpretation, parameters, applicability, status, reviewer |
| compliance_runs / compliance_findings | executions and per-rule results with evidence |
| ai_proposals | instruction, provider, model, operations, preview, validation, approvals |
| audit_events | who did what, when |
| background_jobs | job status records |

`geometry` JSON is type-specific and validated by Zod (e.g. LINE `{a:{x,y},b:{x,y}}`,
POLYLINE `{points:[...], closed}`); everything relational (ownership, layer, type,
provenance, revisions) is in columns.

## Typed architectural elements (cycle 2)

| Type | Geometry | Relationship rules (enforced in `operations.ts`) |
|---|---|---|
| WALL | centreline `a→b`, `thickness` | moving/rotating/mirroring a wall carries its openings; deleting it deletes them |
| DOOR | `wallId`, `offset` (centre from wall start), `width`, `swing`, `side`; derived `p`, `dir` | moving a door alone slides it along its wall (perpendicular part ignored with a warning, purely perpendicular refused); rotate/mirror alone refused |
| WINDOW | `wallId`, `offset`, `width`; derived `p`, `dir` | same as DOOR |

Constraints: an opening must lie within its wall length and must not overlap another opening on the same
wall; violating operations are rejected before anything is written. QA rule `QA-OPENINGS` re-checks them.

## Submission packages (cycle 2)

`submission_packages` (target, status, external application number, outcome document),
`submission_items` (label, origin nova/official/user, required, attached document, status, note) and
`submission_events` (status history). See `ABU_DHABI_REGULATORY_STRATEGY.md` → Binaa.

## Engineering objects

0.1 implements the drafting primitives (LINE, POLYLINE, CIRCLE, ARC, TEXT, POINT) and
**Room** as a derived object: a closed polyline on a layer matching `ROOM|A-AREA|SPACE`
(case-insensitive), named by the TEXT entity whose insertion point lies inside it.
Wall/Door/Window/Column etc. are planned as typed entities with relationships
(`IMPLEMENTATION_ROADMAP.md`).
