import type { FastifyInstance, FastifyRequest } from 'fastify';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { all, audit, get, now, run, tx } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { projectForOrg } from './projects.ts';
import { BINAA, BINAA_STARTER_ITEMS } from '../integrations/binaa.ts';

const esc = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

/** Allowed status transitions. Nothing here talks to Binaa: every transition records what a person did. */
const NEXT: Record<string, string[]> = {
  draft: ['ready_for_review', 'withdrawn'],
  ready_for_review: ['draft', 'submitted_manually', 'withdrawn'],
  submitted_manually: ['returned', 'approval_recorded', 'withdrawn'],
  returned: ['draft', 'withdrawn'],
  approval_recorded: [],
  withdrawn: [],
};

export function submissionRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;

  const pkgForOrg = (req: FastifyRequest) => {
    const p = get<any>(db, `SELECT s.* FROM submission_packages s JOIN projects p ON p.id = s.project_id WHERE s.id = ? AND p.org_id = ?`, (req.params as any).id, req.user.orgId);
    if (!p) throw new HttpError(404, 'submission package not found');
    return p;
  };
  const load = (id: string) => {
    const pkg = get<any>(db, 'SELECT s.*, u.name AS created_by_name FROM submission_packages s JOIN users u ON u.id = s.created_by WHERE s.id = ?', id);
    const items = all(db, `SELECT i.*, d.original_name AS document_name, d.sha256 AS document_sha256, d.origin AS document_origin
                           FROM submission_items i LEFT JOIN documents d ON d.id = i.document_id WHERE i.package_id = ? ORDER BY i.created_at, i.rowid`, id)
      .map((i) => ({ ...i, required: !!i.required }));
    const events = all(db, 'SELECT e.status, e.note, e.created_at, u.name AS user FROM submission_events e JOIN users u ON u.id = e.user_id WHERE e.package_id = ? ORDER BY e.id', id);
    const blocking = items.filter((i) => i.required && i.status === 'missing');
    return { ...pkg, items, events, blocking: blocking.map((b) => b.label), next: NEXT[pkg.status] };
  };

  app.get('/api/integrations/binaa', async (req) => ({
    ...BINAA,
    sources: all(db, `SELECT id, authority, title, url, verification_status, org_id FROM regulatory_sources
                      WHERE (org_id IS NULL OR org_id = ?) AND (url LIKE '%dmt.gov.ae%' OR url LIKE '%mediaoffice.abudhabi%' OR url LIKE '%tamm.abudhabi%' OR title LIKE '%Binaa%')`, req.user.orgId),
  }));

  app.get('/api/projects/:id/submissions', async (req) => {
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    return all(db, 'SELECT id FROM submission_packages WHERE project_id = ? ORDER BY created_at DESC', p.id).map((r) => load(r.id));
  });

  app.post('/api/projects/:id/submissions', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const b = z.object({ target: z.enum(['binaa', 'other']), title: z.string().trim().min(1).max(200) }).parse(req.body);
    const id = randomUUID();
    tx(db, () => {
      run(db, "INSERT INTO submission_packages (id, project_id, target, title, status, created_by, created_at, updated_at) VALUES (?,?,?,?,'draft',?,?,?)", id, p.id, b.target, b.title, req.user.userId, now(), now());
      if (b.target === 'binaa') for (const it of BINAA_STARTER_ITEMS)
        run(db, "INSERT INTO submission_items (id, package_id, label, origin, required, status, note, created_at) VALUES (?,?,?,?,?,'missing',?,?)", randomUUID(), id, it.label, it.origin, it.required ? 1 : 0, it.note, now());
      run(db, "INSERT INTO submission_events (package_id, status, note, user_id, created_at) VALUES (?, 'draft', 'package created', ?, ?)", id, req.user.userId, now());
    });
    audit(db, req.user.orgId, req.user.userId, 'submission.created', id, b);
    return load(id);
  });

  app.get('/api/submissions/:id', async (req) => load(pkgForOrg(req).id));

  const Item = z.object({ label: z.string().trim().min(1).max(500), origin: z.enum(['official', 'user']).default('user'), required: z.boolean().default(true), note: z.string().max(2000).default('') });
  app.post('/api/submissions/:id/items', async (req) => {
    requireRole(req, 'engineer');
    const pkg = pkgForOrg(req);
    if (!['draft', 'returned'].includes(pkg.status)) throw new HttpError(409, 'items can only change while the package is a draft');
    const b = Item.parse(req.body);
    run(db, "INSERT INTO submission_items (id, package_id, label, origin, required, status, note, created_at) VALUES (?,?,?,?,?,'missing',?,?)", randomUUID(), pkg.id, b.label, b.origin, b.required ? 1 : 0, b.note, now());
    return load(pkg.id);
  });

  app.patch('/api/submissions/:id/items/:itemId', async (req) => {
    requireRole(req, 'engineer');
    const pkg = pkgForOrg(req);
    if (!['draft', 'returned'].includes(pkg.status)) throw new HttpError(409, 'items can only change while the package is a draft');
    const b = z.object({ document_id: z.string().uuid().nullable().optional(), status: z.enum(['missing', 'attached', 'not_applicable']).optional(), note: z.string().max(2000).optional(), required: z.boolean().optional() }).parse(req.body);
    const item = get<any>(db, 'SELECT * FROM submission_items WHERE id = ? AND package_id = ?', (req.params as any).itemId, pkg.id);
    if (!item) throw new HttpError(404, 'item not found');
    if (b.document_id && !get(db, 'SELECT 1 FROM documents WHERE id = ? AND project_id = ?', b.document_id, pkg.project_id)) throw new HttpError(422, 'document is not in this project');
    const document_id = b.document_id === undefined ? item.document_id : b.document_id;
    let status = b.status ?? (b.document_id ? 'attached' : b.document_id === null ? 'missing' : item.status);
    if (status === 'attached' && !document_id) throw new HttpError(422, 'attach a document before marking the item attached');
    if (status === 'not_applicable' && item.status !== 'not_applicable' && !b.note?.trim()) throw new HttpError(422, 'say why the item is not applicable');
    run(db, 'UPDATE submission_items SET document_id = ?, status = ?, note = ?, required = ? WHERE id = ?', document_id, status, b.note ?? item.note, b.required === undefined ? item.required : +b.required, item.id);
    run(db, 'UPDATE submission_packages SET updated_at = ? WHERE id = ?', now(), pkg.id);
    return load(pkg.id);
  });

  app.delete('/api/submissions/:id/items/:itemId', async (req) => {
    requireRole(req, 'engineer');
    const pkg = pkgForOrg(req);
    if (!['draft', 'returned'].includes(pkg.status)) throw new HttpError(409, 'items can only change while the package is a draft');
    run(db, "DELETE FROM submission_items WHERE id = ? AND package_id = ? AND origin = 'user'", (req.params as any).itemId, pkg.id);
    return load(pkg.id);
  });

  app.post('/api/submissions/:id/status', async (req) => {
    const pkg = pkgForOrg(req);
    const b = z.object({
      status: z.enum(['draft', 'ready_for_review', 'submitted_manually', 'returned', 'approval_recorded', 'withdrawn']),
      note: z.string().max(2000).default(''),
      external_reference: z.string().trim().max(100).optional(),
      outcome_document_id: z.string().uuid().optional(),
      confirm: z.boolean().optional(),
    }).parse(req.body);
    if (!NEXT[pkg.status].includes(b.status)) throw new HttpError(409, `cannot move from ${pkg.status} to ${b.status}`);
    requireRole(req, b.status === 'approval_recorded' || b.status === 'ready_for_review' ? 'reviewer' : 'engineer');
    const current = load(pkg.id);
    if (b.status === 'ready_for_review' && current.blocking.length) throw new HttpError(422, `required items missing: ${current.blocking.join('; ')}`);
    if (b.status === 'submitted_manually') {
      if (!b.external_reference) throw new HttpError(422, 'enter the application number issued by the platform');
      if (!b.confirm) throw new HttpError(422, 'confirm that you submitted this package yourself on the platform');
    }
    if (b.status === 'returned' && !b.note.trim()) throw new HttpError(422, 'record the reason the application was returned');
    if (b.status === 'approval_recorded') {
      if (!b.outcome_document_id || !get(db, "SELECT 1 FROM documents WHERE id = ? AND project_id = ? AND origin = 'upload'", b.outcome_document_id, pkg.project_id))
        throw new HttpError(422, 'upload the approval issued by the authority to the project and select it as evidence');
    }
    tx(db, () => {
      run(db, 'UPDATE submission_packages SET status = ?, external_reference = COALESCE(?, external_reference), outcome_document_id = COALESCE(?, outcome_document_id), updated_at = ? WHERE id = ?',
        b.status, b.external_reference ?? null, b.outcome_document_id ?? null, now(), pkg.id);
      run(db, 'INSERT INTO submission_events (package_id, status, note, user_id, created_at) VALUES (?,?,?,?,?)', pkg.id, b.status,
        [b.note, b.external_reference ? `application no. ${b.external_reference}` : ''].filter(Boolean).join(' · '), req.user.userId, now());
    });
    audit(db, req.user.orgId, req.user.userId, 'submission.status', pkg.id, { from: pkg.status, to: b.status, ref: b.external_reference });
    return load(pkg.id);
  });

  /** Printable transmittal listing every item with document checksums. */
  app.get('/api/submissions/:id/transmittal', async (req, reply) => {
    const s = load(pkgForOrg(req).id);
    const p = get<any>(db, 'SELECT code, name FROM projects WHERE id = ?', s.project_id);
    reply.header('content-type', 'text/html; charset=utf-8').header('content-security-policy', "default-src 'none'; style-src 'unsafe-inline'");
    return `<!doctype html><html><head><meta charset="utf-8"><title>Transmittal ${esc(p.code)}</title>
<style>body{font:13px/1.45 "Segoe UI",Tahoma,sans-serif;margin:32px;color:#101828}td,th{border:1px solid #d0d5dd;padding:5px 8px;text-align:start;vertical-align:top}table{border-collapse:collapse;width:100%}code{font-size:11px}.n{border:2px solid #b54708;background:#fffaeb;padding:8px 12px;margin:12px 0}</style></head><body>
<h1 style="font-size:20px">Submission transmittal — ${esc(p.code)} ${esc(p.name)}</h1>
<div>Package: <b>${esc(s.title)}</b> · target: ${esc(s.target === 'binaa' ? BINAA.name : 'other')} · status: <b>${esc(s.status)}</b>${s.external_reference ? ` · application no. <b>${esc(s.external_reference)}</b>` : ''}</div>
<div class="n">Prepared by NOVA for <b>manual</b> submission. NOVA has no connection to ${esc(BINAA.name)} and has not submitted anything. The official document checklist must be taken from the platform.</div>
<table><tr><th>#</th><th>Item</th><th>Origin</th><th>Required</th><th>Status</th><th>Document</th><th>SHA-256</th><th>Note</th></tr>
${s.items.map((i: any, k: number) => `<tr><td>${k + 1}</td><td>${esc(i.label)}</td><td>${esc(i.origin)}</td><td>${i.required ? 'yes' : 'no'}</td><td>${esc(i.status)}</td><td>${esc(i.document_name ?? '')}</td><td><code>${esc(i.document_sha256 ?? '')}</code></td><td>${esc(i.note)}</td></tr>`).join('')}
</table>
<h2 style="font-size:15px">History</h2><ul>${s.events.map((e: any) => `<li>${esc(e.created_at)} — ${esc(e.status)} — ${esc(e.user)} ${esc(e.note)}</li>`).join('')}</ul>
</body></html>`;
  });
}
