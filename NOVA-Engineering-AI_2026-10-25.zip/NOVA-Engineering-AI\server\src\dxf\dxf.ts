import DxfParser from 'dxf-parser';
import type { EntityInput, Pt, Units } from '../geometry/types.ts';
import { EntityInput as EntitySchema } from '../geometry/types.ts';
import { geomEqual } from '../geometry/math.ts';

export type ImportedEntity = { input: EntityInput; color?: number; handle: string | null };
export type Diagnostics = {
  format: string;
  acadVersion: string | null;
  units: Units;
  unitsSource: string;
  rawEntityCounts: Record<string, number>;
  imported: Record<string, number>;
  skipped: Record<string, number>;
  warnings: string[];
};
export type ImportResult = { entities: ImportedEntity[]; layers: { name: string; color: number }[]; diagnostics: Diagnostics };

const SUPPORTED = new Set(['LINE', 'LWPOLYLINE', 'POLYLINE', 'CIRCLE', 'ARC', 'TEXT', 'MTEXT', 'POINT']);
const INSUNITS: Record<number, Units> = { 0: 'unitless', 1: 'in', 2: 'ft', 4: 'mm', 5: 'cm', 6: 'm' };

/** DXF R12-era files encode non-ASCII characters as \U+XXXX. */
export const decodeDxfText = (s: string) => s.replace(/\\U\+([0-9A-Fa-f]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
const encodeDxfText = (s: string) => s.replace(/[^\x20-\x7E]/g, (c) => '\\U+' + c.charCodeAt(0).toString(16).toUpperCase().padStart(4, '0'));

function stripMtext(s: string) {
  return s.replace(/\\P/g, ' ').replace(/\\[ACcFfHhLlOoQqTtWw][^;\\]*;?/g, '').replace(/\\[LlOoKk]/g, '').replace(/[{}]/g, '').trim();
}

/**
 * Independent scan of the ENTITIES section: counts every top-level entity type (so nothing is
 * skipped silently) and records which entities have a negative extrusion Z (group 230), which
 * dxf-parser does not expose for every entity type.
 */
function scanRawEntities(text: string): { counts: Record<string, number>; sequence: { type: string; negZ: boolean }[] } {
  const lines = text.split(/\r?\n/);
  const counts: Record<string, number> = {};
  const sequence: { type: string; negZ: boolean }[] = [];
  let inEntities = false;
  let current: { type: string; negZ: boolean } | null = null;
  for (let i = 0; i + 1 < lines.length; i += 2) {
    const code = lines[i].trim(), val = lines[i + 1].trim();
    if (code === '230' && current && parseFloat(val) < 0) current.negZ = true;
    if (code !== '0' && code !== '2') continue;
    if (code === '2' && val === 'ENTITIES' && lines[i - 1]?.trim() === 'SECTION') inEntities = true;
    else if (code === '0' && val === 'ENDSEC') { inEntities = false; current = null; }
    else if (code === '0' && inEntities && val !== 'VERTEX' && val !== 'SEQEND') {
      counts[val] = (counts[val] ?? 0) + 1;
      current = { type: val, negZ: false };
      sequence.push(current);
    }
  }
  return { counts, sequence };
}

const inc = (o: Record<string, number>, k: string) => { o[k] = (o[k] ?? 0) + 1; };

export function importDxf(text: string): ImportResult {
  if (text.startsWith('AutoCAD Binary DXF')) throw new Error('Binary DXF is not supported; save as ASCII DXF.');
  const parser = new (DxfParser as any)();
  let dxf: any;
  try { dxf = parser.parseSync(text); } catch (e: any) { throw new Error(`DXF could not be parsed: ${e?.message ?? e}`); }
  if (!dxf) throw new Error('DXF could not be parsed.');

  const warnings: string[] = [];
  const header = dxf.header ?? {};
  const insunits = header.$INSUNITS;
  let units: Units = 'unitless';
  let unitsSource = '$INSUNITS absent';
  if (typeof insunits === 'number') {
    if (INSUNITS[insunits]) { units = INSUNITS[insunits]; unitsSource = `$INSUNITS = ${insunits}`; }
    else { unitsSource = `$INSUNITS = ${insunits} (not supported)`; warnings.push(`Drawing units code ${insunits} is not supported; treated as unitless.`); }
  }
  if (units === 'unitless') warnings.push('Drawing units are not defined. Areas and unit-bearing checks will report INSUFFICIENT DATA until units are set.');

  const imported: Record<string, number> = {};
  const skipped: Record<string, number> = {};
  const entities: ImportedEntity[] = [];
  let flattenedBulges = 0, droppedZ = 0, mtextStripped = 0, ocsFlipped = 0;
  const raw = scanRawEntities(text);
  let rawPos = 0;

  for (const e of dxf.entities ?? []) {
    const type: string = e.type;
    // dxf-parser keeps file order, so the matching raw record is the next one of the same type.
    while (rawPos < raw.sequence.length && raw.sequence[rawPos].type !== type) rawPos++;
    const rawNegZ = raw.sequence[rawPos++]?.negZ ?? false;
    if (!SUPPORTED.has(type)) { inc(skipped, type); continue; }
    if (e.inPaperSpace) { inc(skipped, `${type} (paper space)`); continue; }
    const layer = decodeDxfText(e.layer ?? '0');
    const handle = e.handle != null ? String(e.handle) : null;
    // Entities with an extrusion of (0,0,-1) store X mirrored in their object coordinate system.
    const flip = (e.extrusionDirectionZ ?? e.extrusionDirection?.z ?? 1) < 0 || rawNegZ;
    if (flip) ocsFlipped++;
    const P = (p: any): Pt => { if (p?.z) droppedZ++; return { x: flip ? -p.x : p.x, y: p.y }; };
    let input: any = null;

    switch (type) {
      case 'LINE': input = { type: 'LINE', layer, geom: { a: P(e.vertices[0]), b: P(e.vertices[1]) } }; break;
      case 'LWPOLYLINE':
      case 'POLYLINE': {
        if (e.is3dPolygonMesh || e.isPolyfaceMesh) { inc(skipped, `${type} (mesh)`); continue; }
        const verts = (e.vertices ?? []).filter((v: any) => !v.splineFrameControlPoint);
        if (verts.some((v: any) => v.bulge)) flattenedBulges++;
        input = { type: 'POLYLINE', layer, geom: { points: verts.map(P), closed: !!e.shape } };
        break;
      }
      case 'CIRCLE': input = { type: 'CIRCLE', layer, geom: { c: P(e.center), r: e.radius } }; break;
      case 'ARC': {
        let s = (e.startAngle * 180) / Math.PI, en = (e.endAngle * 180) / Math.PI;
        if (flip) [s, en] = [180 - en, 180 - s];
        input = { type: 'ARC', layer, geom: { c: P(e.center), r: e.radius, start: s, end: en } };
        break;
      }
      case 'TEXT': input = { type: 'TEXT', layer, geom: { p: P(e.startPoint), h: e.textHeight || 1, rot: e.rotation ?? 0, text: decodeDxfText(e.text ?? '') } }; break;
      case 'MTEXT': {
        const t = stripMtext(decodeDxfText(e.text ?? ''));
        if (t !== e.text) mtextStripped++;
        input = { type: 'TEXT', layer, geom: { p: P(e.position), h: e.height || 1, rot: e.rotation ?? 0, text: t } };
        break;
      }
      case 'POINT': input = { type: 'POINT', layer, geom: { p: P(e.position) } }; break;
    }
    const parsed = EntitySchema.safeParse(input);
    if (!parsed.success) { inc(skipped, `${type} (invalid geometry)`); continue; }
    inc(imported, type);
    entities.push({ input: parsed.data, color: typeof e.colorIndex === 'number' ? e.colorIndex : undefined, handle });
  }

  if (flattenedBulges) warnings.push(`${flattenedBulges} polyline(s) contain arc segments (bulges); they were imported as straight segments.`);
  if (droppedZ) warnings.push(`${droppedZ} coordinate(s) had non-zero Z; NOVA 0.1 is 2D and kept X/Y only.`);
  if (mtextStripped) warnings.push(`${mtextStripped} MTEXT entit(ies) had formatting codes removed and were imported as single-line TEXT.`);
  if (ocsFlipped) warnings.push(`${ocsFlipped} entit(ies) used a mirrored object coordinate system and were converted to world coordinates.`);
  const skippedTotal = Object.values(skipped).reduce((a, b) => a + b, 0);
  if (skippedTotal) warnings.push(`${skippedTotal} entit(ies) were not imported (${Object.entries(skipped).map(([k, v]) => `${k}: ${v}`).join(', ')}). They remain in the original file.`);

  const layerTable = dxf.tables?.layer?.layers ?? {};
  const layers = Object.values(layerTable).map((l: any) => ({ name: decodeDxfText(l.name), color: Math.abs(l.colorIndex ?? 7) || 7 }));

  return {
    entities,
    layers,
    diagnostics: { format: 'DXF (ASCII)', acadVersion: header.$ACADVER ?? null, units, unitsSource, rawEntityCounts: raw.counts, imported, skipped, warnings },
  };
}

const UNIT_CODE: Record<Units, number> = { unitless: 0, in: 1, ft: 2, mm: 4, cm: 5, m: 6 };
const n = (v: number) => String(v);

/** Write DXF R12 (AC1009) containing NOVA's supported entities. */
export function exportDxf(entities: (EntityInput & { props?: { color?: number } })[], layers: { name: string; color: number }[], units: Units): string {
  const out: (string | number)[] = [];
  const g = (code: number, value: string | number) => out.push(code, value);
  const layerNames = new Map<string, number>(layers.map((l) => [l.name, l.color]));
  for (const e of entities) if (!layerNames.has(e.layer)) layerNames.set(e.layer, 7);
  if (!layerNames.has('0')) layerNames.set('0', 7);

  g(0, 'SECTION'); g(2, 'HEADER');
  g(9, '$ACADVER'); g(1, 'AC1009');
  g(9, '$INSUNITS'); g(70, UNIT_CODE[units]);
  g(0, 'ENDSEC');

  g(0, 'SECTION'); g(2, 'TABLES');
  g(0, 'TABLE'); g(2, 'LTYPE'); g(70, 1);
  g(0, 'LTYPE'); g(2, 'CONTINUOUS'); g(70, 0); g(3, 'Solid line'); g(72, 65); g(73, 0); g(40, 0);
  g(0, 'ENDTAB');
  g(0, 'TABLE'); g(2, 'LAYER'); g(70, layerNames.size);
  for (const [name, color] of layerNames) { g(0, 'LAYER'); g(2, encodeDxfText(name)); g(70, 0); g(62, color || 7); g(6, 'CONTINUOUS'); }
  g(0, 'ENDTAB');
  g(0, 'ENDSEC');

  g(0, 'SECTION'); g(2, 'ENTITIES');
  for (const e of entities) {
    const layer = encodeDxfText(e.layer);
    const head = (t: string) => { g(0, t); g(8, layer); if (e.props?.color != null) g(62, e.props.color); };
    const pt = (p: Pt, base = 10) => { g(base, n(p.x)); g(base + 10, n(p.y)); g(base + 20, 0); };
    switch (e.type) {
      case 'LINE': head('LINE'); pt(e.geom.a); pt(e.geom.b, 11); break;
      case 'POLYLINE':
        head('POLYLINE'); g(66, 1); pt({ x: 0, y: 0 }); g(70, e.geom.closed ? 1 : 0);
        for (const p of e.geom.points) { g(0, 'VERTEX'); g(8, layer); pt(p); }
        g(0, 'SEQEND'); g(8, layer);
        break;
      case 'CIRCLE': head('CIRCLE'); pt(e.geom.c); g(40, n(e.geom.r)); break;
      case 'ARC': head('ARC'); pt(e.geom.c); g(40, n(e.geom.r)); g(50, n(e.geom.start)); g(51, n(e.geom.end)); break;
      case 'TEXT': head('TEXT'); pt(e.geom.p); g(40, n(e.geom.h)); g(1, encodeDxfText(e.geom.text.replace(/[\r\n]+/g, ' '))); g(50, n(e.geom.rot)); break;
      case 'POINT': head('POINT'); pt(e.geom.p); break;
    }
  }
  g(0, 'ENDSEC');
  g(0, 'EOF');

  const lines: string[] = [];
  for (let i = 0; i < out.length; i += 2) lines.push(String(out[i]).padStart(3, ' '), String(out[i + 1]));
  return lines.join('\r\n') + '\r\n';
}

export type ExportVerification = { ok: boolean; expected: number; reparsed: number; mismatches: string[]; unitsPreserved: boolean };

/** Re-parse NOVA's own output and compare it to the source entities. */
export function verifyExport(dxfText: string, source: EntityInput[], units: Units, tol = 1e-9): ExportVerification {
  const back = importDxf(dxfText);
  const mismatches: string[] = [];
  if (back.entities.length !== source.length) mismatches.push(`entity count ${back.entities.length} ≠ ${source.length}`);
  const len = Math.min(back.entities.length, source.length);
  for (let i = 0; i < len; i++) {
    const a = source[i], b = back.entities[i].input;
    if (a.layer !== b.layer) mismatches.push(`#${i} layer "${b.layer}" ≠ "${a.layer}"`);
    if (!geomEqual(a, b, tol)) mismatches.push(`#${i} ${a.type} geometry differs`);
    if (mismatches.length > 20) break;
  }
  const unitsPreserved = back.diagnostics.units === units;
  if (!unitsPreserved) mismatches.push(`units ${back.diagnostics.units} ≠ ${units}`);
  return { ok: mismatches.length === 0, expected: source.length, reparsed: back.entities.length, mismatches, unitsPreserved };
}
