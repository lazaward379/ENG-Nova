import { randomUUID } from 'node:crypto';
import { get, now, run, tx, type DB } from '../db.ts';

/**
 * Binaa is the Abu Dhabi Department of Municipalities and Transport (DMT) building-permit platform.
 * Research on 2026-10-25 found no public API, developer programme or published submission
 * specification for third-party software; applicants reach it through TAMM with their own login.
 * NOVA therefore integrates by preparing the package, linking to the official entry points, and
 * recording what a person did on the platform (application number, outcome, evidence).
 */
export const BINAA = {
  name: 'Binaa (DMT building permits)',
  integration: 'manual',
  apiAvailable: false,
  researchedAt: '2026-10-25',
  entryPoints: [
    { label: 'TAMM — Abu Dhabi government services (sign-in required)', url: 'https://www.tamm.abudhabi/' },
    { label: 'Department of Municipalities and Transport', url: 'https://www.dmt.gov.ae/' },
  ],
  knownFacts: [
    'Launched by DMT on 18 June 2025 (DMT news release).',
    'Phase 1 covers new private villas (DMT news release).',
    'Partners named by DMT: Abu Dhabi Civil Defence Authority, TAQA and e& (DMT news release).',
    'DMT describes the use of AI and BIM; no submission file formats are stated in the release.',
  ],
  notes: 'No public API or official submission specification for third-party software was found. Do not automate the TAMM/Binaa web interface: it requires the applicant’s own credentials and is subject to its terms of use.',
};

/** Official sources found during research. Registered as UNVERIFIED until a reviewer adopts and checks them. */
const CATALOGUE = [
  {
    key: 'dmt-binaa-launch-2025',
    authority: 'Department of Municipalities and Transport (DMT), Abu Dhabi',
    title: 'Binaa Construction Permits Platform Launched',
    document_ref: 'DMT news release',
    url: 'https://www.dmt.gov.ae/en/Media-Centre/News/Binaa-Construction-Permits-Platform-Launched',
    publication_date: '2025-06-18',
    applicability: 'Binaa platform scope. Phase 1: new private villas.',
    access_notes: 'News release, not a technical requirement document. States: AI-based platform; phased roll-out; villa phase first; partners Civil Defence, TAQA, e&. No API, file formats or checklist given.',
  },
  {
    key: 'admo-binaa-launch-2025',
    authority: 'Abu Dhabi Media Office',
    title: 'Department of Municipalities and Transport launches Binaa digital platform to enhance building permit processes in Abu Dhabi',
    document_ref: 'Media Office release',
    url: 'https://www.mediaoffice.abudhabi/en/infrastructure/department-of-municipalities-and-transport-launches-binaa-digital-platform-to-enhance-building-permit-processes-in-abu-dhabi/',
    publication_date: null,
    applicability: 'Binaa platform announcement (English; Arabic version also published).',
    access_notes: 'Government press release. Reported outcomes are DMT’s own figures.',
  },
  {
    key: 'adm-bim-002',
    authority: 'Abu Dhabi City Municipality (ADM) / DMT',
    title: 'ADM-BIM-002 Documentation Guidelines for Infrastructure Projects',
    document_ref: 'ADM-BIM-002',
    url: 'https://www.dmt.gov.ae/adm/-/media/Project/DMT/ADM/E-Library/0001-Jan-2022-Doc/ADM-BIM-002Documentation-Guidelines-for-Infrastructure-projects.pdf',
    publication_date: null,
    applicability: 'BIM documentation for INFRASTRUCTURE projects — not villa building permits.',
    access_notes: 'PDF retrieved 2026-10-25 but its text could not be extracted in the build environment. Title taken from the file name; secondary sources date it October 2020. A reviewer must open it and confirm revision and scope.',
  },
];

/** Insert the catalogue as global, unverified sources (idempotent by URL). */
export function seedBinaaSources(db: DB) {
  tx(db, () => {
    for (const s of CATALOGUE) {
      if (get(db, 'SELECT 1 FROM regulatory_sources WHERE org_id IS NULL AND url = ?', s.url)) continue;
      run(db, `INSERT INTO regulatory_sources (id, org_id, authority, title, document_ref, url, publication_date, effective_date, revision, retrieved_at, applicability, checksum, access_notes, verification_status, created_at)
               VALUES (?,NULL,?,?,?,?,?,NULL,'',?,?,NULL,?,'unverified',?)`,
        randomUUID(), s.authority, s.title, s.document_ref, s.url, s.publication_date, BINAA.researchedAt, s.applicability, s.access_notes, now());
    }
  });
}

/** Starter checklist: NOVA outputs plus placeholders that a person must replace with the official list. */
export const BINAA_STARTER_ITEMS: { label: string; origin: 'nova' | 'official' | 'user'; required: boolean; note: string }[] = [
  { label: 'Official Binaa / TAMM document checklist for this project type, recorded from the platform', origin: 'official', required: true, note: 'NOVA does not hold the official list. Copy each required item from Binaa/TAMM into this package.' },
  { label: 'Architectural drawings exported from NOVA (DXF)', origin: 'nova', required: false, note: 'Binaa’s accepted file formats are not published; confirm on the platform.' },
  { label: 'NOVA compliance / drawing-check report', origin: 'nova', required: false, note: 'Engineering support output, not an authority approval.' },
  { label: 'Drawing & document register', origin: 'nova', required: false, note: '' },
  { label: 'Plot documents (site plan / affection plan) from the authority', origin: 'user', required: true, note: 'Upload the official document received for the plot.' },
  { label: 'Signed professional review by the licensed consultant', origin: 'user', required: true, note: 'Upload the signed review or sign-off record.' },
];
