import { randomUUID } from 'node:crypto';
import { get, now, run, type DB } from '../db.ts';
import { loadEntities, layers, type DrawingRow } from '../drawings.ts';
import { bbox, geomEqual } from '../geometry/math.ts';
import { extractRooms } from '../geometry/rooms.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { applyOperation, computeEffect, Operation } from '../operations.ts';
import { evaluateRules } from '../rules/engine.ts';
import type { CopilotIntent, CopilotProvider } from './intent.ts';
import { RuleParserProvider, isArabic } from './ruleParser.ts';
import { AnthropicProvider } from './anthropicProvider.ts';

export const providers: Record<string, CopilotProvider> = { rule: new RuleParserProvider(), anthropic: new AnthropicProvider() };

export function providerStatus() {
  return Object.entries(providers).map(([id, p]) => ({ id, name: p.name, model: p.model, available: p.available() }));
}

/** Convert a provider intent into a concrete NOVA operation on the selection. */
function toOperation(intent: CopilotIntent, selection: string[], drawing: DrawingRow, db: DB): { op: Operation | null; error?: string } {
  if (intent.intent !== 'operation' || intent.operation === 'none') return { op: null };
  const mpu = metresPerUnit(drawing.units);
  const ents = loadEntities(db, drawing.id).filter((e) => selection.includes(e.id));
  if (!ents.length) return { op: null, error: 'none of the selected entities exist in this drawing' };
  const box = bbox(ents)!;
  const c = { x: (box.minX + box.maxX) / 2, y: (box.minY + box.maxY) / 2 };
  switch (intent.operation) {
    case 'move':
    case 'copy': {
      if (mpu === null) return { op: null, error: 'drawing units are unknown, so a distance in mm cannot be converted safely' };
      const k = 0.001 / mpu; // mm → drawing units
      return { op: { kind: intent.operation, ids: selection, dx: (intent.dx_mm ?? 0) * k, dy: (intent.dy_mm ?? 0) * k } };
    }
    case 'rotate':
      if (intent.angle_deg === null) return { op: null, error: 'missing angle' };
      return { op: { kind: 'rotate', ids: selection, cx: c.x, cy: c.y, angle: intent.angle_deg } };
    case 'mirror_horizontal': return { op: { kind: 'mirror', ids: selection, ax: c.x, ay: c.y, bx: c.x, by: c.y + 1 } };
    case 'mirror_vertical': return { op: { kind: 'mirror', ids: selection, ax: c.x, ay: c.y, bx: c.x + 1, by: c.y } };
    case 'delete': return { op: { kind: 'delete', ids: selection } };
  }
}

function answerQuery(db: DB, orgId: string, drawing: DrawingRow, query: CopilotIntent['query']) {
  if (query === 'room_areas') {
    const rooms = extractRooms(loadEntities(db, drawing.id), drawing.units);
    return {
      kind: 'room_areas',
      units: drawing.units,
      rooms: rooms.map((r) => ({ entityId: r.entityId, name: r.name, area_m2: r.areaM2 === null ? null : Math.round(r.areaM2 * 1000) / 1000, area_units2: r.areaUnits2, valid: r.valid, problems: r.problems })),
      note: drawing.units === 'unitless' ? 'Drawing units unknown: areas are given in drawing units² only.' : 'Shoelace polygon area of each closed room boundary.',
    };
  }
  const findings = evaluateRules(db, orgId, drawing);
  const summary: Record<string, number> = {};
  for (const f of findings) summary[f.status] = (summary[f.status] ?? 0) + 1;
  return {
    kind: query,
    summary,
    findings: (query === 'list_issues' ? findings.filter((f) => f.status !== 'PASS') : findings)
      .map((f) => ({ rule: f.rule_code, status: f.status, message: f.message, entityIds: f.entityIds ?? [], location: f.location ?? null })),
  };
}

export async function interpret(db: DB, orgId: string, userId: string, drawing: DrawingRow, instruction: string, selection: string[], providerId: string) {
  const provider = providers[providerId] ?? providers.rule;
  if (!provider.available()) throw Object.assign(new Error(`AI provider "${providerId}" is not configured on the server.`), { statusCode: 503 });
  const ents = loadEntities(db, drawing.id);
  const selected = ents.filter((e) => selection.includes(e.id));
  const selectionTypes: Record<string, number> = {};
  for (const e of selected) selectionTypes[e.type] = (selectionTypes[e.type] ?? 0) + 1;
  const ctx = { units: drawing.units, selectionCount: selected.length, selectionTypes, entityCount: ents.length, layers: layers(db, drawing.id).map((l) => l.name).slice(0, 200) };

  const intent = await provider.interpret(instruction, ctx);
  let operation: Operation | null = null;
  let validation: Record<string, unknown> = {};
  let status: 'proposed' | 'invalid' | 'answered' | 'rejected' = 'answered';
  let preview: unknown = null;
  let answer: unknown = null;

  if (intent.intent === 'operation') {
    const { op, error } = toOperation(intent, selected.map((e) => e.id), drawing, db);
    const parsed = op ? Operation.safeParse(op) : null;
    if (error || !parsed?.success) {
      status = 'invalid';
      validation = { errors: [error ?? parsed?.error?.issues[0]?.message ?? 'invalid operation'], warnings: [] };
    } else {
      operation = parsed.data;
      const effect = computeEffect(db, drawing.id, operation, 'ai');
      validation = { errors: effect.errors, warnings: effect.warnings, affected: effect.changes.length };
      preview = effect.changes.map((c) => ({ id: c.id, before: c.before, after: c.after }));
      status = effect.errors.length ? 'invalid' : 'proposed';
    }
  } else if (intent.intent === 'query') {
    answer = answerQuery(db, orgId, drawing, intent.query);
  }

  const id = randomUUID();
  run(db, `INSERT INTO ai_proposals (id, drawing_id, instruction, language, provider, model, intent, operation, explanation, assumptions, validation, status, created_by, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, drawing.id, instruction, isArabic(instruction) ? 'ar' : 'en', provider.name, provider.model, JSON.stringify(intent), operation ? JSON.stringify(operation) : null,
    intent.explanation, JSON.stringify(intent.assumptions), JSON.stringify(validation), intent.intent === 'operation' ? status : 'answered', userId, now(), now());
  return { id, provider: provider.name, model: provider.model, intent, operation, validation, preview, answer, status: intent.intent === 'operation' ? status : 'answered', preliminary: true };
}

/** Execute an approved proposal, then verify the stored result matches the preview and re-run QA checks. */
export function applyProposal(db: DB, orgId: string, userId: string, drawing: DrawingRow, proposalId: string) {
  const p = get<any>(db, 'SELECT * FROM ai_proposals WHERE id = ? AND drawing_id = ?', proposalId, drawing.id);
  if (!p) throw Object.assign(new Error('proposal not found'), { statusCode: 404 });
  if (p.status !== 'proposed') throw Object.assign(new Error(`proposal is ${p.status}, not awaiting approval`), { statusCode: 409 });
  const op = Operation.parse(JSON.parse(p.operation));
  const result = applyOperation(db, drawing.id, op, userId, 'ai', proposalId);

  const after = new Map(loadEntities(db, drawing.id).map((e) => [e.id, e]));
  const mismatches = result.changes.filter((c) => (c.after ? !after.get(c.id) || !geomEqual(after.get(c.id)!, c.after, 1e-9) : after.has(c.id))).map((c) => c.id);
  const qa = evaluateRules(db, orgId, drawing, (r) => r.category === 'drawing_qa');
  const verification = { stored_matches_preview: mismatches.length === 0, mismatches, qa_summary: qa.reduce<Record<string, number>>((a, f) => ((a[f.status] = (a[f.status] ?? 0) + 1), a), {}) };
  run(db, "UPDATE ai_proposals SET status = 'applied', applied_op_id = ?, approved_by = ?, validation = json_set(validation, '$.verification', json(?)), updated_at = ? WHERE id = ?",
    result.id, userId, JSON.stringify(verification), now(), proposalId);
  return { operationId: result.id, seq: result.seq, affected: result.changes.length, verification };
}

export function rejectProposal(db: DB, drawingId: string, proposalId: string) {
  const r = run(db, "UPDATE ai_proposals SET status = 'rejected', updated_at = ? WHERE id = ? AND drawing_id = ? AND status = 'proposed'", now(), proposalId, drawingId);
  return r.changes > 0;
}
