import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../src/app.ts';
import { sampleDxf } from '../scripts/make-sample.ts';

let app: FastifyInstance;
let dir: string;
let token = '';
let projectId = '', drawingId = '';

const call = async (method: string, url: string, body?: unknown, tk = token) => {
  const res = await app.inject({ method: method as any, url, payload: body as any, headers: tk ? { authorization: `Bearer ${tk}` } : {} });
  let json: any = null;
  try { json = res.json(); } catch { /* non-JSON */ }
  return { status: res.statusCode, json, body: res.body, headers: res.headers };
};

function multipart(filename: string, content: Buffer | string) {
  const boundary = '----nova' + Math.random().toString(16).slice(2);
  const payload = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: application/octet-stream\r\n\r\n`),
    Buffer.isBuffer(content) ? content : Buffer.from(content),
    Buffer.from(`\r\n--${boundary}--\r\n`),
  ]);
  return { payload, headers: { 'content-type': `multipart/form-data; boundary=${boundary}`, authorization: `Bearer ${token}` } };
}

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'nova-test-'));
  ({ app } = await buildApp({ dbPath: ':memory:', storageDir: join(dir, 'storage') }));
});
after(async () => { await app.close(); rmSync(dir, { recursive: true, force: true }); });

test('health is public; everything else needs a session', async () => {
  assert.equal((await call('GET', '/api/health', undefined, '')).json.status, 'ok');
  assert.equal((await call('GET', '/api/projects', undefined, '')).status, 401);
  assert.equal((await call('GET', '/api/projects', undefined, 'forged')).status, 401);
});

test('register, weak password rejected, login works', async () => {
  assert.equal((await call('POST', '/api/auth/register', { orgName: 'Test Consultants', name: 'Eng', email: 'eng@example.test', password: 'short' }, '')).status, 400);
  const r = await call('POST', '/api/auth/register', { orgName: 'Test Consultants', name: 'Eng', email: 'eng@example.test', password: 'correct-horse-battery' }, '');
  assert.equal(r.status, 200);
  assert.equal((await call('POST', '/api/auth/login', { email: 'eng@example.test', password: 'wrong-password!' }, '')).status, 401);
  token = (await call('POST', '/api/auth/login', { email: 'ENG@example.test', password: 'correct-horse-battery' }, '')).json.token;
  assert.equal((await call('GET', '/api/auth/me')).json.role, 'admin');
});

test('VERTICAL SLICE: project → upload DXF → geometry → edit → checkpoint → validate → report → export → history', async () => {
  // 2. create project
  const p = await call('POST', '/api/projects', { code: 'TST-001', name: 'Test villa', description: 'Synthetic fixture', project_type: 'residential_villa' });
  assert.equal(p.status, 200);
  projectId = p.json.id;

  // 3. upload DXF
  const mp = multipart('sample villa.dxf', sampleDxf());
  const up = await app.inject({ method: 'POST', url: `/api/projects/${projectId}/documents`, ...mp });
  assert.equal(up.statusCode, 200, up.body);
  const upj = up.json();
  assert.equal(upj.extraction_status, 'parsed');
  assert.match(upj.sha256, /^[a-f0-9]{64}$/);
  drawingId = upj.drawingId;

  // 4. real geometry
  const d = await call('GET', `/api/drawings/${drawingId}`);
  assert.equal(d.json.units, 'mm');
  assert.equal(d.json.entities.length, 24);
  assert.deepEqual(d.json.import_diagnostics.skipped, { ELLIPSE: 1 });
  const majlis = d.json.rooms.find((r: any) => r.name?.startsWith('MAJLIS'));
  assert.equal(majlis.areaM2, 42);
  const door = d.json.entities.find((e: any) => e.type === 'ARC');

  // plot boundary layer is locked by default
  const plot = d.json.entities.find((e: any) => e.layer === 'PLOT-BOUNDARY');
  const locked = await call('POST', `/api/drawings/${drawingId}/operations`, { op: { kind: 'move', ids: [plot.id], dx: 1, dy: 0 } });
  assert.equal(locked.status, 422);
  assert.match(locked.json.errors[0], /locked/);

  // 6a. checkpoint before the edit
  const rev1 = await call('POST', `/api/drawings/${drawingId}/revisions`, { label: 'As imported' });
  assert.equal(rev1.json.number, 1);

  // 5. modify geometry
  const mv = await call('POST', `/api/drawings/${drawingId}/operations`, { op: { kind: 'move', ids: [door.id], dx: -200, dy: 0 } });
  assert.equal(mv.status, 200, mv.body);
  const d2 = await call('GET', `/api/drawings/${drawingId}`);
  assert.deepEqual(d2.json.entities.find((e: any) => e.id === door.id).geom.c, { x: 6800, y: 4000 });

  // 6b. checkpoint + reload + diff
  await call('POST', `/api/drawings/${drawingId}/revisions`, { label: 'Door moved' });
  const diff = await call('GET', `/api/drawings/${drawingId}/revisions/${rev1.json.id}/diff`);
  assert.deepEqual(diff.json.modified, [door.id]);

  // invalid operation is rejected by schema
  assert.equal((await call('POST', `/api/drawings/${drawingId}/operations`, { op: { kind: 'move', ids: ['not-a-uuid'], dx: 'x' } })).status, 400);

  // 7–8. deterministic validation with evidence
  const run = await call('POST', `/api/drawings/${drawingId}/compliance-runs`, {});
  assert.equal(run.status, 200);
  const byRule = (code: string) => run.json.findings.filter((f: any) => f.rule_code === code);
  assert.equal(byRule('QA-UNITS')[0].status, 'PASS');
  assert.equal(byRule('QA-DUP')[0].status, 'WARNING');
  assert.equal(byRule('QA-LAYER0')[0].status, 'WARNING');
  assert.ok(byRule('QA-ROOM-LABEL').some((f: any) => f.status === 'WARNING' && /no label/.test(f.message)));
  assert.ok(byRule('QA-ROOM-OVERLAP').every((f: any) => f.status === 'PASS'), JSON.stringify(byRule('QA-ROOM-OVERLAP')));
  // regulatory templates are never PASS/FAIL without a verified source
  for (const code of ['REG-TPL-ROOM-AREA', 'REG-TPL-COVERAGE', 'REG-TPL-SETBACK']) assert.equal(byRule(code)[0].status, 'SOURCE NOT VERIFIED');
  assert.ok(byRule('REG-TPL-COVERAGE')[0].evidence.measured_for_information_only[0].evidence.coverage_pct > 0);

  // 9. report
  const rep = await call('GET', `/api/compliance-runs/${run.json.id}/report`);
  assert.equal(rep.status, 200);
  assert.match(rep.body, /not an authority approval/);
  assert.match(rep.body, /SOURCE NOT VERIFIED/);

  // 10. export, verified by re-parse, stored as a generated derivative
  const ex = await call('POST', `/api/drawings/${drawingId}/export`, {});
  assert.equal(ex.status, 200, ex.body);
  assert.equal(ex.json.verification.ok, true);
  const dl = await app.inject({ method: 'GET', url: `/api/documents/${ex.json.documentId}/download`, headers: { authorization: `Bearer ${token}` } });
  assert.match(dl.body, /AC1009/);
  assert.match(dl.body, /\n6800\r?\n/);
  const proj = await call('GET', `/api/projects/${projectId}`);
  assert.deepEqual(proj.json.documents.map((x: any) => x.origin).sort(), ['generated', 'upload']);

  // 11. history + undo/redo
  const h = await call('GET', `/api/drawings/${drawingId}/history`);
  assert.equal(h.json[0].kind, 'move');
  await call('POST', `/api/drawings/${drawingId}/undo`);
  assert.deepEqual((await call('GET', `/api/drawings/${drawingId}`)).json.entities.find((e: any) => e.id === door.id).geom.c, { x: 7000, y: 4000 });
  await call('POST', `/api/drawings/${drawingId}/redo`);
  assert.deepEqual((await call('GET', `/api/drawings/${drawingId}`)).json.entities.find((e: any) => e.id === door.id).geom.c, { x: 6800, y: 4000 });

  // restore checkpoint 1 is itself an undoable operation
  await call('POST', `/api/drawings/${drawingId}/operations`, { op: { kind: 'restore_revision', revisionId: rev1.json.id } });
  assert.deepEqual((await call('GET', `/api/drawings/${drawingId}`)).json.entities.find((e: any) => e.id === door.id).geom.c, { x: 7000, y: 4000 });
  await call('POST', `/api/drawings/${drawingId}/undo`);
});

test('AI SLICE: Arabic instruction → proposal → preview → validate → apply → verify → undo', async () => {
  const d = await call('GET', `/api/drawings/${drawingId}`);
  const door = d.json.entities.find((e: any) => e.type === 'ARC');
  const before = door.geom.c;

  const r = await call('POST', `/api/drawings/${drawingId}/copilot`, { instruction: 'انقل الباب 200 مم لليسار', selection: [door.id] });
  assert.equal(r.status, 200, r.body);
  assert.equal(r.json.status, 'proposed');
  assert.deepEqual(r.json.operation, { kind: 'move', ids: [door.id], dx: -200, dy: 0 });
  assert.equal(r.json.preview[0].after.geom.c.x, before.x - 200);
  assert.deepEqual(r.json.validation.errors, []);
  // nothing changed before approval
  assert.deepEqual((await call('GET', `/api/drawings/${drawingId}`)).json.entities.find((e: any) => e.id === door.id).geom.c, before);

  const ap = await call('POST', `/api/drawings/${drawingId}/proposals/${r.json.id}/apply`, {});
  assert.equal(ap.status, 200, ap.body);
  assert.equal(ap.json.verification.stored_matches_preview, true);
  assert.equal((await call('POST', `/api/drawings/${drawingId}/proposals/${r.json.id}/apply`, {})).status, 409);

  const hist = (await call('GET', `/api/drawings/${drawingId}/history`)).json;
  assert.equal(hist[0].source, 'ai');
  assert.equal(hist[0].proposal_id, r.json.id);

  await call('POST', `/api/drawings/${drawingId}/undo`);
  assert.deepEqual((await call('GET', `/api/drawings/${drawingId}`)).json.entities.find((e: any) => e.id === door.id).geom.c, before);

  // AI cannot move the locked plot boundary
  const plot = d.json.entities.find((e: any) => e.layer === 'PLOT-BOUNDARY');
  const bad = await call('POST', `/api/drawings/${drawingId}/copilot`, { instruction: 'move 1 m right', selection: [plot.id] });
  assert.equal(bad.json.status, 'invalid');

  // query intent
  const q = await call('POST', `/api/drawings/${drawingId}/copilot`, { instruction: 'Calculate the area of each room', selection: [] });
  assert.equal(q.json.answer.rooms.find((x: any) => x.name === 'KITCHEN').area_m2, 22.5);

  // LLM provider is refused when not configured
  if (!process.env.ANTHROPIC_API_KEY) assert.equal((await call('POST', `/api/drawings/${drawingId}/copilot`, { instruction: 'x', provider: 'anthropic' })).status, 503);
});

test('REGULATORY SLICE: source → reviewer verification → verified rule version → deterministic result with evidence', async () => {
  // a verified version cannot use an unverified source
  const src = await call('POST', '/api/regulatory/sources', {
    authority: 'NOVA test suite', title: 'TEST-ONLY fixture source (not a regulation)', document_ref: 'TEST-ONLY-1', url: 'https://example.test/fixture', revision: 'T1',
  });
  assert.equal(src.status, 200);
  const early = await call('POST', '/api/regulatory/rules/REG-TPL-ROOM-AREA/versions', { source_id: src.json.id, clause: 'T-1', interpretation: 'Test-only threshold for automated tests.', params: { min_area_m2: 25 } });
  assert.equal(early.status, 422);

  assert.equal((await call('POST', `/api/regulatory/sources/${src.json.id}/verify`, { status: 'test_only', attestation: 'Fixture for the automated test suite only.' })).status, 200);
  // unknown parameters are rejected
  assert.equal((await call('POST', '/api/regulatory/rules/REG-TPL-ROOM-AREA/versions', { source_id: src.json.id, clause: 'T-1', interpretation: 'Test-only threshold for automated tests.', params: { min_area: 25 } })).status, 400);
  const v = await call('POST', '/api/regulatory/rules/REG-TPL-ROOM-AREA/versions', { source_id: src.json.id, clause: 'T-1', quotation: 'n/a', interpretation: 'Test-only threshold for automated tests.', params: { min_area_m2: 25 } });
  assert.equal(v.status, 200, v.body);

  const rules = (await call('GET', '/api/regulatory/rules')).json;
  const rule = rules.find((r: any) => r.code === 'REG-TPL-ROOM-AREA');
  assert.equal(rule.version_status, 'verified');
  assert.equal(rule.source_status, 'test_only');

  const run = await call('POST', `/api/drawings/${drawingId}/compliance-runs`, { scope: 'regulatory' });
  const res = run.json.findings.filter((f: any) => f.rule_code === 'REG-TPL-ROOM-AREA');
  const kitchen = res.find((f: any) => f.inputs.room === 'KITCHEN');
  assert.equal(kitchen.status, 'FAIL');
  assert.equal(kitchen.inputs.area_m2, 22.5);
  assert.match(kitchen.message, /TEST SOURCE/);
  assert.equal(kitchen.evidence.source.clause, 'T-1');
  assert.equal(res.find((f: any) => f.inputs.room?.startsWith('MAJLIS')).status, 'PASS');
  // other templates remain unverified
  assert.equal(run.json.findings.find((f: any) => f.rule_code === 'REG-TPL-SETBACK').status, 'SOURCE NOT VERIFIED');

  // the global template is untouched (org copy was created)
  const versions = (await call('GET', '/api/regulatory/rules/REG-TPL-ROOM-AREA/versions')).json;
  assert.ok(versions.some((x: any) => x.org_id === null && x.status === 'template'));
});

test('organisation isolation and role enforcement', async () => {
  const other = (await call('POST', '/api/auth/register', { orgName: 'Other Org', name: 'Mallory', email: 'm@other.test', password: 'another-long-password' }, '')).json.token;
  assert.equal((await call('GET', `/api/projects/${projectId}`, undefined, other)).status, 404);
  assert.equal((await call('GET', `/api/drawings/${drawingId}`, undefined, other)).status, 404);
  assert.equal((await call('POST', `/api/drawings/${drawingId}/undo`, {}, other)).status, 404);
  assert.equal((await call('GET', '/api/projects', undefined, other)).json.length, 0);

  // a viewer cannot edit
  assert.equal((await call('POST', '/api/org/members', { name: 'Viewer', email: 'v@example.test', password: 'viewer-password-1', role: 'viewer' })).status, 200);
  const vt = (await call('POST', '/api/auth/login', { email: 'v@example.test', password: 'viewer-password-1' }, '')).json.token;
  assert.equal((await call('GET', `/api/drawings/${drawingId}`, undefined, vt)).status, 200);
  assert.equal((await call('POST', `/api/drawings/${drawingId}/operations`, { op: { kind: 'delete', ids: ['00000000-0000-4000-8000-000000000000'] } }, vt)).status, 403);
  assert.equal((await call('POST', '/api/regulatory/sources', { authority: 'x', title: 'yy' }, vt)).status, 403);
});

test('upload validation: disallowed type, spoofed PDF, readiness report is honest', async () => {
  const exe = multipart('tool.exe', Buffer.from('MZ'));
  assert.equal((await app.inject({ method: 'POST', url: `/api/projects/${projectId}/documents`, ...exe })).statusCode, 415);
  const fakePdf = multipart('plot.pdf', 'not a pdf');
  assert.equal((await app.inject({ method: 'POST', url: `/api/projects/${projectId}/documents`, ...fakePdf })).statusCode, 415);
  const csv = multipart('../../survey.csv', 'easting,northing\n0,0\n30,0\n30,25\n0,25\n');
  const up = await app.inject({ method: 'POST', url: `/api/projects/${projectId}/documents`, ...csv });
  assert.equal(up.statusCode, 200);
  const facts = (await call('GET', `/api/projects/${projectId}`)).json.facts;
  assert.equal(facts.find((f: any) => f.key === 'survey_polygon_area').value, '750');
  assert.equal(facts.find((f: any) => f.key === 'survey_polygon_area').class, 'extracted');
  assert.equal((await call('GET', `/api/projects/${projectId}`)).json.documents.find((x: any) => x.ext === 'csv').original_name, 'survey.csv');

  const r = (await call('GET', `/api/projects/${projectId}/readiness`)).json;
  assert.equal(r.ready_for_submission, false);
  assert.ok(r.missing_critical_inputs.some((m: any) => m.key === 'plot_id'));
  assert.ok(r.checks_not_performable.some((c: any) => c.status === 'SOURCE NOT VERIFIED'));

  // confirmed facts need a source
  assert.equal((await call('PUT', `/api/projects/${projectId}/facts`, { key: 'plot_id', value: 'X', class: 'confirmed', source: '' })).status, 400);
});
