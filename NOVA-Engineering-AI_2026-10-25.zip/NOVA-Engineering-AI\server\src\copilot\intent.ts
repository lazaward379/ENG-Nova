import { z } from 'zod';

/**
 * What any copilot provider may return. It deliberately cannot name entity IDs, coordinates,
 * layers, units or code — targets are always the user's current selection, distances are in mm,
 * and NOVA converts them using the drawing's declared units.
 */
export const CopilotIntent = z.object({
  intent: z.enum(['operation', 'query', 'clarify', 'unsupported']),
  operation: z.enum(['move', 'copy', 'rotate', 'mirror_horizontal', 'mirror_vertical', 'delete', 'none']),
  dx_mm: z.number().nullable(),
  dy_mm: z.number().nullable(),
  angle_deg: z.number().nullable(),
  query: z.enum(['room_areas', 'run_checks', 'list_issues', 'none']),
  explanation: z.string(),
  questions: z.array(z.string()),
  assumptions: z.array(z.string()),
});
export type CopilotIntent = z.infer<typeof CopilotIntent>;

export type CopilotContext = { units: string; selectionCount: number; selectionTypes: Record<string, number>; entityCount: number; layers: string[] };

export interface CopilotProvider {
  readonly name: string;
  readonly model: string | null;
  available(): boolean;
  interpret(instruction: string, ctx: CopilotContext): Promise<CopilotIntent>;
}

export const blankIntent = (patch: Partial<CopilotIntent>): CopilotIntent => ({
  intent: 'unsupported', operation: 'none', dx_mm: null, dy_mm: null, angle_deg: null, query: 'none', explanation: '', questions: [], assumptions: [], ...patch,
});
