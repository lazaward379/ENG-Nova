import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, type Me } from './api';
import { STATUS_AR, useT } from './i18n';

// ---------- icons (stroke icons, 24×24) ----------
const P: Record<string, string> = {
  dashboard: 'M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z',
  projects: 'M3 7h6l2 2h10v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  intake: 'M12 3v12M7 10l5 5 5-5M4 19h16',
  requirements: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
  workspace: 'M3 21l6-6M14 4l6 6-9 9H5v-6z',
  architecture: 'M3 21V9l9-6 9 6v12M9 21v-6h6v6',
  bim: 'M12 2l9 5v10l-9 5-9-5V7zM12 12l9-5M12 12v10M12 12L3 7',
  compliance: 'M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6zM8.5 12l2.5 2.5 4.5-5',
  qa: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-5-5',
  shop: 'M4 4h16v16H4zM4 9h16M9 9v11',
  coordination: 'M6 3v18M18 3v18M3 8h18M3 16h18',
  submission: 'M22 2L11 13M22 2l-7 20-4-9-9-4z',
  documents: 'M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9zM14 3v6h6',
  assistant: 'M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9zM19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z',
  review: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
  admin: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  regulatory: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5zM4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5',
  system: 'M22 12h-4l-3 9L9 3l-3 9H2',
  menu: 'M3 6h18M3 12h18M3 18h18',
  select: 'M4 4l7 17 2.5-7.5L21 11z',
  pan: 'M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20',
  line: 'M4 20L20 4',
  rect: 'M4 6h16v12H4z',
  polyline: 'M3 17l6-8 5 5 7-9',
  circle: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z',
  text: 'M4 7V4h16v3M9 20h6M12 4v16',
  measure: 'M2 17l15-15 5 5L7 22zM7.5 11.5l2 2M10.5 8.5l2 2M13.5 5.5l2 2',
  fit: 'M3 9V3h6M21 9V3h-6M3 15v6h6M21 15v6h-6',
  undo: 'M3 7v6h6M3 13a9 9 0 1 0 3-7.7L3 8',
  redo: 'M21 7v6h-6M21 13a9 9 0 1 1-3-7.7L21 8',
  play: 'M5 3l14 9-14 9z',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  flag: 'M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7',
  eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  eyeoff: 'M17.9 17.9A10 10 0 0 1 12 20C5 20 1 12 1 12a18 18 0 0 1 5.1-5.9M9.9 4.2A9 9 0 0 1 12 4c7 0 11 8 11 8a18 18 0 0 1-2.2 3.2M1 1l22 22',
  lock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4',
  unlock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 7.9-1',
  sun: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4',
  moon: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  globe: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20',
  logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  plus: 'M12 5v14M5 12h14',
  x: 'M18 6L6 18M6 6l12 12',
  check: 'M20 6L9 17l-5-5',
  trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6',
  copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
  rotate: 'M21 2v6h-6M21 13a9 9 0 1 1-3-7.7L21 8',
  mirror: 'M12 3v18M8 7l-5 5 5 5M16 7l5 5-5 5',
  move: 'M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20',
  report: 'M9 17v-6M13 17V7M17 17v-3M4 21h16',
  send: 'M22 2L11 13M22 2l-7 20-4-9-9-4z',
  wall: 'M3 9h18v6H3zM8 9v6M13 9v6M18 9v6',
  door: 'M4 20V10M4 10h10M4 10a10 10 0 0 1 10 10M2 20h20',
  window: 'M3 10h18v4H3zM3 12h18M8 10v4M16 10v4',
  external: 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3',
};
export function Icon({ name, size = 17 }: { name: string; size?: number }) {
  return <svg viewBox="0 0 24 24" width={size} height={size} fill="none" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={P[name] ?? P.x} /></svg>;
}

export function Status({ s }: { s: string }) {
  const { lang } = useT();
  return <span className={`badge s-${s.replace(/ /g, '-')}`}>{lang === 'ar' ? STATUS_AR[s] ?? s : s}</span>;
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-label={title}>
        <div className="card-h"><h2>{title}</h2><span className="spacer" /><button className="btn ghost icon" onClick={onClose} aria-label="close"><Icon name="x" /></button></div>
        {children}
      </div>
    </div>
  );
}

// ---------- app-wide context ----------
export type Toast = { id: number; kind: 'ok' | 'error' | 'info'; text: string };
export type AppCtx = {
  me: Me;
  go: (route: string) => void;
  toast: (text: string, kind?: Toast['kind']) => void;
  theme: string;
  project: string | null; setProject: (id: string | null) => void;
  drawing: string | null; setDrawing: (id: string | null) => void;
  can: (min: Me['role']) => boolean;
};
export const AppContext = createContext<AppCtx>(null as any);
export const useApp = () => useContext(AppContext);

/** Load data and expose reload + error, so every screen renders real state or a real error. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setLoading(true);
    try { setData(await fn()); setError(null); } catch (e: any) { setError(e.message ?? String(e)); } finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { reload(); }, [reload]);
  return { data, error, loading, reload, setData };
}

export function Loading({ error, loading }: { error: string | null; loading: boolean }) {
  const { t } = useT();
  if (error) return <div className="notice">{error}</div>;
  if (loading) return <div className="empty">{t('common.loading', 'Loading…')}</div>;
  return null;
}

/** Project + drawing selector shared by screens that operate on "the current drawing". */
export function ProjectDrawingPicker({ needDrawing = true }: { needDrawing?: boolean }) {
  const { project, setProject, drawing, setDrawing } = useApp();
  const { t } = useT();
  const projects = useLoad(() => api.get('/api/projects'), []);
  const detail = useLoad(() => (project ? api.get(`/api/projects/${project}`) : Promise.resolve(null)), [project]);
  useEffect(() => {
    if (!needDrawing || !detail.data) return;
    const ids = detail.data.drawings.map((d: any) => d.id);
    if (!drawing || !ids.includes(drawing)) setDrawing(ids[0] ?? null);
  }, [detail.data]);
  return (
    <div className="row">
      <select value={project ?? ''} onChange={(e) => setProject(e.target.value || null)} style={{ maxWidth: 280 }} aria-label={t('common.selectProject', 'Select project')}>
        <option value="">{t('common.selectProject', 'Select project')}</option>
        {projects.data?.map((p: any) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
      </select>
      {needDrawing && project && (
        <select value={drawing ?? ''} onChange={(e) => setDrawing(e.target.value || null)} style={{ maxWidth: 280 }} aria-label={t('common.selectDrawing', 'Select drawing')}>
          {!detail.data?.drawings.length && <option value="">{t('common.none', 'None')}</option>}
          {detail.data?.drawings.map((d: any) => <option key={d.id} value={d.id}>{d.name} ({d.entities})</option>)}
        </select>
      )}
    </div>
  );
}

export const when = (iso: string) => { try { return new Date(iso).toLocaleString(); } catch { return iso; } };
export const bytes = (n: number) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`);
