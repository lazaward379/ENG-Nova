# Abu Dhabi Regulatory Strategy

## Position

NOVA ships **no verified Abu Dhabi regulatory thresholds**. During this build no official
document was retrieved, read and checked, so encoding any number (setback, coverage,
minimum room size, parking ratio, corridor width, …) would be invention. That is
prohibited by the product principles.

Instead, NOVA ships:

1. A **source registry** to record official documents (DMT, Abu Dhabi municipalities,
   Binaa guidance, Civil Defence fire & life safety, utility providers, developer/client
   manuals such as Aldar's where the client provides them).
2. A **rule schema** separating official text from software interpretation.
3. **Rule templates** whose *logic* is deterministic (e.g. "room area ≥ threshold",
   "plot coverage ≤ max ratio") but whose *threshold and citation* are empty. Their status
   is `SOURCE NOT VERIFIED` and they never return PASS or FAIL in that state.
4. A **verification workflow**: a user with `reviewer` or `admin` role records the source
   document, clause/page, permitted quotation and the parameter value. That creates a new
   immutable `rule_version` marked `verified` with reviewer and date. Previous versions are
   kept so past reports remain reproducible.

Project-specific limits (e.g. coverage from a plot's affection plan / site plan) are
**project facts**, entered with their source, not global rules.

## Rule statuses

`PASS`, `FAIL`, `WARNING`, `NOT CHECKED`, `INSUFFICIENT DATA`, `REQUIRES ENGINEER REVIEW`,
`SOURCE NOT VERIFIED`. Missing evidence never yields PASS.

## Source discovery plan (not yet executed)

| Priority | Source family | Action |
|---|---|---|
| 1 | DMT / municipality building permit guides and checklists | Retrieve from official portals; record URL, revision, retrieval date, checksum |
| 2 | Abu Dhabi International Building Code adoption and amendments | Check access/licensing; cite clauses only |
| 3 | UAE Fire & Life Safety Code (Civil Defence) | Record edition and effective date |
| 4 | Accessibility requirements applicable in Abu Dhabi | Identify the currently applicable document |
| 5 | Utility provider design requirements | Per provider, per project type |
| 6 | Developer / client design manuals | Client-provided; stored with client confidentiality |

Do not bypass logins, paywalls or terms. Record inaccessible sources with that limitation.

## Binaa (DMT building-permit platform) — researched 2026-10-25

Findings from official pages (DMT news release, Abu Dhabi Media Office):
- Binaa is DMT's AI-assisted building-permit platform, launched 18 June 2025; phase 1 covers new private villas.
- Partners named: Abu Dhabi Civil Defence Authority, TAQA, e&.
- Applicants reach it through TAMM with their own sign-in.
- **No public API, developer programme or published submission specification for third-party software was found.**

Therefore NOVA's integration is a **manual workflow** (`server/src/integrations/binaa.ts`, `routes/submissions.ts`):
1. Catalogue sources (DMT release, Media Office release, ADM-BIM-002) are seeded as global, **unverified** records.
   A reviewer *adopts* one into the organisation and verifies it with a written attestation.
2. A Binaa submission package starts with a starter checklist: NOVA outputs plus placeholders. The first
   required item tells the team to copy the **official** checklist from Binaa/TAMM into the package; NOVA does
   not invent it.
3. Status flow: draft → ready_for_review (reviewer, no required item missing) → submitted_manually (application
   number + explicit confirmation that a person submitted it) → returned (reason) or approval_recorded
   (reviewer + the authority's uploaded approval document as evidence). Every transition is logged.
4. A printable transmittal lists items with document SHA-256 checksums.

NOVA never logs into TAMM/Binaa, never automates its web interface, and never reports a submission or approval
it has no evidence of. If DMT publishes an API or partner programme, the package model is the integration point.

## Update workflow

Changed checksum or revision on a registered source → admin notification → reviewer
creates new rule versions → active rule set changes only after approval.
(0.1 implements versioning and verification; automated change detection is backlog.)
