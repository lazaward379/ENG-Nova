# File Format Support

| Format | Intake | Parse | Edit | Export | Notes |
|---|---|---|---|---|---|
| DXF (ASCII) | ✅ | ✅ subset | ✅ | ✅ R12 (AC1009) | via dxf-parser; see entity table |
| DXF (binary) | ✅ registered | ❌ | — | — | reported as unsupported |
| DWG | ✅ | ✅ when AutoCAD is installed locally | ✅ | ✅ AutoCAD 2018 format | read/written by the local AutoCAD Core Console (`accoreconsole.exe`); without AutoCAD, DWG is registered only |
| PDF sheet (output) | — | — | — | ✅ via AutoCAD plot (DWG To PDF.pc3) | detailed plan sheet, A1/A2/A3 |
| IFC | ✅ registered | ❌ | — | — | planned: web-ifc or IfcOpenShell |
| PDF | ✅ registered | ❌ | — | — | text/OCR extraction planned |
| PNG / JPEG | ✅ registered | ❌ | — | — | reference only; never treated as CAD geometry |
| CSV | ✅ | ✅ coordinate tables (`x,y` or `easting,northing` columns) | — | — | creates extracted facts with confidence |
| XLSX / DOCX | ✅ registered | ❌ | — | — | planned |

Uploads are limited to 50 MB, checked against an extension allow-list **and** magic bytes
where applicable (PDF, PNG, JPEG, ZIP-based XLSX/DOCX), stored content-addressed, and the
original is never modified.

## DXF entity support

| Entity | Import | Export | Round-trip tested |
|---|---|---|---|
| LINE | ✅ | ✅ | ✅ |
| LWPOLYLINE / POLYLINE (2D, no bulge) | ✅ | ✅ (as POLYLINE) | ✅ |
| CIRCLE | ✅ | ✅ | ✅ |
| ARC | ✅ | ✅ | ✅ |
| TEXT / MTEXT (plain content) | ✅ (MTEXT → TEXT, formatting codes stripped, flagged) | ✅ TEXT | ✅ |
| POINT | ✅ | ✅ | ✅ |
| Polyline bulges (arc segments) | ⚠ imported as straight segments **with a warning** | — | — |
| INSERT (blocks), HATCH, DIMENSION, SPLINE, ELLIPSE, 3DFACE, … | ❌ counted and listed per type in import diagnostics; kept in the original file | — | — |

NOVA-typed WALL / DOOR / WINDOW elements are exported as drafting primitives (wall outline polyline; door
leaf line + swing arc; window line). DXF R12 cannot carry their object semantics; the export notes this and
the round-trip verification compares against the exploded primitives. Importing DXF does not yet recognise
walls/doors/windows.

Import diagnostics are stored on the drawing and shown in the workspace. Nothing is
silently discarded: the original file stays in the register, and every skipped entity
type is reported with a count.

Export verification: after writing, NOVA re-parses its own output and compares entity
count, types, layers and coordinates (tolerance 1e-9) and reports the result.
