import { normalise } from './ruleParser.ts';

export type Suggestion = { key: string; value: string; evidence: string };

const NUMBER_WORDS: Record<string, number> = {
  one: 1, single: 1, two: 2, double: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8,
  واحد: 1, واحدة: 1, اثنين: 2, اثنان: 2, طابقين: 2, ثلاث: 3, ثلاثة: 3, اربع: 4, اربعة: 4, خمس: 5, خمسة: 5, ست: 6, ستة: 6,
};
const num = (w: string) => (/^\d+$/.test(w) ? parseInt(w, 10) : NUMBER_WORDS[w]);

const SPACES: [string, RegExp][] = [
  ['majlis', /majlis|مجلس/u], ['kitchen', /kitchen|مطبخ/u], ['living_room', /living|معيشة|صالة/u], ['dining_room', /dining|طعام/u],
  ['maid_room', /maid|خادمة/u], ['driver_room', /driver|سائق/u], ['parking', /parking|garage|carport|مواقف|موقف|كراج/u],
  ['landscaping', /landscap|garden|حديقة|تنسيق/u], ['swimming_pool', /pool|مسبح/u], ['basement', /basement|قبو|سرداب/u], ['roof_floor', /roof floor|penthouse|ملحق علوي/u],
];

/**
 * Offline extraction of requirement hints from a free-text description. Every result is a
 * suggestion (class ai_suggestion) with the text that triggered it — the user confirms or discards.
 */
export function suggestRequirements(description: string): Suggestion[] {
  const s = normalise(description);
  const out: Suggestion[] = [];
  const floors = s.match(/(\d+|one|single|two|double|three|four|five)[\s-]*(storey|story|stories|storeys|floor)s?/u)
    ?? s.match(/(طابق واحد|طابقين|(\d+|ثلاث|ثلاثة|اربع|اربعة)\s*طوابق)/u);
  if (floors) {
    const word = floors[0].includes('طابق واحد') ? 'واحد' : floors[0].includes('طابقين') ? 'طابقين' : floors[1] ?? floors[2];
    const n = num(word);
    if (n) out.push({ key: 'floors', value: String(n), evidence: floors[0] });
  }
  const beds = s.match(/(\d+|one|two|three|four|five|six|seven|eight)\s+(bed)?rooms?/u)
    ?? s.match(/(\d+|ثلاث|ثلاثة|اربع|اربعة|خمس|خمسة|ست|ستة)\s+غرف\s+نوم/u);
  if (beds && (beds[2] === 'bed' || beds[0].includes('نوم'))) {
    const n = num(beds[1]);
    if (n) out.push({ key: 'bedrooms', value: String(n), evidence: beds[0] });
  }
  for (const [key, re] of SPACES) {
    const m = s.match(re);
    if (m) out.push({ key: `space_${key}`, value: 'required', evidence: m[0] });
  }
  if (/villa|فيلا/u.test(s)) out.push({ key: 'building_type', value: 'residential villa', evidence: s.match(/villa|فيلا/u)![0] });
  return out;
}
