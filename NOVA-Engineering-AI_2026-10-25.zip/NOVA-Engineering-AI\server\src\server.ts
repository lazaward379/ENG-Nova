import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildApp } from './app.ts';

const here = dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.NOVA_DATA_DIR || join(here, '..', 'data');

const { app } = await buildApp({
  dbPath: process.env.NOVA_DB_PATH || join(dataDir, 'nova.sqlite'),
  storageDir: process.env.NOVA_STORAGE_DIR || join(dataDir, 'storage'),
  webDist: process.env.NOVA_WEB_DIST || join(here, '..', '..', 'web', 'dist'),
  allowSignup: process.env.NOVA_ALLOW_SIGNUP !== 'false',
  logger: true,
});

const port = Number(process.env.PORT || 8787);
const host = process.env.HOST || '127.0.0.1';
await app.listen({ port, host });
