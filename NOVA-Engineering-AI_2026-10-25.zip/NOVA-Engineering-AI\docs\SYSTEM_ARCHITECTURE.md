# System Architecture

## 1. Environment finding (2026-10-25)

The build machine has **Node.js 24.22 and npm 11** only. Python, Git and Docker are not
installed. The brief's preferred backend (Python/FastAPI/ezdxf/PostgreSQL) therefore could
not be run here. Decision:

| Concern | Brief preference | Chosen for 0.1 | Migration path |
|---|---|---|---|
| API | FastAPI + Pydantic | **Fastify 5 + Zod 4** (TypeScript, run via Node's native type stripping) | Same REST contract; Pydantic models mirror Zod schemas |
| DB | PostgreSQL + SQLAlchemy + Alembic | **SQLite via built-in `node:sqlite`**, numbered SQL migrations | Schema is plain SQL with FKs/indexes; port to PostgreSQL by re-running migrations with type tweaks |
| DXF | ezdxf | **dxf-parser** (read) + NOVA's own R12 writer (write) | Add a Python worker using ezdxf for the full entity set |
| DWG | commercial SDK | **Not supported** — boundary documented | ODA Drawings SDK / Teigha File Converter worker |
| IFC | IfcOpenShell | **Not parsed** — files registered only | web-ifc (browser) or IfcOpenShell worker |
| Queue | Celery + Redis | In-process synchronous jobs, recorded in `background_jobs` | BullMQ/Redis or Celery |
| Storage | S3-compatible | Local disk under `server/data/storage`, content-addressed by SHA-256 | `StorageProvider` interface; add S3 adapter |

No technology was added only because it was listed.

## 2. Modules

```
web/  (React 19 + TypeScript + Vite)
  app shell · i18n (en/ar, RTL) · command palette · screens
  cad/  Canvas2D renderer, view transform, grid spatial index, snapping, tools
server/src
  app.ts          HTTP wiring, auth hook, error handling
  db.ts           node:sqlite connection + migrations
  auth.ts         scrypt password hashing, session tokens, RBAC helpers
  storage.ts      StorageProvider (local), checksums, safe paths
  geometry/       entity model, math (area, bbox, transforms), validation
  dxf/            import (dxf-parser) with diagnostics, R12 export
  operations.ts   typed geometry operations, apply/invert, undo/redo
  rules/          rule registry, deterministic engine, QA checks
  copilot/        provider interface, deterministic bilingual parser, LLM provider
  reports.ts      HTML report generation
  routes/*.ts     REST endpoints
```

## 3. Request flow — copilot edit

```
user text ──► /copilot/interpret ──► provider (rule parser | LLM w/ tool schema)
                                         │ structured operations (Zod-validated)
                                         ▼
                              proposal stored (status=proposed) + preview diff
user approves ──► /proposals/:id/apply ──► operations.apply (transaction)
                                         ──► validation run ──► provenance record
undo ──► /drawings/:id/undo ──► inverse operation from stored before-state
```

The LLM never executes code; it may only emit operations from the fixed schema.

## 4. Security boundaries

Auth hook on every `/api` route except `/api/auth/*` and `/api/health`. Every query is
scoped by `org_id` derived from the session, never from the request body.
See `SECURITY_AND_PRIVACY.md`.
