# NOVA Engineering AI — Product Specification

Status: living document · Version 0.1 (first vertical slice) · 2026-10-25

## 1. Purpose

NOVA is an engineering support platform for consultancies, architectural practices and
design-build firms working in Abu Dhabi. It combines CAD-grade 2D geometry, a structured
engineering object model, deterministic validation, an auditable regulatory rule library,
an AI copilot that acts only through validated tools, and submission/document management.

NOVA is a **support tool**. It does not grant approvals, does not replace licensed
professionals, and does not submit to government portals unless a real, authorised
integration exists (none exists today).

## 2. Users

| Role | Typical needs |
|---|---|
| Organisation admin | Members, roles, rule-set governance, title blocks |
| Project engineer / architect | Intake, drafting, validation, revisions |
| Reviewer (licensed engineer) | Rule verification, approvals, sign-off |
| Viewer / client | Read-only access to issued documents and reports |

## 3. Primary journey

1. Create a project (wizard: description → plot → requirements → documents → readiness).
2. Upload plot information, survey, reference drawings (DXF today; others registered).
3. Describe the work in Arabic or English.
4. NOVA extracts facts with source + confidence, lists missing critical inputs.
5. Engineer edits geometry in the CAD workspace, directly or via the copilot.
6. Run compliance and drawing QA; review findings with evidence.
7. Approve, revise, export (DXF, HTML report) and manage revisions.

## 4. Information classes (always kept distinct)

- **Confirmed fact** — entered and confirmed by an authorised user, or from a verified source.
- **Extracted** — parsed from an uploaded document; carries source file + confidence.
- **Assumption** — explicit user assumption, labelled as such.
- **AI suggestion** — preliminary until reviewed.
- **Unresolved question** — missing input blocking a check or design step.

## 5. Scope of release 0.1 (implemented)

See `IMPLEMENTATION_ROADMAP.md` for the backlog and `KNOWN_LIMITATIONS.md` for gaps.

- Organisation sign-up, login, server-side authorisation, organisation isolation.
- Projects with a guided intake wizard and project facts with provenance class.
- Secure file intake (type allow-list, size limit, SHA-256 checksum, originals preserved).
- DXF import (supported entity subset) with diagnostics for unsupported entities.
- CAD workspace: real coordinates, pan/zoom, layers, selection, snapping, move/rotate/copy/
  delete/add, undo/redo, checkpoints (revisions), DXF export with round-trip verification.
- Rooms detected from closed polylines with deterministic shoelace areas.
- Rule engine with the seven mandated statuses; rule registry with source records,
  versioning and reviewer verification. Shipped regulatory rules are **unverified
  templates** until a reviewer records an official source.
- Drawing QA checks (geometry integrity, duplicates, zero-length, layer conventions).
- AI copilot: bilingual deterministic command parser plus optional LLM provider;
  proposal → preview → validate → apply → verify → undo pipeline.
- Reports (HTML, printable) with evidence; operation history; audit log.
- Bilingual UI (English / Arabic with real RTL), dark/light themes, command palette.

## 6. Non-goals for 0.1

DWG read/write, IFC parsing, OCR, clash detection, structural/MEP design, authority
submission. Each has a documented integration boundary and a visible placeholder screen.
