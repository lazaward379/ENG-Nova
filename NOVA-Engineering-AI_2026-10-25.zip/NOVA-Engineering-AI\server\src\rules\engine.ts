import { randomUUID } from 'node:crypto';
import { all, get, now, run, tx, type DB } from '../db.ts';
import { loadEntities, currentSeq, type DrawingRow } from '../drawings.ts';
import { buildContext, evaluators, type Fact, type Result, type Status } from './evaluators.ts';

type Seed = { code: string; title: string; title_ar: string; category: 'regulatory' | 'drawing_qa'; discipline: string; evaluator: string; interpretation: string; required_inputs: string[]; params?: Record<string, unknown> };

/**
 * Built-in rules. Drawing-QA rules are NOVA's own conventions (status "internal").
 * Regulatory rules are TEMPLATES only: deterministic logic with no threshold and no
 * citation. They report SOURCE NOT VERIFIED until a reviewer records an official source.
 */
const SEEDS: Seed[] = [
  { code: 'QA-UNITS', title: 'Drawing units defined', title_ar: 'تحديد وحدات الرسم', category: 'drawing_qa', discipline: 'general', evaluator: 'qa.units_defined', interpretation: 'A drawing must declare its length unit so that measurements are meaningful.', required_inputs: ['drawing units'] },
  { code: 'QA-DEGEN', title: 'No zero-length geometry', title_ar: 'لا توجد عناصر بطول صفري', category: 'drawing_qa', discipline: 'general', evaluator: 'qa.degenerate_geometry', interpretation: 'Lines and polylines must have non-zero length.', required_inputs: ['geometry'] },
  { code: 'QA-DUP', title: 'No duplicate entities', title_ar: 'لا توجد عناصر مكررة', category: 'drawing_qa', discipline: 'general', evaluator: 'qa.duplicates', interpretation: 'Identical entities on the same layer within 1e-6 units are duplicates.', required_inputs: ['geometry'] },
  { code: 'QA-ROOM-CLOSED', title: 'Room boundaries closed and simple', title_ar: 'حدود الغرف مغلقة وغير متقاطعة', category: 'drawing_qa', discipline: 'architectural', evaluator: 'qa.room_closure', interpretation: 'Room boundaries on room layers are closed polygons without self-intersection.', required_inputs: ['room boundaries'] },
  { code: 'QA-ROOM-LABEL', title: 'Each room has one label', title_ar: 'لكل غرفة تسمية واحدة', category: 'drawing_qa', discipline: 'architectural', evaluator: 'qa.room_labels', interpretation: 'Exactly one TEXT label lies inside each room boundary.', required_inputs: ['room boundaries', 'room labels'] },
  { code: 'QA-ROOM-OVERLAP', title: 'Rooms do not overlap', title_ar: 'عدم تداخل الغرف', category: 'drawing_qa', discipline: 'architectural', evaluator: 'qa.room_overlap', interpretation: 'Room polygons must not overlap.', required_inputs: ['room boundaries'] },
  { code: 'QA-LAYER0', title: 'No geometry on layer 0', title_ar: 'لا عناصر على الطبقة 0', category: 'drawing_qa', discipline: 'general', evaluator: 'qa.layer_zero', interpretation: 'Office layer convention: entities belong on discipline layers.', required_inputs: ['layers'] },
  { code: 'QA-OPENINGS', title: 'Doors and windows hosted within their walls', title_ar: 'الأبواب والنوافذ ضمن جدرانها', category: 'drawing_qa', discipline: 'architectural', evaluator: 'qa.openings', interpretation: 'Every door and window has an existing host wall, lies entirely within the wall length, and does not overlap another opening in the same wall.', required_inputs: ['typed walls', 'typed doors and windows'] },
  { code: 'QA-IMPORT', title: 'All source entities imported', title_ar: 'استيراد جميع عناصر الملف', category: 'drawing_qa', discipline: 'general', evaluator: 'qa.unsupported_entities', interpretation: 'Checks cover only imported entities; skipped entities are flagged.', required_inputs: ['import diagnostics'] },
  { code: 'REG-TPL-ROOM-AREA', title: 'Minimum room area (template)', title_ar: 'الحد الأدنى لمساحة الغرفة (قالب)', category: 'regulatory', discipline: 'architectural', evaluator: 'reg.room_min_area', interpretation: 'Rooms whose name matches room_name_pattern must have area ≥ min_area_m2. Threshold and applicability must come from a verified source.', required_inputs: ['room boundaries', 'room labels', 'drawing units', 'min_area_m2', 'room_name_pattern'] },
  { code: 'REG-TPL-COVERAGE', title: 'Maximum plot coverage (template)', title_ar: 'الحد الأقصى لنسبة التغطية (قالب)', category: 'regulatory', discipline: 'planning', evaluator: 'reg.plot_coverage', interpretation: 'Σ footprint area ÷ plot area ≤ max_coverage_pct. The maximum normally comes from the plot’s official planning document.', required_inputs: ['plot boundary', 'building footprint', 'max_coverage_pct'] },
  { code: 'REG-TPL-SETBACK', title: 'Minimum setback, uniform (template)', title_ar: 'الحد الأدنى للارتداد، موحد (قالب)', category: 'regulatory', discipline: 'planning', evaluator: 'reg.setback_uniform', interpretation: 'Every footprint lies inside the plot at ≥ min_setback_m from every boundary edge. Real setbacks often differ per side; this template applies one value to all sides.', required_inputs: ['plot boundary', 'building footprint', 'drawing units', 'min_setback_m'] },
];

export function seedRules(db: DB) {
  tx(db, () => {
    for (const s of SEEDS) {
      if (get(db, 'SELECT 1 FROM regulatory_rules WHERE org_id IS NULL AND code = ?', s.code)) continue;
      const id = randomUUID();
      run(db, 'INSERT INTO regulatory_rules (id, org_id, code, title, title_ar, category, discipline, evaluator, created_at) VALUES (?,NULL,?,?,?,?,?,?,?)',
        id, s.code, s.title, s.title_ar, s.category, s.discipline, s.evaluator, now());
      run(db, 'INSERT INTO rule_versions (id, rule_id, version, status, interpretation, params, required_inputs, created_at) VALUES (?,?,1,?,?,?,?,?)',
        randomUUID(), id, s.category === 'drawing_qa' ? 'internal' : 'template', s.interpretation, JSON.stringify(s.params ?? {}), JSON.stringify(s.required_inputs), now());
    }
  });
}

/** Rules visible to an org: its own copy of a code wins over the global template. */
export function activeRules(db: DB, orgId: string) {
  const rows = all(db, `SELECT r.*, v.id AS version_id, v.version, v.status AS version_status, v.source_id, v.clause, v.quotation, v.interpretation,
                               v.params, v.applicability, v.required_inputs, v.effective_date, v.reviewer_id, v.reviewed_at,
                               s.title AS source_title, s.authority AS source_authority, s.url AS source_url, s.verification_status AS source_status, s.revision AS source_revision,
                               u.name AS reviewer_name
                        FROM regulatory_rules r
                        JOIN rule_versions v ON v.rule_id = r.id AND v.status <> 'superseded'
                        LEFT JOIN regulatory_sources s ON s.id = v.source_id
                        LEFT JOIN users u ON u.id = v.reviewer_id
                        WHERE r.org_id IS NULL OR r.org_id = ?
                        ORDER BY r.category DESC, r.code, r.org_id IS NULL`, orgId);
  const byCode = new Map<string, any>();
  for (const r of rows) if (!byCode.has(r.code) || r.org_id) byCode.set(r.code, r);
  return [...byCode.values()].map((r) => ({ ...r, params: JSON.parse(r.params), applicability: JSON.parse(r.applicability), required_inputs: JSON.parse(r.required_inputs) }));
}

export function projectFacts(db: DB, projectId: string): Map<string, Fact> {
  return new Map(all(db, 'SELECT key, value, class, source, unit FROM project_facts WHERE project_id = ?', projectId).map((f) => [f.key, f as Fact]));
}

export type Finding = Result & { rule_code: string; rule_version_id: string; rule_title: string; category: string; source: Record<string, unknown> | null };

export function evaluateRules(db: DB, orgId: string, drawing: DrawingRow, filter?: (rule: any) => boolean): Finding[] {
  const entities = loadEntities(db, drawing.id);
  const ctx = buildContext(entities, drawing.units, JSON.parse(drawing.import_diagnostics || '{}'), projectFacts(db, drawing.project_id));
  const findings: Finding[] = [];
  for (const rule of activeRules(db, orgId).filter(filter ?? (() => true))) {
    const ev = evaluators[rule.evaluator];
    const source = rule.source_id ? { id: rule.source_id, title: rule.source_title, authority: rule.source_authority, url: rule.source_url, revision: rule.source_revision, clause: rule.clause, quotation: rule.quotation, status: rule.source_status } : null;
    const common = { rule_code: rule.code, rule_version_id: rule.version_id, rule_title: rule.title, category: rule.category, source };
    let results: Result[];
    try {
      results = ev ? ev(ctx, rule.params) : [{ status: 'NOT CHECKED', message: `No evaluator "${rule.evaluator}" is installed.` }];
    } catch (e: any) {
      results = [{ status: 'NOT CHECKED', message: `Evaluator error: ${e?.message ?? e}` }];
    }
    if (rule.category === 'regulatory' && rule.version_status !== 'verified') {
      // Measurements are kept as information, but nothing is assessed without a verified source.
      results = [{
        status: 'SOURCE NOT VERIFIED',
        message: 'This rule is a template with no verified official source. Not assessed.',
        evidence: { measured_for_information_only: results.map((r) => ({ message: r.message, inputs: r.inputs, evidence: r.evidence })) },
        correctiveAction: 'A reviewer must register the official source, clause and parameter values before this rule can be assessed.',
      }];
    } else if (rule.category === 'regulatory' && rule.source_status === 'test_only') {
      results = results.map((r) => ({ ...r, message: `[TEST SOURCE — not a real regulation] ${r.message}` }));
    }
    for (const r of results) findings.push({ ...common, ...r });
  }
  return findings;
}

export function runCompliance(db: DB, orgId: string, userId: string, drawing: DrawingRow, filter?: (rule: any) => boolean) {
  const findings = evaluateRules(db, orgId, drawing, filter);
  const summary: Record<string, number> = {};
  for (const f of findings) summary[f.status] = (summary[f.status] ?? 0) + 1;
  const runId = randomUUID();
  tx(db, () => {
    run(db, 'INSERT INTO compliance_runs (id, project_id, drawing_id, op_seq, rule_version_ids, summary, run_by, created_at) VALUES (?,?,?,?,?,?,?,?)',
      runId, drawing.project_id, drawing.id, currentSeq(db, drawing.id), JSON.stringify([...new Set(findings.map((f) => f.rule_version_id))]), JSON.stringify(summary), userId, now());
    for (const f of findings) {
      run(db, `INSERT INTO compliance_findings (id, run_id, rule_version_id, rule_code, status, message, inputs, evidence, entity_ids, location, corrective_action)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        randomUUID(), runId, f.rule_version_id, f.rule_code, f.status, f.message, JSON.stringify(f.inputs ?? {}), JSON.stringify({ ...(f.evidence ?? {}), source: f.source }),
        JSON.stringify(f.entityIds ?? []), f.location ? JSON.stringify(f.location) : null, f.correctiveAction ?? '');
    }
  });
  return { runId, summary, findings };
}

export function loadRun(db: DB, runId: string) {
  const runRow = get(db, 'SELECT * FROM compliance_runs WHERE id = ?', runId);
  if (!runRow) return null;
  const findings = all(db, `SELECT f.*, r.title AS rule_title, r.category FROM compliance_findings f
                            JOIN rule_versions v ON v.id = f.rule_version_id JOIN regulatory_rules r ON r.id = v.rule_id
                            WHERE f.run_id = ? ORDER BY r.category DESC, f.rule_code`, runId)
    .map((f) => ({ ...f, inputs: JSON.parse(f.inputs), evidence: JSON.parse(f.evidence), entity_ids: JSON.parse(f.entity_ids), location: f.location ? JSON.parse(f.location) : null }));
  return { ...runRow, summary: JSON.parse(runRow.summary), rule_version_ids: JSON.parse(runRow.rule_version_ids), findings };
}

export type StatusCount = Partial<Record<Status, number>>;
