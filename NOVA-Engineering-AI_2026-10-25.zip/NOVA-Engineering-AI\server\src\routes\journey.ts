import type { FastifyInstance } from 'fastify';
import { all, get } from '../db.ts';
import type { Deps } from '../app.ts';
import { projectForOrg } from './projects.ts';

type Step = { key: string; status: 'done' | 'partial' | 'todo' | 'unavailable'; en: string; ar: string; detail_en: string; detail_ar: string; route: string };

/** Design journey: the real state of each stage, computed from the project's data (never assumed). */
export function journeyRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;
  app.get('/api/projects/:id/journey', async (req) => {
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const facts = all(db, 'SELECT key, class FROM project_facts WHERE project_id = ?', p.id);
    const confirmed = new Set(facts.filter((f) => f.class === 'confirmed').map((f) => f.key));
    const docs = all(db, 'SELECT original_name, origin, ext FROM documents WHERE project_id = ?', p.id);
    const drawings = all(db, `SELECT d.id, d.name, (SELECT COUNT(*) FROM entities e WHERE e.drawing_id = d.id AND e.type = 'WALL') AS walls,
                              (SELECT COUNT(*) FROM entities e WHERE e.drawing_id = d.id) AS entities FROM drawings d WHERE d.project_id = ? ORDER BY d.updated_at DESC`, p.id);
    const main = drawings.find((d) => d.walls > 0) ?? drawings[0];
    const lastRun = main ? get<any>(db, 'SELECT summary, created_at FROM compliance_runs WHERE drawing_id = ? ORDER BY created_at DESC LIMIT 1', main.id) : null;
    const summary = lastRun ? JSON.parse(lastRun.summary) : null;
    const pkg = get<any>(db, "SELECT status, external_reference FROM submission_packages WHERE project_id = ? ORDER BY created_at DESC LIMIT 1", p.id);
    const comments = get<any>(db, "SELECT COUNT(*) AS n FROM review_comments WHERE project_id = ? AND status IN ('open','in_progress')", p.id)?.n ?? 0;
    const gen = docs.filter((d) => d.origin === 'generated');
    const planSheet = gen.some((d) => d.ext === 'pdf' && !/ELEV-SECT/.test(d.original_name) && /_1-\d+_A\d/.test(d.original_name));
    const elevSheet = gen.some((d) => d.ext === 'pdf' && /ELEV-SECT/.test(d.original_name));
    const plotKeys = ['plot_id', 'plot_area_m2', 'setbacks', 'max_plot_coverage_pct'].filter((k) => confirmed.has(k));
    const reqKeys = ['floors', 'bedrooms', 'gross_area_target_m2', 'target_authority'].filter((k) => confirmed.has(k));

    const steps: Step[] = [
      {
        key: 'brief', en: 'Brief & requirements', ar: 'الوصف والمتطلبات', route: `project/${p.id}/requirements`,
        status: p.description && reqKeys.length ? 'done' : p.description ? 'partial' : 'todo',
        detail_en: p.description ? `${reqKeys.length} confirmed requirement(s)` : 'Describe the project', detail_ar: p.description ? `${reqKeys.length} متطلبات مؤكدة` : 'اكتب وصف المشروع',
      },
      {
        key: 'plot', en: 'Plot & documents', ar: 'القطعة والوثائق', route: `project/${p.id}/plot`,
        status: plotKeys.length >= 3 ? 'done' : plotKeys.length || docs.some((d) => d.origin === 'upload') ? 'partial' : 'todo',
        detail_en: `${plotKeys.length}/4 plot facts confirmed · ${docs.filter((d) => d.origin === 'upload').length} uploaded file(s)`,
        detail_ar: `${plotKeys.length}/4 من بيانات القطعة مؤكدة · ${docs.filter((d) => d.origin === 'upload').length} ملفات مرفوعة`,
      },
      {
        key: 'plan', en: 'Floor plan', ar: 'المسقط الأفقي', route: main ? `workspace/${main.id}` : 'generate',
        status: main?.walls ? 'done' : main ? 'partial' : 'todo',
        detail_en: main ? `${main.name}: ${main.walls} walls, ${main.entities} elements` : 'Draw from a reference project or in the CAD workspace',
        detail_ar: main ? `${main.name}: ${main.walls} جدار، ${main.entities} عنصر` : 'ارسم من مشروع مرجعي أو في مساحة CAD',
      },
      {
        key: 'checks', en: 'Checks & readiness', ar: 'الفحص والجاهزية', route: main ? 'compliance' : `project/${p.id}/readiness`,
        status: !summary ? 'todo' : (summary.FAIL ?? 0) === 0 ? 'done' : 'partial',
        detail_en: summary ? `last run: ${Object.entries(summary).map(([k, v]) => `${k} ${v}`).join(', ')}` : 'No checks run yet',
        detail_ar: summary ? `آخر فحص: ${summary.PASS ?? 0} ناجح، ${summary.FAIL ?? 0} راسب، ${summary.WARNING ?? 0} تحذير` : 'لم يتم تشغيل الفحوصات بعد',
      },
      {
        key: 'sheets', en: 'Drawing sheets (AutoCAD)', ar: 'لوحات المخططات (AutoCAD)', route: main ? `workspace/${main.id}` : 'generate',
        status: planSheet && elevSheet ? 'done' : planSheet || elevSheet ? 'partial' : 'todo',
        detail_en: `plan sheet ${planSheet ? '✓' : '—'} · elevations & section ${elevSheet ? '✓' : '—'}`,
        detail_ar: `لوحة المسقط ${planSheet ? '✓' : '—'} · الواجهات والمقطع ${elevSheet ? '✓' : '—'}`,
      },
      {
        key: 'submission', en: 'Municipality submission (Binaa)', ar: 'التقديم للبلدية (بناء)', route: 'submission',
        status: !pkg ? 'todo' : ['submitted_manually', 'approval_recorded'].includes(pkg.status) ? 'done' : 'partial',
        detail_en: pkg ? `package: ${pkg.status.replace(/_/g, ' ')}${pkg.external_reference ? ` · application ${pkg.external_reference}` : ''}${comments ? ` · ${comments} open comment(s)` : ''}` : 'No package yet',
        detail_ar: pkg ? `الحزمة: ${pkg.status}${pkg.external_reference ? ` · رقم الطلب ${pkg.external_reference}` : ''}${comments ? ` · ${comments} ملاحظات مفتوحة` : ''}` : 'لا توجد حزمة تقديم بعد',
      },
      {
        key: 'shop', en: 'Shop drawings (construction)', ar: 'المخططات التنفيذية (شوب دروينغ)', route: 'shop',
        status: 'unavailable',
        detail_en: 'Needs approved design + verified structural/MEP data. The AutoCAD plan sheet (DWG) is the base to develop them.',
        detail_ar: 'تحتاج تصميماً معتمداً وبيانات إنشائية وكهروميكانيكية موثقة. لوحة المسقط (DWG) هي الأساس لتطويرها.',
      },
    ];
    return { project: { id: p.id, code: p.code, name: p.name }, drawingId: main?.id ?? null, steps, openComments: comments };
  });
}
