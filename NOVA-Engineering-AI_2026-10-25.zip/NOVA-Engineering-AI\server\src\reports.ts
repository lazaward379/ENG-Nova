import { all, get, type DB } from './db.ts';
import { loadEntities, type DrawingRow } from './drawings.ts';
import { extractRooms } from './geometry/rooms.ts';
import { loadRun } from './rules/engine.ts';

const esc = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

const STATUS_COLOR: Record<string, string> = {
  PASS: '#0f7b4f', FAIL: '#b42318', WARNING: '#b54708', 'NOT CHECKED': '#475467', 'INSUFFICIENT DATA': '#6941c6',
  'REQUIRES ENGINEER REVIEW': '#175cd3', 'SOURCE NOT VERIFIED': '#344054',
};

/** Self-contained, printable HTML compliance and drawing report. */
export function complianceReportHtml(db: DB, drawing: DrawingRow, runId: string, generatedBy: string): string {
  const project = get<any>(db, 'SELECT * FROM projects WHERE id = ?', drawing.project_id);
  const runRow = loadRun(db, runId)!;
  const entities = loadEntities(db, drawing.id);
  const rooms = extractRooms(entities, drawing.units);
  const diag = JSON.parse(drawing.import_diagnostics || '{}');
  const facts = all(db, 'SELECT key, value, unit, class, source, confidence FROM project_facts WHERE project_id = ? ORDER BY key', drawing.project_id);
  const revisions = all(db, 'SELECT number, label, created_at FROM drawing_revisions WHERE drawing_id = ? ORDER BY number', drawing.id);
  const sourceDoc = drawing.source_document_id ? get<any>(db, 'SELECT original_name, sha256 FROM documents WHERE id = ?', drawing.source_document_id) : null;
  const blocking = runRow.findings.filter((f: any) => f.status !== 'PASS');

  const findingRows = runRow.findings.map((f: any) => `
    <tr>
      <td><code>${esc(f.rule_code)}</code><div class="muted">${esc(f.rule_title)}</div></td>
      <td><span class="badge" style="background:${STATUS_COLOR[f.status] ?? '#344054'}">${esc(f.status)}</span></td>
      <td>${esc(f.message)}${f.corrective_action ? `<div class="muted">Action: ${esc(f.corrective_action)}</div>` : ''}</td>
      <td><pre>${esc(JSON.stringify(f.inputs, null, 1))}</pre></td>
      <td><pre>${esc(JSON.stringify({ ...f.evidence, source: undefined }, null, 1))}</pre>
          ${f.evidence?.source ? `<div class="muted">Source: ${esc(f.evidence.source.authority)} — ${esc(f.evidence.source.title)} ${esc(f.evidence.source.clause)} (${esc(f.evidence.source.status)})</div>` : '<div class="muted">Source: NOVA internal QA convention</div>'}</td>
    </tr>`).join('');

  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>NOVA Report — ${esc(project.code)} — ${esc(drawing.name)}</title>
<style>
body{font:13px/1.45 "IBM Plex Sans","Segoe UI",Tahoma,sans-serif;color:#101828;margin:32px;max-width:1200px}
h1{font-size:22px;margin:0}h2{font-size:16px;margin:28px 0 8px;border-bottom:1px solid #d0d5dd;padding-bottom:4px}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #e4e7ec;padding:6px 8px;vertical-align:top;text-align:start}
th{background:#f2f4f7;font-weight:600}pre{margin:0;font-size:11px;white-space:pre-wrap;max-width:320px}
.badge{color:#fff;border-radius:4px;padding:2px 6px;font-size:11px;font-weight:600;white-space:nowrap}
.muted{color:#667085;font-size:11px}.banner{border:2px solid #b54708;background:#fffaeb;padding:10px 12px;margin:16px 0}
@media print{body{margin:12mm}}
</style></head><body>
<h1>NOVA Engineering AI — Drawing Check Report</h1>
<div class="muted">Generated ${esc(new Date().toISOString())} by ${esc(generatedBy)} · Run ${esc(runRow.id)} · Drawing state at operation #${esc(runRow.op_seq)}</div>
<div class="banner"><strong>Engineering support output — not an authority approval.</strong>
This report records automated checks against the rule versions listed below. It does not certify compliance with Abu Dhabi
regulations. Results marked SOURCE NOT VERIFIED, INSUFFICIENT DATA or NOT CHECKED have not been assessed.
Professional review and sign-off by an appropriately licensed engineer is required before any submission.
${blocking.length ? `<br><strong>${blocking.length} result(s) are not PASS.</strong>` : ''}</div>

<h2>Project</h2>
<table><tr><th>Code</th><td>${esc(project.code)}</td><th>Name</th><td>${esc(project.name)}</td></tr>
<tr><th>Type</th><td>${esc(project.project_type)}</td><th>Status</th><td>${esc(project.status)}</td></tr>
<tr><th>Description</th><td colspan="3">${esc(project.description)}</td></tr></table>

<h2>Project facts and provenance</h2>
${facts.length ? `<table><tr><th>Key</th><th>Value</th><th>Class</th><th>Source</th><th>Confidence</th></tr>
${facts.map((f) => `<tr><td>${esc(f.key)}</td><td>${esc(f.value)} ${esc(f.unit ?? '')}</td><td>${esc(f.class)}</td><td>${esc(f.source)}</td><td>${esc(f.confidence ?? '')}</td></tr>`).join('')}</table>` : '<p class="muted">No project facts recorded.</p>'}

<h2>Drawing</h2>
<table><tr><th>Name</th><td>${esc(drawing.name)}</td><th>Units</th><td>${esc(drawing.units)}</td></tr>
<tr><th>Source file</th><td>${sourceDoc ? `${esc(sourceDoc.original_name)}<div class="muted">SHA-256 ${esc(sourceDoc.sha256)}</div>` : 'created in NOVA'}</td><th>Entities</th><td>${entities.length}</td></tr>
<tr><th>Import warnings</th><td colspan="3">${(diag.warnings ?? []).map((w: string) => `• ${esc(w)}`).join('<br>') || '—'}</td></tr>
<tr><th>Revisions</th><td colspan="3">${revisions.map((r) => `R${r.number} ${esc(r.label)} (${esc(r.created_at)})`).join('<br>') || '—'}</td></tr></table>

<h2>Rooms (derived from closed boundaries)</h2>
${rooms.length ? `<table><tr><th>Name</th><th>Area (m²)</th><th>Vertices</th><th>Valid</th></tr>
${rooms.map((r) => `<tr><td>${esc(r.name ?? '(unlabelled)')}</td><td>${r.areaM2 === null ? 'units unknown' : (Math.round(r.areaM2 * 1000) / 1000).toFixed(3)}</td><td>${r.points.length}</td><td>${r.valid ? 'yes' : esc(r.problems.join(', '))}</td></tr>`).join('')}</table>` : '<p class="muted">No room boundaries found.</p>'}

<h2>Check results</h2>
<p>${Object.entries(runRow.summary).map(([k, v]) => `<span class="badge" style="background:${STATUS_COLOR[k] ?? '#344054'}">${esc(k)}: ${v}</span>`).join(' ')}</p>
<table><tr><th>Rule</th><th>Status</th><th>Result</th><th>Inputs</th><th>Evidence</th></tr>${findingRows}</table>

<h2>Sign-off</h2>
<table><tr><th>Prepared by</th><td style="height:40px"></td><th>Reviewed by (licensed engineer)</th><td></td></tr>
<tr><th>Date</th><td></td><th>Date</th><td></td></tr></table>
</body></html>`;
}
