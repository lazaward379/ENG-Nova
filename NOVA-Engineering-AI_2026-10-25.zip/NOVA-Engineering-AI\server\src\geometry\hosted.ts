import type { Entity, EntityInput, Pt } from './types.ts';
import { arcPoint, dist } from './math.ts';

export type WallEntity = Extract<Entity, { type: 'WALL' }>;
export type OpeningEntity = Extract<Entity, { type: 'DOOR' | 'WINDOW' }>;
export const isOpening = (e: { type: string }): e is OpeningEntity => e.type === 'DOOR' || e.type === 'WINDOW';

export function wallFrame(w: { a: Pt; b: Pt }) {
  const len = dist(w.a, w.b);
  const dir = len ? { x: (w.b.x - w.a.x) / len, y: (w.b.y - w.a.y) / len } : { x: 1, y: 0 };
  return { len, dir, normal: { x: -dir.y, y: dir.x } };
}

/** Recompute the derived centre and direction of an opening from its host wall. */
export function resolveOpening<T extends { geom: any }>(o: T, wall: { geom: { a: Pt; b: Pt } }): T {
  const { dir } = wallFrame(wall.geom);
  const p = { x: wall.geom.a.x + dir.x * o.geom.offset, y: wall.geom.a.y + dir.y * o.geom.offset };
  return { ...o, geom: { ...o.geom, p, dir } };
}

/** Constraint check: the opening lies wholly within its wall, clear of the wall ends. */
export function openingWithinWall(o: { geom: { offset: number; width: number } }, wall: { geom: { a: Pt; b: Pt } }, tol = 1e-9) {
  const { len } = wallFrame(wall.geom);
  return o.geom.offset - o.geom.width / 2 >= -tol && o.geom.offset + o.geom.width / 2 <= len + tol;
}

export function openingsOverlap(a: { geom: { offset: number; width: number } }, b: { geom: { offset: number; width: number } }, tol = 1e-9) {
  return Math.abs(a.geom.offset - b.geom.offset) < (a.geom.width + b.geom.width) / 2 - tol;
}

/** Wall outline as a closed rectangle around its centreline. */
export function wallOutline(g: { a: Pt; b: Pt; thickness: number }): Pt[] {
  const { normal: n } = wallFrame(g);
  const h = g.thickness / 2;
  return [
    { x: g.a.x + n.x * h, y: g.a.y + n.y * h }, { x: g.b.x + n.x * h, y: g.b.y + n.y * h },
    { x: g.b.x - n.x * h, y: g.b.y - n.y * h }, { x: g.a.x - n.x * h, y: g.a.y - n.y * h },
  ];
}

/** Door leaf hinge, leaf tip and swing arc derived from the opening geometry. */
export function doorParts(g: { p?: Pt; dir?: Pt; width: number; swing: 'left' | 'right'; side: 1 | -1 }) {
  const p = g.p!, d = g.dir!;
  const sgn = g.swing === 'left' ? -1 : 1;
  const hinge = { x: p.x + sgn * d.x * g.width / 2, y: p.y + sgn * d.y * g.width / 2 };
  const n = { x: -d.y * g.side, y: d.x * g.side };
  const tip = { x: hinge.x + n.x * g.width, y: hinge.y + n.y * g.width };
  const closed = { x: p.x - sgn * d.x * g.width / 2, y: p.y - sgn * d.y * g.width / 2 };
  const ang = (q: Pt) => (Math.atan2(q.y - hinge.y, q.x - hinge.x) * 180) / Math.PI;
  let start = ang(closed), end = ang(tip);
  // keep the 90° sweep counter-clockwise
  if ((((end - start) % 360) + 360) % 360 > 180) [start, end] = [end, start];
  return { hinge, tip, closed, start, end };
}

/** Typed elements as plain drafting primitives (used for DXF export and bounding geometry). */
export function explode(e: EntityInput): EntityInput[] {
  const L = e.layer;
  switch (e.type) {
    case 'WALL': return [{ type: 'POLYLINE', layer: L, geom: { points: wallOutline(e.geom), closed: true } }];
    case 'DOOR': {
      const k = doorParts(e.geom as any);
      return [
        { type: 'LINE', layer: L, geom: { a: k.hinge, b: k.tip } },
        { type: 'ARC', layer: L, geom: { c: k.hinge, r: e.geom.width, start: k.start, end: k.end } },
      ];
    }
    case 'WINDOW': {
      const { p, dir: d } = e.geom as any;
      const h = e.geom.width / 2;
      const a = { x: p.x - d.x * h, y: p.y - d.y * h }, b = { x: p.x + d.x * h, y: p.y + d.y * h };
      return [{ type: 'LINE', layer: L, geom: { a, b } }];
    }
    default: return [e];
  }
}

export function typedPoints(e: EntityInput): Pt[] | null {
  switch (e.type) {
    case 'WALL': return wallOutline(e.geom);
    case 'DOOR': { const k = doorParts(e.geom as any); return [k.hinge, k.tip, k.closed, arcPoint(k.hinge, e.geom.width, (k.start + k.end) / 2)]; }
    case 'WINDOW': { const { p, dir: d } = e.geom as any; const h = e.geom.width / 2; return [{ x: p.x - d.x * h, y: p.y - d.y * h }, { x: p.x + d.x * h, y: p.y + d.y * h }]; }
    default: return null;
  }
}
