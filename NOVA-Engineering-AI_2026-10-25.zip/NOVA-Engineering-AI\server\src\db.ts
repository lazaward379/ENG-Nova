import { DatabaseSync } from 'node:sqlite';
import { readdirSync, readFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export type DB = DatabaseSync;
type Row = any;

const MIGRATIONS_DIR = join(dirname(fileURLToPath(import.meta.url)), 'migrations');

export function openDb(path: string): DB {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec('PRAGMA foreign_keys = ON;');
  if (path !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
  migrate(db);
  return db;
}

function migrate(db: DB) {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  const applied = new Set(all(db, 'SELECT name FROM schema_migrations').map((r) => r.name));
  const files = readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith('.sql')).sort();
  // Table rebuilds drop/rename tables, so FK enforcement is paused during migrations and re-checked after.
  db.exec('PRAGMA foreign_keys = OFF;');
  try {
    for (const f of files) {
      if (applied.has(f)) continue;
      tx(db, () => {
        db.exec(readFileSync(join(MIGRATIONS_DIR, f), 'utf8'));
        run(db, 'INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)', f, now());
      });
    }
    const broken = all(db, 'PRAGMA foreign_key_check');
    if (broken.length) throw new Error(`foreign key check failed after migration: ${JSON.stringify(broken.slice(0, 3))}`);
  } finally {
    db.exec('PRAGMA foreign_keys = ON;');
  }
}

export const now = () => new Date().toISOString();

export function get<T = Row>(db: DB, sql: string, ...params: any[]): T | undefined {
  return db.prepare(sql).get(...params) as T | undefined;
}
export function all<T = Row>(db: DB, sql: string, ...params: any[]): T[] {
  return db.prepare(sql).all(...params) as T[];
}
export function run(db: DB, sql: string, ...params: any[]) {
  return db.prepare(sql).run(...params);
}

let depth = 0;
/** Run fn in a transaction (nested calls join the outer transaction). */
export function tx<T>(db: DB, fn: () => T): T {
  if (depth > 0) return fn();
  db.exec('BEGIN');
  depth++;
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    depth--;
  }
}

export function audit(db: DB, orgId: string | null, userId: string | null, action: string, target = '', detail: unknown = {}) {
  run(db, 'INSERT INTO audit_events (org_id, user_id, action, target, detail, created_at) VALUES (?,?,?,?,?,?)',
    orgId, userId, action, target, JSON.stringify(detail), now());
}
