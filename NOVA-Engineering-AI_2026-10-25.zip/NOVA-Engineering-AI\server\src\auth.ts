import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { get, now, run, type DB } from './db.ts';

export type Role = 'admin' | 'reviewer' | 'engineer' | 'viewer';
export type SessionUser = { userId: string; orgId: string; role: Role; name: string; email: string; orgName: string };

const SESSION_HOURS = 12;
const SCRYPT = { N: 16384, r: 8, p: 1 } as const;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const key = scryptSync(password, salt, 64, SCRYPT);
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [alg, saltB64, keyB64] = stored.split('$');
  if (alg !== 'scrypt' || !saltB64 || !keyB64) return false;
  const expected = Buffer.from(keyB64, 'base64');
  const actual = scryptSync(password, Buffer.from(saltB64, 'base64'), expected.length, SCRYPT);
  return timingSafeEqual(expected, actual);
}

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

export function createSession(db: DB, userId: string, orgId: string): string {
  const token = randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + SESSION_HOURS * 3600_000).toISOString();
  run(db, 'INSERT INTO sessions (token_hash, user_id, org_id, expires_at, created_at) VALUES (?,?,?,?,?)', sha256(token), userId, orgId, expires, now());
  return token;
}

export function sessionFromToken(db: DB, token: string): SessionUser | null {
  const row = get<any>(db, `SELECT s.user_id, s.org_id, s.expires_at, m.role, u.name, u.email, o.name AS org_name
                            FROM sessions s JOIN memberships m ON m.user_id = s.user_id AND m.org_id = s.org_id
                            JOIN users u ON u.id = s.user_id JOIN organizations o ON o.id = s.org_id
                            WHERE s.token_hash = ?`, sha256(token));
  if (!row || row.expires_at < now()) return null;
  return { userId: row.user_id, orgId: row.org_id, role: row.role, name: row.name, email: row.email, orgName: row.org_name };
}

export function destroySession(db: DB, token: string) {
  run(db, 'DELETE FROM sessions WHERE token_hash = ?', sha256(token));
}

const RANK: Record<Role, number> = { viewer: 0, engineer: 1, reviewer: 2, admin: 3 };
/** Reviewer and admin can do everything an engineer can; verification needs reviewer or admin. */
export const atLeast = (role: Role, min: Role) => RANK[role] >= RANK[min];

/** Fixed-window in-memory limiter (single process). */
export function rateLimiter(limit: number, windowMs: number) {
  const hits = new Map<string, { n: number; reset: number }>();
  return (key: string) => {
    const t = Date.now();
    const h = hits.get(key);
    if (!h || h.reset < t) { hits.set(key, { n: 1, reset: t + windowMs }); return true; }
    h.n++;
    return h.n <= limit;
  };
}
