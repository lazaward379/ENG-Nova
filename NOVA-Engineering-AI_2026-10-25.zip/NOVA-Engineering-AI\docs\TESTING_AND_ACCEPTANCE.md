# Testing and Acceptance

## Test suites

| Suite | Runner | Command |
|---|---|---|
| Geometry math & validation | `node --test` | `cd server; npm test` |
| DXF import / export round-trip | `node --test` | included |
| Operations, undo/redo | `node --test` | included |
| Rule engine statuses | `node --test` | included |
| Copilot parser (EN/AR) | `node --test` | included |
| API integration (auth, isolation, full vertical slice) | `node --test` + Fastify `inject` | included |
| Frontend type-check and build | `tsc -b && vite build` | `cd web; npm run build` |

Test results for each cycle are recorded in `IMPLEMENTATION_ROADMAP.md` (cycle log).

## Acceptance — first vertical slice

Each item is covered by `server/test/api.test.ts` ("vertical slice") and was also
exercised manually in the browser.

1. Start locally with documented commands.
2. Create a project.
3. Upload a DXF.
4. Inspect real geometry.
5. Modify geometry (move).
6. Save (checkpoint) and reload.
7. Run a deterministic validation.
8. See a result with evidence.
9. Generate a report.
10. Export DXF (verified by re-parse).
11. Inspect operation history.

## Acceptance — AI slice

Instruction (EN or AR) → structured proposal → preview → validation → apply → verify → undo.
Tested with the deterministic provider. The LLM provider is exercised only when
`ANTHROPIC_API_KEY` is set; it is not covered by automated tests.

## Acceptance — regulatory slice

Template rule → reviewer records source + parameter → verified version → deterministic
execution with inputs, evidence and source reference. The test uses a clearly labelled
**test source** (`TEST-ONLY`), not a real regulation.
