import { useEffect, useImperativeHandle, useMemo, useRef, forwardRef } from 'react';
import type { Entity, Layer, Pt } from '../api';
import { SpatialIndex, distanceTo, drawEntity, fitView, gridStep, render, snapCandidates, toScreen, toWorld, unionBBox, entityBBox, projectOnWall, wallFrame, type View, type SnapKind } from './engine';

export type Tool = 'select' | 'pan' | 'line' | 'rect' | 'polyline' | 'circle' | 'text' | 'measure' | 'wall' | 'door' | 'window';
export type NewEntity = { type: Entity['type']; layer: string; geom: any };

export type CadHandle = { fit: () => void; focus: (p: Pt, ids?: string[]) => void };

type Props = {
  entities: Entity[];
  layers: Layer[];
  selected: Set<string>;
  onSelect: (ids: Set<string>) => void;
  tool: Tool;
  activeLayer: string;
  snap: boolean;
  gridSnap: boolean;
  ortho: boolean;
  showGrid: boolean;
  ghosts: Entity[];
  markers: { p: Pt; status: string; n: number; active: boolean }[];
  onCreate: (es: NewEntity[]) => void;
  onMoveBy: (dx: number, dy: number) => void;
  onRequestText: (p: Pt) => void;
  onCursor: (p: Pt | null, snap: SnapKind | null) => void;
  onMeasure: (a: Pt, b: Pt) => void;
  theme: string;
  /** Element sizes in drawing units (null when the drawing has no units). */
  wallThickness: number | null;
  doorWidth: number | null;
  windowWidth: number | null;
  onHint: (text: string | null) => void;
};

export const CadCanvas = forwardRef<CadHandle, Props>(function CadCanvas(props, ref) {
  const wrap = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const view = useRef<View>({ ox: 0, oy: 0, scale: 1, width: 1, height: 1 });
  const fitted = useRef(false);
  const st = useRef({
    mouse: null as Pt | null, snapped: null as { p: Pt; kind: SnapKind } | null, panning: null as { sx: number; sy: number; ox: number; oy: number } | null,
    box: null as { a: Pt; b: Pt } | null, drag: null as { from: Pt; to: Pt } | null, pts: [] as Pt[], hover: null as string | null, space: false,
  });
  const p = useRef(props);
  p.current = props;

  const index = useMemo(() => new SpatialIndex(props.entities), [props.entities]);
  const layerInfo = useMemo(() => new Map(props.layers.map((l) => [l.name, l])), [props.layers]);
  const theme = useMemo(() => {
    const cs = getComputedStyle(document.documentElement);
    const v = (n: string) => cs.getPropertyValue(n).trim();
    return { fg: v('--text'), grid: v('--canvas-grid'), gridMajor: v('--canvas-grid-major'), sel: v('--cyan'), ghost: v('--violet'), text: v('--text-2'), bg: v('--canvas-bg') };
  }, [props.theme]);

  // Long-lived callbacks (ResizeObserver, window key handlers) must see the latest index, not the one from mount.
  const live = useRef({ index, layerInfo, theme });
  live.current = { index, layerInfo, theme };

  const raf = useRef(0);
  const draw = () => {
    cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(() => {
      const { index, layerInfo, theme } = live.current;
      const c = canvas.current;
      if (!c) return;
      const ctx = c.getContext('2d')!;
      const dpr = window.devicePixelRatio || 1;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const s = st.current, P = p.current, v = view.current;
      const ghosts = [...P.ghosts];
      if (s.drag) {
        const dx = s.drag.to.x - s.drag.from.x, dy = s.drag.to.y - s.drag.from.y;
        for (const e of P.entities) if (P.selected.has(e.id)) {
          // a door/window whose wall is not being moved slides along that wall, as the server will do
          if ((e.type === 'DOOR' || e.type === 'WINDOW') && !P.selected.has(e.geom.wallId)) {
            const along = dx * e.geom.dir.x + dy * e.geom.dir.y;
            ghosts.push(shift(e, along * e.geom.dir.x, along * e.geom.dir.y));
          } else ghosts.push(shift(e, dx, dy));
        }
      }
      const hostPreview = openingPreview();
      if (hostPreview) ghosts.push(hostPreview);
      render(ctx, { view: v, index, layerInfo, selected: P.selected, hover: s.hover, ghosts, markers: P.markers, showGrid: P.showGrid, theme });      // rubber band for drawing tools
      const cur = s.snapped?.p ?? s.mouse;
      if (cur && s.pts.length) {
        ctx.strokeStyle = theme.sel; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
        const rb = rubber(P.tool, s.pts, applyOrtho(s.pts[s.pts.length - 1], cur, P.ortho), P.wallThickness ?? 0);
        for (const e of rb) drawEntity(ctx, v, e);
        ctx.setLineDash([]);
      }
      if (s.box) {
        const a = toScreen(v, s.box.a), b = toScreen(v, s.box.b);
        ctx.fillStyle = 'rgba(34,211,238,0.08)'; ctx.strokeStyle = theme.sel; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
        ctx.fillRect(a.x, a.y, b.x - a.x, b.y - a.y); ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y); ctx.setLineDash([]);
      }
      if (s.snapped && s.snapped.kind !== 'grid') {
        const q = toScreen(v, s.snapped.p);
        ctx.strokeStyle = '#fbbf24'; ctx.lineWidth = 1.5; ctx.beginPath();
        if (s.snapped.kind === 'endpoint') ctx.rect(q.x - 5, q.y - 5, 10, 10);
        else if (s.snapped.kind === 'midpoint') { ctx.moveTo(q.x, q.y - 6); ctx.lineTo(q.x + 6, q.y + 5); ctx.lineTo(q.x - 6, q.y + 5); ctx.closePath(); }
        else ctx.arc(q.x, q.y, 6, 0, Math.PI * 2);
        ctx.stroke();
      }
    });
  };

  const resize = () => {
    const w = wrap.current!, c = canvas.current!;
    const dpr = window.devicePixelRatio || 1;
    const { width, height } = w.getBoundingClientRect();
    c.width = Math.max(1, width * dpr); c.height = Math.max(1, height * dpr);
    const v = view.current;
    // keep the world point at the centre of the view fixed when the canvas resizes
    const cx = v.ox + v.width / v.scale / 2, cy = v.oy + v.height / v.scale / 2;
    view.current = { ...v, width, height, ox: cx - width / v.scale / 2, oy: cy - height / v.scale / 2 };
    if (!fitted.current && width > 10) { fit(); fitted.current = true; }
    draw();
  };

  const fit = () => {
    const P = p.current;
    const b = unionBBox(P.entities.map(entityBBox));
    view.current = fitView(b, view.current.width, view.current.height);
    draw();
  };

  useImperativeHandle(ref, () => ({
    fit,
    focus: (pt: Pt, ids?: string[]) => {
      const P = p.current;
      const ents = ids?.length ? P.entities.filter((e) => ids.includes(e.id)) : [];
      const b = unionBBox(ents.map(entityBBox));
      if (b) {
        const pad = Math.max(b.maxX - b.minX, b.maxY - b.minY, 1) * 1.5;
        view.current = fitView({ minX: b.minX - pad, minY: b.minY - pad, maxX: b.maxX + pad, maxY: b.maxY + pad }, view.current.width, view.current.height);
      } else {
        const v = view.current;
        view.current = { ...v, ox: pt.x - v.width / v.scale / 2, oy: pt.y - v.height / v.scale / 2 };
      }
      draw();
    },
  }));

  useEffect(() => {
    const ro = new ResizeObserver(resize);
    ro.observe(wrap.current!);
    return () => ro.disconnect();
  }, []);
  useEffect(draw, [index, layerInfo, props.selected, props.ghosts, props.markers, props.showGrid, theme, props.tool]);
  useEffect(() => { st.current.pts = []; draw(); }, [props.tool]);

  const snapAt = (sx: number, sy: number): { p: Pt; kind: SnapKind } | null => {
    const P = p.current, v = view.current;
    const w = toWorld(v, sx, sy);
    if (P.snap) {
      const r = 10 / v.scale;
      let best: { p: Pt; kind: SnapKind; d: number } | null = null;
      for (const i of index.query({ minX: w.x - r, minY: w.y - r, maxX: w.x + r, maxY: w.y + r })) {
        const e = index.entities[i];
        if (layerInfo.get(e.layer)?.visible === false) continue;
        for (const c of snapCandidates(e)) {
          const d = Math.hypot(c.p.x - w.x, c.p.y - w.y);
          if (d <= r && (!best || d < best.d)) best = { ...c, d };
        }
      }
      if (best) return { p: best.p, kind: best.kind };
    }
    if (P.gridSnap) {
      const s = gridStep(v.scale);
      return { p: { x: Math.round(w.x / s) * s, y: Math.round(w.y / s) * s }, kind: 'grid' };
    }
    return null;
  };

  /** Nearest wall under the cursor and where an opening of the current tool would sit on it. */
  const hostAt = (w: Pt) => {
    const P = p.current, v = view.current;
    const width = P.tool === 'door' ? P.doorWidth : P.windowWidth;
    if (!width) return null;
    let best: { wall: Entity; offset: number; d: number; len: number } | null = null;
    const r = 12 / v.scale;
    for (const i of index.query({ minX: w.x - r, minY: w.y - r, maxX: w.x + r, maxY: w.y + r })) {
      const e = index.entities[i];
      if (e.type !== 'WALL' || layerInfo.get(e.layer)?.visible === false) continue;
      const pr = projectOnWall(e.geom, w);
      if (pr.perp <= e.geom.thickness / 2 + r && (!best || pr.perp < best.d)) best = { wall: e, offset: pr.offset, d: pr.perp, len: pr.len };
    }
    if (!best) return null;
    const offset = Math.min(Math.max(best.offset, width / 2), best.len - width / 2);
    return { wall: best.wall, offset, width, fits: best.len >= width };
  };
  const openingPreview = (): Entity | null => {
    const P = p.current, s = st.current;
    if ((P.tool !== 'door' && P.tool !== 'window') || !s.mouse) return null;
    const h = hostAt(s.mouse);
    if (!h || !h.fits) return null;
    const { dir } = wallFrame(h.wall.geom);
    const pt = { x: h.wall.geom.a.x + dir.x * h.offset, y: h.wall.geom.a.y + dir.y * h.offset };
    return { id: '_', type: P.tool === 'door' ? 'DOOR' : 'WINDOW', layer: '_', props: {}, provenance: 'preview', geom: { wallId: h.wall.id, offset: h.offset, width: h.width, swing: 'left', side: 1, p: pt, dir } };
  };

  const pick = (w: Pt): string | null => {
    const v = view.current, r = 6 / v.scale;
    let best: { id: string; d: number } | null = null;
    for (const i of index.query({ minX: w.x - r, minY: w.y - r, maxX: w.x + r, maxY: w.y + r })) {
      const e = index.entities[i];
      if (layerInfo.get(e.layer)?.visible === false) continue;
      const d = distanceTo(e, w);
      if (d <= r && (!best || d < best.d)) best = { id: e.id, d };
    }
    return best?.id ?? null;
  };

  const local = (ev: { clientX: number; clientY: number }) => {
    const r = canvas.current!.getBoundingClientRect();
    return { sx: ev.clientX - r.left, sy: ev.clientY - r.top };
  };

  const onPointerDown = (ev: React.PointerEvent) => {
    canvas.current!.setPointerCapture(ev.pointerId);
    const { sx, sy } = local(ev);
    const s = st.current, P = p.current, v = view.current;
    if (ev.button === 1 || P.tool === 'pan' || s.space) { s.panning = { sx, sy, ox: v.ox, oy: v.oy }; return; }
    if (ev.button !== 0) return;
    const w = toWorld(v, sx, sy);
    const at = s.snapped?.p ?? w;
    if (P.tool === 'select') {
      const id = pick(w);
      if (id) {
        const locked = layerInfo.get(index.entities.find((e) => e.id === id)!.layer)?.locked;
        if (ev.shiftKey) { const n = new Set(P.selected); n.has(id) ? n.delete(id) : n.add(id); P.onSelect(n); }
        else if (!P.selected.has(id)) P.onSelect(new Set([id]));
        if (!ev.shiftKey && !locked) s.drag = { from: at, to: at };
      } else {
        if (!ev.shiftKey) P.onSelect(new Set());
        s.box = { a: w, b: w };
      }
      draw();
      return;
    }
    if (P.tool === 'door' || P.tool === 'window') {
      const h = hostAt(w);
      if (!h) P.onHint('Click on a wall to place the opening.');
      else if (!h.fits) P.onHint('This wall is shorter than the opening width.');
      else { P.onHint(null); P.onCreate([{ type: P.tool === 'door' ? 'DOOR' : 'WINDOW', layer: P.activeLayer, geom: { wallId: h.wall.id, offset: h.offset, width: h.width, ...(P.tool === 'door' ? { swing: 'left', side: 1 } : {}) } }]); }
      return;
    }
    const pt = s.pts.length ? applyOrtho(s.pts[s.pts.length - 1], at, P.ortho) : at;
    s.pts.push(pt);
    const L = P.activeLayer;
    if (P.tool === 'wall' && s.pts.length === 2) {
      if (P.wallThickness && (s.pts[0].x !== s.pts[1].x || s.pts[0].y !== s.pts[1].y)) P.onCreate([{ type: 'WALL', layer: L, geom: { a: s.pts[0], b: s.pts[1], thickness: P.wallThickness } }]);
      s.pts = [pt]; // chain walls
    }
    else if (P.tool === 'text') { s.pts = []; P.onRequestText(pt); }
    else if (P.tool === 'line' && s.pts.length === 2) { P.onCreate([{ type: 'LINE', layer: L, geom: { a: s.pts[0], b: s.pts[1] } }]); s.pts = [pt]; }
    else if (P.tool === 'rect' && s.pts.length === 2) {
      const [a, b] = s.pts;
      if (a.x !== b.x && a.y !== b.y) P.onCreate([{ type: 'POLYLINE', layer: L, geom: { points: [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }], closed: true } }]);
      s.pts = [];
    } else if (P.tool === 'circle' && s.pts.length === 2) {
      const r = Math.hypot(s.pts[1].x - s.pts[0].x, s.pts[1].y - s.pts[0].y);
      if (r > 0) P.onCreate([{ type: 'CIRCLE', layer: L, geom: { c: s.pts[0], r } }]);
      s.pts = [];
    } else if (P.tool === 'measure' && s.pts.length === 2) { P.onMeasure(s.pts[0], s.pts[1]); s.pts = []; }
    draw();
  };

  const onPointerMove = (ev: React.PointerEvent) => {
    const { sx, sy } = local(ev);
    const s = st.current, P = p.current, v = view.current;
    if (s.panning) {
      view.current = { ...v, ox: s.panning.ox - (sx - s.panning.sx) / v.scale, oy: s.panning.oy + (sy - s.panning.sy) / v.scale };
      draw(); return;
    }
    const w = toWorld(v, sx, sy);
    s.mouse = w;
    s.snapped = P.tool === 'pan' ? null : snapAt(sx, sy);
    if (s.box) s.box.b = w;
    if (s.drag) s.drag.to = applyOrtho(s.drag.from, s.snapped?.p ?? w, P.ortho);
    if (P.tool === 'select' && !s.box && !s.drag) s.hover = pick(w);
    P.onCursor(s.snapped?.p ?? w, s.snapped?.kind ?? null);
    draw();
  };

  const onPointerUp = () => {
    const s = st.current, P = p.current;
    s.panning = null;
    if (s.drag) {
      const dx = s.drag.to.x - s.drag.from.x, dy = s.drag.to.y - s.drag.from.y;
      s.drag = null;
      if (dx || dy) P.onMoveBy(dx, dy);
    }
    if (s.box) {
      const { a, b } = s.box;
      s.box = null;
      const box = { minX: Math.min(a.x, b.x), minY: Math.min(a.y, b.y), maxX: Math.max(a.x, b.x), maxY: Math.max(a.y, b.y) };
      if (box.maxX - box.minX > 2 / view.current.scale) {
        const hits = index.query(box).filter((i) => {
          const e = index.entities[i], eb = index.boxes[i];
          return layerInfo.get(e.layer)?.visible !== false && eb.minX >= box.minX && eb.maxX <= box.maxX && eb.minY >= box.minY && eb.maxY <= box.maxY;
        }).map((i) => index.entities[i].id);
        P.onSelect(new Set([...P.selected, ...hits]));
      }
    }
    draw();
  };

  const onDoubleClick = () => {
    const s = st.current, P = p.current;
    if (P.tool === 'polyline' && s.pts.length >= 3) {
      // the double-click's second pointerdown added a duplicate final point
      const pts = s.pts.slice(0, -1);
      if (pts.length >= 2) P.onCreate([{ type: 'POLYLINE', layer: P.activeLayer, geom: { points: pts, closed: false } }]);
      s.pts = []; draw();
    }
  };

  const onWheel = (ev: React.WheelEvent) => {
    const { sx, sy } = local(ev);
    const v = view.current;
    const w = toWorld(v, sx, sy);
    const k = Math.exp(-ev.deltaY * 0.0015);
    const scale = Math.min(1e6, Math.max(1e-7, v.scale * k));
    view.current = { ...v, scale, ox: w.x - sx / scale, oy: w.y - (v.height - sy) / scale };
    draw();
  };

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.closest('input, textarea, select')) return;
      const s = st.current, P = p.current;
      if (e.key === ' ') { s.space = true; e.preventDefault(); }
      if (e.key === 'Escape') { s.pts = []; s.box = null; s.drag = null; draw(); }
      if (e.key === 'Enter' && P.tool === 'polyline' && s.pts.length >= 2) { P.onCreate([{ type: 'POLYLINE', layer: P.activeLayer, geom: { points: s.pts, closed: false } }]); s.pts = []; draw(); }
      if ((e.key === 'c' || e.key === 'C') && P.tool === 'polyline' && s.pts.length >= 3) { P.onCreate([{ type: 'POLYLINE', layer: P.activeLayer, geom: { points: s.pts, closed: true } }]); s.pts = []; draw(); }
    };
    const up = (e: KeyboardEvent) => { if (e.key === ' ') st.current.space = false; };
    window.addEventListener('keydown', down); window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  return (
    <div ref={wrap} className="ws-canvas" onMouseLeave={() => { st.current.mouse = null; p.current.onCursor(null, null); }}>
      <canvas ref={canvas} role="img" aria-label="CAD drawing canvas"
        onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onDoubleClick={onDoubleClick} onWheel={onWheel}
        onContextMenu={(e) => e.preventDefault()}
        style={{ cursor: props.tool === 'pan' ? 'grab' : props.tool === 'select' ? 'default' : 'crosshair' }} />
    </div>
  );
});

function applyOrtho(from: Pt, to: Pt, ortho: boolean): Pt {
  if (!ortho) return to;
  return Math.abs(to.x - from.x) >= Math.abs(to.y - from.y) ? { x: to.x, y: from.y } : { x: from.x, y: to.y };
}

function shift(e: Entity, dx: number, dy: number): Entity {
  const m = (p: Pt) => ({ x: p.x + dx, y: p.y + dy });
  const g = e.geom;
  const geom = e.type === 'LINE' || e.type === 'WALL' ? { ...g, a: m(g.a), b: m(g.b) } : e.type === 'POLYLINE' ? { ...g, points: g.points.map(m) }
    : e.type === 'CIRCLE' || e.type === 'ARC' ? { ...g, c: m(g.c) } : { ...g, p: m(g.p) };
  return { ...e, geom };
}

function rubber(tool: Tool, pts: Pt[], cur: Pt, thickness: number): Entity[] {
  const mk = (type: Entity['type'], geom: any): Entity => ({ id: '_', type, layer: '_', geom, props: {}, provenance: 'preview' });
  const last = pts[pts.length - 1];
  switch (tool) {
    case 'wall': return thickness && (last.x !== cur.x || last.y !== cur.y) ? [mk('WALL', { a: last, b: cur, thickness })] : [];
    case 'line': case 'measure': return [mk('LINE', { a: last, b: cur })];
    case 'polyline': return [mk('POLYLINE', { points: [...pts, cur], closed: false })];
    case 'rect': return [mk('POLYLINE', { points: [pts[0], { x: cur.x, y: pts[0].y }, cur, { x: pts[0].x, y: cur.y }], closed: true })];
    case 'circle': return [mk('CIRCLE', { c: pts[0], r: Math.max(1e-9, Math.hypot(cur.x - pts[0].x, cur.y - pts[0].y)) })];
    default: return [];
  }
}
