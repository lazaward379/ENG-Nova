import type { FastifyInstance, FastifyRequest } from 'fastify';
import { createHash, randomUUID } from 'node:crypto';
import { z } from 'zod';
import { all, audit, get, now, run, tx } from '../db.ts';
import { HttpError, requireRole, type Deps } from '../app.ts';
import { createDrawing, currentSeq, drawingForOrg, layers, loadEntities, ensureLayer, type DrawingRow } from '../drawings.ts';
import { applyOperation, computeEffect, history, Operation, redo, undo } from '../operations.ts';
import { bbox, geomEqual } from '../geometry/math.ts';
import { extractRooms } from '../geometry/rooms.ts';
import type { Entity } from '../geometry/types.ts';
import { explode } from '../geometry/hosted.ts';
import { exportDxf, verifyExport } from '../dxf/dxf.ts';
import { loadRun, runCompliance } from '../rules/engine.ts';
import { complianceReportHtml } from '../reports.ts';
import { applyProposal, interpret, providerStatus, rejectProposal } from '../copilot/service.ts';
import { projectForOrg } from './projects.ts';

export function drawingRoutes(app: FastifyInstance, deps: Deps) {
  const { db } = deps;
  const drawingOf = (req: FastifyRequest): DrawingRow => {
    const d = drawingForOrg(db, (req.params as any).id, req.user.orgId);
    if (!d) throw new HttpError(404, 'drawing not found');
    return d;
  };

  app.post('/api/projects/:id/drawings', async (req) => {
    requireRole(req, 'engineer');
    const p = projectForOrg(deps, (req.params as any).id, req.user.orgId);
    const b = z.object({ name: z.string().trim().min(1).max(200), units: z.enum(['mm', 'cm', 'm', 'in', 'ft']) }).parse(req.body);
    const id = createDrawing(db, { projectId: p.id, name: b.name, units: b.units, userId: req.user.userId, diagnostics: { format: 'created in NOVA', units: b.units, unitsSource: 'chosen at creation', warnings: [], imported: {}, skipped: {} } });
    ensureLayer(db, id, '0');
    audit(db, req.user.orgId, req.user.userId, 'drawing.created', id);
    return { id };
  });

  app.get('/api/drawings/:id', async (req) => {
    const d = drawingOf(req);
    const entities = loadEntities(db, d.id);
    const project = get<any>(db, 'SELECT id, code, name FROM projects WHERE id = ?', d.project_id);
    const canUndo = !!get(db, "SELECT 1 FROM geometry_operations WHERE drawing_id = ? AND state = 'applied'", d.id);
    const canRedo = !!get(db, "SELECT 1 FROM geometry_operations WHERE drawing_id = ? AND state = 'undone'", d.id);
    return {
      ...d, import_diagnostics: JSON.parse(d.import_diagnostics || '{}'), project, entities, layers: layers(db, d.id),
      extents: bbox(entities), seq: currentSeq(db, d.id), canUndo, canRedo,
      rooms: extractRooms(entities, d.units).map((r) => ({ entityId: r.entityId, name: r.name, areaM2: r.areaM2, areaUnits2: r.areaUnits2, valid: r.valid, problems: r.problems })),
    };
  });

  app.patch('/api/drawings/:id', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const b = z.object({ name: z.string().trim().min(1).max(200).optional(), units: z.enum(['mm', 'cm', 'm', 'in', 'ft']).optional(), unitsSource: z.string().max(300).optional() }).parse(req.body);
    if (b.units && d.units !== 'unitless' && b.units !== d.units) throw new HttpError(409, `units are already defined (${d.units}); changing them would change the meaning of every coordinate`);
    if (b.units && !b.unitsSource?.trim()) throw new HttpError(400, 'state where the units come from (unitsSource)');
    const diag = JSON.parse(d.import_diagnostics || '{}');
    if (b.units) { diag.units = b.units; diag.unitsSource = `set by ${req.user.name}: ${b.unitsSource}`; }
    run(db, 'UPDATE drawings SET name = ?, units = ?, import_diagnostics = ?, updated_at = ? WHERE id = ?', b.name ?? d.name, b.units ?? d.units, JSON.stringify(diag), now(), d.id);
    audit(db, req.user.orgId, req.user.userId, 'drawing.updated', d.id, b);
    return { ok: true };
  });

  app.patch('/api/drawings/:id/layers/:name', async (req) => {
    const d = drawingOf(req);
    const b = z.object({ visible: z.boolean().optional(), locked: z.boolean().optional(), color: z.number().int().min(1).max(255).optional() }).parse(req.body);
    if (b.locked !== undefined || b.color !== undefined) requireRole(req, 'engineer');
    const name = decodeURIComponent((req.params as any).name);
    const l = get<any>(db, 'SELECT * FROM layers WHERE drawing_id = ? AND name = ?', d.id, name);
    if (!l) throw new HttpError(404, 'layer not found');
    run(db, 'UPDATE layers SET visible = ?, locked = ?, color = ? WHERE drawing_id = ? AND name = ?',
      b.visible === undefined ? l.visible : +b.visible, b.locked === undefined ? l.locked : +b.locked, b.color ?? l.color, d.id, name);
    if (b.locked !== undefined) audit(db, req.user.orgId, req.user.userId, b.locked ? 'layer.locked' : 'layer.unlocked', d.id, { layer: name });
    return { ok: true };
  });

  // ---- geometry operations ----
  app.post('/api/drawings/:id/preview', async (req) => {
    const d = drawingOf(req);
    const op = Operation.parse((req.body as any)?.op);
    const e = computeEffect(db, d.id, op, 'user');
    return { errors: e.errors, warnings: e.warnings, changes: e.changes };
  });

  app.post('/api/drawings/:id/operations', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const op = Operation.parse((req.body as any)?.op);
    const r = applyOperation(db, d.id, op, req.user.userId, 'user');
    audit(db, req.user.orgId, req.user.userId, 'geometry.operation', d.id, { kind: op.kind, seq: r.seq, affected: r.changes.length });
    return { id: r.id, seq: r.seq, affected: r.changes.length, created: r.changes.filter((c) => !c.before).map((c) => c.id), warnings: r.warnings };
  });

  app.post('/api/drawings/:id/undo', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const r = undo(db, d.id);
    if (r) audit(db, req.user.orgId, req.user.userId, 'geometry.undo', d.id, r);
    return { undone: r };
  });
  app.post('/api/drawings/:id/redo', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const r = redo(db, d.id);
    if (r) audit(db, req.user.orgId, req.user.userId, 'geometry.redo', d.id, r);
    return { redone: r };
  });
  app.get('/api/drawings/:id/history', async (req) => history(db, drawingOf(req).id));

  // ---- revisions (checkpoints) ----
  app.post('/api/drawings/:id/revisions', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const { label } = z.object({ label: z.string().trim().min(1).max(200) }).parse(req.body);
    const snapshot = JSON.stringify(loadEntities(db, d.id));
    const id = randomUUID();
    const number = tx(db, () => {
      const n = ((get<any>(db, 'SELECT COALESCE(MAX(number), 0) AS n FROM drawing_revisions WHERE drawing_id = ?', d.id)?.n) ?? 0) + 1;
      run(db, 'INSERT INTO drawing_revisions (id, drawing_id, number, label, snapshot, sha256, op_seq, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
        id, d.id, n, label, snapshot, createHash('sha256').update(snapshot).digest('hex'), currentSeq(db, d.id), req.user.userId, now());
      return n;
    });
    audit(db, req.user.orgId, req.user.userId, 'drawing.checkpoint', d.id, { number, label });
    return { id, number };
  });
  app.get('/api/drawings/:id/revisions', async (req) => {
    const d = drawingOf(req);
    return all(db, `SELECT r.id, r.number, r.label, r.sha256, r.op_seq, r.created_at, u.name AS author, json_array_length(r.snapshot) AS entities
                    FROM drawing_revisions r JOIN users u ON u.id = r.created_by WHERE r.drawing_id = ? ORDER BY r.number DESC`, d.id);
  });
  /** Compare a checkpoint with the current drawing state. */
  app.get('/api/drawings/:id/revisions/:revId/diff', async (req) => {
    const d = drawingOf(req);
    const rev = get<any>(db, 'SELECT snapshot, number FROM drawing_revisions WHERE id = ? AND drawing_id = ?', (req.params as any).revId, d.id);
    if (!rev) throw new HttpError(404, 'revision not found');
    const old: Entity[] = JSON.parse(rev.snapshot);
    const cur = loadEntities(db, d.id);
    const oldMap = new Map(old.map((e) => [e.id, e]));
    const curMap = new Map(cur.map((e) => [e.id, e]));
    return {
      revision: rev.number,
      added: cur.filter((e) => !oldMap.has(e.id)).map((e) => e.id),
      removed: old.filter((e) => !curMap.has(e.id)).map((e) => ({ id: e.id, type: e.type, layer: e.layer })),
      modified: cur.filter((e) => oldMap.has(e.id) && (oldMap.get(e.id)!.layer !== e.layer || !geomEqual(oldMap.get(e.id)!, e, 1e-9))).map((e) => e.id),
    };
  });

  // ---- export ----
  app.post('/api/drawings/:id/export', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const all_ = loadEntities(db, d.id);
    if (!all_.length) throw new HttpError(422, 'drawing is empty');
    // DXF R12 has no wall/door/window objects: typed elements are written as their drafting primitives.
    const typed = all_.filter((e) => ['WALL', 'DOOR', 'WINDOW'].includes(e.type)).length;
    const entities = all_.flatMap((e) => explode(e).map((x) => ({ ...x, props: e.props })));
    const dxf = exportDxf(entities, layers(db, d.id), d.units);
    const verification = { ...verifyExport(dxf, entities, d.units), typedElementsExploded: typed };
    if (!verification.ok) throw Object.assign(new HttpError(500, 'export verification failed; file not stored'), { verification });
    const buf = Buffer.from(dxf, 'utf8');
    const { key, sha256 } = deps.storage.put(buf);
    const docId = randomUUID();
    const name = `${d.name.replace(/[^\p{L}\p{N}._ -]/gu, '_')}_seq${currentSeq(db, d.id)}.dxf`;
    run(db, `INSERT INTO documents (id, org_id, project_id, original_name, ext, mime, size_bytes, sha256, storage_key, origin, derived_from, classification, extraction_status, extraction_notes, uploaded_by, created_at)
             VALUES (?,?,?,?,'dxf','image/vnd.dxf',?,?,?,'generated',?,'cad_drawing','parsed',?,?,?)`,
      docId, req.user.orgId, d.project_id, name, buf.length, sha256, key, d.source_document_id, JSON.stringify([`Generated DXF R12 export of drawing "${d.name}" at operation #${currentSeq(db, d.id)}.`, `Re-parse verification: ${verification.reparsed}/${verification.expected} entities matched, units preserved.`,
        ...(typed ? [`${typed} wall/door/window element(s) written as lines, arcs and polylines; their object semantics are not preserved in DXF R12.`] : [])]),
      req.user.userId, now());
    audit(db, req.user.orgId, req.user.userId, 'drawing.exported', d.id, { document: docId, sha256 });
    return { documentId: docId, name, sha256, verification };
  });

  // ---- compliance ----
  app.post('/api/drawings/:id/compliance-runs', async (req) => {
    const d = drawingOf(req);
    const { scope } = z.object({ scope: z.enum(['all', 'drawing_qa', 'regulatory']).default('all') }).parse(req.body ?? {});
    const r = runCompliance(db, req.user.orgId, req.user.userId, d, scope === 'all' ? undefined : (rule) => rule.category === scope);
    audit(db, req.user.orgId, req.user.userId, 'compliance.run', d.id, { run: r.runId, summary: r.summary });
    return loadRun(db, r.runId);
  });
  app.get('/api/drawings/:id/compliance-runs', async (req) => {
    const d = drawingOf(req);
    return all(db, 'SELECT r.id, r.summary, r.op_seq, r.created_at, u.name AS run_by FROM compliance_runs r JOIN users u ON u.id = r.run_by WHERE r.drawing_id = ? ORDER BY r.created_at DESC LIMIT 50', d.id)
      .map((r) => ({ ...r, summary: JSON.parse(r.summary) }));
  });
  const runForOrg = (req: FastifyRequest) => {
    const r = get<any>(db, 'SELECT r.id, r.drawing_id FROM compliance_runs r JOIN projects p ON p.id = r.project_id WHERE r.id = ? AND p.org_id = ?', (req.params as any).id, req.user.orgId);
    if (!r) throw new HttpError(404, 'run not found');
    return r;
  };
  app.get('/api/compliance-runs/:id', async (req) => loadRun(db, runForOrg(req).id));
  app.get('/api/compliance-runs/:id/report', async (req, reply) => {
    const r = runForOrg(req);
    const d = drawingForOrg(db, r.drawing_id, req.user.orgId)!;
    audit(db, req.user.orgId, req.user.userId, 'report.generated', r.id);
    reply.header('content-type', 'text/html; charset=utf-8').header('content-security-policy', "default-src 'none'; style-src 'unsafe-inline'");
    return complianceReportHtml(db, d, r.id, req.user.name);
  });
  app.patch('/api/findings/:id', async (req) => {
    requireRole(req, 'engineer');
    const b = z.object({ resolution: z.enum(['open', 'resolved', 'accepted_risk']) }).parse(req.body);
    if (b.resolution === 'accepted_risk') requireRole(req, 'reviewer');
    const f = get<any>(db, `SELECT f.id FROM compliance_findings f JOIN compliance_runs r ON r.id = f.run_id JOIN projects p ON p.id = r.project_id WHERE f.id = ? AND p.org_id = ?`, (req.params as any).id, req.user.orgId);
    if (!f) throw new HttpError(404, 'finding not found');
    run(db, 'UPDATE compliance_findings SET resolution = ?, assignee_id = ? WHERE id = ?', b.resolution, req.user.userId, f.id);
    audit(db, req.user.orgId, req.user.userId, 'finding.resolution', f.id, b);
    return { ok: true };
  });

  // ---- copilot ----
  app.get('/api/copilot/providers', async () => providerStatus());
  app.post('/api/drawings/:id/copilot', async (req) => {
    const d = drawingOf(req);
    const b = z.object({ instruction: z.string().trim().min(1).max(2000), selection: z.array(z.string().uuid()).max(10_000).default([]), provider: z.enum(['rule', 'anthropic']).default('rule') }).parse(req.body);
    const r = await interpret(db, req.user.orgId, req.user.userId, d, b.instruction, b.selection, b.provider);
    audit(db, req.user.orgId, req.user.userId, 'copilot.interpret', d.id, { proposal: r.id, intent: r.intent.intent, status: r.status });
    return r;
  });
  app.get('/api/drawings/:id/proposals', async (req) => {
    const d = drawingOf(req);
    return all(db, `SELECT a.id, a.instruction, a.language, a.provider, a.model, a.intent, a.operation, a.explanation, a.assumptions, a.validation, a.status, a.applied_op_id, a.created_at, u.name AS author, ap.name AS approved_by
                    FROM ai_proposals a JOIN users u ON u.id = a.created_by LEFT JOIN users ap ON ap.id = a.approved_by WHERE a.drawing_id = ? ORDER BY a.created_at DESC LIMIT 100`, d.id)
      .map((a) => ({ ...a, intent: JSON.parse(a.intent), operation: a.operation ? JSON.parse(a.operation) : null, assumptions: JSON.parse(a.assumptions), validation: JSON.parse(a.validation) }));
  });
  app.post('/api/drawings/:id/proposals/:pid/apply', async (req) => {
    requireRole(req, 'engineer');
    const d = drawingOf(req);
    const r = applyProposal(db, req.user.orgId, req.user.userId, d, (req.params as any).pid);
    audit(db, req.user.orgId, req.user.userId, 'copilot.applied', d.id, { proposal: (req.params as any).pid, operation: r.operationId });
    return r;
  });
  app.post('/api/drawings/:id/proposals/:pid/reject', async (req) => {
    const d = drawingOf(req);
    if (!rejectProposal(db, d.id, (req.params as any).pid)) throw new HttpError(409, 'proposal is not awaiting approval');
    audit(db, req.user.orgId, req.user.userId, 'copilot.rejected', d.id, { proposal: (req.params as any).pid });
    return { ok: true };
  });
}
