import PptxGenJS from 'pptxgenjs';
import { all, get, type DB } from '../db.ts';
import { loadEntities, type DrawingRow } from '../drawings.ts';
import { extractRooms, closedOnLayer, PLOT_LAYER } from '../geometry/rooms.ts';
import { metresPerUnit } from '../geometry/types.ts';
import { polygonArea } from '../geometry/math.ts';
import { evaluateRules } from '../rules/engine.ts';
import { CRITICAL_INPUTS } from '../routes/projects.ts';
import { planSvg } from './planSvg.ts';

export type Lang = 'ar' | 'en';
export type Slide = {
  kind: 'cover' | 'brief' | 'site' | 'plan' | 'areas' | 'heights' | 'checks' | 'next' | 'close';
  title: string; subtitle?: string; bullets: string[]; table?: { head: string[]; rows: string[][] };
  svg?: string; notes: string;
};

const FACT_LABEL: Record<string, [string, string]> = {
  floors: ['Floors', 'عدد الأدوار'], bedrooms: ['Bedrooms', 'غرف النوم'], gross_area_target_m2: ['Target area (m²)', 'المساحة المستهدفة (م²)'],
  parking_spaces: ['Parking spaces', 'المواقف'], structural_system: ['Structural system', 'النظام الإنشائي'], design_language: ['Design language', 'الطابع المعماري'],
  target_authority: ['Authority / workflow', 'الجهة المعتمدة'], plot_id: ['Plot number', 'رقم القطعة'], plot_area_m2: ['Plot area (m²)', 'مساحة القطعة (م²)'],
  setbacks: ['Setbacks', 'الارتدادات'], max_plot_coverage_pct: ['Max coverage (%)', 'نسبة التغطية القصوى (%)'], building_type: ['Building type', 'نوع المبنى'],
};
const label = (k: string, L: Lang) => FACT_LABEL[k]?.[L === 'ar' ? 1 : 0] ?? (k.startsWith('space_') ? (L === 'ar' ? `فراغ: ${k.slice(6).replace(/_/g, ' ')}` : `Space: ${k.slice(6).replace(/_/g, ' ')}`) : k.replace(/_/g, ' '));

/** Build a client presentation from the project's real data, with a spoken explanation for each slide. */
export function buildDeck(db: DB, orgId: string, project: any, drawing: DrawingRow | null, L: Lang, preparedBy: string, orgName: string): Slide[] {
  const ar = L === 'ar';
  const t = (en: string, a: string) => (ar ? a : en);
  const facts = all(db, 'SELECT key, value, unit, class, source FROM project_facts WHERE project_id = ? ORDER BY key', project.id);
  const confirmed = facts.filter((f) => f.class === 'confirmed' && f.key !== 'floor_heights');
  const suggested = facts.filter((f) => f.class === 'ai_suggestion' || f.class === 'assumption');
  const entities = drawing ? loadEntities(db, drawing.id) : [];
  const rooms = drawing ? extractRooms(entities, drawing.units).filter((r) => r.valid) : [];
  const doors = entities.filter((e) => e.type === 'DOOR').length, windows = entities.filter((e) => e.type === 'WINDOW').length;
  const mpu = drawing ? metresPerUnit(drawing.units) : null;
  const plots = drawing ? closedOnLayer(entities, PLOT_LAYER) : [];
  const plotArea = plots.length === 1 && mpu ? polygonArea(plots[0].geom.points) * mpu * mpu : null;
  const total = rooms.reduce((s, r) => s + (r.areaM2 ?? 0), 0);
  const coverage = plotArea ? (total / plotArea) * 100 : null;
  const fh = facts.find((f) => f.key === 'floor_heights');
  const heights = fh ? JSON.parse(fh.value) : null;
  const findings = drawing ? evaluateRules(db, orgId, drawing) : [];
  const count = (s: string) => findings.filter((f) => f.status === s).length;
  const issues = findings.filter((f) => f.status === 'FAIL' || f.status === 'WARNING');
  const confirmedKeys = new Set(confirmed.map((f) => f.key));
  const missing = CRITICAL_INPUTS.filter((c) => !confirmedKeys.has(c.key));
  const openComments = get<any>(db, "SELECT COUNT(*) AS n FROM review_comments WHERE project_id = ? AND status IN ('open','in_progress')", project.id)?.n ?? 0;
  const pkg = get<any>(db, 'SELECT status FROM submission_packages WHERE project_id = ? ORDER BY created_at DESC LIMIT 1', project.id);
  const biggest = [...rooms].sort((a, b) => (b.areaM2 ?? 0) - (a.areaM2 ?? 0))[0];
  const date = new Date().toISOString().slice(0, 10);

  const slides: Slide[] = [];
  slides.push({
    kind: 'cover', title: project.name, subtitle: `${project.code} · ${project.project_type || t('Project', 'مشروع')} · ${date}`,
    bullets: [t(`Prepared by ${preparedBy} — ${orgName}`, `إعداد: ${preparedBy} — ${orgName}`), t('Preliminary design presentation', 'عرض تصميم مبدئي')],
    notes: t(`Open by thanking the client and stating the purpose: to walk through the preliminary design of ${project.name}, show what has been decided, and agree the next decisions. Mention this is a preliminary stage — nothing here is approved by the authority yet.`,
      `ابدأ بشكر العميل ووضّح هدف الاجتماع: استعراض التصميم المبدئي لمشروع ${project.name}، وما تم الاتفاق عليه، والقرارات المطلوبة للمرحلة القادمة. نبّه أن هذه مرحلة مبدئية ولم يُعتمد شيء من البلدية بعد.`),
  });
  slides.push({
    kind: 'brief', title: t('Project brief', 'وصف المشروع'),
    bullets: [project.description || t('No description recorded yet.', 'لم يُسجَّل وصف للمشروع بعد.'),
      ...confirmed.filter((f) => !['plot_id', 'plot_area_m2', 'setbacks', 'max_plot_coverage_pct'].includes(f.key)).slice(0, 6).map((f) => `${label(f.key, L)}: ${f.value}${f.unit ? ' ' + f.unit : ''}`),
      ...suggested.slice(0, 4).map((f) => `${label(f.key, L)}: ${f.value} ${t('(to confirm)', '(للتأكيد)')}`)],
    notes: t(`Read the brief back to the client in your own words and check it is still right. Items marked "to confirm" were extracted from the description and still need the client's confirmation — ask about each one.`,
      `أعِد صياغة وصف المشروع للعميل بكلماتك وتأكد أنه ما زال صحيحاً. البنود المكتوب بجانبها "للتأكيد" استُخرجت من الوصف وتحتاج موافقة العميل — اسأله عنها واحداً واحداً.`),
  });
  const plotFacts = ['plot_id', 'plot_area_m2', 'setbacks', 'max_plot_coverage_pct'].map((k) => { const f = facts.find((x) => x.key === k); return `${label(k, L)}: ${f ? `${f.value}${f.unit ? ' ' + f.unit : ''}${f.class !== 'confirmed' ? t(' (unconfirmed)', ' (غير مؤكد)') : ''}` : t('missing', 'غير متوفر')}`; });
  slides.push({
    kind: 'site', title: t('Site & plot', 'الموقع والقطعة'),
    bullets: [...plotFacts, ...(plotArea ? [t(`Plot area measured on the drawing: ${plotArea.toFixed(1)} m²`, `مساحة القطعة من الرسم: ${plotArea.toFixed(1)} م²`)] : [])],
    svg: drawing && plots.length ? planSvg(entities, drawing.units, { width: 1200, height: 900 }) : undefined,
    notes: t(`Show where the building sits on the plot. Explain that the setbacks and coverage must come from the plot's official planning document; anything shown as missing or unconfirmed must be provided before the design can be finalised.`,
      `وضّح موقع المبنى داخل القطعة. اشرح أن الارتدادات ونسبة التغطية تُؤخذ من وثيقة التخطيط الرسمية للقطعة، وأن أي بند ظاهر كـ"غير متوفر" أو "غير مؤكد" يجب توفيره قبل اعتماد التصميم.`),
  });
  if (drawing) slides.push({
    kind: 'plan', title: t('Ground floor plan', 'مسقط الدور الأرضي'),
    bullets: [t(`${rooms.length} rooms · ${doors} doors · ${windows} windows`, `${rooms.length} غرف · ${doors} أبواب · ${windows} نوافذ`), ...(biggest ? [t(`Largest space: ${biggest.name} (${biggest.areaM2?.toFixed(1)} m²)`, `أكبر فراغ: ${biggest.name} (${biggest.areaM2?.toFixed(1)} م²)`)] : [])],
    svg: planSvg(entities, drawing.units, { showPlot: false }),
    notes: t(`Walk the client through the plan as if entering the house: start at the entrance, then the reception spaces${biggest ? ` (the largest is ${biggest.name})` : ''}, then the service and private areas. Ask how they will use each room day to day and note any change they want — every change can be made in NOVA and is tracked.`,
      `امشِ مع العميل في المسقط كأنكم تدخلون البيت: ابدأ من المدخل، ثم فراغات الاستقبال${biggest ? ` (أكبرها ${biggest.name})` : ''}، ثم الخدمات والمناطق الخاصة. اسأله كيف سيستخدم كل غرفة يومياً وسجّل أي تعديل يريده — كل تعديل يُنفَّذ في NOVA ويُوثَّق.`),
  });
  if (rooms.length) slides.push({
    kind: 'areas', title: t('Area schedule', 'جدول المساحات'),
    bullets: [t(`Total room area: ${total.toFixed(1)} m²`, `إجمالي مساحة الغرف: ${total.toFixed(1)} م²`), ...(coverage !== null ? [t(`Plot coverage: ${coverage.toFixed(1)}%`, `نسبة التغطية: ${coverage.toFixed(1)}%`)] : [])],
    table: { head: [t('Room', 'الغرفة'), t('Area (m²)', 'المساحة (م²)')], rows: rooms.map((r) => [r.name ?? '—', (r.areaM2 ?? 0).toFixed(1)]) },
    notes: t(`Areas are measured to wall centrelines, so finished room sizes will be slightly smaller. Compare the total with the client's budget and target area${coverage !== null ? `; the current coverage is ${coverage.toFixed(1)}% of the plot` : ''}.`,
      `المساحات مقاسة إلى محاور الجدران، لذلك ستكون المساحات الصافية أصغر قليلاً. قارن الإجمالي مع ميزانية العميل والمساحة المستهدفة${coverage !== null ? `؛ نسبة التغطية الحالية ${coverage.toFixed(1)}% من القطعة` : ''}.`),
  });
  if (heights) {
    const h = heights.floors.reduce((s: number, f: any) => s + f.height_m, 0) + heights.plinth_m + heights.parapet_m;
    slides.push({
      kind: 'heights', title: t('Heights & massing', 'الارتفاعات والكتلة'),
      bullets: [t(`Total height to top of parapet: ${h.toFixed(2)} m`, `الارتفاع الكلي حتى أعلى الدروة: ${h.toFixed(2)} م`), t(`Source of heights: ${fh!.source}`, `مصدر الارتفاعات: ${fh!.source}`)],
      table: { head: [t('Floor', 'الدور'), t('Floor-to-floor (m)', 'الارتفاع (م)')], rows: heights.floors.map((f: any) => [f.name, f.height_m.toFixed(2)]) },
      notes: t('Explain the floor heights and total height. Upper floors are shown as massing only until their plans are designed. The elevations and section sheet (PDF) can be shown alongside this slide.',
        'اشرح ارتفاعات الأدوار والارتفاع الكلي. الأدوار العليا معروضة ككتلة فقط حتى يتم تصميم مساقطها. يمكن عرض لوحة الواجهات والمقطع (PDF) بجانب هذه الشريحة.'),
    });
  }
  if (drawing) slides.push({
    kind: 'checks', title: t('Design checks', 'الفحوصات'),
    bullets: [t(`${count('PASS')} checks passed · ${count('FAIL')} failed · ${count('WARNING')} warnings`, `${count('PASS')} فحص ناجح · ${count('FAIL')} راسب · ${count('WARNING')} تحذير`),
      ...issues.slice(0, 4).map((f) => `${f.rule_code}: ${f.message}`),
      t('Authority regulations are not yet assessed: they need verified official sources.', 'اشتراطات البلدية لم تُقيَّم بعد: تحتاج مصادر رسمية موثقة.')],
    notes: t('Be transparent: these are NOVA drawing checks, not an authority approval. Explain any failing item and how it will be fixed. Regulatory compliance will be confirmed by the licensed engineer against the official requirements.',
      'كن واضحاً: هذه فحوصات NOVA على الرسم وليست موافقة البلدية. اشرح أي بند راسب وكيف سيُعالج. التوافق مع الاشتراطات يؤكده المهندس المرخّص وفق المتطلبات الرسمية.'),
  });
  slides.push({
    kind: 'next', title: t('Decisions & next steps', 'القرارات والخطوات التالية'),
    bullets: [...missing.slice(0, 5).map((m) => t(`Provide: ${m.label}`, `توفير: ${m.label_ar}`)),
      ...(openComments ? [t(`${openComments} open review comment(s) to close`, `${openComments} ملاحظات مراجعة مفتوحة`)] : []),
      t(`Municipality submission: ${pkg ? pkg.status.replace(/_/g, ' ') : 'not started'}`, `التقديم للبلدية: ${pkg ? pkg.status : 'لم يبدأ'}`)],
    notes: t('End with clear actions: list what you need from the client (documents, confirmations) and what your team will deliver next, with dates. Confirm the decisions taken in this meeting in writing afterwards.',
      'اختم بإجراءات واضحة: ما المطلوب من العميل (وثائق، تأكيدات) وما سيسلّمه فريقك في المرحلة القادمة مع المواعيد. وثّق القرارات المتخذة في الاجتماع كتابياً بعده.'),
  });
  slides.push({
    kind: 'close', title: t('Thank you', 'شكراً لكم'), subtitle: t('Questions & discussion', 'أسئلة ونقاش'), bullets: [`${orgName}`],
    notes: t('Invite questions. Agree the date of the next review meeting.', 'افتح باب الأسئلة واتفق على موعد اجتماع المراجعة القادم.'),
  });
  return slides;
}

/** Render the slides to a .pptx (16:9) with the explanation in each slide's speaker notes. */
export async function deckToPptx(slides: Slide[], L: Lang, projectName: string): Promise<Buffer> {
  // pptxgenjs's default export is the constructor at runtime; its typings describe a namespace under NodeNext.
  const pptx = new (PptxGenJS as unknown as new () => any)();
  pptx.layout = 'LAYOUT_WIDE'; // 13.33 x 7.5 in
  pptx.title = projectName;
  const ar = L === 'ar';
  const font = ar ? 'Arial' : 'Segoe UI';
  const base = { fontFace: font, rtlMode: ar, lang: ar ? 'ar-AE' : 'en-US', align: (ar ? 'right' : 'left') as 'right' | 'left' };
  const NAVY = '0B1222', CYAN = '22D3EE', INK = '0F172A', MUTED = '475569';
  for (const s of slides) {
    const sl = pptx.addSlide();
    if (s.kind === 'cover' || s.kind === 'close') {
      sl.background = { color: NAVY };
      sl.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 13.33, h: 0.08, fill: { color: CYAN } });
      sl.addText(s.title, { ...base, x: 0.8, y: 2.3, w: 11.7, h: 1.3, fontSize: 40, bold: true, color: 'FFFFFF' });
      if (s.subtitle) sl.addText(s.subtitle, { ...base, x: 0.8, y: 3.6, w: 11.7, h: 0.6, fontSize: 20, color: CYAN });
      sl.addText(s.bullets.join('\n'), { ...base, x: 0.8, y: 4.4, w: 11.7, h: 1.2, fontSize: 16, color: 'CBD5E1' });
    } else {
      sl.background = { color: 'FFFFFF' };
      sl.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.33, h: 0.9, fill: { color: NAVY } });
      sl.addText(s.title, { ...base, x: 0.5, y: 0.12, w: 12.3, h: 0.66, fontSize: 26, bold: true, color: 'FFFFFF' });
      const hasVisual = !!(s.svg || s.table);
      const textX = hasVisual ? (ar ? 7.1 : 0.5) : 0.5, textW = hasVisual ? 5.7 : 12.3;
      if (s.bullets.length) sl.addText(s.bullets.map((b) => ({ text: b, options: { bullet: true, breakLine: true } })), { ...base, x: textX, y: 1.2, w: textW, h: 5.6, fontSize: 16, color: INK, valign: 'top', paraSpaceAfter: 8 });
      const vx = ar ? 0.5 : 6.4;
      if (s.svg) sl.addImage({ data: `data:image/svg+xml;base64,${Buffer.from(s.svg).toString('base64')}`, x: vx, y: 1.15, w: 6.4, h: 4.6 * (s.svg.includes('viewBox="0 0 1200 900"') ? 1.17 : 1), sizing: { type: 'contain', w: 6.4, h: 5.6 } });
      else if (s.table) {
        const rows = [s.table.head.map((h) => ({ text: h, options: { bold: true, color: 'FFFFFF', fill: { color: '1E293B' } } })), ...s.table.rows.map((r) => r.map((c) => ({ text: c })))];
        sl.addTable(rows as any, { ...base, x: vx, y: 1.2, w: 6.4, fontSize: 13, color: INK, border: { type: 'solid', pt: 0.5, color: 'CBD5E1' }, autoPage: false });
      }
      sl.addText('NOVA Engineering AI · PRELIMINARY', { ...base, x: 0.5, y: 7.05, w: 12.3, h: 0.3, fontSize: 10, color: MUTED });
    }
    sl.addNotes(s.notes);
  }
  const out = await pptx.write({ outputType: 'nodebuffer' });
  return out as Buffer;
}
