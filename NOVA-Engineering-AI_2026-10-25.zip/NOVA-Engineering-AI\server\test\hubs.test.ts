import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../src/app.ts';
import { sampleEntities } from '../scripts/make-sample.ts';
import { exportDxf } from '../src/dxf/dxf.ts';
import { parseRss, wisdomFor, WISDOM } from '../src/routes/home.ts';

let app: FastifyInstance, dir: string, token = '', project = '', drawing = '';
const call = async (method: string, url: string, body?: unknown) => {
  const res = await app.inject({ method: method as any, url, payload: body as any, headers: { authorization: `Bearer ${token}` } });
  let json: any = null; try { json = res.json(); } catch { /* html */ }
  return { status: res.statusCode, json, body: res.body, raw: res.rawPayload };
};

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'nova-hubs-'));
  ({ app } = await buildApp({ dbPath: ':memory:', storageDir: join(dir, 's'), acadJobsDir: join(dir, 'j') }));
  token = (await app.inject({ method: 'POST', url: '/api/auth/register', payload: { orgName: 'Hub Co', name: 'H', email: 'h@example.test', password: 'long-enough-pass' } })).json().token;
  const ref = (await call('POST', '/api/projects', { code: 'REF', name: 'Ref' })).json.id;
  const b = '----h' + Math.random().toString(16).slice(2);
  const payload = Buffer.concat([Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="file"; filename="r.dxf"\r\n\r\n`), Buffer.from(exportDxf(sampleEntities(), [], 'mm')), Buffer.from(`\r\n--${b}--\r\n`)]);
  const refDrawing = (await app.inject({ method: 'POST', url: `/api/projects/${ref}/documents`, payload, headers: { 'content-type': `multipart/form-data; boundary=${b}`, authorization: `Bearer ${token}` } })).json().drawingId;
  project = (await call('POST', '/api/projects', { code: 'VILLA-7', name: 'فيلا العميل', description: 'Two-storey villa with majlis', project_type: 'residential_villa' })).json.id;
  drawing = (await call('POST', `/api/projects/${project}/generate-from-reference`, { referenceDrawingId: refDrawing, plot: { width_m: 30, depth_m: 26, source: 'test plot' }, setback_m: 3, setback_source: 'test' })).json.drawingId;
});
after(async () => { await app.close(); rmSync(dir, { recursive: true, force: true }); });

test('daily wisdom is stable within a day and changes the next day', () => {
  const a = wisdomFor(new Date('2026-10-25T05:00:00Z')), b = wisdomFor(new Date('2026-10-25T18:00:00Z')), c = wisdomFor(new Date('2026-10-26T05:00:00Z'));
  assert.equal(a.ar, b.ar);
  assert.notEqual(a.ar, c.ar);
  assert.ok(WISDOM.length >= 30);
});

test('AI hero: 4 distinct architecture themes per day, stable within a day, different next day and per variant', async () => {
  const { heroForDay } = await import('../src/routes/home.ts');
  const a = heroForDay(20000), b = heroForDay(20000), c = heroForDay(20001), v = heroForDay(20000, 1);
  assert.equal(a.length, 4);
  assert.equal(new Set(a.map((x) => x.prompt)).size, 4);
  assert.deepEqual(a, b);
  assert.notDeepEqual(a.map((x) => x.prompt), c.map((x) => x.prompt));
  assert.notDeepEqual(a.map((x) => x.seed), v.map((x) => x.seed));
  const meta = await call('GET', '/api/home/hero');
  assert.equal(meta.json.images.length, 4);
  assert.ok(meta.json.images.every((x: any) => x.ar && x.en && typeof x.ready === 'boolean'));
  assert.equal((await call('GET', '/api/home/hero/9/image')).status, 404);
});

test('news RSS parsing keeps title, link, date and source; strips the source suffix', () => {
  const xml = `<rss><channel><item><title>بلدية أبوظبي تعزز المظهر الحضاري - وام</title><link>https://example.test/a</link><pubDate>Wed, 21 Oct 2026 16:06:58 GMT</pubDate><source url="https://wam.ae">وام</source></item>
  <item><title>Older</title><link>https://example.test/b</link><pubDate>Tue, 13 Oct 2026 10:00:00 GMT</pubDate><source url="x">X</source></item>
  <item><title>bad link</title><link>javascript:alert(1)</link><pubDate>Tue, 13 Oct 2026 10:00:00 GMT</pubDate></item></channel></rss>`;
  const items = parseRss(xml);
  assert.equal(items.length, 2);
  assert.equal(items[0].title, 'بلدية أبوظبي تعزز المظهر الحضاري');
  assert.equal(items[0].source, 'وام');
  assert.ok(items[0].date > items[1].date);
});

test('municipality letter pasted → numbered comments; closing needs a response; evidence = operations made', async () => {
  const r = await call('POST', `/api/projects/${project}/comments`, { source: 'municipality', drawing_id: drawing, text: '1- تعديل موقع باب المجلس\n٢. إضافة نافذة للمطبخ\n\n3) Provide parking layout', reference_prefix: 'DMT-' });
  assert.equal(r.status, 200, r.body);
  assert.equal(r.json.added, 3);
  const c1 = r.json.comments.find((c: any) => c.reference === 'DMT-1');
  assert.equal(c1.text, 'تعديل موقع باب المجلس');
  assert.ok(r.json.comments.some((c: any) => c.reference === 'DMT-٢'));
  assert.equal((await call('PATCH', `/api/comments/${c1.id}`, { status: 'resolved' })).status, 422);
  // make an edit on the drawing, then close the comment
  const d = (await call('GET', `/api/drawings/${drawing}`)).json;
  const door = d.entities.find((e: any) => e.type === 'DOOR');
  assert.equal((await call('POST', `/api/drawings/${drawing}/operations`, { op: { kind: 'set_opening', id: door.id, width: door.geom.width } })).status, 200);
  const closed = await call('PATCH', `/api/comments/${c1.id}`, { status: 'resolved', response: 'تم تعديل موقع الباب حسب الملاحظة' });
  assert.equal(closed.json.status, 'resolved');
  assert.equal(closed.json.operations.length, 1);
  assert.equal(closed.json.operations[0].kind, 'set_opening');
  assert.equal((await call('DELETE', `/api/comments/${c1.id}`)).status, 409);
  const sheet = await call('GET', `/api/projects/${project}/comments/response-sheet`);
  assert.match(sheet.body, /تم تعديل موقع الباب/);
  assert.match(sheet.body, /#\d+ set_opening/);
});

test('NOVA check findings become tracked comments without duplicates', async () => {
  const a = await call('POST', `/api/drawings/${drawing}/comments-from-checks`);
  const b = await call('POST', `/api/drawings/${drawing}/comments-from-checks`);
  assert.equal(b.json.added, 0);
  assert.ok(a.json.comments.every((c: any) => c.source !== 'nova_check' || c.finding_rule));
});

test('design journey reflects the real project state', async () => {
  const j = (await call('GET', `/api/projects/${project}/journey`)).json;
  const st = Object.fromEntries(j.steps.map((s: any) => [s.key, s.status]));
  assert.equal(st.plan, 'done');
  assert.equal(st.brief, 'partial');
  assert.equal(st.submission, 'todo');
  assert.equal(st.shop, 'unavailable');
  assert.equal(st.checks, 'done'); // the generator ran checks with no FAIL
  assert.equal(j.openComments, 2 + (await call('GET', `/api/projects/${project}/comments`)).json.filter((c: any) => c.source === 'nova_check' && c.status === 'open').length);
});

test('client presentation: slides with explanation in Arabic, stored as a real .pptx', async () => {
  await call('PUT', `/api/projects/${project}/facts`, { key: 'floors', value: '2', class: 'confirmed', source: 'client meeting' });
  const r = await call('POST', `/api/projects/${project}/presentation`, { lang: 'ar' });
  assert.equal(r.status, 200, r.body);
  const kinds = r.json.slides.map((s: any) => s.kind);
  assert.deepEqual(kinds.slice(0, 5), ['cover', 'brief', 'site', 'plan', 'areas']);
  assert.ok(r.json.slides.every((s: any) => s.notes.length > 40));
  assert.match(r.json.slides.find((s: any) => s.kind === 'plan').svg, /^<svg/);
  assert.match(r.json.slides[1].bullets.join(' '), /عدد الأدوار: 2/);
  const file = await call('GET', `/api/documents/${r.json.document.id}/download`);
  assert.equal(file.raw.subarray(0, 2).toString('latin1'), 'PK');
  assert.ok(file.raw.includes(Buffer.from('ppt/notesSlides/notesSlide1.xml')));
  const en = await call('POST', `/api/projects/${project}/presentation`, { lang: 'en' });
  assert.equal(en.json.slides[0].title, 'فيلا العميل');
  assert.match(en.json.slides[1].title, /Project brief/);
});
